package com.xiyou.businessplatform.alipay;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ChoiceFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.adapter.PayWayAdapter;
import com.xiyou.businessplatform.entity.PayEntity;
import com.xiyou.businessplatform.entity.PayWayBean;
import com.xiyou.businessplatform.entity.StringMap;
import com.xiyou.businessplatform.http.BaseRequestPacket;
import com.xiyou.businessplatform.http.ClientEngine;
import com.xiyou.businessplatform.http.IRequestContentCallback;
import com.xiyou.businessplatform.http.IToStringMap;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.JsonParse;
import com.xiyou.businessplatform.util.LocalSharePreference;
import com.xiyou.businessplatform.view.center.LoginActivity;

@SuppressLint("ShowToast")
public class PayActivity extends FragmentActivity implements
		IRequestContentCallback, IToStringMap, Constants {
	public static final String PARTNER = "2088711270630216";
	public static final String SELLER = "xiyoudream@163.com";
	public static final String RSA_PRIVATE = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJmdeTuF/PmcSZLQZlKf8njbgiZmDxG0fYdO2QZ5K/KIRy25S+qGL0kY83GA0vnn1sK1CMiGRZZPN/PbsS+8vQ+EjkSNHFKjHMYgyKlqWp2VqwUMrIK2Ztn69tUK8Pw6udLWFo6GZx9U16hWW45r/SSOKohfszRugSj+C+oi+5jZAgMBAAECgYAghRfPJBRj+1QQApJG15mLQF0TJ/P0uZMBfA2xsyE8nOEEqv+JTJLiFKgk1TLUuOHcIlsTqGk+4tJji5S9GGWleWChy32BRT3o/vYX3KGSOHvMjOyLz7prbNUB3bI+NZ8hmTo1UPZkmGCCTxQZW7HDKY7YQKQjIqlagBV1IZWPIQJBAMhvpIBZxo5OSZUY+FnpWcMyPcULXZTqHjlrPjo82R2//rj6rj/8/sjITtUGMrwkaWsFzSzF5Tio8Jv4rS4lJJUCQQDEMxXFGyzuHCCQ3p4n/1PysDBB0LywTLzNmtFB6/lXQj9sMmCRL8D9VWFDN5sXTbMRZIp+53uXL+sngo3Bh241AkEAilU7FHZhai+v6x4rsWoy0Fwpc4gPk0oth/VzIiCCvFyZAbPJdVI3yf0tIyq+80iyFPIRE/iU5hD61rq/U1zBLQJAaLhrkj0jCiRxLWHlQKwDfrGT0E09qUwMKiHMN0dgWra9a16oNFYsyAreUyZG3XVXcp0bXwjm6pdlCD2is/05UQJAFd7ChwPg4iZk/b6MkQg3MhWX5gbIE9pdFh+FLIhKIF3t0vasg95wI5aO8hDBS/1uqsz7cQFE2xxmILjiZtzcPA==";
	public static final String RSA_PUBLIC = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB";
	private static final int SDK_PAY_FLAG = 1;
	private static final int SDK_CHECK_FLAG = 2;
	private static final int BACK_TO_SERVER = 3;
	private static final int IS_LOGIN_FOR_PAY = 4;
	private boolean is_login = false;
	private String out_trade_no = null;
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SDK_PAY_FLAG: {
				Result resultObj = new Result((String) msg.obj);
				String resultStatus = resultObj.resultStatus;
				String result = resultObj.result;
				String s = resultObj.memo;
				Log.e("PayDemoActivity", resultStatus + "=====" + result
						+ "======" + s);
				// 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
				if (TextUtils.equals(resultStatus, "9000")) {
					// 发送信息到服务器
					ClientEngine client = ClientEngine
							.getInstance(PayActivity.this);
					BaseRequestPacket packet = new BaseRequestPacket();
					packet.action = BACK_TO_SERVER;
					packet.object = PayActivity.this;
					packet.url = BACK_TO_SERVER_URL;
					client.httpPostRequest(packet, PayActivity.this);
				} else {
					// 判断resultStatus 为非“9000”则代表可能支付失败
					// “8000”
					// 代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
					if (TextUtils.equals(resultStatus, "8000")) {
						Toast.makeText(PayActivity.this, "支付结果确认中",
								Toast.LENGTH_SHORT).show();

					} else {
						Toast.makeText(PayActivity.this, "支付失败",
								Toast.LENGTH_SHORT).show();
					}
				}
				break;
			}
			case SDK_CHECK_FLAG: {
				Toast.makeText(PayActivity.this, "检查结果为：" + msg.obj,
						Toast.LENGTH_SHORT).show();
				break;
			}
			default:
				break;
			}
		};
	};
	private TextView product_name, product_info, product_price;
	private ListView lv;
	private PayEntity payBean;
	private PayWayAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_main);
		Intent intent = getIntent();
		if (intent.hasExtra("paybean")) {
			payBean = intent.getParcelableExtra("paybean");
		}
		this.product_name = (TextView) this.findViewById(R.id.product_subject);
		this.product_info = (TextView) this.findViewById(R.id.product_info);
		this.product_price = (TextView) this.findViewById(R.id.product_price);
		this.lv = (ListView) this.findViewById(R.id.pay_way_lv);
		initView();
	}
	private void initView() {
		PayWayBean payWayBean = new PayWayBean(R.drawable.zhifubao, "支付宝支付",
				"推荐有支付宝账号的用户使用");
		List<PayWayBean> list = new ArrayList<PayWayBean>();
		list.add(payWayBean);
		adapter = new PayWayAdapter(list, this);
		this.lv.setAdapter(adapter);
		this.lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		if (payBean != null) {
			this.product_name.setText(payBean.getPay_userName());
			this.product_info.setText(payBean.getPay_info());
			this.product_price.setText(payBean.getPay_price() + "元");
		}
	}
	/**
	 * call alipay sdk pay. 调用SDK支付
	 * 
	 */
	public void pay(View v) {
		if (!is_login)
			checkLogin();
		else
			selectPayWay();
	}
	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) {
		if (arg0 == 666 && arg1 == 668) {
			is_login = true;
		}
	}
	private void checkLogin() {
		if (LocalSharePreference.getUserID(this).equals("")) {
			toLoginActivity();
		} else {
			// 发送信息到服务器
			ClientEngine client = ClientEngine.getInstance(PayActivity.this);
			BaseRequestPacket packet = new BaseRequestPacket();
			packet.action = IS_LOGIN_FOR_PAY;
			Map<String, String> map = new HashMap<String, String>();
			map.put("authNum", LocalSharePreference.getUserID(this));
			StringMap sm = new StringMap(map);
			packet.object = sm;
			packet.url = VALIDATE_IS_LOGIN;
			client.httpGetRequest(packet, PayActivity.this);
		}
	}
	public void back(View v) {
		this.finish();
	}
	private void payByAlipay() {
		String orderInfo = null;
		if (payBean == null)
			return;
		else
			orderInfo = getOrderInfo(payBean.getPay_userName(),
					payBean.getPay_info(), payBean.getPay_price(),
					payBean.getPay_sn());
		String sign = sign(orderInfo);
		try {
			// 仅需对sign 做URL编码
			sign = URLEncoder.encode(sign, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		final String payInfo = orderInfo + "&sign=\"" + sign + "\"&"
				+ getSignType();
		Log.e("PayDemoActivity", payInfo);
		Runnable payRunnable = new Runnable() {

			@Override
			public void run() {
				// 构造PayTask 对象
				PayTask alipay = new PayTask(PayActivity.this);
				// 调用支付接口
				String result = alipay.pay(payInfo);

				Message msg = new Message();
				msg.what = SDK_PAY_FLAG;
				msg.obj = result;
				mHandler.sendMessage(msg);
			}
		};

		Thread payThread = new Thread(payRunnable);
		payThread.start();
	}

	/**
	 * check whether the device has authentication alipay account.
	 * 查询终端设备是否存在支付宝认证账户
	 */
	public void check() {
		Runnable checkRunnable = new Runnable() {

			@Override
			public void run() {
				PayTask payTask = new PayTask(PayActivity.this);
				boolean isExist = payTask.checkAccountIfExist();

				Message msg = new Message();
				msg.what = SDK_CHECK_FLAG;
				msg.obj = isExist;
				mHandler.sendMessage(msg);
			}
		};

		Thread checkThread = new Thread(checkRunnable);
		checkThread.start();

	}

	/**
	 * get the sdk version. 获取SDK版本号
	 * 
	 */
	public void getSDKVersion() {
		PayTask payTask = new PayTask(this);
		String version = payTask.getVersion();
		Toast.makeText(this, version, Toast.LENGTH_SHORT).show();
	}

	/**
	 * create the order info. 创建订单信息
	 * 
	 */
	public String getOrderInfo(String subject, String body, String price,String sn) {
		Log.e("sn============", sn+",,,,,,,,");
		// 合作者身份ID
		String orderInfo = "partner=" + "\"" + PARTNER + "\"";

		// 卖家支付宝账号
		orderInfo += "&seller_id=" + "\"" + SELLER + "\"";

		// 商户网站唯一订单号
		out_trade_no = sn;
		orderInfo += "&out_trade_no=" + "\"" + sn + "\"";

		// 商品名称
		orderInfo += "&subject=" + "\"" + subject + "\"";

		// 商品详情
		orderInfo += "&body=" + "\"" + body + "\"";

		// 商品金额
		orderInfo += "&total_fee=" + "\"" + price + "\"";

		// 服务器异步通知页面路径
		orderInfo += "&notify_url=" + "\"" + "http://notify.msp.hk/notify.htm"
				+ "\"";

		// 接口名称， 固定值
		orderInfo += "&service=\"mobile.securitypay.pay\"";

		// 支付类型， 固定值
		orderInfo += "&payment_type=\"1\"";

		// 参数编码， 固定值
		orderInfo += "&_input_charset=\"utf-8\"";
		// 设置未付款交易的超时时间
		// 默认30分钟，一旦超时，该笔交易就会自动被关闭。
		// 取值范围：1m～15d。
		// m-分钟，h-小时，d-天，1c-当天（无论交易何时创建，都在0点关闭）。
		// 该参数数值不接受小数点，如1.5h，可转换为90m。
		orderInfo += "&it_b_pay=\"30m\"";

		// 支付宝处理完请求后，当前页面跳转到商户指定页面的路径，可空
		orderInfo += "&return_url=\"m.alipay.com\"";
		// 调用银行卡支付，需配置此参数，参与签名， 固定值
		// orderInfo += "&paymethod=\"expressGateway\"";
		return orderInfo;
	}
	/**
	 * get the out_trade_no for an order. 获取外部订单号
	 * 
	 */
	public String getOutTradeNo() {
		SimpleDateFormat format = new SimpleDateFormat("MMddHHmmss",
				Locale.getDefault());
		Date date = new Date();
		String key = format.format(date);

		Random r = new Random();
		key = key + r.nextInt();
		key = key.substring(0, 15);
		return key;
	}
	/**
	 * sign the order info. 对订单信息进行签名
	 * 
	 * @param content
	 *            待签名订单信息
	 */
	public String sign(String content) {
		return SignUtils.sign(content, RSA_PRIVATE);
	}
	/**
	 * get the sign type we use. 获取签名方式
	 * 
	 */
	public String getSignType() {
		return "sign_type=\"RSA\"";
	}
	@Override
	public void onResult(int requestAction, Boolean isSuccess, String content,
			Object extra) {
		Log.e("PayActivity", content);
		switch (requestAction) {
		case BACK_TO_SERVER:
			if (isSuccess) {
				try {
					Map<String, Object> map = JsonParse
							.parseBaskToServer(content);
					Log.e("Oay", map.toString());
					if (map.containsKey(IS_SUCCESS)) {
						int success = (Integer) map.get(IS_SUCCESS);
						if (success == 1) {
							Toast.makeText(PayActivity.this, "充值成功",
									Toast.LENGTH_SHORT).show();
							PayActivity.this.finish();
						} else {
							Toast.makeText(PayActivity.this,
									(String) map.get(ERROR), Toast.LENGTH_LONG).show();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			break;
		case IS_LOGIN_FOR_PAY:
			if (isSuccess) {
				try {
					String islogin = JsonParse.parseIsLogin(content);
					if (islogin != null) {// 已经登陆
						if (Integer.parseInt(islogin) == 1)
							selectPayWay();
						else
							toLoginActivity();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			break;
		default:
			break;
		}
	}
	private void toLoginActivity() {
		Intent intenx = new Intent();
		intenx.setClass(this, LoginActivity.class);
		intenx.putExtra("mark", Constants.PAY);
		startActivityForResult(intenx, 666);
	}
	private void selectPayWay() {
		int pos = this.adapter.getPosion();
		switch (pos) {
		case 0:
			payByAlipay();
			break;
		default:
			break;
		}
	}
	@Override
	public Map<String, String> toStringMap() {
		Map<String, String> map = new HashMap<String, String>();
		if (payBean != null) {
			map.put("sn", payBean.getPay_mark());
			map.put(USER_IDEN, LocalSharePreference.getUserID(this));
			map.put(OUT_ID, payBean.getPay_sn());
		} 
		return map;
	}
}

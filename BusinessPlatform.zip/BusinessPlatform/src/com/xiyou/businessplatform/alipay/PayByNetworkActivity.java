package com.xiyou.businessplatform.alipay;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.adapter.PayWaySelectAdapter;
import com.xiyou.businessplatform.entity.PayEntity;
import com.xiyou.businessplatform.entity.PayWaySelectBean;
import com.xiyou.businessplatform.service.LoginService;
import com.xiyou.businessplatform.util.ToastUtils;
import com.xiyou.businessplatform.view.center.BaseActivity;
import com.xiyou.businessplatform.view.center.LoginActivity;
import com.xiyou.businessplatform.view.customer.MyGridView;

public class PayByNetworkActivity extends BaseActivity implements
		OnItemClickListener {
	@ViewInject(R.id.kuaijie_gd_select)
	private MyGridView gd1;
	@ViewInject(R.id.card_gd_select)
	private MyGridView gd2;
	@ViewInject(R.id.bank_card_gd_select)
	private MyGridView gd3;
	private PayWaySelectAdapter adapter1, adapter2, adapter3;
	private PayEntity mEntity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_paybynet_activity);
		ViewUtils.inject(this);
		Intent intent = getIntent();
		if (intent.hasExtra("paybean")) {
			mEntity = intent.getParcelableExtra("paybean");
		}
		initData();
	}

	private void initData() {
		List<PayWaySelectBean> li1 = new ArrayList<PayWaySelectBean>();
		PayWaySelectBean pay1 = new PayWaySelectBean(R.drawable.zhifubao1,
				"支付宝快捷", null);
		PayWaySelectBean pay2 = new PayWaySelectBean(R.drawable.chuxu, "无网银快捷",
				null);
		li1.add(pay1);
		li1.add(pay2);
		List<PayWaySelectBean> li2 = new ArrayList<PayWaySelectBean>();
		PayWaySelectBean pay11 = new PayWaySelectBean(R.drawable.yinlian,
				"银行卡快捷", null);
		PayWaySelectBean pay21 = new PayWaySelectBean(R.drawable.xinyongka,
				"信用卡快捷", null);
		li2.add(pay11);
		li2.add(pay21);
		List<PayWaySelectBean> li3 = new ArrayList<PayWaySelectBean>();
		PayWaySelectBean pay_1 = new PayWaySelectBean(R.drawable.zhongguo,
				"中国银行", null);
		PayWaySelectBean pay_2 = new PayWaySelectBean(
				R.drawable.jianshe, "中国建设银行", null);
		PayWaySelectBean pay_3 = new PayWaySelectBean(R.drawable.zhaoshang,
				"招商银行", null);
		PayWaySelectBean pay_4 = new PayWaySelectBean(R.drawable.pufa,
				"浦东发展银行", null);
		PayWaySelectBean pay_5 = new PayWaySelectBean(R.drawable.youzheng,
				"邮政储蓄", null);
		PayWaySelectBean pay_6 = new PayWaySelectBean(R.drawable.gongshang,
				"中国工商银行", null);
		li3.add(pay_1);
		li3.add(pay_2);
		li3.add(pay_3);
		li3.add(pay_4);
		li3.add(pay_5);
		li3.add(pay_6);
		adapter1 = new PayWaySelectAdapter(li1, this);
		adapter2 = new PayWaySelectAdapter(li2, this);
		adapter3 = new PayWaySelectAdapter(li3, this);
		gd1.setAdapter(adapter1);
		gd2.setAdapter(adapter2);
		gd3.setAdapter(adapter3);
		gd1.setOnItemClickListener(this);
		gd2.setOnItemClickListener(this);
		gd3.setOnItemClickListener(this);
	}

	public void back(View v) {
		if (v.getId() == R.id.paybynet_imagebutton_back)
			this.finish();
	}

	private static final int REQUEST_LOGIN = 345;

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Intent intent = null;
		// 验证登录
		if (!LoginService.isLogin()) {
			intent = new Intent(this, LoginActivity.class);
			startActivityForResult(intent, REQUEST_LOGIN);
		} else {
			int parent_id = parent.getId();
			switch (parent_id) {
			case R.id.kuaijie_gd_select:
				switch (position) {
				case 0:// 跳到支付宝充值

					intent = new Intent(this, PayByZhifubaoActivity.class);
					if (mEntity != null)
						intent.putExtra("paybean", mEntity);
					startActivity(intent);
					PayByNetworkActivity.this.finish();
					break;
				case 1:// 无网银快捷
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 2:
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;

				default:
					break;
				}
				break;
			case R.id.card_gd_select:
				switch (position) {
				case 0:// 银行卡快捷
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 1:// 信用卡快捷
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 2:
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;

				default:
					break;
				}
				break;
			case R.id.bank_card_gd_select:
				switch (position) {
				case 0:// 中国银行
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 1:// 建设银行
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 2:// 招商银行
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 3:// 浦发银行
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 4:// 邮政储蓄
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;
				case 5:// 招商银行
					ToastUtils.getInstance().showToast("目前只支持支付宝支付", 0);
					break;

				default:
					break;
				}
				break;

			default:
				break;
			}
		}
	}
}

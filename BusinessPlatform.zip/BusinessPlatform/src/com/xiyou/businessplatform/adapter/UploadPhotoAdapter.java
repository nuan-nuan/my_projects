package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.util.ImgUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class UploadPhotoAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<Bitmap> task = new ArrayList<Bitmap>();
	private List<String> photos = new ArrayList<String>();
	private Integer selected_id;
	private ImageLoader mImageLoader;

	public Integer getSelectedPosition() {
		return selected_id;
	}

	public UploadPhotoAdapter(Context context, ArrayList<Bitmap> list,
			List<String> strs) {
		this.context = context;
		if (list != null && !list.isEmpty()) {
			this.task.clear();
			this.task.addAll(list);
		}
		if (strs != null && !strs.isEmpty()) {
			this.photos.clear();
			this.photos.addAll(strs);
		}
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
	}

	@Override
	public int getCount() {
		if (!task.isEmpty())
			return task.size();
		else if (!photos.isEmpty())
			return photos.size();
		else
			return 0;
	}

	@Override
	public Object getItem(int position) {
		if (!task.isEmpty())
			return task.get(position);
		else if (!photos.isEmpty())
			return photos.size();
		else
			return 0;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView,
			final ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.upload_photo_item, null);
		}
		ImageView image = (ImageView) convertView
				.findViewById(R.id.upload_photo_item_imageview);
		if (!task.isEmpty()) {
			Bitmap bitmap = task.get(position);
			image.setImageBitmap(bitmap);
		} else if (!photos.isEmpty()) {
			String imgurl = photos.get(position);
			if (mImageLoader != null) {
				ImgUtil.showImage(null, imgurl, image);
			}
		}
		return convertView;
	}
}

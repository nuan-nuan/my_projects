package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.customer.RoundedImageView;
import com.xiyou.businessplatform.view.mainfragment.RewardOrderActivity;

public class DemandRecOrderAdapter extends BaseAdapter implements Constants{
	private List<Task> list=new ArrayList<Task>();
	private Context context;
	private LayoutInflater inflater;
	private int id;
	private ImageLoader imageLoader;
	
	public DemandRecOrderAdapter(Context context,List<Task> list) {
		this.context=context;
		this.inflater=(LayoutInflater)context.getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}
	
	public void reflushAdapter(List<Task> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		if(convertView==null){
			convertView=inflater.inflate(R.layout.demand_receiveorder_item, null);
			holder=new ViewHolder();
			holder.icon=(RoundedImageView)convertView.findViewById(R.id.iv_receive_icon);
			holder.identify=(ImageView)convertView.findViewById(R.id.iv_receive_identify);
			holder.title=(TextView)convertView.findViewById(R.id.tv_receive_name);
			holder.money=(TextView)convertView.findViewById(R.id.tv_receive_count);
			holder.bidders=(TextView)convertView.findViewById(R.id.tv_receive_total);
			holder.publisher=(TextView)convertView.findViewById(R.id.tv_receive_publisher);
			holder.intro=(TextView)convertView.findViewById(R.id.tv_receive_description);
			//holder.receive=(RelativeLayout)convertView.findViewById(R.id.receive);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder)convertView.getTag();
		}
		Task task=list.get(position);
		String imgUrl=task.getAbacus_avatar();
		if(imgUrl!=null&&!"".equals(imgUrl)){
			ImgUtil.showImage(imageLoader, imgUrl,  holder.icon);
		}else{
			holder.icon.setBackgroundResource(R.drawable.default_head);
		}
//		if(task.getIs_company().equals("1")){
//			holder.identify.setBackgroundResource(R.drawable.company_certifucate);
//		}else if(task.getIs_auth().equals("1")){
//			holder.identify.setBackgroundResource(R.drawable.personal_identify);
//		}
		String title=task.getTasktitle();
		if(title!=null&&!"".equals(title)&&!title.equals("null")){
		    holder.title.setText(list.get(position).getTasktitle());
		}else{
			holder.title.setText(NO_NICK);
		}
		String money=task.getPrice();
		if(money!=null&&!money.equals("")&&!money.equals("null")){
		    holder.money.setText(list.get(position).getPrice());
		}else{
			holder.money.setText("0");
		}
		String bidder=task.getNumber();
		if(bidder!=null&&!"".equals(bidder)&&!bidder.equals("null")){
		    holder.bidders.setText(list.get(position).getNumber());
		}else{
			holder.bidders.setText("0");
		}
		String intro=task.getIntroduction();
		if(intro!=null&&!intro.equals("")&&!intro.equals("null")){
		    holder.intro.setText(list.get(position).getIntroduction());
		}else{
			holder.intro.setText(NO_INTRO);
		}
		String publish=task.getName();
		if(publish!=null&&!publish.equals("")&&!publish.equals("null")){
		    holder.publisher.setText(list.get(position).getName());
		}else{
			holder.publisher.setText(NO_CONTENT);
		}
		//id=Integer.parseInt(list.get(position).getId());
		//holder.receive.setId(id);
		//holder.receive.setOnClickListener(new buttonListener(position));
		
		return convertView;
	}
	/*class buttonListener implements OnClickListener{
		private int position;
		buttonListener(int index){
			position=index+1;
		}
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intent=new Intent(context,RewardOrderActivity.class);
			Bundle bundle=new Bundle();
			bundle.putInt("id", id);
			intent.putExtras(bundle);
			Toast.makeText(context, "�����idΪ"+id, Toast.LENGTH_SHORT).show();
			context.startActivity(intent);
		}
	}*/
	static class ViewHolder{
		RoundedImageView icon;
		ImageView identify;
		TextView title,money,bidders,publisher,intro;
		RelativeLayout receive;
	}
}

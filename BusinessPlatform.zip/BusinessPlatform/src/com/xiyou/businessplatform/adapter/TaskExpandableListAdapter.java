﻿package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;
import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.R.color;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.entity.TaskListViewBean;
import com.xiyou.businessplatform.util.DateUtil;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.util.LocalSharePreference;

public class TaskExpandableListAdapter extends BaseExpandableListAdapter {
	private List<TaskListViewBean> group = new ArrayList<TaskListViewBean>();
	private List<List<Task>> child = new ArrayList<List<Task>>();
	private Context mContext;
	private ImageLoader mImageLoader;

	public TaskExpandableListAdapter(Context context,
			List<TaskListViewBean> beans, List<List<Task>> tasks) {
		this.mContext = context;
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(beans, tasks);
	}

	public void reflushAdapter(List<TaskListViewBean> beans,
			List<List<Task>> tasks) {
		if (beans != null && !beans.isEmpty()) {
			this.group = beans;
		} else {
			this.group.clear();
		}
		if (tasks != null && !tasks.isEmpty()) {
			this.child = tasks;
		} else {
			this.child.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getGroupCount() {
		if (group.isEmpty())
			return 0;
		return group.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		if (child.isEmpty())
			return 0;
		return child.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return group.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return child.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		ViewHolder viewHolder = null;
		if (convertView == null) {
			convertView = View.inflate(mContext,
					R.layout.expandablelist_group_layout, null);
			viewHolder = new ViewHolder();
			viewHolder.ib_group = (ImageButton) convertView
					.findViewById(R.id.left_group_layout);
			viewHolder.tv_group = (TextView) convertView
					.findViewById(R.id.tv_group_layout);
			viewHolder.num_group = (TextView) convertView
					.findViewById(R.id.tv_group_child_num);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		if (group != null && !group.isEmpty()) {
			TaskListViewBean taskListViewBean = group.get(groupPosition);
			if (taskListViewBean.getLeftdrawable() != 0)
				viewHolder.ib_group.setBackgroundColor(taskListViewBean
						.getLeftdrawable());
			if (taskListViewBean.getContent() != null)
				viewHolder.tv_group.setText(taskListViewBean.getContent());
			Log.e("TASKADAT", taskListViewBean.getChildnum() + "");
			if (taskListViewBean.getChildnum() != 0)
				viewHolder.num_group.setText("("
						+ taskListViewBean.getChildnum() + "个)");
			else
				viewHolder.num_group.setText("(0个)");
		}
		return convertView;
	}

	@SuppressLint("NewApi")
	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		ViewHolder viewHolder = null;
		if (convertView == null) {
			convertView = View.inflate(mContext,
					R.layout.expandablelist_child_layout, null);
			viewHolder = new ViewHolder();
			viewHolder.iv_child = (ImageView) convertView
					.findViewById(R.id.img_head_child_layout);
			viewHolder.title_child = (TextView) convertView
					.findViewById(R.id.txt_title_child_layout);
			viewHolder.monney_child = (TextView) convertView
					.findViewById(R.id.txt_monney_child_layout);
			viewHolder.cycle_child = (TextView) convertView
					.findViewById(R.id.txt_cycle_child_layout);
			viewHolder.hidden_child = (LinearLayout) convertView
					.findViewById(R.id.hidden_child_layout);
			viewHolder.time_child = (TextView) convertView
					.findViewById(R.id.txt_time_child_layout);
			convertView.setTag(viewHolder);

		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		if (child != null && !child.isEmpty()) {
			Task task = child.get(groupPosition).get(childPosition);
			if (task.getTasktitle() != null) {
				viewHolder.title_child.setText(task.getTasktitle());
			}
			if (task.getImagepath() != null && !"".equals(task.getImagepath())) {
				ImgUtil.showImage(mImageLoader, task.getImagepath(),
						viewHolder.iv_child);
			} else {
				viewHolder.iv_child.setBackground(mContext.getResources()
						.getDrawable(R.drawable.default_head));
			}
			if (task.getPrice() != null) {
				viewHolder.monney_child.setText("￥" + task.getPrice());
			}
			if (task.getCycle() != null) {
				viewHolder.cycle_child.setText("任务周期" + task.getCycle() + "天");
			}
			// pub_time：发布时间
			String pub_time = task.getAdd_time();
			// actor_time：提交时间
			String actor_time = task.getSub_time();
			// order_time：订单时间
			String order_time = task.getOrder_time();
			String time1 = null;
			StringBuffer sb = new StringBuffer();
			if (pub_time != null && !"0".equals(pub_time)) {
				time1 = pub_time;
				sb.append("发布时间:");
			} else if (actor_time != null && !"0".equals(actor_time)) {
				time1 = actor_time;
				sb.append("提交时间:");
			} else if (order_time != null && !"0".equals(order_time)) {
				time1 = order_time;
				sb.append("接单时间:");
			}
			long timec = 0;
			try {
				timec = Long.parseLong(time1);
				if (timec != 0) {
					sb.append(DateUtil.getDate(timec));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			viewHolder.time_child.setText(sb.toString());
			String uid = task.getUid();
			String userid = String
					.valueOf(LocalSharePreference.getID(mContext));
			if (task.getNick() != null && !"".equals(task.getNick())) {
				viewHolder.hidden_child.removeAllViews();
				if (!uid.equals(userid)) {// 我是发布者
					TextView nick_tv = getGenericView(task.getNick());
					viewHolder.hidden_child.addView(nick_tv);
				}
			}
			if (task.isChangeBg()) {
				convertView.setBackgroundColor(R.color.green);
			}
		}
		return convertView;
	}

	class ViewHolder {
		ImageButton ib_group;
		TextView tv_group;
		TextView num_group;
		ImageView iv_child;
		TextView title_child;
		TextView monney_child;
		TextView cycle_child;
		TextView time_child;
		LinearLayout hidden_child;

	}

	// 创建组/子视图
	public TextView getGenericView(String s) {
		TextView text = new TextView(mContext);
		text.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		text.setTextColor(color.text_color_low);
		text.setText("发布者: " + s);
		return text;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

}

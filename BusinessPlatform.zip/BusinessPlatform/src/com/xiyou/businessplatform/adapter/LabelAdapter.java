package com.xiyou.businessplatform.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.LabelBean;

public class LabelAdapter extends BaseAdapter {
	private List<LabelBean> labelList;
	private Context context;
	private LayoutInflater inflater;

	public LabelAdapter(List<LabelBean> labelList, Context context) {
		this.labelList = labelList;
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return labelList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		boolean isChecked;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_label, null);
			holder.checkBox = (CheckBox) convertView
					.findViewById(R.id.check_label);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.checkBox.setText(labelList.get(position).getName());
		if (labelList.get(position).getCheck() == 0) {
			isChecked = false;
		} else {
			isChecked = true;
		}
		holder.checkBox.setChecked(isChecked);
		return convertView;
	}

	class ViewHolder {
		CheckBox checkBox;
	}
}

package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EvaluateEntity;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.customer.RoundedImageView;

public class EvaluateFragmentAdapter extends BaseAdapter {
	private List<EvaluateEntity> list = new ArrayList<EvaluateEntity>();
	private Context context;
	private LayoutInflater inflater;
	private ImageLoader imageLoader;

	public EvaluateFragmentAdapter(Context context, List<EvaluateEntity> li) {
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}

	public void reflushAdapter(List<EvaluateEntity> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(
					R.layout.personal_evaluate_content_item, null);
			holder = new ViewHolder();
			holder.name = (TextView) convertView
					.findViewById(R.id.tv_per_eval_name);
			holder.evaluate = (TextView) convertView
					.findViewById(R.id.tv_per_evaluate);
			holder.content = (TextView) convertView
					.findViewById(R.id.tv_per_eval_content);
			holder.picture = (RoundedImageView) convertView
					.findViewById(R.id.iv_per_eval_pic);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		EvaluateEntity entity = list.get(position);
		String imgUrl = entity.getImagePath();
		if (imgUrl != null && !"".equals(imgUrl)) {
			ImgUtil.showImage(imageLoader, imgUrl, holder.picture);
		} else {

			holder.picture.setBackgroundResource(R.drawable.default_head);
		}
		holder.name.setText(list.get(position).getTitle());
		holder.evaluate.setText(list.get(position).getEvaluate());
		holder.content.setText(list.get(position).getContent());
		return convertView;
	}

	class ViewHolder {
		RoundedImageView picture;
		TextView name, content, evaluate;
	}
}

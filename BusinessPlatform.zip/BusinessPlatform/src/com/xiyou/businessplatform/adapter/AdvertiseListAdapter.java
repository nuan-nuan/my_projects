package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.demand.EngageDirectDescActivity;

public class AdvertiseListAdapter extends BaseAdapter implements Constants {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<EntityBean> tasks = new ArrayList<EntityBean>();
	private ImageLoader mImageLoader;

	// private Button hire;

	public AdvertiseListAdapter(Context context, ArrayList<EntityBean> list) {
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}

	public void reflushAdapter(ArrayList<EntityBean> list) {
		if (list != null && !list.isEmpty()) {
			this.tasks = list;
		} else {
			this.tasks.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return tasks.size();
	}

	@Override
	public Object getItem(int position) {
		return tasks.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.advertise_item, null);
		}
		ImageView icon = (ImageView) convertView
				.findViewById(R.id.advertfragment_hot_image);
		ImageView image = (ImageView) convertView
				.findViewById(R.id.advertfragment_image);
		TextView titlename = (TextView) convertView
				.findViewById(R.id.advertfragment_title_name);
//		TextView clicknumber = (TextView) convertView
//				.findViewById(R.id.advertfragment_clicknumber);
		TextView ordernumber = (TextView) convertView
				.findViewById(R.id.advertfragment_text_ordernumber);
		TextView commentnumber = (TextView) convertView
				.findViewById(R.id.advertfragment_praise);
		TextView introduction = (TextView) convertView
				.findViewById(R.id.advertfragment_introduction);
		// hire = (Button) convertView
		// .findViewById(R.id.advertfragment_button_hire);
		EntityBean newtask = tasks.get(position);
		String imageUrl = newtask.getImagepath();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		if (newtask.getIscompany() != null
				&& !"".equals(newtask.getIscompany())) {
			if (Integer.parseInt(newtask.getIscompany()) == 0) {
				icon.setVisibility(View.GONE);
			} else if (Integer.parseInt(newtask.getIscompany()) == 1) {
				icon.setVisibility(View.VISIBLE);
			}
		}
		titlename.setText(newtask.getNick());
//		clicknumber.setText(newtask.getClicknum()
//				+ context.getResources().getString(R.string._mouce_num_text));
		if (newtask.getClicknum() == null || "".equals(newtask.getClicknum()))
			ordernumber.setText(context.getResources().getString(
					R.string._zero_text));
		else
			ordernumber.setText(newtask.getClicknum());
		if (newtask.getCommentnum() == null
				|| "".equals(newtask.getCommentnum()))
			commentnumber.setText(context.getResources().getString(
					R.string._zero_text));
		else
			commentnumber.setText(newtask.getCommentnum());
		introduction.setText(newtask.getIntroduction());
		// hire.setOnClickListener(new lvButtonListener(position));
		return convertView;
	}

	class lvButtonListener implements OnClickListener {
		private int position;

		lvButtonListener(int pos) {
			position = pos;
		}

		@Override
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(context, EngageDirectDescActivity.class);
			intent.putExtra("uid", tasks.get(position).getUid());
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		}
	}
}

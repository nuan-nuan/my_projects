﻿package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.DateUtil;
import com.xiyou.businessplatform.util.ImgUtil;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ExtenderListAdapter extends BaseAdapter implements Constants {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<EntityBean> list = new ArrayList<EntityBean>();
	private ImageLoader mImageLoader;
	public ExtenderListAdapter(Context context, ArrayList<EntityBean> list) {
		this.context = context;
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		reflushAdapter(list);
	}

	public void reflushAdapter(ArrayList<EntityBean> li) {
		if (li != null && !li.isEmpty()) {
			this.list = li;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}
	@Override
	public int getCount() {
		return list.size();
	}
	@Override
	public Object getItem(int position) {
		return list.get(position);
	}
	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.extender_listview_item,
					null);
		}
		ImageView image = (ImageView) convertView
				.findViewById(R.id.extender_list_item_image);
		ImageView imageicon = (ImageView) convertView
				.findViewById(R.id.extender_list_item_imageicon);
		// 推广者名称
		TextView extendname = (TextView) convertView
				.findViewById(R.id.extender_list_item_name);
		// 任务状态
		TextView isfinish = (TextView) convertView
				.findViewById(R.id.extender_list_item_isfinish);
		// 日期
		TextView date = (TextView) convertView
				.findViewById(R.id.extender_list_item_date);

		EntityBean task = list.get(position);
		String imageUrl = task.getImagepath();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		if (task.getIs_company() != null
				&& Integer.parseInt(task.getIs_company()) == 1) {
			imageicon.setVisibility(View.VISIBLE);
		} else if (task.getIs_company() == null
				|| Integer.parseInt(task.getIs_company()) == 0) {
			imageicon.setVisibility(View.GONE);
		}
		if (task.getIs_auth() != null
				&& Integer.parseInt(task.getIs_auth()) == 1) {
			imageicon.setBackgroundResource(R.drawable.personal_identify);
		}
		int level = task.getLevel();
		if (level == 101) {
			isfinish.setText(WAIT_CONFIRM);
		} else if (level == 102) {
			isfinish.setText(WAIT_PUBLISH);
		} else if (level == 201) {
			isfinish.setText(DEVIVERY);
		} else if (level == 202) {
			isfinish.setText(WAIT_SELECT);
		} else if (level == 301) {
			isfinish.setText(TASK_GOING);
		} else if (level == 302) {
			isfinish.setText(TASK_GOING);
		} else if (level == 401) {
			isfinish.setText(WAIT_PAYMENT);
		} else if (level == 402) {
			isfinish.setText(WAIT_OTHER_PAYMENT);
		}else if(level == 500){
			isfinish.setText(WAIT_EVALUATE);
		} 
		else if (level == 501) {
			isfinish.setText(WAIT_EVALUATE);
		} else if (level == 502) {
			isfinish.setText(WAIT_EVALUATE);
		}
		String nick = task.getNick();
		if (nick != null && !nick.equals(""))
			extendname.setText(nick);
		// String newdate =
		// DateUtil.getDate(Long.parseLong(task.getAdd_time()));
		// date.setText(newdate);
		return convertView;
	}
}

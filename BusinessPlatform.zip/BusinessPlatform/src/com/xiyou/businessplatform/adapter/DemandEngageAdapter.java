package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.util.LocalSharePreference;
import com.xiyou.businessplatform.util.ToastUtils;
import com.xiyou.businessplatform.view.center.LoginActivity;
import com.xiyou.businessplatform.view.customer.RoundedImageView;
import com.xiyou.businessplatform.view.demand.EngageDirectDescActivity;

public class DemandEngageAdapter extends BaseAdapter implements Constants {
	private List<Task> list = new ArrayList<Task>();
	private Context context;
	private LayoutInflater inflater;
	private ImageLoader imageLoader;

	public DemandEngageAdapter(Context context, List<Task> list) {
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}

	public void reflushAdapter(List<Task> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.demand_engage_item, null);
			holder = new ViewHolder();
			holder.icon = (RoundedImageView) convertView
					.findViewById(R.id.iv_engage_picture);
			holder.name = (TextView) convertView
					.findViewById(R.id.tv_engage_name);
			holder.clickNo = (TextView) convertView
					.findViewById(R.id.tv_engage_clickno);
			holder.orderNo = (TextView) convertView
					.findViewById(R.id.tv_engage_orderno);
			holder.praiseNo = (TextView) convertView
					.findViewById(R.id.tv_engage_commendno);
			holder.description = (TextView) convertView
					.findViewById(R.id.tv_engage_desc);
			// holder.engage = (Button)
			// convertView.findViewById(R.id.btn_engage);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Task task = list.get(position);
		String imgUrl = task.getImagepath();
		if (imgUrl != null && !"".equals(imgUrl)) {
			ImgUtil.showImage(imageLoader, imgUrl, holder.icon);
		} else {
			holder.icon.setBackgroundResource(R.drawable.default_head);
		}
		// holder.icon.setImageBitmap(list.get(position).getBitmap());
		String name = list.get(position).getName();
		if (name != null && !"".equals(name) && !name.equals("null")) {
			holder.name.setText(name);
		} else {
			holder.name.setText(NO_NICK);
		}
		String click = list.get(position).getClick();
		if (click != null && !click.equals("") && !click.equals("null")) {
			holder.clickNo.setText(click);
		} else {
			holder.clickNo.setText("0");
		}
		String order = list.get(position).getOrdernumber();
		if (order != null && !"".equals(order) && !order.equals("null")) {
			holder.orderNo.setText(order);
		} else {
			holder.orderNo.setText("0");
		}
		String praise = list.get(position).getComment();
		if (praise != null && !"".equals(praise) && !praise.equals("null")) {
			holder.praiseNo.setText(praise);
		} else {
			holder.praiseNo.setText("0");
		}
		String intro = list.get(position).getIntroduction();
		if (intro != null && !"".equals(intro) && !intro.equals("null")) {
			holder.description.setText(intro);
		} else {
			holder.description.setText(NO_INTRO);
		}
		// holder.engage.setId(Integer.parseInt(list.get(position).getUid()));
		// holder.engage.setOnClickListener(new
		// listViewButtonListener(position));
		return convertView;
	}

	static class ViewHolder {
		RoundedImageView icon;
		TextView name, clickNo, orderNo, praiseNo, description;
		// Button engage;
		String address, uid;
	}

	class listViewButtonListener implements OnClickListener {
		private int position;

		listViewButtonListener(int index) {
			position = index;
		}

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intent = null;
			String otherid = list.get(position).getUid();
			String selfid = LocalSharePreference.getID(context) + "";
			if (otherid.equals(selfid)) {
				Toast.makeText(context, NOT_SELF, 0).show();
				return;
			}
			if (selfid != null && !"-1".equals(selfid)) {
				intent = new Intent(context, EngageDirectDescActivity.class);
				intent.putExtra("uid", list.get(position).getUid());
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(intent);
			} else {
				intent = new Intent(context, LoginActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(intent);
			}
		}
	}
}

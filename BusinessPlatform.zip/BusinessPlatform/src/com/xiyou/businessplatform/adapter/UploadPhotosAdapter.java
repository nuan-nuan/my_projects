package com.xiyou.businessplatform.adapter;

import java.util.List;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class UploadPhotosAdapter extends BaseAdapter {
	private List<View> lists;

	public UploadPhotosAdapter(List<View> list) {
		this.lists = list;
	}

	@Override
	public int getCount() {
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		convertView = lists.get(position);
		return convertView;
	}

}

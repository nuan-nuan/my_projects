package com.xiyou.businessplatform.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.adapter.CaseAdapter.ViewHolder;
import com.xiyou.businessplatform.entity.PayWaySelectBean;

public class PayWaySelectAdapter extends BaseAdapter {
	private List<PayWaySelectBean> list;
	private Context mContext;

	public PayWaySelectAdapter(List<PayWaySelectBean> li, Context context) {
		this.list = li;
		this.mContext = context;
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			holder = new Holder();
			convertView = View.inflate(mContext, R.layout.pay_way_seclect_item,
					null);
			holder.iv = (ImageView) convertView
					.findViewById(R.id.icon_payway_select);
			holder.tv = (TextView) convertView
					.findViewById(R.id.name_payway_select);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		if (list != null && !list.isEmpty()) {
			PayWaySelectBean payWaySelectBean = list.get(position);
			if (payWaySelectBean.getIcon_id() != 0) {
				holder.iv.setBackgroundResource(payWaySelectBean.getIcon_id());
			}
			if (payWaySelectBean.getName() != null) {
				holder.tv.setText(payWaySelectBean.getName());
			}
		}
		return convertView;
	}

	public class Holder {
		private ImageView iv;
		private TextView tv;
	}
}

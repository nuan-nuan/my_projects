package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
public class MainAdapter extends FragmentPagerAdapter{
	private ArrayList<Fragment> fragmentlist;
	public MainAdapter(FragmentManager fm,ArrayList<Fragment> list) {
		super(fm);
		this. fragmentlist=list;
	}
	@Override
	public Fragment getItem(int arg0) {
		 return  fragmentlist.get(arg0);
	}
	@Override
	public int getCount() {
		return  fragmentlist.size();
	}
}

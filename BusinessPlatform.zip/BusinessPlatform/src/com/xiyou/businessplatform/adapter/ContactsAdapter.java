package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.RecentContact;

public class ContactsAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<RecentContact> contacts;
	private LayoutInflater inflater;

	public ContactsAdapter(Context c, ArrayList<RecentContact> list) {
		this.context = c;
		this.contacts = list;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public int getCount() {
		return contacts.size();
	}

	public Object getItem(int position) {
		return contacts.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		// RecentContact contact=contacts.get(position);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_recent_contacts, null);
			holder.icon = (ImageView) convertView.findViewById(R.id.img_head);
			holder.name = (TextView) convertView
					.findViewById(R.id.txt_pickname);
			holder.word = (TextView) convertView.findViewById(R.id.txt_recent);
			holder.date = (TextView) convertView.findViewById(R.id.txt_date);
			// ΪconvertView���ñ�ǩ
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		//Ϊÿ����ϵ������ͷ�����ơ����¼�¼�����ʱ��
//		holder.icon.setImageDrawable(contacts.get(position).getIcon());
		holder.name.setText(contacts.get(position).getName());
		holder.word.setText(contacts.get(position).getRencentWord());
		holder.date.setText(contacts.get(position).getDate());

		return convertView;
	}

	/** ��ſؼ� */
	class ViewHolder {
		ImageView icon;
		TextView name;
		TextView word;
		TextView date;
	}
}

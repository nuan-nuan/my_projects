package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.adapter.TaskAdapter.ViewHolder;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.entity.Spreader;
import com.xiyou.businessplatform.entity.TaskEntity;
import com.xiyou.businessplatform.util.DateUtil;
import com.xiyou.businessplatform.util.ImgUtil;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class SpreadedAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<TaskEntity> spreaders=new ArrayList<TaskEntity>();;
	private LayoutInflater inflater;
	 private ImageLoader mImageLoader;
	public SpreadedAdapter(Context c, ArrayList<TaskEntity> list) {
		this.context = c;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}
	public void reflushAdapter(ArrayList<TaskEntity> list) {
		if (list != null && !list.isEmpty()) {
			this.spreaders = list;
		} else {
			this.spreaders.clear();
		}
		this.notifyDataSetChanged();
	}
	@Override
	public int getCount() {
		return spreaders.size();
	}

	@Override
	public Object getItem(int position) {
		return spreaders.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_spreaded, null);
			holder.icon = (ImageView) convertView.findViewById(R.id.img_head);
			holder.name = (TextView) convertView.findViewById(R.id.txt_name);
			holder.time = (TextView) convertView
					.findViewById(R.id.txt_time);
			// 为convertView锟斤拷锟矫憋拷签
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		String imageUrl = spreaders.get(position).getImageurl();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, holder.icon);
		}else{
			holder.icon.setBackgroundResource(R.drawable.default_head);
		}
		holder.name.setText(spreaders.get(position).getNike());
		String date=DateUtil.getDate(Long.parseLong(spreaders.get(position).getOk_time()));
		holder.time.setText(date);
		return convertView;
	}

	/** 锟斤拷趴丶锟�*/
	class ViewHolder {
		ImageView icon;
		TextView name;
		TextView time;
	}

}

package com.xiyou.businessplatform.adapter;

import java.util.List;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.PayWayBean;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class PayWayAdapter extends BaseAdapter {
	private List<PayWayBean> list;
	private Context mContext;
	private Activity c;
	private int pos;
	private int temp = -1;

	public PayWayAdapter(List<PayWayBean> li, Activity context) {
		this.list = li;
		c = context;
		this.mContext = context;
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public int getPosion() {
		return pos;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			holder = new Holder();
			convertView = View.inflate(mContext, R.layout.pay_way_item, null);
			holder.iv = (ImageView) convertView
					.findViewById(R.id.iv_pay_way_item);
			holder.name = (TextView) convertView
					.findViewById(R.id.name_pay_way_item);
			holder.hint = (TextView) convertView
					.findViewById(R.id.hint_pay_way_item);
			holder.rd = (RadioButton) convertView
					.findViewById(R.id.rd_pay_way_item);
			holder.rd.setChecked(false);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		if (list != null && !list.isEmpty()) {
			PayWayBean payWayBean = list.get(position);
			holder.name.setText(payWayBean.getTitle());
			holder.hint.setText(payWayBean.getHint());
			holder.iv.setBackgroundResource(payWayBean.getImg());
			holder.rd.setId(position);
			if (position == 0) {
				holder.rd.setChecked(true);
			}
			holder.rd.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView,
						boolean isChecked) {
					// TODO Auto-generated method stub
					if (isChecked) {
						if (temp != -1) {
							RadioButton tempButton = (RadioButton) c
									.findViewById(temp);
							if (tempButton != null) {
								tempButton.setChecked(false);
							}
						}
						temp = buttonView.getId();
						// ReportListActivity.checked_map = list.get(position);
					}
				}
			});
			convertView.setOnClickListener(new MyOnClickListener(holder));

			if (position == temp) {
				holder.rd.setChecked(true);
			} else {
				holder.rd.setChecked(false);
			}
		}
		return convertView;
	}

	class MyOnClickListener implements View.OnClickListener {
		private Holder mHolder;

		public MyOnClickListener(Holder holder) {
			this.mHolder = holder;
		}

		@Override
		public void onClick(View v) {
			if (!mHolder.rd.isChecked()) {
				mHolder.rd.setChecked(true);
			}
		}

	}

	class Holder {
		ImageView iv;
		TextView name;
		TextView hint;
		RadioButton rd;
	}
}

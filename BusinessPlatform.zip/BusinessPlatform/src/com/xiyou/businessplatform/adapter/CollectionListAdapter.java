package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Collection;
import com.xiyou.businessplatform.util.DateUtil;

public class CollectionListAdapter extends BaseAdapter {
	private ArrayList<Collection> list;
	private Context context;
	private LayoutInflater inflater;
	// AsyncImageLoder loader = new AsyncImageLoder();
	ImageLoader imageLoader;
	DisplayImageOptions options; // DisplayImageOptions����������ͼƬ��ʾ����

	public CollectionListAdapter(Context context, ArrayList<Collection> list) {
		this.context = context;
		this.list = list;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		options = new DisplayImageOptions.Builder()
				.showImageForEmptyUri(R.drawable.default_head) 
				.showImageOnFail(R.drawable.default_head) 
				.cacheInMemory(true) 
				.cacheOnDisc(true) 
				.build(); 
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(context));
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		Collection collection = list.get(position);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_collect, null);
			holder.icon = (ImageView) convertView
					.findViewById(R.id.img_coll_icon);
			holder.name = (TextView) convertView
					.findViewById(R.id.txt_publisher_name);
			holder.money = (TextView) convertView
					.findViewById(R.id.txt_task_money);
			holder.taskName = (TextView) convertView
					.findViewById(R.id.txt_task_name);
			holder.date = (TextView) convertView
					.findViewById(R.id.txt_coll_time);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		imageLoader.displayImage(collection.getImagepath(), holder.icon,
				options, null);

		holder.name.setText(collection.getTitle());
		holder.taskName.setText(collection.getTaskName());
		holder.money.setText(collection.getMoney());
		holder.date.setText(DateUtil.getDate(collection.getDate()));
		return convertView;
	}

	class ViewHolder {
		ImageView icon;
		TextView name;
		TextView money;
		TextView taskName;
		TextView date;
	}

}

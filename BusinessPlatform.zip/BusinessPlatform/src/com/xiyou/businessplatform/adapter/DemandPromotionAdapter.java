package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.util.Constants;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.customer.RoundedImageView;


public class DemandPromotionAdapter extends BaseAdapter implements Constants{
	private Context context;
	private List<Task> list=new ArrayList<Task>();
	private LayoutInflater inflater;
	private ImageLoader imageLoader;
	
	public DemandPromotionAdapter(Context context,List<Task> list) {
		// TODO Auto-generated constructor stub
		this.context=context;
		if(list==null){
			this.list=new ArrayList<Task>();
		}else{
			this.list=list;
		}
		this.inflater=(LayoutInflater) context.getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
		
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}
	
	public void reflushAdapter(List<Task> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		if(convertView==null){
			convertView=inflater.inflate(R.layout.demand_promotion_item, null);
			holder=new ViewHolder();
			holder.icon=(ImageView)convertView.findViewById(R.id.iv_pro_icon);
			holder.gameLogo=(RoundedImageView)convertView.findViewById(R.id.iv_pro_picture);
			holder.gameName=(TextView)convertView.findViewById(R.id.tv_pro_game);
			holder.amount=(TextView)convertView.findViewById(R.id.tv_pro_amount);
			holder.number=(TextView)convertView.findViewById(R.id.tv_pro_number);
			holder.cycle=(TextView)convertView.findViewById(R.id.tv_pro_cycleno);
			holder.introduction=(TextView)convertView.findViewById(R.id.tv_pro_description);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder)convertView.getTag();
		}
		Task task=list.get(position);
		String imgUrl=task.getAbacus_avatar();
		if(imgUrl!=null&&!"".equals(imgUrl)){
			ImgUtil.showImage(imageLoader, imgUrl, holder.gameLogo);
		}else{
			holder.gameLogo.setBackgroundResource(R.drawable.default_head);
		}
//		int is_company=Integer.parseInt(task.getIs_company());
//		int is_auth=Integer.parseInt(task.getIs_auth());
//		if(is_company==1){
//			holder.icon.setBackgroundResource(R.drawable.company_certifucate);
//		}else if(is_auth==1){
//			holder.icon.setBackgroundResource(R.drawable.personal_identify);
//		}
		String name=task.getTasktitle();
		if(name!=null&&!name.equals("")&&!name.equals("null")){
		    holder.gameName.setText(list.get(position).getTasktitle());
		}else{
			holder.gameName.setText("暂无名称");
		}
		String amount=task.getPrice();
		if(amount!=null&&!amount.equals("")&&!amount.equals("null")){
		    holder.amount.setText(list.get(position).getPrice());
		}else{
			holder.amount.setText("0");
		}
		String number=task.getProtimes();
		if(number!=null&&!number.equals("")&&!number.equals("null")){
		    holder.number.setText(list.get(position).getProtimes());
		}else{
			holder.number.setText("0");
		}
		String cycle=task.getCycle();
		if(cycle!=null&&!cycle.equals("")&&!cycle.equals("null")){
		    holder.cycle.setText(list.get(position).getCycle());
		}else{
			holder.cycle.setText("0");
		}
		String intro=task.getIntroduction();
		if(intro!=null&&!intro.equals("")&&!intro.equals("null")){
		    holder.introduction.setText(list.get(position).getIntroduction());
		}else{
			holder.introduction.setText(NO_INTRO);
		}
		//holder.promotion.setId((Integer)list.get(position).get("id"));
		//holder.promotion.setOnClickListener(new listViewButtonListener(position));
		return convertView;
	}
	
	static class ViewHolder{
		TextView gameName,amount,number,cycle,introduction;
		RoundedImageView gameLogo;
		Button promotion;
		ImageView icon;
	}
	/*class listViewButtonListener implements OnClickListener{
		private int position;
		listViewButtonListener(int index){
			position=index+1;
		}
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Toast.makeText(context, "����˵�"+position+"��", Toast.LENGTH_SHORT).show();
			Intent intent=new Intent(context,ConfirmExtendActivity.class);
			context.startActivity(intent);
		}
		
	}*/

}

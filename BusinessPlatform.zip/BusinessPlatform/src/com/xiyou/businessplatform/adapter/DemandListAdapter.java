package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.customer.RoundedImageView;
import com.xiyou.businessplatform.view.mainfragment.RewardOrderActivity;

public class DemandListAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<EntityBean> tasks = new ArrayList<EntityBean>();
	private ImageLoader mImageLoader;

	public DemandListAdapter(Context context, ArrayList<EntityBean> list) {
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.context = context;
		reflushAdapter(list);
	}
	public void reflushAdapter(ArrayList<EntityBean> list) {
		if (list != null && !list.isEmpty()) {
			this.tasks = list;
		} else {
			this.tasks.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return tasks.size();
	}

	@Override
	public Object getItem(int position) {
		return tasks.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.demand_item, null);
		}
		ImageView hoticon = (ImageView) convertView
				.findViewById(R.id.damanditem_image_hot);
		RoundedImageView image = (RoundedImageView) convertView
				.findViewById(R.id.damanditem_image);
		TextView titlename = (TextView) convertView
				.findViewById(R.id.damanditem_text_name);
		TextView number = (TextView) convertView
				.findViewById(R.id.damanditem_text_checknumber);
		TextView publishname = (TextView) convertView
				.findViewById(R.id.damanditem_publish_name);
		TextView introduction = (TextView) convertView
				.findViewById(R.id.damanditem_text_introduction);
		TextView price = (TextView) convertView
				.findViewById(R.id.damanditem_price);
		EntityBean newtask = tasks.get(position);
		String imageUrl = newtask.getImagepath();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		if (newtask.getIsNew() != null
				&& Integer.parseInt(newtask.getIsNew()) == 1) {
			hoticon.setVisibility(View.VISIBLE);
			hoticon.setImageResource(R.drawable.new_icon);
		} else if (newtask.getIsNew() == null
				|| Integer.parseInt(newtask.getIsNew()) == 0) {
			hoticon.setVisibility(View.GONE);
		}
		titlename.setText(newtask.getTitlename());
		if (newtask.getNumber() != null && !"".equals(newtask.getNumber()))
			number.setText(newtask.getNumber());
		else
			number.setText(context.getResources()
					.getString(R.string._zero_text));
		publishname.setText(newtask.getNick());
		introduction.setText(newtask.getIntroduction());
		if (newtask.getPrice() != null && !"".equals(newtask.getPrice()))
			price.setText(context.getResources().getString(
					R.string._monney_text)
					+ newtask.getPrice());
		else
			price.setText(context.getResources().getString(
					R.string._monney_text)
					+ context.getResources().getString(R.string._zero_text));
		return convertView;
	}

}

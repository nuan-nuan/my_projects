﻿package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.support.v4.view.PagerAdapter;

import android.util.Log;

import android.support.v4.view.ViewPager;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.BannerBean;
import com.xiyou.businessplatform.view.mainfragment.RewardOrderActivity;

public class BannerAdapter extends PagerAdapter {
	private List<View> mPagers = new ArrayList<View>();
	private List<BannerBean> mEntityBean = new ArrayList<BannerBean>();
	private Context mContext;

	public BannerAdapter(List<View> pagers, List<BannerBean> bannerBean,
			Context context) {
		this.mContext = context;
		reflushAdapter(pagers, bannerBean);
	}

	public void reflushAdapter(List<View> pagers, List<BannerBean> beans) {
		if (pagers != null && !pagers.isEmpty()) {
			mPagers = pagers;
		} else {
			mPagers.clear();
		}
		if (beans != null && !beans.isEmpty()) {
			mEntityBean = beans;
		} else {
			mEntityBean.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		Log.e("banner适配器", "个数: " + (mPagers == null ? 0 : mPagers.size() + 1));
		return mPagers.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

	@Override
	public Object instantiateItem(ViewGroup container, final int position) {
		if (mPagers != null && !mPagers.isEmpty()) {
			View pager = mPagers.get(position);
			pager.findViewById(R.id.iv_banner).setOnClickListener(
					new OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(mContext,
									RewardOrderActivity.class);
							if (mEntityBean != null && !mEntityBean.isEmpty()) {
								BannerBean enBean = mEntityBean.get(position);
								intent.putExtra("bean", enBean);
							}
							intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
							mContext.startActivity(intent);
						}
					});
			container.addView(pager);
			return pager;
		} else {
			return null;
		}
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		if (mPagers == null || mPagers.isEmpty())
			return;
		View view = mPagers.get(position);
		container.removeView(view);
	}
	// private ArrayList<Fragment> list;
	// public BannerAdapter(FragmentManager fm,ArrayList<Fragment> list) {
	// super(fm);
	// this.list=list;
	// }
	//
	// @Override
	// public Fragment getItem(int arg0) {
	// return list.get(arg0);
	// }
	//
	// @Override
	// public int getCount() {
	// return list.size();
	// }

}

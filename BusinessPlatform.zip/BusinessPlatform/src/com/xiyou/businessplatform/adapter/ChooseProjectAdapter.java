package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.entity.TaskEntity;
import com.xiyou.businessplatform.util.DateUtil;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.view.mainfragment.CheckProjectActivity;

public class ChooseProjectAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<TaskEntity> list = new ArrayList<TaskEntity>();
	private String hint;
	private ImageLoader mImageLoader;

	public ChooseProjectAdapter(Context context, ArrayList<TaskEntity> list) {
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImageLoaderConfiguration.createDefault(context));
		reflushAdapter(list);
	}

	public void reflushAdapter(ArrayList<TaskEntity> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return list.size();
	}
	@Override
	public Object getItem(int position) {
		return list.get(position);
	}
	@Override
	public long getItemId(int position) {
		return position;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.listview_checkable_item,
					null);
		}
		ImageView image = (ImageView) convertView
				.findViewById(R.id.developer_order_item_image);
		TextView name = (TextView) convertView
				.findViewById(R.id.developer_order_bid_name);
		// TextView solustion=(TextView)
		// convertView.findViewById(R.id.developer_order_solustion_number);
		TextView iscommit = (TextView) convertView
				.findViewById(R.id.developer_order_iscommit);
		// TextView date=(TextView)
		// convertView.findViewById(R.id.developer_order_commit_date);
		Button check = (Button) convertView
				.findViewById(R.id.developer_order_button_isbid);
		TaskEntity newtask = list.get(position);
		String imageUrl = newtask.getImageurl();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		name.setText(newtask.getNike());
//		String newdate = DateUtil.getDate(Long.parseLong(newtask
//				.getActor_time()));
		//		 date.setText(newdate);
		if(newtask.getIs_bid()!=null&&newtask.getIs_bid().equals("ok")){
			Log.e("TAG", newtask.getIs_bid());
			check.setText(context.getResources().getString(R.string.actor_is_bid));
			check.setBackgroundResource(R.color.actor_list_button_selector_red);
		}else{
		check.setText(context.getResources().getString(
				R.string.check_out));
		check.setBackgroundResource(R.color.actor_list_button_selector_greed);
		}
		hint=newtask.getHint();
		if (hint != null && !"".equals(hint)) {
			if (Integer.parseInt(hint) == 101) {
				check.setText(context.getResources().getString(
						R.string.wait_hint));
				check.setBackgroundResource(R.color.actor_list_button_selector_gray);
			}
			if (Integer.parseInt(hint) == 201) {
				}
			if (Integer.parseInt(hint) == 301) {
				check.setText(context.getResources().getString(
						R.string.button_is_actor));
				check.setBackgroundResource(R.color.actor_list_button_selector_gray);
			}
			if (Integer.parseInt(hint) == 401) {
				check.setText(context.getResources().getString(
						R.string.wait_pay_for));
				check.setBackgroundResource(R.color.actor_list_button_selector_red);
			}
			if (Integer.parseInt(hint) == 501) {
				check.setText(context.getResources().getString(
						R.string.wait_for_comment));
				check.setBackgroundResource(R.color.actor_list_button_selector_red);
			}
			if(Integer.parseInt(hint) ==500){
				check.setText(context.getResources().getString(
						R.string.wait_for_comment));
				check.setBackgroundResource(R.color.actor_list_button_selector_red);
			}
			if(Integer.parseInt(hint) ==502){
				check.setText(context.getResources().getString(
						R.string.wait_for_opposite_comment));
				check.setBackgroundResource(R.color.actor_list_button_selector_gray);
			}
		}
		return convertView;
	}
}

package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.CaseEntity;
import com.xiyou.businessplatform.util.ImgUtil;
import com.xiyou.businessplatform.util.LocalSharePreference;

public class CaseAdapter extends BaseAdapter {

	private ArrayList<CaseEntity> cases;
	private Context context;
	private LayoutInflater inflater;
	private ImageLoader imageLoader;

	public CaseAdapter(ArrayList<CaseEntity> list, Context con) {
		cases = list;
		context = con;
		inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImgUtil.getImageConfig(con));
	}

	@Override
	public int getCount() {
		return cases.size();
	}

	@Override
	public Object getItem(int position) {
		return cases.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Log.e("CaseAdapter", cases.size() + "");
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_case, null);
			// convertView
			// .setLayoutParams(new GridView.LayoutParams(width, height));
			holder.caseImage = (ImageView) convertView
					.findViewById(R.id.img_case);
			holder.caseName = (TextView) convertView
					.findViewById(R.id.txt_case);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		if (cases.get(position).getCasePhotoUrl() != null
				&& !"".equals(cases.get(position).getCasePhotoUrl())) {
			Log.e("适配器网络图片", position + "--------"
					+ cases.get(position).getCasePhotoUrl());
			ImgUtil.showImage(imageLoader, cases.get(position)
					.getCasePhotoUrl(), holder.caseImage);
			holder.caseName.setText(cases.get(position).getCaseTitle());
		} else {
			Log.e("适配器本地图片", position + "--------"
					+ cases.get(position).getCaseBitmap().toString());
			holder.caseImage
					.setImageBitmap(cases.get(position).getCaseBitmap());
			holder.caseName.setText(cases.get(position).getCaseTitle());
		}

		return convertView;
	}

	class ViewHolder {
		ImageView caseImage;
		TextView caseName;
	}

}

package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.Date;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.MsgAlertEntity;
import com.xiyou.businessplatform.util.DateUtil;

public class MsgAlertAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<MsgAlertEntity> mArlMsgs;
	private LayoutInflater inflater;

	public MsgAlertAdapter(Context context, ArrayList<MsgAlertEntity> list) {
		this.context = context;
		this.mArlMsgs = list;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return mArlMsgs.size();
	}

	@Override
	public Object getItem(int position) {
		return mArlMsgs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_msg_alert, null);
			holder.title = (TextView) convertView
					.findViewById(R.id.txt_msg_title);
			holder.hint = (TextView) convertView.findViewById(R.id.title_hint);
			holder.time = (TextView) convertView.findViewById(R.id.txt_time);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		if (mArlMsgs != null && !mArlMsgs.isEmpty()) {
			MsgAlertEntity msgAlertEntity = mArlMsgs.get(position);
			holder.title.setText(msgAlertEntity.getMsgAlertTitle());
			holder.hint.setText(msgAlertEntity.getMsgAlertHint());
			long time = msgAlertEntity.getMsgAlertTime();
			if (time != 0)
				holder.time.setText(DateUtil.getShortDate(time));
			else
				holder.time
						.setText(DateUtil.getShortDate(new Date().getTime()));
		}
		return convertView;
	}

	class ViewHolder {
		TextView title;
		TextView hint;
		TextView time;
	}
}

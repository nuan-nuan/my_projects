package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.util.DateUtil;
import com.xiyou.businessplatform.util.ImgUtil;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ConfirmExtendAdapter extends BaseAdapter{
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<EntityBean> list = new ArrayList<EntityBean>();
	private ImageLoader mImageLoader;	
public ConfirmExtendAdapter(Context context, ArrayList<EntityBean> list){
	this.context = context;
	mImageLoader = ImageLoader.getInstance();
	mImageLoader.init(ImgUtil.getImageConfig(context));
	this.inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	reflushAdapter(list);
}
public void reflushAdapter(ArrayList<EntityBean> li) {
	if (li != null && !li.isEmpty()) {
		this.list = li;
	} else {
		this.list.clear();
	}
	this.notifyDataSetChanged();
}
	@Override
	public int getCount() {
		return list.size();
	}
	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.confirm_extend_actor_item,
					null);
		}
		ImageView image=(ImageView) convertView.findViewById(R.id.confirm_extend_actor_item_image);
		ImageView imageicon=(ImageView) convertView.findViewById(R.id.confirm_extend_actor_item_imageicon);
		TextView extendname=(TextView) convertView.findViewById(R.id.confirm_extend_actor_item_name);
		TextView add_date=(TextView) convertView.findViewById(R.id.confirm_extend_actor_item_date);
		EntityBean task = list.get(position);
		String imageUrl = task.getImagepath();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		extendname.setText(task.getTitlename());
		String date=DateUtil.getDate(Long.parseLong(task.getDate()));
		add_date.setText(date);
		if(task.getIscompany()!=null &&Integer.parseInt(task.getIscompany())==1){
			imageicon.setVisibility(Button.VISIBLE);
		}
		return convertView;
	}
}

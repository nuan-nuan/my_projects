package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Task;
import com.xiyou.businessplatform.entity.TaskEntity;
import com.xiyou.businessplatform.util.ImgUtil;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class CommitProjectAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<TaskEntity> list = new ArrayList<TaskEntity>();
	private ImageLoader mImageLoader;

	public CommitProjectAdapter(Context context, ArrayList<TaskEntity> list) {
		this.context = context;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(context));
		reflushAdapter(list);
	}

	public void reflushAdapter(ArrayList<TaskEntity> list) {
		if (list != null && !list.isEmpty()) {
			this.list = list;
		} else {
			this.list.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.commit_project_actor_item,
					null);
		}
		ImageView identify = (ImageView) convertView
				.findViewById(R.id.identify);
		ImageView image = (ImageView) convertView
				.findViewById(R.id.commit_project_item_image);
		TextView name = (TextView) convertView
				.findViewById(R.id.commit_project_bid_name);
		TextView iscommit = (TextView) convertView
				.findViewById(R.id.commit_project_iscommit);
		TaskEntity entity = list.get(position);
		String imgUrl = entity.getImageurl();
		if (imgUrl != null && !"".equals(imgUrl)) {
			ImgUtil.showImage(mImageLoader, imgUrl, image);
		} else {
			image.setBackgroundResource(R.drawable.default_head);
		}
		int hint = Integer.parseInt(entity.getHint());
		if (hint == 102) {
			iscommit.setText("雇佣确认中");
			// check.setVisibility(View.GONE);
		} else if (hint == 202) {
			iscommit.setText("选稿中");
		} else if (hint == 302) {
			iscommit.setText("中标");
		} else if (hint == 402) {
			iscommit.setText("等待付款");
		} else if (hint == 502 || hint == 500) {
			iscommit.setText("待评价");
		} else if (hint == 501) {
			iscommit.setText("待对方评价");
		}
		name.setText(entity.getNike());
		if (Integer.parseInt(entity.getIs_company()) == 1) {
			identify.setVisibility(Button.VISIBLE);
		}
		return convertView;
	}

}

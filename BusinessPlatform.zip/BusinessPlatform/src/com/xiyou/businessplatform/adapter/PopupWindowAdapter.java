package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.xiyou.businessplatform.R;

public class PopupWindowAdapter extends BaseAdapter {
	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Context context;
	LayoutInflater inflater;

	public PopupWindowAdapter(Context context, List<Map<String, Object>> list) {
		this.context = context;
		if (list == null) {
			this.list = new ArrayList<Map<String, Object>>();
		} else {
			this.list = list;
		}
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.popupwindow_item, null);
			holder = new ViewHolder();
			holder.stencilName = (TextView) convertView
					.findViewById(R.id.textview_pop_item);
			convertView.setTag(holder);

		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.stencilName.setText((String) list.get(position).get("name"));
		return convertView;
	}

	class ViewHolder {
		TextView stencilName;
	}

}

package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.EntityBean;
import com.xiyou.businessplatform.entity.TaskEntity;
import com.xiyou.businessplatform.util.ImgUtil;

public class TaskAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<TaskEntity> tasks = new ArrayList<TaskEntity>();
	private LayoutInflater inflater;
	private ImageLoader mImageLoader;

	public TaskAdapter(Context c, ArrayList<TaskEntity> list) {
		this.context = c;
		this.inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mImageLoader = ImageLoader.getInstance();
		mImageLoader.init(ImgUtil.getImageConfig(c));
		reflushAdapter(list);
	}

	public void reflushAdapter(ArrayList<TaskEntity> list) {
		if (list != null && !list.isEmpty()) {
			this.tasks = list;
		} else {
			this.tasks.clear();
		}
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return tasks.size();
	}

	@Override
	public Object getItem(int position) {
		return tasks.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_task, null);
			holder.icon = (ImageView) convertView.findViewById(R.id.img_head);
			holder.name = (TextView) convertView
					.findViewById(R.id.txt_pickname);
			holder.detail = (TextView) convertView
					.findViewById(R.id.txt_detail);
			holder.introdution = (TextView) convertView
					.findViewById(R.id.txt_introduction);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		String imageUrl = tasks.get(position).getImageurl();
		if (imageUrl != null && !"".equals(imageUrl)) {
			ImgUtil.showImage(mImageLoader, imageUrl, holder.icon);
		} else {
			holder.icon.setBackgroundResource(R.drawable.default_head);
		}
		holder.name.setText(tasks.get(position).getTitlename());
		holder.introdution.setText(tasks.get(position).getDetail());
		return convertView;
	}

	class ViewHolder {
		ImageView icon;
		TextView name;
		TextView detail;
		TextView introdution;
	}

}

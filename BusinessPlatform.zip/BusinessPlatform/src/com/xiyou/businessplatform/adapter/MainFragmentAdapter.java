package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
public class MainFragmentAdapter extends FragmentPagerAdapter{
	private ArrayList<Fragment> list;
	public MainFragmentAdapter(FragmentManager fm,ArrayList<Fragment> li) {
		super(fm);
		this.list=li;
	}

	@Override
	public Fragment getItem(int arg0) {
		return list.get(arg0);
	}

	@Override
	public int getCount() {
		return list.size();
	}

}

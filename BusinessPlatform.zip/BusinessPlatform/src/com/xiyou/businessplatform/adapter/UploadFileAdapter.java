package com.xiyou.businessplatform.adapter;

import java.util.ArrayList;

import com.xiyou.businessplatform.R;
import com.xiyou.businessplatform.entity.Task;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class UploadFileAdapter extends BaseAdapter{
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<Task> task;
public UploadFileAdapter(Context context,ArrayList<Task> list){
	this.context=context;
	this.task=list;
	this.inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);				
}
	@Override
	public int getCount() {
		return task.size();
	}

	@Override
	public Object getItem(int position) {
		return task.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView==null){
			convertView=inflater.inflate(R.layout.upload_filelist_item, null);
		}
		TextView filename=(TextView) convertView.findViewById(R.id.upload_project_file_path);
		Task newtask=task.get(position);
		filename.setText(newtask.getFilename());
		return convertView;
	}

}

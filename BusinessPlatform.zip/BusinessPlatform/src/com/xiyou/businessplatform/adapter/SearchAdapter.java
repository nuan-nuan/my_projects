package com.xiyou.businessplatform.adapter;

import java.util.List;

import com.xiyou.businessplatform.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SearchAdapter extends BaseAdapter {
	private List<String> searchs;
	private Context mContext;

	public SearchAdapter(Context c, List<String> s) {
		this.mContext = c;
		this.searchs = s;
	}

	@Override
	public int getCount() {
		return searchs.size();
	}

	@Override
	public Object getItem(int position) {
		return searchs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = View.inflate(mContext, R.layout.search_layout_item,
					null);
			String t = searchs.get(position);
			TextView tv = (TextView) convertView
					.findViewById(R.id.tv_search_layout_item);
			tv.setText(t);
		}
		return convertView;
	}

}

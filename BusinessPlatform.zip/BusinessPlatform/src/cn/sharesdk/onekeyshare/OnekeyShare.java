/*
 * 鐎规缍夐崷鎵彲:http://www.mob.com
 * 閹讹拷婀抽弨顖涘瘮QQ: 4006852216
 * 鐎规ɑ鏌熷顔讳繆:ShareSDK   閿涘牆顪嗛弸婊冨絺鐢啯鏌婇悧鍫熸拱閻ㄥ嫯鐦介敍灞惧灉娴狀剙鐨㈡导姘鳖儑娑擄拷妞傞梻鎾拷鏉╁洤浜曟穱鈥崇殺閻楀牊婀伴弴瀛樻煀閸愬懎顔愰幒銊╋拷缂佹瑦鍋嶉妴鍌氼渾閺嬫粈濞囬悽銊ㄧ箖缁嬪鑵戦張澶夋崲娴ｆ洟妫舵０姗堢礉娑旂喎褰叉禒銉╋拷鏉╁洤浜曟穱鈥茬瑢閹存垳婊戦崣鏍х繁閼辨梻閮撮敍灞惧灉娴狀剙鐨㈡导姘躬24鐏忓繑妞傞崘鍛舶娴滃牆娲栨径宥忕礆
 *
 * Copyright (c) 2013楠烇拷mob.com. All rights reserved.
 */

package cn.sharesdk.onekeyshare;

import static cn.sharesdk.framework.utils.BitmapHelper.captureView;
import static cn.sharesdk.framework.utils.R.getBitmapRes;
import static cn.sharesdk.framework.utils.R.getStringRes;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Handler.Callback;
import android.os.Message;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.Toast;
import cn.sharesdk.framework.CustomPlatform;
import cn.sharesdk.framework.FakeActivity;
import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.framework.utils.UIHandler;

/**
 * 韫囶偅宓庨崚鍡曢煩閻ㄥ嫬鍙嗛崣锟�*
 * <p>
 * 闁俺绻冩稉宥呮倱閻ㄥ墕etter鐠佸墽鐤嗛崣鍌涙殶閿涘瞼鍔ч崥搴ょ殶閻⑩杽@link #show(Context)}閺傝纭堕崥顖氬З韫囶偅宓庨崚鍡曢煩
 */
public class OnekeyShare extends FakeActivity implements OnClickListener,
		PlatformActionListener, Callback {
	private static final int MSG_TOAST = 1;
	private static final int MSG_ACTION_CCALLBACK = 2;
	private static final int MSG_CANCEL_NOTIFY = 3;
	private FrameLayout flPage;
	// 鐎诡偅鐗搁崚妤勩�
	private PlatformGridView grid;
	// 閸欐牗绉烽幐澶愭尦
	private Button btnCancel;
	private Animation animShow;
	private Animation animHide;
	private boolean finishing;
	private boolean canceled;
	private HashMap<String, Object> reqMap;
	private ArrayList<CustomerLogo> customers;
	private int notifyIcon;
	private String notifyTitle;
	private boolean silent;
	private PlatformActionListener callback;
	private ShareContentCustomizeCallback customizeCallback;
	private boolean dialogMode;
	private boolean disableSSO;
	private HashMap<String, String> hiddenPlatforms;
	private View bgView;

	public OnekeyShare() {
		reqMap = new HashMap<String, Object>();
		customers = new ArrayList<CustomerLogo>();
		callback = this;
		hiddenPlatforms = new HashMap<String, String>();
	}

	public void show(Context context) {
		ShareSDK.initSDK(context);
		super.show(context, null);
	}

	/** 閸掑棔闊╅弮绂tification閻ㄥ嫬娴橀弽鍥ф嫲閺傚洤鐡� */
	public void setNotification(int icon, String title) {
		notifyIcon = icon;
		notifyTitle = title;
	}

	/** address閺勵垱甯撮弨鏈垫眽閸︽澘娼冮敍灞肩矌閸︺劋淇婇幁顖氭嫲闁喕娆㈡担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰返 */
	public void setAddress(String address) {
		reqMap.put("address", address);
	}

	/**
	 * title閺嶅洭顣介敍灞芥躬閸楁媽钖勭粭鏃囶唶閵嗕線鍋栫粻渚匡拷娣団剝浼呴妴浣镐簳娣団槄绱欓崠鍛婵傝棄寮搁妴浣规箙閸欏婀�
	 * 崪灞炬暪閽樺骏绱氶妴锟� *
	 * 閺勬挷淇婇敍鍫濆瘶閹奉剙銈介崣瀣拷閺堝寮搁崷鍫礆閵嗕椒姹夋禍铏圭秹閸滃Q缁屾椽妫挎担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰返
	 */
	public void setTitle(String title) {
		reqMap.put("title", title);
	}

	/** titleUrl閺勵垱鐖ｆ０妯兼畱缂冩垹绮堕柧鐐复閿涘奔绮庨崷銊ゆ眽娴滆櫣缍夐崪瀛甉缁屾椽妫挎担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰返 */
	public void setTitleUrl(String titleUrl) {
		reqMap.put("titleUrl", titleUrl);
	}

	/** text閺勵垰鍨庢禍顐ｆ瀮閺堫剨绱濋幍锟芥箒楠炲啿褰撮柈浠嬫付鐟曚浇绻栨稉顏勭摟濞堬拷 */
	public void setText(String text) {
		reqMap.put("text", text);
	}

	/** 閼惧嘲褰噒ext鐎涙顔岄惃鍕拷 */
	public String getText() {
		return reqMap.containsKey("text") ? String.valueOf(reqMap.get("text"))
				: null;
	}

	/** imagePath閺勵垱婀伴崷鎵畱閸ュ墽澧栫捄顖氱窞閿涘矂娅嶭inked-In婢舵牜娈戦幍锟芥箒楠炲啿褰撮柈鑺ユ暜閹镐浇绻栨稉顏勭摟濞堬拷 */
	public void setImagePath(String imagePath) {
		if (!TextUtils.isEmpty(imagePath))
			reqMap.put("imagePath", imagePath);
	}

	/**
	 * imageUrl閺勵垰娴橀悧鍥╂畱缂冩垹绮剁捄顖氱窞閿涘本鏌婂ù顏勪簳閸楁哎锟芥禍杞版眽缂冩垯锟絈Q缁屾椽妫块崪瀛nked-In閺�垱瀵斿
	 * 銈呯摟濞堬拷
	 */
	public void setImageUrl(String imageUrl) {
		if (!TextUtils.isEmpty(imageUrl))
			reqMap.put("imageUrl", imageUrl);
	}

	public void setUrl(String url) {
		reqMap.put("url", url);
	}

	public void setFilePath(String filePath) {
		reqMap.put("filePath", filePath);
	}

	/**
	 * comment閺勵垱鍨滅�纭呯箹閺夆�鍨庢禍顐ゆ畱鐠囧嫯顔戦敍灞肩矌閸︺劋姹夋禍铏圭秹閸滃Q缁屾椽妫挎担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰
	 * 返
	 */
	public void setComment(String comment) {
		reqMap.put("comment", comment);
	}

	/** site閺勵垰鍨庢禍顐ｎ劃閸愬懎顔愰惃鍕秹缁旀瑥鎮曠粔甯礉娴犲懎婀猀Q缁屾椽妫挎担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰返 */
	public void setSite(String site) {
		reqMap.put("site", site);
	}

	/** siteUrl閺勵垰鍨庢禍顐ｎ劃閸愬懎顔愰惃鍕秹缁旀瑥婀撮崸锟界礉娴犲懎婀猀Q缁屾椽妫挎担璺ㄦ暏閿涘苯鎯侀崚娆忓讲娴犮儰绗夐幓鎰返 */
	public void setSiteUrl(String siteUrl) {
		reqMap.put("siteUrl", siteUrl);
	}

	public void setVenueName(String venueName) {
		reqMap.put("venueName", venueName);
	}

	/** foursquare閸掑棔闊╅弮鍓佹畱閸︾増鏌熼幓蹇氬牚 */
	public void setVenueDescription(String venueDescription) {
		reqMap.put("venueDescription", venueDescription);
	}

	/** 閸掑棔闊╅崷鎵惈鎼达讣绱濋弬鐗堟爱瀵邦喖宕ラ妴浣藉悩鐠侇垰浜曢崡姘嫲foursquare閺�垱瀵斿銈呯摟濞堬拷 */
	public void setLatitude(float latitude) {
		reqMap.put("latitude", latitude);
	}

	/** 閸掑棔闊╅崷鎵病鎼达讣绱濋弬鐗堟爱瀵邦喖宕ラ妴浣藉悩鐠侇垰浜曢崡姘嫲foursquare閺�垱瀵斿銈呯摟濞堬拷 */
	public void setLongitude(float longitude) {
		reqMap.put("longitude", longitude);
	}

	/** 閺勵垰鎯侀惄瀛樺复閸掑棔闊� */
	public void setSilent(boolean silent) {
		this.silent = silent;
	}

	/** 鐠佸墽鐤嗙紓鏍帆妞ょ數娈戦崚婵嗩瀶閸栨牠锟芥稉顓為挬閸欙拷 */
	public void setPlatform(String platform) {
		reqMap.put("platform", platform);
	}

	public void setInstallUrl(String installurl) {
		reqMap.put("installurl", installurl);
	}

	public void setExecuteUrl(String executeurl) {
		reqMap.put("executeurl", executeurl);
	}

	/** 鐠佸墽鐤嗛懛顏勭暰娑斿娈戞径鏍劥閸ョ偠鐨� */
	public void setCallback(PlatformActionListener callback) {
		this.callback = callback;
	}

	/** 鏉╂柨娲栭幙宥勭稊閸ョ偠鐨� */
	public PlatformActionListener getCallback() {
		return callback;
	}

	/** 鐠佸墽鐤嗛悽銊ょ艾閸掑棔闊╂潻鍥┾柤娑擃叏绱濋弽瑙勫祦娑撳秴鎮撻獮鍐插酱閼奉亜鐣炬稊澶婂瀻娴滎偄鍞寸�鍦畱閸ョ偠鐨� */
	public void setShareContentCustomizeCallback(
			ShareContentCustomizeCallback callback) {
		customizeCallback = callback;
	}

	/** 鏉╂柨娲栭懛顏勭暰娑斿鍨庢禍顐㈠敶鐎瑰湱娈戦崶鐐剁殶 */
	public ShareContentCustomizeCallback getShareContentCustomizeCallback() {
		return customizeCallback;
	}

	/** 鐠佸墽鐤嗛懛顏勭箒閸ョ偓鐖ｉ崪宀�仯閸戣绨ㄦ禒璁圭礉閸欘垯浜掗柌宥咁樉鐠嬪啰鏁ゅǎ璇插婢舵碍顐� */
	public void setCustomerLogo(Bitmap logo, String label,
			OnClickListener ocListener) {
		CustomerLogo cl = new CustomerLogo();
		cl.label = label;
		cl.logo = logo;
		cl.listener = ocListener;
		customers.add(cl);
	}

	/** 鐠佸墽鐤嗘稉锟介嚋閹绱戦崗绛圭礉閻€劋绨崷銊ュ瀻娴滎偄澧犻懟銉╂付鐟曚焦宸块弶鍐跨礉閸掓瑧顪呴悽鈺痵o閸旂喕鍏� */
	public void disableSSOWhenAuthorize() {
		disableSSO = true;
	}

	/** 鐠佸墽鐤嗙紓鏍帆妞ょ敻娼伴惃鍕▔缁�儤膩瀵繋璐烡ialog濡�绱� */
	public void setDialogMode() {
		dialogMode = true;
		reqMap.put("dialogMode", dialogMode);
	}

	/** 濞ｈ濮炴稉锟介嚋闂呮劘妫岄惃鍒緇atform */
	public void addHiddenPlatform(String platform) {
		hiddenPlatforms.put(platform, platform);
	}

	/** 鐠佸墽鐤嗘稉锟介嚋鐏忓棜顤嗛幋顏勬禈閸掑棔闊╅惃鍒卛ew */
	public void setViewToShare(View viewToShare) {
		try {
			Bitmap bm = captureView(viewToShare, viewToShare.getWidth(),
					viewToShare.getHeight());
			reqMap.put("viewToShare", bm);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void setEditPageBackground(View bgView) {
		this.bgView = bgView;
	}

	public void onCreate() {
		// 閺勫墽銇氶弬鐟扮础閺勵垳鏁眕latform閸滃ilent娑撱倓閲滅�妤侇唽閹貉冨煑閻拷
		// 婵″倹鐏塸latform鐠佸墽鐤嗘禍鍡礉閸掓瑦妫ゆい缁樻▔缁�桨绡��顐ｇ壐閿涘苯鎯侀崚娆撳厴娴兼碍妯夌粈鐚寸幢
		// 婵″倹鐏塻ilent娑撶皪rue閿涘矁銆冪粈杞扮瑝鏉╂稑鍙嗙紓鏍帆妞ょ敻娼伴敍灞芥儊閸掓瑤绱版潻娑樺弳閵嗭拷
		// 閺堫剛琚崣顏勫灲閺傜捀latform閿涘苯娲滄稉杞扮瘈鐎诡偅鐗搁弰鍓с仛娴犮儱鎮楅敍灞肩皑娴犳湹姘︾紒姗甽atformGridView閹貉冨煑
		// 瑜版悕latform閸滃ilent闁垝璐焧rue閿涘苯鍨惄瀛樺复鏉╂稑鍙嗛崚鍡曢煩閿涳拷
		// 瑜版悕latform鐠佸墽鐤嗘禍鍡礉娴ｅ棙妲竤ilent娑撶alse閿涘苯鍨崚銈嗘焽閺勵垰鎯侀弰顖楋拷娴ｈ法鏁ょ�銏″煕缁旑垰鍨庢禍顐燂拷閻ㄥ嫬閽╅崣甯礉
		// 閼汇儰璐熼垾婊�▏閻€劌顓归幋椋庮伂閸掑棔闊╅垾婵堟畱楠炲啿褰撮敍灞藉灟閻╁瓨甯撮崚鍡曢煩閿涘苯鎯侀崚娆掔箻閸忋儳绱潏鎴︺�闂堬拷
		HashMap<String, Object> copy = new HashMap<String, Object>();
		copy.putAll(reqMap);
		if (copy.containsKey("platform")) {
			String name = String.valueOf(copy.get("platform"));
			if (silent) {
				HashMap<Platform, HashMap<String, Object>> shareData = new HashMap<Platform, HashMap<String, Object>>();
				shareData.put(ShareSDK.getPlatform(name), copy);
				share(shareData);
			} else if (ShareCore.isUseClientToShare(name)) {
				HashMap<Platform, HashMap<String, Object>> shareData = new HashMap<Platform, HashMap<String, Object>>();
				shareData.put(ShareSDK.getPlatform(name), copy);
				share(shareData);
			} else {
				Platform pp = ShareSDK.getPlatform(name);
				if (pp instanceof CustomPlatform) {
					HashMap<Platform, HashMap<String, Object>> shareData = new HashMap<Platform, HashMap<String, Object>>();
					shareData.put(ShareSDK.getPlatform(name), copy);
					share(shareData);
				} else {
					EditPage page = new EditPage();
					page.setBackGround(bgView);
					bgView = null;
					page.setShareData(copy);
					if (dialogMode) {
						page.setDialogMode();
					}
					page.showForResult(activity, null, new FakeActivity() {
						public void onResult(HashMap<String, Object> data) {
							if (data != null && data.containsKey("editRes")) {
								@SuppressWarnings("unchecked")
								HashMap<Platform, HashMap<String, Object>> editRes = (HashMap<Platform, HashMap<String, Object>>) data
										.get("editRes");
								share(editRes);
							}
						}
					});
				}
			}
			finish();
			return;
		}

		finishing = false;
		canceled = false;
		initPageView();
		initAnim();
		activity.setContentView(flPage);

		// 鐠佸墽鐤嗙�顐ｇ壐閸掓銆冮弫鐗堝祦
		grid.setData(copy, silent);
		grid.setHiddenPlatforms(hiddenPlatforms);
		grid.setCustomerLogos(customers);
		grid.setParent(this);
		btnCancel.setOnClickListener(this);

		// 閺勫墽銇氶崚妤勩�
		flPage.clearAnimation();
		flPage.startAnimation(animShow);

		// 閹垫挸绱戦崚鍡曢煩閼挎粌宕熼惃鍕埠鐠侊拷
		ShareSDK.logDemoEvent(1, null);
	}

	private void initPageView() {
		flPage = new FrameLayout(getContext());
		flPage.setOnClickListener(this);

		LinearLayout llPage = new LinearLayout(getContext()) {
			public boolean onTouchEvent(MotionEvent event) {
				return true;
			}
		};
		llPage.setOrientation(LinearLayout.VERTICAL);
		int resId = getBitmapRes(getContext(), "share_vp_back");
		if (resId > 0) {
			llPage.setBackgroundResource(resId);
		}
		FrameLayout.LayoutParams lpLl = new FrameLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		lpLl.gravity = Gravity.BOTTOM;
		llPage.setLayoutParams(lpLl);
		flPage.addView(llPage);

		// 鐎诡偅鐗搁崚妤勩�
		grid = new PlatformGridView(getContext());
		grid.setEditPageBackground(bgView);
		LinearLayout.LayoutParams lpWg = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		grid.setLayoutParams(lpWg);
		llPage.addView(grid);

		// 閸欐牗绉烽幐澶愭尦
		btnCancel = new Button(getContext());
		btnCancel.setTextColor(0xffffffff);
		btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
		resId = getStringRes(getContext(), "cancel");
		if (resId > 0) {
			btnCancel.setText(resId);
		}
		btnCancel.setPadding(0, 0, 0,
				cn.sharesdk.framework.utils.R.dipToPx(getContext(), 5));
		resId = getBitmapRes(getContext(), "btn_cancel_back");
		if (resId > 0) {
			btnCancel.setBackgroundResource(resId);
		}
		LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT,
				cn.sharesdk.framework.utils.R.dipToPx(getContext(), 45));
		int dp_10 = cn.sharesdk.framework.utils.R.dipToPx(getContext(), 10);
		lpBtn.setMargins(dp_10, dp_10, dp_10, dp_10);
		btnCancel.setLayoutParams(lpBtn);
		llPage.addView(btnCancel);
	}

	private void initAnim() {
		animShow = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0,
				Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1,
				Animation.RELATIVE_TO_SELF, 0);
		animShow.setDuration(300);

		animHide = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0,
				Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0,
				Animation.RELATIVE_TO_SELF, 1);
		animHide.setDuration(300);
	}

	public void onClick(View v) {
		if (v.equals(flPage) || v.equals(btnCancel)) {
			canceled = true;
			finish();
		}
	}

	public boolean onKeyEvent(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			canceled = true;
		}
		return super.onKeyEvent(keyCode, event);
	}

	public void onConfigurationChanged(Configuration newConfig) {
		if (grid != null) {
			grid.onConfigurationChanged();
		}
	}

	public boolean onFinish() {
		if (finishing) {
			return super.onFinish();
		}

		if (animHide == null) {
			finishing = true;
			super.finish();
			return super.onFinish();
		}

		// 閸欐牗绉烽崚鍡曢煩閼挎粌宕熼惃鍕埠鐠侊拷
		if (canceled) {
			ShareSDK.logDemoEvent(2, null);
		}
		finishing = true;
		animHide.setAnimationListener(new AnimationListener() {
			public void onAnimationStart(Animation animation) {

			}

			public void onAnimationRepeat(Animation animation) {

			}

			public void onAnimationEnd(Animation animation) {
				flPage.setVisibility(View.GONE);
				OnekeyShare.super.finish();
			}
		});
		flPage.clearAnimation();
		flPage.startAnimation(animHide);
		return super.onFinish();
	}

	/** 瀵邦亞骞嗛幍褑顢戦崚鍡曢煩 */
	public void share(HashMap<Platform, HashMap<String, Object>> shareData) {
		boolean started = false;
		for (Entry<Platform, HashMap<String, Object>> ent : shareData
				.entrySet()) {
			Platform plat = ent.getKey();
			plat.SSOSetting(disableSSO);
			String name = plat.getName();

			boolean isGooglePlus = "GooglePlus".equals(name);
			if (isGooglePlus && !plat.isValid()) {
				Message msg = new Message();
				msg.what = MSG_TOAST;
				int resId = getStringRes(getContext(),
						"google_plus_client_inavailable");
				msg.obj = activity.getString(resId);
				UIHandler.sendMessage(msg, this);
				continue;
			}

			boolean isKakaoTalk = "KakaoTalk".equals(name);
			if (isKakaoTalk && !plat.isValid()) {
				Message msg = new Message();
				msg.what = MSG_TOAST;
				int resId = getStringRes(getContext(),
						"kakaotalk_client_inavailable");
				msg.obj = activity.getString(resId);
				UIHandler.sendMessage(msg, this);
				continue;
			}

			boolean isKakaoStory = "KakaoStory".equals(name);
			if (isKakaoStory && !plat.isValid()) {
				Message msg = new Message();
				msg.what = MSG_TOAST;
				int resId = getStringRes(getContext(),
						"kakaostory_client_inavailable");
				msg.obj = activity.getString(resId);
				UIHandler.sendMessage(msg, this);
				continue;
			}

			boolean isPinterest = "Pinterest".equals(name);
			if (isPinterest && !plat.isValid()) {
				Message msg = new Message();
				msg.what = MSG_TOAST;
				int resId = getStringRes(getContext(),
						"pinterest_client_inavailable");
				msg.obj = activity.getString(resId);
				UIHandler.sendMessage(msg, this);
				continue;
			}

			if ("Instagram".equals(name)) {
				Intent test = new Intent(Intent.ACTION_SEND);
				test.setPackage("com.instagram.android");
				test.setType("image/*");
				ResolveInfo ri = activity.getPackageManager().resolveActivity(
						test, 0);
				if (ri == null) {
					Message msg = new Message();
					msg.what = MSG_TOAST;
					int resId = getStringRes(getContext(),
							"instagram_client_inavailable");
					msg.obj = activity.getString(resId);
					UIHandler.sendMessage(msg, this);
					continue;
				}
			}

			boolean isYixin = "YixinMoments".equals(name)
					|| "Yixin".equals(name);
			if (isYixin && !plat.isValid()) {
				Message msg = new Message();
				msg.what = MSG_TOAST;
				int resId = getStringRes(getContext(),
						"yixin_client_inavailable");
				msg.obj = activity.getString(resId);
				UIHandler.sendMessage(msg, this);
				continue;
			}

			HashMap<String, Object> data = ent.getValue();
			int shareType = Platform.SHARE_TEXT;
			String imagePath = String.valueOf(data.get("imagePath"));
			if (imagePath != null && (new File(imagePath)).exists()) {
				shareType = Platform.SHARE_IMAGE;
				if (imagePath.endsWith(".gif")) {
					shareType = Platform.SHARE_EMOJI;
				} else if (data.containsKey("url")
						&& !TextUtils.isEmpty(data.get("url").toString())) {
					shareType = Platform.SHARE_WEBPAGE;
				}
			} else {
				Bitmap viewToShare = (Bitmap) data.get("viewToShare");
				if (viewToShare != null && !viewToShare.isRecycled()) {
					shareType = Platform.SHARE_IMAGE;
					if (data.containsKey("url")) {
						Object url = data.get("url");
						if (url != null && !TextUtils.isEmpty(url.toString())) {
							shareType = Platform.SHARE_WEBPAGE;
						}
					}
				} else {
					Object imageUrl = data.get("imageUrl");
					if (imageUrl != null
							&& !TextUtils.isEmpty(String.valueOf(imageUrl))) {
						shareType = Platform.SHARE_IMAGE;
						if (String.valueOf(imageUrl).endsWith(".gif")) {
							shareType = Platform.SHARE_EMOJI;
						} else if (data.containsKey("url")) {
							Object url = data.get("url");
							if (url != null
									&& !TextUtils.isEmpty(url.toString())) {
								shareType = Platform.SHARE_WEBPAGE;
							}
						}
					}
				}
			}
			data.put("shareType", shareType);

			if (!started) {
				started = true;
				if (this == callback) {
					int resId = getStringRes(getContext(), "sharing");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				}
				finish();
			}
			plat.setPlatformActionListener(callback);
			ShareCore shareCore = new ShareCore();
			shareCore.setShareContentCustomizeCallback(customizeCallback);
			shareCore.share(plat, data);
		}
	}

	public void onComplete(Platform platform, int action,
			HashMap<String, Object> res) {
		Message msg = new Message();
		msg.what = MSG_ACTION_CCALLBACK;
		msg.arg1 = 1;
		msg.arg2 = action;
		msg.obj = platform;
		UIHandler.sendMessage(msg, this);
	}

	public void onError(Platform platform, int action, Throwable t) {
		t.printStackTrace();

		Message msg = new Message();
		msg.what = MSG_ACTION_CCALLBACK;
		msg.arg1 = 2;
		msg.arg2 = action;
		msg.obj = t;
		UIHandler.sendMessage(msg, this);

		// 閸掑棔闊╂径杈Е閻ㄥ嫮绮虹拋锟�
		ShareSDK.logDemoEvent(4, platform);
	}

	public void onCancel(Platform platform, int action) {
		Message msg = new Message();
		msg.what = MSG_ACTION_CCALLBACK;
		msg.arg1 = 3;
		msg.arg2 = action;
		msg.obj = platform;
		UIHandler.sendMessage(msg, this);
	}

	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case MSG_TOAST: {
			String text = String.valueOf(msg.obj);
			Toast.makeText(activity, text, Toast.LENGTH_SHORT).show();
		}
			break;
		case MSG_ACTION_CCALLBACK: {
			switch (msg.arg1) {
			case 1: {
				int resId = getStringRes(getContext(), "share_completed");
				if (resId > 0) {
					showNotification(2000, getContext().getString(resId));
				}
			}
				break;
			case 2: {
				String expName = msg.obj.getClass().getSimpleName();
				if ("WechatClientNotExistException".equals(expName)
						|| "WechatTimelineNotSupportedException"
								.equals(expName)
						|| "WechatFavoriteNotSupportedException"
								.equals(expName)) {
					int resId = getStringRes(getContext(),
							"wechat_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else if ("GooglePlusClientNotExistException".equals(expName)) {
					int resId = getStringRes(getContext(),
							"google_plus_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else if ("QQClientNotExistException".equals(expName)) {
					int resId = getStringRes(getContext(),
							"qq_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else if ("YixinClientNotExistException".equals(expName)
						|| "YixinTimelineNotSupportedException".equals(expName)) {
					int resId = getStringRes(getContext(),
							"yixin_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else if ("KakaoTalkClientNotExistException".equals(expName)) {
					int resId = getStringRes(getContext(),
							"kakaotalk_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else if ("KakaoStoryClientNotExistException".equals(expName)) {
					int resId = getStringRes(getContext(),
							"kakaostory_client_inavailable");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				} else {
					int resId = getStringRes(getContext(), "share_failed");
					if (resId > 0) {
						showNotification(2000, getContext().getString(resId));
					}
				}
			}
				break;
			case 3: {
				int resId = getStringRes(getContext(), "share_canceled");
				if (resId > 0) {
					showNotification(2000, getContext().getString(resId));
				}
			}
				break;
			}
		}
			break;
		case MSG_CANCEL_NOTIFY: {
			NotificationManager nm = (NotificationManager) msg.obj;
			if (nm != null) {
				nm.cancel(msg.arg1);
			}
		}
			break;
		}
		return false;
	}

	private void showNotification(long cancelTime, String text) {
		try {
			Context app = getContext().getApplicationContext();
			NotificationManager nm = (NotificationManager) app
					.getSystemService(Context.NOTIFICATION_SERVICE);
			final int id = Integer.MAX_VALUE / 13 + 1;
			nm.cancel(id);

			long when = System.currentTimeMillis();
			Notification notification = new Notification(notifyIcon, text, when);
			PendingIntent pi = PendingIntent.getActivity(app, 0, new Intent(),
					0);
			notification.setLatestEventInfo(app, notifyTitle, text, pi);
			notification.flags = Notification.FLAG_AUTO_CANCEL;
			nm.notify(id, notification);

			if (cancelTime > 0) {
				Message msg = new Message();
				msg.what = MSG_CANCEL_NOTIFY;
				msg.obj = nm;
				msg.arg1 = id;
				UIHandler.sendMessageDelayed(msg, cancelTime, this);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/** 閺勵垰鎯侀弨顖涘瘮QQ,QZone閹哄牊娼堥惂璇茬秿閸氬骸褰傚顔煎触 */
	public void setShareFromQQAuthSupport(boolean shareFromQQLogin) {
		reqMap.put("isShareTencentWeibo", shareFromQQLogin);
	}
}

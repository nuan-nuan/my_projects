package com.liulishuo.engzo.wxapi;

/**
 * Created by echo on 10/11/14.
 */

import com.liulishuo.share.wechat.WechatHandlerActivity;


/** 微信客户端回调activity */
public class WXEntryActivity extends WechatHandlerActivity {


}
package com.lefen58.lefenmall.entity;

public class Payment {
	
	private String code; //服务器返回结果（1/0/-4/-13/-14）
	private String intrgral; //积分余额
	private String deal_id; //交易流水号
	private String deal_time; //交易时间
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getIntrgral() {
		return intrgral;
	}
	public void setIntrgral(String intrgral) {
		this.intrgral = intrgral;
	}
	public String getDeal_id() {
		return deal_id;
	}
	public void setDeal_id(String deal_id) {
		this.deal_id = deal_id;
	}
	public String getDeal_time() {
		return deal_time;
	}
	public void setDeal_time(String deal_time) {
		this.deal_time = deal_time;
	}
	
	

}

package com.lefen58.lefenmall.entity;

public class Get_SMS_code {
	
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	

}

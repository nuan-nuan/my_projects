package com.lefen58.lefenmall.entity;

public class NearDetails {
	
	private String code;
	
	private String merchant_type;
	
	//private FilialeDetails info;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMerchant_type() {
		return merchant_type;
	}

	public void setMerchant_type(String merchant_type) {
		this.merchant_type = merchant_type;
	}

//	public FilialeDetails getInfo() {
//		return info;
//	}
//
//	public void setInfo(FilialeDetails info) {
//		this.info = info;
//	}
	

}

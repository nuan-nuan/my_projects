package com.lefen58.lefenmall.entity;

public class FilialeCode {
	private String code;
	private String filiale_id;
	private FilialeDetails info;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFiliale_id() {
		return filiale_id;
	}
	public void setFiliale_id(String filiale_id) {
		this.filiale_id = filiale_id;
	}
	public FilialeDetails getInfo() {
		return info;
	}
	public void setInfo(FilialeDetails info) {
		this.info = info;
	}
	

}

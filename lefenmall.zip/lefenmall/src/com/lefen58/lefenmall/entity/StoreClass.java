package com.lefen58.lefenmall.entity;

public class StoreClass {
	
	private String industry_id; 
	private String industry_name;
	private String industry_desp;
	private String industry_parent;
	
	public String getIndustry_id() {
		return industry_id;
	}
	public void setIndustry_id(String industry_id) {
		this.industry_id = industry_id;
	}
	public String getIndustry_name() {
		return industry_name;
	}
	public void setIndustry_name(String industry_name) {
		this.industry_name = industry_name;
	}
	public String getIndustry_desp() {
		return industry_desp;
	}
	public void setIndustry_desp(String industry_desp) {
		this.industry_desp = industry_desp;
	}
	public String getIndustry_parent() {
		return industry_parent;
	}
	public void setIndustry_parent(String industry_parent) {
		this.industry_parent = industry_parent;
	}

}

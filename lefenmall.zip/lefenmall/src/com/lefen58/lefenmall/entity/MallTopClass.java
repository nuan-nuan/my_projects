package com.lefen58.lefenmall.entity;

import com.google.gson.annotations.SerializedName;

public class MallTopClass extends BaseEntity{

	/**
	 * 分类id
	 */
	@SerializedName("classify_id")
	public String classifyId;  
	
	/**
	 * 分类等级，1代表一级分类
	 */
	@SerializedName("classify_level")
	public String classifyLevel;

	/**
	 * 分类名字
	 */
	@SerializedName("classify_name")
	public String classifyName;



}

package com.lefen58.lefenmall.entity;

public class ObtainIntegral {
	
	private String code; //服务器处理结果    1    -17  -3
	private String status; //赠送活动状态    0 活动未开始  1 进行中  2 暂停  3 结束 4 已经领过不能再领
	private String given_integral; //获得积分数量
	private String integral_balance; //用户当前积分余额
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGiven_integral() {
		return given_integral;
	}
	public void setGiven_integral(String given_integral) {
		this.given_integral = given_integral;
	}
	public String getIntegral_balance() {
		return integral_balance;
	}
	public void setIntegral_balance(String integral_balance) {
		this.integral_balance = integral_balance;
	}
	
	
	
	

}

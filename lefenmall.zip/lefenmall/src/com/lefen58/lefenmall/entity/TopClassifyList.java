package com.lefen58.lefenmall.entity;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class TopClassifyList extends BaseEntity{
	
	/**
	 * 一级分类列表
	 */
	@SerializedName("list")
	public List<MallTopClass> list;
}

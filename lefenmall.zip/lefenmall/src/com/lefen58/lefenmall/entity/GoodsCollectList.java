package com.lefen58.lefenmall.entity;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class GoodsCollectList extends BaseEntity{
	
	@SerializedName("list")
	public ArrayList<GoodsCollectListInfor> infor;
	
}

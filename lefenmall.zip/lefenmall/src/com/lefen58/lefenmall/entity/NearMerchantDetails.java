package com.lefen58.lefenmall.entity;

public class NearMerchantDetails {
	
	private String code;
	
	private String merchant_type;
	
	private MerchantDetails info;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMerchant_type() {
		return merchant_type;
	}

	public void setMerchant_type(String merchant_type) {
		this.merchant_type = merchant_type;
	}

	public MerchantDetails getInfo() {
		return info;
	}

	public void setInfo(MerchantDetails info) {
		this.info = info;
	}

	

}

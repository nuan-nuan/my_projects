package com.lefen58.lefenmall.entity;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class MallTwoClass{

	/**
	 * 分类ID
	 */
	@SerializedName("classify_id")
	public String classifyId;
	
	/**
	 * 分类等级，2代表二级分类
	 */
	@SerializedName("classify_level")
	public String classifyLevel;
	
	/**
	 * 归属的父分类ID
	 */
	@SerializedName("classify_parent_id")
	public String classifyParentId;
	
	/**
	 * 分类名字
	 */
	@SerializedName("classify_name")
	public String classifyname;
	
	/**
	 * 图片路径，加cdn前缀
	 */
	@SerializedName("logo_path")
	public String logoPath;
	
	/**
	 * 二级分类的三级分类列表，如果长度为0表示没有三级分类
	 */
	@SerializedName("classify_list")
	public List<MallThreeClass> classifyList;

}

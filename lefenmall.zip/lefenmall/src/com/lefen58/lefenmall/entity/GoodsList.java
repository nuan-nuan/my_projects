package com.lefen58.lefenmall.entity;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class GoodsList extends BaseEntity{
	
	/**
	 * 商品列表
	 */
	@SerializedName("list")
	public ArrayList<MallGoodsList> list;

}

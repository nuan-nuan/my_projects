package com.lefen58.lefenmall.entity;

public class Submit_card_info {
	private String code; //处理结果（1、0、-3、-4、-12)//如果是-12表示已经提交过数据，可以跳转到上传照片页面
	private String card_index; //身份证资料数据编号
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCard_index() {
		return card_index;
	}
	public void setCard_index(String card_index) {
		this.card_index = card_index;
	}
	
	
}

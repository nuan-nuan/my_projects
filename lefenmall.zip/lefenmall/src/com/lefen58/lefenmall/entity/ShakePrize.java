package com.lefen58.lefenmall.entity;

import java.util.ArrayList;

public class ShakePrize {
	
	private String code; //服务器处理结果（1/0/-17/-21）
	private ArrayList<PrizeList> list;

	public static class PrizeList{
		private String prize_for_activity; //归属活动唯一id
		private String prize_name; //奖品名字标
		private String prize_url; //奖品图片地址
		private String prize_tel; //赞助方联系电话
		private String prize_address; //兑奖地址
		private String prize_sponsor_name; //奖品赞助商名字
		private String prize_amount; //奖品数量
		public String getPrize_for_activity() {
			return prize_for_activity;
		}
		public void setPrize_for_activity(String prize_for_activity) {
			this.prize_for_activity = prize_for_activity;
		}
		public String getPrize_name() {
			return prize_name;
		}
		public void setPrize_name(String prize_name) {
			this.prize_name = prize_name;
		}
		public String getPrize_url() {
			return prize_url;
		}
		public void setPrize_url(String prize_url) {
			this.prize_url = prize_url;
		}
		public String getPrize_tel() {
			return prize_tel;
		}
		public void setPrize_tel(String prize_tel) {
			this.prize_tel = prize_tel;
		}
		public String getPrize_address() {
			return prize_address;
		}
		public void setPrize_address(String prize_address) {
			this.prize_address = prize_address;
		}
		public String getPrize_sponsor_name() {
			return prize_sponsor_name;
		}
		public void setPrize_sponsor_name(String prize_sponsor_name) {
			this.prize_sponsor_name = prize_sponsor_name;
		}
		public String getPrize_amount() {
			return prize_amount;
		}
		public void setPrize_amount(String prize_amount) {
			this.prize_amount = prize_amount;
		}


	}


	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public ArrayList<PrizeList> getList() {
		return list;
	}

	public void setList(ArrayList<PrizeList> list) {
		this.list = list;
	}

}

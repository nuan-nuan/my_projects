package com.lefen58.lefenmall.entity;

import java.util.List;

public class ActivityList {
	private String code;
	private List<MainActivityList> list;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<MainActivityList> getList() {
		return list;
	}
	public void setList(List<MainActivityList> list) {
		this.list = list;
	}
	
	

}

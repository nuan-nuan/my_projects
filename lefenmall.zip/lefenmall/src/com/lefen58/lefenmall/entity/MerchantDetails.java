package com.lefen58.lefenmall.entity;

import java.util.ArrayList;

public class MerchantDetails {
	
	private String merchant_id; //商家唯一id
	private String merchant_name; //商家名字标题
	private String graded; //商家评分10-50之间，代表1-5颗星
	private String merchant_province; //省
	private String merchant_city; //市
	private String merchant_county; //县
	private String merchant_address; //商家地址
	private String merchant_longitude; //商家地理位置经度
	private String merchant_latitude; //商家地理位置纬度
	private String merchant_industry; //商家所属的二级行业
	private String merchant_industry_parent; //商家所属的顶级行业
	private String merchant_scope; //经营范围
	private String merchant_desp; //特色简介
	private String merchant_worktime; //营业时间
	private String merchant_regtime; //注册时间
	private ArrayList<FilialeCodeImage> images; // 商家环境图片
	private String merchant_percent; //商家送积分比例，取值范围10-100，代表百分比
	private String merchant_tel; //商家固定电话号码
	
	public String getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(String merchant_id) {
		this.merchant_id = merchant_id;
	}
	public String getMerchant_name() {
		return merchant_name;
	}
	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}
	public String getGraded() {
		return graded;
	}
	public void setGraded(String graded) {
		this.graded = graded;
	}
	public String getMerchant_province() {
		return merchant_province;
	}
	public void setMerchant_province(String merchant_province) {
		this.merchant_province = merchant_province;
	}
	public String getMerchant_city() {
		return merchant_city;
	}
	public void setMerchant_city(String merchant_city) {
		this.merchant_city = merchant_city;
	}
	public String getMerchant_county() {
		return merchant_county;
	}
	public void setMerchant_county(String merchant_county) {
		this.merchant_county = merchant_county;
	}
	public String getMerchant_address() {
		return merchant_address;
	}
	public void setMerchant_address(String merchant_address) {
		this.merchant_address = merchant_address;
	}
	public String getMerchant_longitude() {
		return merchant_longitude;
	}
	public void setMerchant_longitude(String merchant_longitude) {
		this.merchant_longitude = merchant_longitude;
	}
	public String getMerchant_latitude() {
		return merchant_latitude;
	}
	public void setMerchant_latitude(String merchant_latitude) {
		this.merchant_latitude = merchant_latitude;
	}
	public String getMerchant_industry() {
		return merchant_industry;
	}
	public void setMerchant_industry(String merchant_industry) {
		this.merchant_industry = merchant_industry;
	}
	public String getMerchant_industry_parent() {
		return merchant_industry_parent;
	}
	public void setMerchant_industry_parent(String merchant_industry_parent) {
		this.merchant_industry_parent = merchant_industry_parent;
	}
	public String getMerchant_scope() {
		return merchant_scope;
	}
	public void setMerchant_scope(String merchant_scope) {
		this.merchant_scope = merchant_scope;
	}
	public String getMerchant_desp() {
		return merchant_desp;
	}
	public void setMerchant_desp(String merchant_desp) {
		this.merchant_desp = merchant_desp;
	}
	public String getMerchant_worktime() {
		return merchant_worktime;
	}
	public void setMerchant_worktime(String merchant_worktime) {
		this.merchant_worktime = merchant_worktime;
	}
	public String getMerchant_regtime() {
		return merchant_regtime;
	}
	public void setMerchant_regtime(String merchant_regtime) {
		this.merchant_regtime = merchant_regtime;
	}
	
	public String getMerchant_percent() {
		return merchant_percent;
	}
	

	public ArrayList<FilialeCodeImage> getImages() {
		return images;
	}
	public void setImages(ArrayList<FilialeCodeImage> images) {
		this.images = images;
	}
	public void setMerchant_percent(String merchant_percent) {
		this.merchant_percent = merchant_percent;
	}
	public String getMerchant_tel() {
		return merchant_tel;
	}
	public void setMerchant_tel(String merchant_tel) {
		this.merchant_tel = merchant_tel;
	}
	
	public class FilialeCodeImage {
		String photo_path;

		public String getPhoto_path() {
			return photo_path;
		}

		public void setPhoto_path(String photo_path) {
			this.photo_path = photo_path;
		}

	}

}

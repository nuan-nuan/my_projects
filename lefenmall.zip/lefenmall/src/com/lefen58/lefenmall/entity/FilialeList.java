package com.lefen58.lefenmall.entity;

public class FilialeList {
	
	/**
	 * 兑换中心
	 */
	
	private String shop_index; //兑换中心分店唯一ID
	private String shop_filiale_id; //兑换中心唯一ID
	private String shop_name; //兑换中心门店标题
	private String graded; //兑换中心门店评分10-50之间，代表1-5颗星
	private String shop_province; //省
	private String shop_city; //市
	private String shop_county; //县
	private String shop_address; //兑换中心门店地址
	private String shop_longitude; //兑换中心门店地理位置经度
	private String shop_latitude; //兑换中心门店地理位置纬度
	private String shop_tel; //联系电话
	private String shop_desp; //兑换中心门店简介
	private String shop_type; //0分店，1总店
	private String merchant_worktimeprivate; //营业时间
	private String shop_image;//兑换中心门店商家图片
	
	public String getShop_index() {
		return shop_index;
	}
	public void setShop_index(String shop_index) {
		this.shop_index = shop_index;
	}
	public String getShop_filiale_id() {
		return shop_filiale_id;
	}
	public void setShop_filiale_id(String shop_filiale_id) {
		this.shop_filiale_id = shop_filiale_id;
	}
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public String getGraded() {
		return graded;
	}
	public void setGraded(String graded) {
		this.graded = graded;
	}
	public String getShop_province() {
		return shop_province;
	}
	public void setShop_province(String shop_province) {
		this.shop_province = shop_province;
	}
	public String getShop_city() {
		return shop_city;
	}
	public void setShop_city(String shop_city) {
		this.shop_city = shop_city;
	}
	public String getShop_county() {
		return shop_county;
	}
	public void setShop_county(String shop_county) {
		this.shop_county = shop_county;
	}
	public String getShop_address() {
		return shop_address;
	}
	public void setShop_address(String shop_address) {
		this.shop_address = shop_address;
	}
	public String getShop_longitude() {
		return shop_longitude;
	}
	public void setShop_longitude(String shop_longitude) {
		this.shop_longitude = shop_longitude;
	}
	public String getShop_latitude() {
		return shop_latitude;
	}
	public void setShop_latitude(String shop_latitude) {
		this.shop_latitude = shop_latitude;
	}
	public String getShop_tel() {
		return shop_tel;
	}
	public void setShop_tel(String shop_tel) {
		this.shop_tel = shop_tel;
	}
	public String getShop_desp() {
		return shop_desp;
	}
	public void setShop_desp(String shop_desp) {
		this.shop_desp = shop_desp;
	}
	public String getShop_type() {
		return shop_type;
	}
	public void setShop_type(String shop_type) {
		this.shop_type = shop_type;
	}
	public String getMerchant_worktimeprivate() {
		return merchant_worktimeprivate;
	}
	public void setMerchant_worktimeprivate(String merchant_worktimeprivate) {
		this.merchant_worktimeprivate = merchant_worktimeprivate;
	}
	public String getShop_image() {
		return shop_image;
	}
	public void setShop_image(String shop_image) {
		this.shop_image = shop_image;
	}
	
	
	

}

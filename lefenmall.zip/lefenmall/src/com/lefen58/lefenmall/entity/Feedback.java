package com.lefen58.lefenmall.entity;

import java.util.List;

public class Feedback {
	private String code;
	private List<String> list;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<String> getList() {
		return list;
	}
	public void setList(List<String> list) {
		this.list = list;
	}
	
}

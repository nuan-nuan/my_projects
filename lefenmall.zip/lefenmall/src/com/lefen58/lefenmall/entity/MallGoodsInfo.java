package com.lefen58.lefenmall.entity;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class MallGoodsInfo{
	
	/**
	 * 商品 ID
	 */
	@SerializedName("goods_id")
	public String goodsId;
	
	/**
	 * 商品名字
	 */
	public String goods_name;
	
	/**
	 * 商品兑换积分价
	 */
	@SerializedName("goods_integral_price")
	public String goodsIntegralPrice;
	
	/**
	 * 商品销量
	 */
	@SerializedName("goods_sales_volume")
	public String goodsSalesVolume;
	
	/**
	 * 商品评分
	 */
	@SerializedName("goods_grade")
	public String goods_grade;
	
	/**
	 * 好评率
	 */
	@SerializedName("goods_good")
	public String goods_good;
	
	/**
	 * 商品浏览次数
	 */
	@SerializedName("goods_renqi")
	public String goods_renqi;
	
	/**
	 * 商品品牌
	 */
	@SerializedName("goods_brand_name")
	public String goodsBrand;
	
	/**
	 * 商品相册,加cdn前缀
	 */
	@SerializedName("goods_album")
	public List<String> goods_album;
	
	/**
	 * 商品介绍
	 */
	@SerializedName("goods_introduce")
	public List<String> goodsIntroduce;
	
	/**
	 * sku规格属性名列表，空数组表示没有sku表
	 */
	public List<GoodsSkuProperty> goods_sku_property;
	
	/**
	 * sku规格属性值列表,没有sku时为空数组
	 */
	public List<GoodsSkuProperty> goods_sku_values;
	

}

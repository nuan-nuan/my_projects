package com.lefen58.lefenmall.entity;

import com.google.gson.annotations.SerializedName;

public class MallGoodsList extends BaseEntity{

	/**
	 * 商品ID
	 */
	@SerializedName("goods_id")
	public String goodsId;
	
	/**
	 * 商品名称
	 */
	@SerializedName("goods_name")
	public String goodsName;
	
	/**
	 * 商品销量
	 */
	@SerializedName("goods_sale")
	public String goodsSalesVolume;
	
	/**
	 * 商品兑换积分价
	 */
	@SerializedName("goods_integral_price")
	public String goodsIntegralPrice;
	
	/**
	 * 商品上架时间
	 */
	@SerializedName("goods_online")
	public String goodsOnlineTime;
	
	/**
	 * 商品评分
	 */
	@SerializedName("goods_grade")
	public String goodsGrade;
	
	/**
	 * 商品icon地址
	 */
	@SerializedName("goods_icon")
	public String goods_icon;
	
	/**
	 * 好评百分比
	 */
	@SerializedName("goods_good")
	private String goods_good;
	
	/**
	 * 商品浏览次数
	 */
	@SerializedName("goods_renqi")
	public String goodsViewedCount;

}

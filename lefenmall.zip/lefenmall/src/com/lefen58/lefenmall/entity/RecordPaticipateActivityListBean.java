package com.lefen58.lefenmall.entity;

import java.util.List;

public class RecordPaticipateActivityListBean {
	private String code;
	private List<PaticipateActivityListBean> list;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<PaticipateActivityListBean> getList() {
		return list;
	}
	public void setList(List<PaticipateActivityListBean> list) {
		this.list = list;
	}
	
	public class PaticipateActivityListBean {
		private String activity_name;//活动名字
		private String activity_pay; //支付积分数量
		private String paticipate_time; //活动参与时间
		public String getActivity_name() {
			return activity_name;
		}
		public void setActivity_name(String activity_name) {
			this.activity_name = activity_name;
		}
		public String getActivity_pay() {
			return activity_pay;
		}
		public void setActivity_pay(String activity_pay) {
			this.activity_pay = activity_pay;
		}
		public String getPaticipate_time() {
			return paticipate_time;
		}
		public void setPaticipate_time(String paticipate_time) {
			this.paticipate_time = paticipate_time;
		}
		
	}
}

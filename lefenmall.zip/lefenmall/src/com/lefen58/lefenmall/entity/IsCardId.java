package com.lefen58.lefenmall.entity;

public class IsCardId {
	
	private String errNum;
	private String retMsg;
//	private IsCardIdRetData retData;
	public String getErrNum() {
		return errNum;
	}
	public void setErrNum(String errNum) {
		this.errNum = errNum;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
//	public IsCardIdRetData getRetData() {
//		return retData;
//	}
//	public void setRetData(IsCardIdRetData retData) {
//		this.retData = retData;
//	}
	
}

package com.lefen58.lefenmall.entity;

public class IsCardIdRetData {

	private String sex; //M-男，F-女，N-未知
	private String birthday; // "1987-04-20",
	private String address; // "湖北省孝感市汉川市"
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	

}

/*
 * @description
 * BaseResult.java
 * classes:com.vcyber.drivingservice.eneity.BaseResult
 * @author yym create at 2014-10-30下午3:49:03
*/
package com.lefen58.lefenmall.entity;


import android.util.Log;

import com.google.gson.Gson;
import com.lefen58.lefenmall.utils.LogUtil;

/**
 * @description:实体基类
 */
public class BaseEntity {
	public int code;
	LogUtil log = LogUtil.lLog();
	 
	public String msg;

	/* (non-Javadoc)
	 * @see com.vcyber.afinal.BaseClass#parser(java.lang.String)
	 */
	public void parser(String src) {
		// TODO Auto-generated method stub
		
	}
	
	

	/* (non-Javadoc)
	 * @see com.vcyber.afinal.BaseClass#parserT(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public <T> T parserT(String src) {
		// TODO Auto-generated method stub
	    
		log.i(" src is: " + src);
		if (src == null || src.length() == 0) {
			return null;
		}
		Gson gson = new Gson();
		return (T) gson.fromJson(src, this.getClass());
	}

}

package com.lefen58.lefenmall.entity;

public class GetActivityInfoResult extends BaseEntity{

//	/**
//	 * 服务器处理结果（1/0/-17/-21）
//	 */
//	public int code;
	
	public ActivityInfo activity;
}

package com.lefen58.lefenmall.entity;

import java.util.List;

public class RecordObtainJifenListBean {
	private String code;
	private List<JifenRecordListBean> list;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<JifenRecordListBean> getList() {
		return list;
	}
	public void setList(List<JifenRecordListBean> list) {
		this.list = list;
	}
	
	public class JifenRecordListBean {
		
		private String merchant_name;//商家名字
		private String merchant_goods; //消费品名字
		private String merchant_income; //消费金额（人民币分）
		private String merchant_give_integral; //获得积分数量
		private String merchant_give_time; //积分获得时间
		public String getMerchant_name() {
			return merchant_name;
		}
		public void setMerchant_name(String merchant_name) {
			this.merchant_name = merchant_name;
		}
		public String getMerchant_goods() {
			return merchant_goods;
		}
		public void setMerchant_goods(String merchant_goods) {
			this.merchant_goods = merchant_goods;
		}
		public String getMerchant_income() {
			return merchant_income;
		}
		public void setMerchant_income(String merchant_income) {
			this.merchant_income = merchant_income;
		}
		public String getMerchant_give_integral() {
			return merchant_give_integral;
		}
		public void setMerchant_give_integral(String merchant_give_integral) {
			this.merchant_give_integral = merchant_give_integral;
		}
		public String getMerchant_give_time() {
			return merchant_give_time;
		}
		public void setMerchant_give_time(String merchant_give_time) {
			this.merchant_give_time = merchant_give_time;
		}
		
	}

}

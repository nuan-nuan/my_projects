package com.lefen58.lefenmall.entity;


public class RegisterAccount extends BaseEntity {
	//注册时验证短信码并注册帐号实体类
	
	/**
	 * 服务器返回的token值
	 */
	public String token;
	
	/**
	 * 新用户注册赠送积分 0 标示没有赠送积分
	 */
	public String given_integral;
	
	/**
	 * 账户积分余额
	 */
	public String integral_balance;
	
	
}

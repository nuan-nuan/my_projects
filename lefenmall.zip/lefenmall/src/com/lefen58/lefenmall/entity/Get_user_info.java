package com.lefen58.lefenmall.entity;

public class Get_user_info {
	
	private String code;
	
	private String user_info;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getUser_info() {
		return user_info;
	}

	public void setUser_info(String user_info) {
		this.user_info = user_info;
	}
	

}

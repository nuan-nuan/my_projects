package com.lefen58.lefenmall.entity;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class GetPrizeVoucherListResult {

	/**
	 * 服务器处理结果 1
	 */
	public int code;
	
	/**
	 * 凭证列表
	 */
	@SerializedName("list")
	public List<PrizeVoucher> vouchers;
}

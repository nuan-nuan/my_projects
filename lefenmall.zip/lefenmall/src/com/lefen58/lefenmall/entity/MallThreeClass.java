package com.lefen58.lefenmall.entity;

import com.google.gson.annotations.SerializedName;

public class MallThreeClass {
	/**
	 * 分类ID
	 */
	@SerializedName("classify_id")
	public String classifyId; 
	/**
	 * 分类等级，1代表一级分类
	 */
	@SerializedName("classify_level")
	public String classify_level;
	/**
	 * 归属的父分类ID
	 */
	@SerializedName("classify_parent_id")
	public String classify_parent_id;
	/**
	 * 分类名字
	 */
	@SerializedName("classify_name")
	public String classifyName;
	/**
	 * 图片路径，加cdn前缀
	 */
	@SerializedName("logo_path")
	public String logoPath;
}

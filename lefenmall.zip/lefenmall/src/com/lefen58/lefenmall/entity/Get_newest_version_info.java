package com.lefen58.lefenmall.entity;

public class Get_newest_version_info extends BaseEntity {
	
	private String info;
	
	public int getCode() {
		return code;
	}
	
	public void setCode(int code) {
		this.code = code;
	}
	
	public String getInfo() {
		return info;
	}
	
	public void setInfo(String info) {
		this.info = info;
	}
	
	

}

package com.lefen58.lefenmall.entity;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class ClassifyList extends BaseEntity{
	
	/**
	 * 二级分类列表
	 */
	@SerializedName("list")
	public List<MallTwoClass> list;
}

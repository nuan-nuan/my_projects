package com.lefen58.lefenmall.entity;

import java.util.List;

public class Search {
	private String code;
	private List<MerchantList> merchant_list;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<MerchantList> getMerchant_list() {
		return merchant_list;
	}
	public void setMerchant_list(List<MerchantList> merchant_list) {
		this.merchant_list = merchant_list;
	}
	

}

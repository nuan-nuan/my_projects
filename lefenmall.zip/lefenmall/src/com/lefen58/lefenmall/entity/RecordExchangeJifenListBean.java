package com.lefen58.lefenmall.entity;

import java.util.List;


public class RecordExchangeJifenListBean {
	private String code;
	private List<ExchangeJifenListBean> list;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<ExchangeJifenListBean> getList() {
		return list;
	}

	public void setList(List<ExchangeJifenListBean> list) {
		this.list = list;
	}

	public class ExchangeJifenListBean {
		private String filiale_name;//兑换中心名字
		private String sell_cash; //额外支付金额（人民币分）
		private String sell_total_integral; //支付积分数量
		private String sell_time; //积分兑换时间
		public String getFiliale_name() {
			return filiale_name;
		}
		public void setFiliale_name(String filiale_name) {
			this.filiale_name = filiale_name;
		}
		public String getSell_cash() {
			return sell_cash;
		}
		public void setSell_cash(String sell_cash) {
			this.sell_cash = sell_cash;
		}
		public String getSell_total_integral() {
			return sell_total_integral;
		}
		public void setSell_total_integral(String sell_total_integral) {
			this.sell_total_integral = sell_total_integral;
		}
		public String getSell_time() {
			return sell_time;
		}
		public void setSell_time(String sell_time) {
			this.sell_time = sell_time;
		}
	}
}

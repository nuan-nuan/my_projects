package com.lefen58.lefenmall.widgets;

/**
 * @author Jungly
 * @mail jungly.ik@gmail.com
 * @date 15/3/21 16:47
 */
public enum PasswordType {

    NUMBER, TEXT, TEXTVISIBLE, TEXTWEB;

}

package com.lefen58.lefenmall;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;
import com.baidu.mapapi.SDKInitializer;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.AreaInfo;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.nostra13.universalimageloader.core.DisplayImageOptions;

import android.app.Application;
import android.content.SharedPreferences;

public class LeFenMallApplication extends Application {
	public static LeFenMallApplication instance = null;
	public LocationClient mLocationClient;
	DisplayImageOptions fadeoptions;
	LogUtil log = LogUtil.lLog();
	
	private double Latitude = 0.0;
	private double Longitude = 0.0;
	private static SharedPreferences sp;
	private String city;
	private String district;//区、县
	@Override
	public void onCreate() {
		super.onCreate();
		instance=this;
		SDKInitializer.initialize(this);
		CrashHandler crashHandler = CrashHandler.getInstance();
		crashHandler.init(getApplicationContext());
		sp = getSharedPreferences("UserInfor", 0);
		mLocationClient = new LocationClient(this.getApplicationContext());
		mLocationClient.registerLocationListener(bdLocationListener);
		initLocation();
		mLocationClient.start();
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
	public String getDistrict() {
		return district;
	}


	BDLocationListener bdLocationListener = new BDLocationListener() {

		@Override
		public void onReceiveLocation(final BDLocation location) {
			// TODO Auto-generated method stub
			if (location.getLatitude() != 4.9E-324
					&& location.getLongitude() != 4.9E-324) {
				Latitude = location.getLatitude();
				Longitude = location.getLongitude();
			}
			city = location.getCity();
			district=location.getDistrict();
			sp.edit().putString("locationCity", location.getCity()).commit();
			sp.edit().putString("locationdescribe", location.getLocationDescribe()).commit();
			if (location.getCity() != null) {
				new Thread(
						new Runnable() {
							public void run() {
								JSONArray js;
								try {
									InputStream is = getResources().getAssets().open("config_region.json");
									byte [] buffer = new byte[is.available()] ; 
									is.read(buffer);
									String json = new String(buffer,"utf-8");
									js = new JSONArray(json);
									Gson gson = new Gson();
									for (int index = 1; index < js.length(); index++) {
										if (location.getCity().contains(gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_name())) {
											sp.edit().putString("city", gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_name()).commit();
											sp.edit().putString("cityId", gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_id()).commit();
											sp.edit().putString("countyId", "0").commit();
											sp.edit().putString("locationCityId", gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_id()).commit();
											mLocationClient.stop();
											JSONObject object = new JSONObject();
											object.put("city",gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_id());
											HttpUtils http = new HttpUtils();
											RequestParams params = new RequestParams();
											params.addBodyParameter("c", "set_user_info");
											params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(getApplicationContext()));
											params.addBodyParameter("token", RequestOftenKey.getToken(getApplicationContext()));
											params.addBodyParameter("user_info", object.toString());
											http.send(HttpMethod.POST,Ip.url+"account.php",
													params, new RequestCallBack<String>(){
												
												@Override
												public void onFailure(HttpException arg0, String arg1) {
												}
												
												@Override
												public void onSuccess(ResponseInfo<String> arg0) {
												}
											});
										}
									}
								} catch (JsonSyntaxException e) {
									e.printStackTrace();
								} catch (UnsupportedEncodingException e) {
									e.printStackTrace();
								} catch (IOException e) {
									e.printStackTrace();
								} catch (JSONException e) {
									e.printStackTrace();
								}
							}
						}).start();
			}
		}
	};
	private void initLocation() {
		LocationClientOption option = new LocationClientOption();
		option.setLocationMode(LocationMode.Hight_Accuracy);// 鍙�夛紝榛樿楂樼簿搴︼紝璁剧疆瀹氫綅妯″紡锛岄珮绮惧害锛屼綆鍔熻�楋紝浠呰澶�
		option.setScanSpan(2000);// 鍙�夛紝榛樿0锛屽嵆浠呭畾浣嶄竴娆★紝璁剧疆鍙戣捣瀹氫綅璇锋眰鐨勯棿闅旈渶瑕佸ぇ浜庣瓑浜�1000ms鎵嶆槸鏈夋晥鐨�
		option.setIsNeedAddress(true);// 鍙�夛紝璁剧疆鏄惁闇�瑕佸湴鍧�淇℃伅锛岄粯璁や笉闇�瑕�
		//option.setLocationMode(LocationMode.Battery_Saving);// 璁剧疆瀹氫綅妯″紡:Hight_Accuracy楂樼簿搴︺�丅attery_Saving浣庡姛鑰椼�丏evice_Sensors浠呰澶�(GPS)
		option.setOpenGps(true); // 鎵撳紑gps
		option.setCoorType("bd09ll"); // 璁剧疆鍧愭爣绫诲瀷
		option.setLocationNotify(true);// 鍙�夛紝榛樿false锛岃缃槸鍚﹀綋gps鏈夋晥鏃舵寜鐓�1S1娆￠鐜囪緭鍑篏PS缁撴灉
		option.setIgnoreKillProcess(true);// 鍙�夛紝榛樿true锛屽畾浣峉DK鍐呴儴鏄竴涓猄ERVICE锛屽苟鏀惧埌浜嗙嫭绔嬭繘绋嬶紝璁剧疆鏄惁鍦╯top鐨勬椂鍊欐潃姝昏繖涓繘绋嬶紝榛樿涓嶆潃姝�
		option.setEnableSimulateGps(false);// 鍙�夛紝榛樿false锛岃缃槸鍚﹂渶瑕佽繃婊ps浠跨湡缁撴灉锛岄粯璁ら渶瑕�
		option.setIsNeedLocationDescribe(false);// 鍙�夛紝榛樿false锛岃缃槸鍚﹂渶瑕佷綅缃涔夊寲缁撴灉锛屽彲浠ュ湪BDLocation.getLocationDescribe閲屽緱鍒帮紝缁撴灉绫讳技浜庘�滃湪鍖椾含澶╁畨闂ㄩ檮杩戔��
		option.setIsNeedLocationPoiList(true);// 鍙�夛紝榛樿false锛岃缃槸鍚﹂渶瑕丳OI缁撴灉锛屽彲浠ュ湪BDLocation.getPoiList閲屽緱鍒�
		mLocationClient.setLocOption(option);
	}

	public double getLatitude() {
		return Latitude;
	}
	public void setLatitude(double lat) {
		this.Latitude = lat;
	}
	public double getLongitude() {
		return Longitude;
	}
	public void setLongitude(double lng) {
		this.Longitude = lng;
	}

}
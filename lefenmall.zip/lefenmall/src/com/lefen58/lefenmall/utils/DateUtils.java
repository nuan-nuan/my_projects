package com.lefen58.lefenmall.utils;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	/**
	 * 日期时间字符串转化为Date类型
	 * @param dateString
	 * @return
	 */
	 public static Date stringToDate(String dateString) {  
         ParsePosition position = new ParsePosition(0);  
         SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
         Date dateValue = simpleDateFormat.parse(dateString, position);  
         return dateValue;  
     }
}

package com.lefen58.lefenmall.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.http.protocol.HTTP;

import com.lefen58.lefenmall.config.Constants;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
public class FileUtils {

	/**
	 * 图像保存到文件中
	 * 
	 * @param bmp
	 * @param filename
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static String saveBtpToFile(Context mContext, Bitmap bmp,
			String filename) throws IOException, FileNotFoundException {
		String path = null;
		if (filename != null && filename.contains("/")) {
			path = filename;
		} else {
			path = Constants.BASE_PATH + "/" + filename;
		}
		File basePath = new File(path.substring(0, path.lastIndexOf("/")));
		if (!basePath.exists()) {
			basePath.mkdirs();
		}
		File file = new File(path);
		if (file.exists()) {
			file.delete();
		}
		
		FileOutputStream foutput = null;
		foutput = new FileOutputStream(path);
		if(filename.endsWith(".webp") || filename.endsWith(".WEBP")){
			bmp.compress(Bitmap.CompressFormat.WEBP, 100, foutput);
		} else if (filename.endsWith(".png") || filename.endsWith(".PNG")) {
			bmp.compress(Bitmap.CompressFormat.PNG, 100, foutput);
		} else {
			bmp.compress(Bitmap.CompressFormat.JPEG, 100, foutput);
		}

		foutput.close();
		// bmp.recycle();
		return path;
	}

	public static boolean isExit(String filePath) {
		File apkFile = new File(filePath);
		return apkFile.exists();
	}
	
	/**
	 * 图像保存到文件中
	 * 
	 * @param bmp
	 * @param filename
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static String saveDrawableToFile(Context mContext, Bitmap bmp,
			String filename) throws IOException, FileNotFoundException {
		String path = null;
		if (filename != null && filename.contains("/")) {
			path = filename;
			File basePath = new File(Constants.BASE_PATH);
			if (!basePath.exists()) {
				basePath.mkdirs();
			}
		} else {
			path = Constants.BASE_PATH + "/" + filename;
			File basePath = new File(Constants.BASE_PATH);
			if (!basePath.exists()) {
				basePath.mkdirs();
			}
			File file = new File(path);
			if (file.exists()) {
				file.delete();
			}
		}
		FileOutputStream foutput = null;
		foutput = new FileOutputStream(path);
		bmp.compress(Bitmap.CompressFormat.JPEG, 100, foutput);

		foutput.close();
		// bmp.recycle();
		return path;
	}
	

	/**
	 * 追加文件：使用FileWriter
	 * 
	 * @param fileName
	 * @param content
	 */
	public static void writeMsgSdcard(String content, String path,
			String fileName, boolean isAdpend) {
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.mkdir();
			}
			// 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件
			FileWriter writer = new FileWriter(
					path + File.separator + fileName, isAdpend);
			if ("log.txt".equals(fileName)) {
				writer.write("\n\n" + content);
			} else {
				writer.write(content);
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * 读取文件内容
	 */
	public static String readMsgSdcard(String path, String fileName) {
		byte Buffer[] = new byte[1024];
		// 得到文件输入流
		File file = new File(path + File.separator + fileName);
		if (!file.exists()) {
			return "";
		}
		FileInputStream in = null;
		ByteArrayOutputStream outputStream = null;
		try {
			in = new FileInputStream(file);
			// 读出来的数据首先放入缓冲区，满了之后再写到字符输出流中
			int len = in.read(Buffer);
			// 创建一个字节数组输出流
			outputStream = new ByteArrayOutputStream();
			outputStream.write(Buffer, 0, len);
			// 把字节输出流转String
			return new String(outputStream.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (outputStream != null) {
				try {
					outputStream.flush();
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 删除文件
	 * 
	 * @param path
	 */
	public static void delFile(String path) {
		if (path == null) {
			return;
		}
		File file = new File(Environment.getExternalStorageDirectory() + path);
		if (file.exists()) {
			file.delete();
		}
	}

	/**
	 * 删除文件夹里的文件
	 */
	public static void deleteDirectory(File file) {
		if (file.isFile()) {
			file.delete();
			return;
		}
		if (file.isDirectory()) {
			File[] childFile = file.listFiles();
			if (childFile == null || childFile.length == 0) {
				file.delete();
				return;
			}
			for (File f : childFile) {
				deleteDirectory(f);
			}
			file.delete();
		}

	}

	/**
	 * 压缩文件
	 * 
	 * @param sourceFilePath
	 *            需要压缩的文件路径
	 * @param sourceFileName
	 *            压缩的文件名称
	 * @param toPath
	 *            压缩的文件生成路径
	 */
	public static void zipFile(String sourceFilePath,String sourceFileName,String toPath) throws FileNotFoundException,
			IOException {
		ZipOutputStream zipout = new ZipOutputStream(new BufferedOutputStream(
				new FileOutputStream(new File(toPath)), 1024 * 1024));
		sourceFilePath = new String(sourceFilePath.getBytes("8859_1"), HTTP.UTF_8);
		BufferedInputStream in = null;
		try {
			byte buffer[] = new byte[1024 * 1024];
			in = new BufferedInputStream(new FileInputStream(new File(sourceFilePath)),
					1024 * 1024);
			zipout.putNextEntry(new ZipEntry(sourceFileName));
			int realLength;
			while ((realLength = in.read(buffer)) != -1) {
				zipout.write(buffer, 0, realLength);
			}
			in.close();
			zipout.flush();
			zipout.closeEntry();
		} finally {
			if (in != null)
				in.close();
			if (zipout != null);
			 	zipout.close();
		}
	}

	/**
	 * 获取文件大小
	 * 
	 * @param path
	 * @return
	 * @throws Exception
	 */
	public static long getFileSize(String path) throws Exception {
		long s = 0;
		File f = new File(path);
		if (f.exists()) {
			FileInputStream fis = null;
			fis = new FileInputStream(f);
			s = fis.available();
		} else {
			f.createNewFile();
			System.out.println("文件不存在");
		}
		return s;
	}
	
	  // 递归取得文件夹（包括子目录）中所有文件的大小
    public static long getFileSize(File f)throws Exception//取得文件夹大小
    {
        long size = 0;
        File flist[] = f.listFiles();
        for (int i = 0; i < flist.length; i++)
        {
            if (flist[i].isDirectory())
            {
                size = size + getFileSize(flist[i]);
            } else
            {
                size = size + flist[i].length();
            }
        }
        return size;
    }
    public static String FormetFileSize(long fileS) {//转换文件大小
        DecimalFormat df = new DecimalFormat("#.00");
        String fileSizeString = "";
        if (fileS < 1024) {
            fileSizeString = df.format((double) fileS) + "B";
        } else if (fileS < 1048576) {
            fileSizeString = df.format((double) fileS / 1024) + "K";
        } else if (fileS < 1073741824) {
            fileSizeString = df.format((double) fileS / 1048576) + "M";
        } else {
            fileSizeString = df.format((double) fileS / 1073741824) + "G";
        }
        return fileSizeString;
    }
   
    public static long getlist(File f){//递归求取目录文件个数
        long size = 0;
        File flist[] = f.listFiles();
        size=flist.length;
        for (int i = 0; i < flist.length; i++) {
            if (flist[i].isDirectory()) {
                size = size + getlist(flist[i]);
                size--;
            }
        }
        return size;
    }
    public static long getDir(File f){//递归求取目录中文件（包括目录）的个数
        long size = 0;
        File flist[] = f.listFiles();
        size=flist.length;
        for (int i = 0; i < flist.length; i++) {
            if (flist[i].isDirectory()) {
                size = size + getDir(flist[i]);
               
            }
        }
        return size;
    }

    public static String getFileSizes(String path) throws Exception{
    	//取得文件大小
    	long l = 0;
    	  File ff = new File(Environment.getExternalStorageDirectory() + path);
          if (ff.isDirectory()) { //如果路径是文件夹的时候
              System.out.println("文件个数           " + getlist(ff));
              System.out.println("文件和目录总个数           " + getDir(ff));
          
              System.out.println("目录");
              l = getFileSize(ff);
              return FormetFileSize(l);
          } else {
              System.out.println("     文件个数           1");
              System.out.println("文件");
              l = getFileSize(ff);
              return FormetFileSize(l);
          }
    }

	/**
	 * 复制单个文件
	 * 
	 * @param oldPath
	 *            String 原文件路径 如：c:/fqf.txt
	 * @param newPath
	 *            String 复制后路径 如：f:/fqf.txt
	 * @return boolean
	 */
	public static void copyFile(String oldPath, String newPath) {
		try {
			int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(oldPath);
			if (oldfile.exists()) { // 文件存在时
				InputStream inStream = new FileInputStream(oldPath); // 读入原文件
				FileOutputStream fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				int length;
				while ((byteread = inStream.read(buffer)) != -1) {
					bytesum += byteread; // 字节数 文件大小
					System.out.println(bytesum);
					fs.write(buffer, 0, byteread);
				}
				inStream.close();
			}
		} catch (Exception e) {
			System.out.println("复制单个文件操作出错");
			e.printStackTrace();
		}
	}

}

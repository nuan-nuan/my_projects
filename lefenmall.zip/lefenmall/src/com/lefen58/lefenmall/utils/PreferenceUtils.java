package com.lefen58.lefenmall.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceUtils {
	
	
	private final static String strPreferName = "UserInfor";
		
	public static void writeStrConfig(String key, String value, Context context) {
		SharedPreferences.Editor editor = getSharedPreferences(context).edit();
		editor.putString(key, value);
		editor.commit();
	}

	public static String readStrConfig(String key, Context context) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getString(key, "");
	}

	public static String readStrConfig(String key, Context context, String defaultValue) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getString(key, defaultValue);
	}

	public static void writeLongConfig(String key, Long value, Context context) {
		SharedPreferences.Editor editor = getSharedPreferences(context).edit();
		editor.putLong(key, value);
		editor.commit();
	}

	public static Long readLongConfig(String key, Context context) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getLong(key, 0);
	}

	public static Long readLongConfig(String key, Context context, Long defaultValue) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getLong(key, defaultValue);
	}

	public static int readIntConfig(String key, Context context, int defaultValue) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getInt(key, defaultValue);
	}

	public static void writeIntConfig(String key, int value, Context context) {
		SharedPreferences.Editor editor = getSharedPreferences(context).edit();
		editor.putInt(key, value);
		editor.commit();
	}

	public static void writeBoolConfig(String key, Boolean value, Context context) {
		SharedPreferences.Editor editor = getSharedPreferences(context).edit();
		editor.putBoolean(key, value);
		editor.commit();
	}

	public static Boolean readBoolConfig(String key, Context context) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getBoolean(key, false);
	}

	public static Boolean readBoolConfig(String key, Context context, boolean defaultValue) {
		SharedPreferences settings = getSharedPreferences(context);
		return settings.getBoolean(key, defaultValue);
	}

	private static SharedPreferences getSharedPreferences(Context context) {
		SharedPreferences settings = context.getSharedPreferences(strPreferName, 0);
		return settings;
	}

	public static void RemoveStrConfig(String key, Context context) {
		SharedPreferences.Editor editor = getSharedPreferences(context).edit();
		editor.remove(key);
		editor.commit();
	}

}

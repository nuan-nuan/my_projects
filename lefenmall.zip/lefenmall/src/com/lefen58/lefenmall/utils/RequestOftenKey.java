package com.lefen58.lefenmall.utils;

import com.google.gson.Gson;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_user_info;
import com.lefen58.lefenmall.entity.User_info;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

import android.content.Context;
import android.content.SharedPreferences;

public class RequestOftenKey {
	
	static LogUtil Log = LogUtil.lLog();

	/**
	 * 网络请求常用Key
	 * 
	 */

	public static String getDeviceIndex(Context context){
		return PreferenceUtils.readStrConfig(Constants.SPKEY_DEVICE_INDEX, context);
	};

	public static String getToken(Context context){
		try {
			return String.valueOf(Long.valueOf(PreferenceUtils.readStrConfig(Constants.SPKEY_TOKEN, context))+Long.valueOf(PreferenceUtils.readStrConfig(Constants.SPKEY_SERVER_SALT, context)));
		} catch (NumberFormatException e) {
			return "";
		}
	};
	
	public static String gettoken(Context context){
			return PreferenceUtils.readStrConfig(Constants.SPKEY_TOKEN, context);
	};

	public static String getServerSalt(Context context){
		return PreferenceUtils.readStrConfig(Constants.SPKEY_SERVER_SALT, context);
	}
	public static void getUserInfor(final Context context,final SharedPreferences sp) {
	
		if (sp.getBoolean("state", false)) {
			HttpUtils http = new HttpUtils();
			RequestParams params = new RequestParams();
			params.addBodyParameter("c", "get_user_info");
			params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
			params.addBodyParameter("token", RequestOftenKey.getToken(context));
			http.send(HttpMethod.POST, Ip.url+"account.php",
					params, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					Log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					Log.i("infor"+ "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
					Gson gson = new Gson();
					Get_user_info get_user_info = gson.fromJson(arg0.result, Get_user_info.class);

					if (CommonUtils.NetworkRequestReturnCode(context, get_user_info.getCode())) {
						User_info user_info = gson.fromJson(get_user_info.getUser_info(), User_info.class);
						sp.edit().putString("phone", user_info.getPhone()).commit();
						sp.edit().putString("name", user_info.getName()).commit();
						sp.edit().putString("sex", user_info.getSex()).commit();
						sp.edit().putString("integral", user_info.getIntegral()).commit();
						sp.edit().putString("birthday", user_info.getBirthday()).commit();
						sp.edit().putString("provinceId", user_info.getProvince()).commit();
						sp.edit().putString("cityId", user_info.getCity()).commit();
						sp.edit().putString("district", user_info.getDistrict()).commit();
						sp.edit().putString("address", user_info.getAddress()).commit();
						sp.edit().putString("intro", user_info.getIntro()).commit();
						sp.edit().putString("photo", user_info.getPhoto()).commit();
						sp.edit().putString("card_index", user_info.getCard_index()).commit();
						sp.edit().putString("card_name", user_info.getCard_name()).commit();
						sp.edit().putBoolean("pay_password", user_info.getPay_password()).commit();
						sp.edit().putBoolean("login_password", user_info.getLogin_password()).commit();
					}  

				}
			});
		}
	}

}

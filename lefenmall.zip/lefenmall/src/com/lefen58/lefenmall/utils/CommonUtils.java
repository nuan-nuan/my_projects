package com.lefen58.lefenmall.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class CommonUtils {

	public static void showInfoDialog(Context context, String message) {
		showInfoDialog(context, message, "提示", "确定", null);
	}

	public static void showInfoDialog(Context context, String message,
			String titleStr, String positiveStr,
			DialogInterface.OnClickListener onClickListener) {
		AlertDialog.Builder localBuilder = new AlertDialog.Builder(context);
		localBuilder.setTitle(titleStr);
		localBuilder.setMessage(message);
		if (onClickListener == null)
			onClickListener = new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

			}
		};
		localBuilder.setPositiveButton(positiveStr, onClickListener);
		localBuilder.show();
	}

	/**
	 *  服务区返回状态码
	 * @param context 上下文
	 * @param Code 返回码
	 */
	public static Boolean NetworkRequestReturnCode(Context context,String code){

		switch (code) {
		case "1":
			return true;
		case "-1":
			Toast.makeText(context, "操作频繁,请稍后", Toast.LENGTH_SHORT).show();
			return false;
		case "-2":
			Toast.makeText(context, "系统限制", Toast.LENGTH_SHORT).show();
			return false;
		case "-3":
			Toast.makeText(context, "系统繁忙", Toast.LENGTH_SHORT).show();
			return false;
		case "-4":
			Toast.makeText(context, "登录状态失效", Toast.LENGTH_SHORT).show();
			context.getSharedPreferences("UserInfor", 0 ).edit().putBoolean("state", false).commit();
			FileUtils.delFile("/com.lefen58/userphoto/userphoto.png");
			return false;
		case "-5":
			Toast.makeText(context, "密码验证失败", Toast.LENGTH_SHORT).show();
			return false;
		case "-6":
			Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
			return false;
		case "-12":
			Toast.makeText(context, "数据已存在", Toast.LENGTH_SHORT).show();
			return false;
		case "-13":
			Toast.makeText(context, "余额不足", Toast.LENGTH_SHORT).show();
			return false;
		case "-14":
			Toast.makeText(context, "订单失效", Toast.LENGTH_SHORT).show();
			return false;
		case "-15":
			Toast.makeText(context, "验证时间过长，请返回上一界面重新获取验证码", Toast.LENGTH_SHORT).show();
			return false;
		case "-16":
			Toast.makeText(context, "手机号未注册", Toast.LENGTH_SHORT).show();
			return false;
		case "-21":
			Toast.makeText(context, "没有数据了", Toast.LENGTH_SHORT).show();
			return false;
		case "-22":
			Toast.makeText(context, "活动已结束", Toast.LENGTH_SHORT).show();
			return false;
		case "-23":
			Toast.makeText(context, "设备ID验证失败", Toast.LENGTH_SHORT).show();
			return false;
		case "-24":
			Toast.makeText(context, "盐验证失败", Toast.LENGTH_SHORT).show();
			return false;
		case "-25":
			Toast.makeText(context, "该身份证信息已认证", Toast.LENGTH_SHORT).show();
			return false;
		}
		return false;

	}

	public static int getStatusBarHeight(Context context) {
		int result = 0;
		int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			result = context.getResources().getDimensionPixelSize(resourceId);
		}
		return result;
	}

	public static boolean passwordVerify(String str) {   
		String str1 = "([0-9](?=[0-9]*?[a-zA-Z])\\w{5,17})|([a-zA-Z](?=[a-zA-Z]*?[0-9])\\w{5,17})";
		return str.matches(str1);
	} 

	public static String md5(String paramString) {
		String returnStr;
		try {
			MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
			localMessageDigest.update(paramString.getBytes());
			returnStr = byteToHexString(localMessageDigest.digest());
			return returnStr;
		} catch (Exception e) {
			return paramString;
		}
	}

	/**
	 * 将指定byte数组转换成16进制字符串
	 * 
	 * @param b
	 * @return
	 */
	public static String byteToHexString(byte[] b) {
		StringBuffer hexString = new StringBuffer();
		for (int i = 0; i < b.length; i++) {
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			hexString.append(hex.toUpperCase());
		}
		return hexString.toString();
	}

	/**
	 * 判断当前是否有可用的网络以及网络类型 0：无网络 1：WIFI 2：CMWAP 3：CMNET
	 * 
	 * @param context
	 * @return  0：无网络 1：WIFI 2：CMWAP 3：CMNET
	 */
	public static int isNetworkAvailable(Context context){
		ConnectivityManager connectivity = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			return 0;
		} else {
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null) {
				for (int i = 0; i < info.length; i++) {
					if (info[i].getState() == NetworkInfo.State.CONNECTED) {
						NetworkInfo netWorkInfo = info[i];
						if (netWorkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
							return 1;
						} else if (netWorkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
							String extraInfo = netWorkInfo.getExtraInfo();
							if ("cmwap".equalsIgnoreCase(extraInfo)
									|| "cmwap:gsm".equalsIgnoreCase(extraInfo)) {
								return 2;
							}
							return 3;
						}
					}
				}
			}
		}
		return 0;
	}


	/**
	 * 获取现在时间
	 * 
	 * @return 返回短时间字符串格式yyyy-MM-dd HH:mm:ss
	 */

	public static String getStringDate() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(currentTime);
		return dateString;
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	public static int getScreenPicHeight(int screenWidth, Bitmap bitmap) {
		int picWidth = bitmap.getWidth();
		int picHeight = bitmap.getHeight();
		int picScreenHeight = 0;
		picScreenHeight = (screenWidth * picHeight) / picWidth;
		return picScreenHeight;
	}

	/**
	 * 
	 * @param context
	 * @param button
	 * @param nornalImageFileName
	 * @param pressedImageFileName
	 * @throws Exception
	 */
	public static void bindViewSelector(Context context, final View view,
			String nornalImageurl, final String pressedImageUrl) {
		final StateListDrawable stateListDrawable = new StateListDrawable();
		final BitmapUtils utils = new BitmapUtils(context);
		utils.display(view, nornalImageurl, new BitmapLoadCallBack<View>() {

			@Override
			public void onLoadCompleted(View container, String uri,
					Bitmap bitmap, BitmapDisplayConfig config,
					BitmapLoadFrom from) {
				Drawable normalDrawable = new BitmapDrawable(bitmap);
				stateListDrawable.addState(
						new int[] { android.R.attr.state_active },
						normalDrawable);
				stateListDrawable.addState(new int[] {
						android.R.attr.state_focused,
						android.R.attr.state_enabled }, normalDrawable);
				stateListDrawable.addState(
						new int[] { android.R.attr.state_enabled },
						normalDrawable);
				utils.display(container, pressedImageUrl,
						new BitmapLoadCallBack<View>() {

					@Override
					public void onLoadCompleted(View container,
							String uri, Bitmap bitmap,
							BitmapDisplayConfig config,
							BitmapLoadFrom from) {
						stateListDrawable.addState(new int[] {
								android.R.attr.state_pressed,
								android.R.attr.state_enabled },
								new BitmapDrawable(bitmap));

						view.setBackgroundDrawable(stateListDrawable);

					}

					@Override
					public void onLoadFailed(View container,
							String uri, Drawable drawable) {
						// TODO Auto-generated method stub

					}
				});
			}

			@Override
			public void onLoadFailed(View container, String uri,
					Drawable drawable) {

			}
		});

	}

	public static boolean isPhoneNumer(String mobiles){
		//String telRegex = "[1][358]\\d{9}";//"[1]"代表第1位为数字1，"[358]"代表第二位可以为3、5、8中的一个，"\\d{9}"代表后面是可以是0～9的数字，有9位。  
		String telRegex = "^((145|147)|(15[^4])|(17[6-8])|((13|18)[0-9]))\\d{8}$";//"[1]"代表第1位为数字1，"[358]"代表第二位可以为3、5、8中的一个，"\\d{9}"代表后面是可以是0～9的数字，有9位。  
		if (TextUtils.isEmpty(mobiles)) return false;  
		else return mobiles.matches(telRegex);  
	}

	public static String getMD5Str(String str) {       
		MessageDigest messageDigest = null;       
		try {       
			messageDigest = MessageDigest.getInstance("MD5");       

			messageDigest.reset();       

			messageDigest.update(str.getBytes("UTF-8"));       
		} catch (NoSuchAlgorithmException e) {       
			System.out.println("NoSuchAlgorithmException caught!");       
			System.exit(-1);       
		} catch (UnsupportedEncodingException e) {       
			e.printStackTrace();       
		}       

		byte[] byteArray = messageDigest.digest();       

		StringBuffer md5StrBuff = new StringBuffer();       

		for (int i = 0; i < byteArray.length; i++) {                   
			if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)       
				md5StrBuff.append("0").append(Integer.toHexString(0xFF & byteArray[i]));       
			else       
				md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));       
		}       
		//16位加密，从第9位到25位  
		return md5StrBuff.substring(8, 24).toString().toUpperCase();      
	}    


	private static Drawable createDrawable(Drawable d, Paint p) {

		BitmapDrawable bd = (BitmapDrawable) d;
		Bitmap b = bd.getBitmap();
		Bitmap bitmap = Bitmap.createBitmap(bd.getIntrinsicWidth(),
				bd.getIntrinsicHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		canvas.drawBitmap(b, 0, 0, p); // 关键代码，使用新的Paint画原图，

		return new BitmapDrawable(bitmap);
	}

	/** 设置Selector。 本次只增加点击变暗的效果，注释的代码为更多的效果 */
	public static StateListDrawable createSLD(Context context, Drawable drawable) {
		StateListDrawable bg = new StateListDrawable();
		int brightness = 50 - 127;
		ColorMatrix cMatrix = new ColorMatrix();
		cMatrix.set(new float[] { 1, 0, 0, 0, brightness, 0, 1, 0, 0,
				brightness,// 改变亮度
				0, 0, 1, 0, brightness, 0, 0, 0, 1, 0 });

		Paint paint = new Paint();
		paint.setColorFilter(new ColorMatrixColorFilter(cMatrix));

		Drawable normal = drawable;
		Drawable pressed = createDrawable(drawable, paint);
		bg.addState(new int[] { android.R.attr.state_pressed, }, pressed);
		bg.addState(new int[] { android.R.attr.state_focused, }, pressed);
		bg.addState(new int[] { android.R.attr.state_selected }, pressed);
		bg.addState(new int[] {}, normal);
		return bg;
	}

	public static Bitmap getImageFromAssetsFile(Context ct, String fileName) {
		Bitmap image = null;
		AssetManager am = ct.getAssets();
		try {
			InputStream is = am.open(fileName);
			image = BitmapFactory.decodeStream(is);
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return image;

	}

	//	public static <Params, Progress, Result> void executeAsyncTask(
	//			AsyncTask<Params, Progress, Result> task, Params... params) {
	//		if (Build.VERSION.SDK_INT >= 11) {
	//			task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, params);
	//		} else {
	//			task.execute(params);
	//		}
	//	}

	public static String getUploadtime(long created) {
		StringBuffer when = new StringBuffer();
		int difference_seconds;
		int difference_minutes;
		int difference_hours;
		int difference_days;
		int difference_months;
		long curTime = System.currentTimeMillis();
		difference_months = (int) (((curTime / 2592000) % 12) - ((created / 2592000) % 12));
		if (difference_months > 0) {
			when.append(difference_months + "月");
		}

		difference_days = (int) (((curTime / 86400) % 30) - ((created / 86400) % 30));
		if (difference_days > 0) {
			when.append(difference_days + "天");
		}

		difference_hours = (int) (((curTime / 3600) % 24) - ((created / 3600) % 24));
		if (difference_hours > 0) {
			when.append(difference_hours + "小时");
		}

		difference_minutes = (int) (((curTime / 60) % 60) - ((created / 60) % 60));
		if (difference_minutes > 0) {
			when.append(difference_minutes + "分钟");
		}

		difference_seconds = (int) ((curTime % 60) - (created % 60));
		if (difference_seconds > 0) {
			when.append(difference_seconds + "秒");
		}

		return when.append("前").toString();
	}

	//	public static boolean hasToken(Context ct) {
	//		String token = SharePrefUtil.getString(ct, "token", "");
	//		if (TextUtils.isEmpty(token)) {
	//			return false;
	//		} else {
	//			return true;
	//		}
	//	}

	public static void setListViewHeightBasedOnChildren(ListView listView) {
		// 获取ListView对应的Adapter
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) { // listAdapter.getCount()返回数据项的数目
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0); // 计算子项View 的宽高
			totalHeight += listItem.getMeasuredHeight(); // 统计所有子项的总高度
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		// listView.getDividerHeight()获取子项间分隔符占用的高度
		// params.height最后得到整个ListView完整显示需要的高度
		listView.setLayoutParams(params);
	}

	public static String formatDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		return sdf.format(new Date());
	}

	public static String getStr(String[]args){
		String str="";
		for(int i=0;i<args.length;i++){	
			str+=(String)args[i];
		}	
		return str;
	}

	/**
	 * 判断 String 是否相同
	 * @param str
	 * @return 结果
	 */
	public static boolean verification(String str){
		char s = str.charAt(0);
		for (int i = 1; i < str.length() && i < 8; i++) {
			if (s!=str.charAt(i)) {
				return true;	
			}
		}
		return false;
	}
	/**
	 * 获取状态栏高度
	 * @param activity
	 * @return
	 */
	public static int getStatusHeight(Activity activity){
		int statusHeight = 0;
		Rect localRect = new Rect();
		activity.getWindow().getDecorView(
				).getWindowVisibleDisplayFrame(localRect);
		statusHeight = localRect.top;
		if (0 == statusHeight){
			Class<?> localClass;
			try {
				localClass = Class.forName(
						"com.android.internal.R$dimen");
				Object localObject = localClass.newInstance();
				int i5 = Integer.parseInt(
						localClass.getField("status_bar_height").get(
								localObject).toString());
				statusHeight = activity.getResources(
						).getDimensionPixelSize(i5);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			}
		}
		return statusHeight;
	}

	public static int getHeight(Activity activity,String s){
		DisplayMetrics metric = new DisplayMetrics();
		activity.getWindowManager().getDefaultDisplay().getMetrics(metric);
		int height = metric.heightPixels;   // 屏幕高度（像素）
		int w = metric.widthPixels;
		if (s.equals("h")) {
			return height;
		}else {
			return w;
		}

	}
	
	/**
	 * 
	 * @description 获取app versionName
	 * @param context
	 * @return String
	 * @throws NameNotFoundException
	 */
	public static String getAppVersion(Context context){
			PackageManager packageManager = context.getPackageManager();
			// getPackageName()是你当前类的包名，0代表是获取版本信息
			PackageInfo packInfo;
			try {
				packInfo = packageManager.getPackageInfo(
						context.getPackageName(), 0);
				return packInfo.versionName;
			} catch (NameNotFoundException e) {
				// TODO Auto-generated catch block
				return "";
			}
	}

}

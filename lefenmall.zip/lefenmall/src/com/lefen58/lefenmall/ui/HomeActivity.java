package com.lefen58.lefenmall.ui;

import java.util.Timer;
import java.util.TimerTask;

import com.igexin.sdk.PushManager;
import com.lefen58.lefenmall.AppManager;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.ui.MainActivity.ChangePageListener;
import com.lefen58.lefenmall.utils.PreferenceUtils;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends TabActivity {

	public static final String TAG = HomeActivity.class.getSimpleName();
	
	private static TabHost mTabHost;

	private RadioGroup mTabButtonGroup;
	private static RadioButton home_tab_nearby;
	private static RadioButton home_tab_main;
	private static RadioButton home_tab_shangcheng;
	
	public static final String TAB_MAIN = "MAIN_ACTIVITY";
	public static final String TAB_NEAR = "NEAR_ACTIVITY";
	public static final String TAB_SHANGCHENG = "SHANGCHENG_ACTIVITY";
	public static final String TAB_LEXIN = "LEXIN_ACTIVITY";
	public static final String TAB_PERSONAL = "USERINFOR_ACTIVITY";

	public static void getInstance() {
		mTabHost.setCurrentTabByTag(TAB_MAIN);
		home_tab_main.setChecked(true);
	}

	public static ChangePageListener mChangePageListener = new ChangePageListener() {

		@Override
		public void changeListener() {
			mTabHost.setCurrentTabByTag(TAB_NEAR);
			home_tab_nearby.setChecked(true);
		}
	};

	public static ChangePageListener ChangePageListener = new ChangePageListener() {

		@Override
		public void changeListener() {
			mTabHost.setCurrentTabByTag(TAB_SHANGCHENG);
			home_tab_shangcheng.setChecked(true);
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// //透明状态栏
		// getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		// //透明导航栏
		// getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		AppManager.getInstance().addActivity(this);
		setContentView(R.layout.activity_home);
		findViewById();
		initView();
		PushManager.getInstance().initialize(this.getApplicationContext());
		PushManager.getInstance().getClientid(this.getApplicationContext());
		Log.i("infor", "Clientid=" + PushManager.getInstance().getClientid(this.getApplicationContext()));

		try {
			String given = HomeActivity.this.getSharedPreferences("UserInfor", 0).getString("given_integral", "0");
			if (!given.equals("0")) {
				final Dialog dialog = new Dialog(this, R.style.Dialog);
				View view = View.inflate(this, R.layout.dialog_given_jifen, null);
				WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
				lp.dimAmount = 1f;
				dialog.getWindow().setAttributes(lp);
				dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
				dialog.setContentView(view);
				TextView tv_huodejifen = (TextView) view.findViewById(R.id.tv_huodejifen);
				tv_huodejifen.setText(given);
				TextView tv_huodejifen2 = (TextView) view.findViewById(R.id.tv_huodejifen2);
				tv_huodejifen2.setText("恭喜您！获得" + given + "乐分");
				dialog.show();
				view.findViewById(R.id.btn).setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.cancel();
						HomeActivity.this.getSharedPreferences("UserInfor", 0).edit().putString("given_integral", "0").commit();
					}
				});
				
				PreferenceUtils.writeStrConfig("given_integral", "0", this);
			}

		} catch (NullPointerException e) {
			Log.i("info", "");

		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		try {
			String given = HomeActivity.this.getSharedPreferences("UserInfor", 0).getString("given_integral", "0");
			if (!given.equals("0")) {
				final Dialog dialog = new Dialog(this, R.style.Dialog);
				View view = View.inflate(this, R.layout.dialog_given_jifen, null);
				WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
				lp.dimAmount = 1f;
				dialog.getWindow().setAttributes(lp);
				dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
				dialog.setContentView(view);
				TextView tv_huodejifen = (TextView) view.findViewById(R.id.tv_huodejifen);
				tv_huodejifen.setText(given);
				TextView tv_huodejifen2 = (TextView) view.findViewById(R.id.tv_huodejifen2);
				tv_huodejifen2.setText("恭喜您！获得" + given + "乐分");
				dialog.show();
				view.findViewById(R.id.btn).setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.cancel();
						HomeActivity.this.getSharedPreferences("UserInfor", 0).edit().putString("given_integral", "0")
								.commit();
					}
				});
				
				PreferenceUtils.writeStrConfig("given_integral", "0", this);
			}

		} catch (NullPointerException e) {
			Log.i("info", "");

		}
	}

	private void findViewById() {
		mTabButtonGroup = (RadioGroup) findViewById(R.id.home_radio_button_group);
		home_tab_nearby = (RadioButton) findViewById(R.id.home_tab_nearby);
		home_tab_main = (RadioButton) findViewById(R.id.home_tab_main);
		home_tab_shangcheng = (RadioButton) findViewById(R.id.home_tab_shangcheng);
	}

	private void initView() {

		mTabHost = getTabHost();

		Intent i_main = new Intent(this, MainActivity.class);//首页
		Intent i_near = new Intent(this, NearActivity.class);//附近
		Intent i_shangcheng = new Intent(this, MallActivity.class);//商城
		Intent i_lexin = new Intent(this, ActivityLeXin.class);//乐信
		Intent i_userinfor = new Intent(this, UserInforActivity.class);//我的
		

		mTabHost.addTab(mTabHost.newTabSpec(TAB_MAIN).setIndicator(TAB_MAIN).setContent(i_main));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_NEAR).setIndicator(TAB_NEAR).setContent(i_near));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_SHANGCHENG).setIndicator(TAB_SHANGCHENG).setContent(i_shangcheng));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_LEXIN).setIndicator(TAB_LEXIN).setContent(i_lexin));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_PERSONAL).setIndicator(TAB_PERSONAL).setContent(i_userinfor));

		
		mTabHost.setCurrentTabByTag(TAB_MAIN);

		mTabButtonGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				switch (checkedId) {
				case R.id.home_tab_main:
					mTabHost.setCurrentTabByTag(TAB_MAIN);
					break;

				case R.id.home_tab_nearby:
					mTabHost.setCurrentTabByTag(TAB_NEAR);
					break;
					
				case R.id.home_tab_shangcheng:
					mTabHost.setCurrentTabByTag(TAB_SHANGCHENG);
					break;

				case R.id.home_tab_lexin:
					mTabHost.setCurrentTabByTag(TAB_LEXIN);
					break;

				case R.id.home_tab_userinfor:
					mTabHost.setCurrentTabByTag(TAB_PERSONAL);
					break;
				default:
					break;
				}
			}
		});
	}

	/** ���б��⡢���ݡ�������ť�ĶԻ��� **/
	protected void showAlertDialog(String title, String message, String positiveText,
			DialogInterface.OnClickListener onPositiveClickListener, String negativeText,
			DialogInterface.OnClickListener onNegativeClickListener) {
		new AlertDialog.Builder(this).setTitle(title).setMessage(message)
				.setPositiveButton(positiveText, onPositiveClickListener)
				.setNegativeButton(negativeText, onNegativeClickListener).show();
	}

	/**
	 * 设置添加屏幕的背景透明度
	 * 
	 * @param bgAlpha
	 */
	public void backgroundAlpha(float bgAlpha) {
		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.alpha = bgAlpha; // 0.0-1.0
		getWindow().setAttributes(lp);
	}

	private static Boolean isExit = false;

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		// TODO Auto-generated method stub
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			exitBy2Click();
		}
		return true;
	}

	private void exitBy2Click() {
		Timer tExit = null;
		if (isExit == false) {
			isExit = true; // 准备退出
			Toast.makeText(this, "再按一次返回,退出程序", Toast.LENGTH_SHORT).show();
			tExit = new Timer();
			tExit.schedule(new TimerTask() {
				@Override
				public void run() {
					isExit = false; // 取消退出
				}
			}, 2000); // 如果2秒钟内没有按下返回键，则启动定时器取消掉刚才执行的任务
		} else {
			AppManager.getInstance().AppExit(this);
		}
	}

}

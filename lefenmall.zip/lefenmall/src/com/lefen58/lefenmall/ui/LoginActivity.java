package com.lefen58.lefenmall.ui;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.entity.RegisterAccount;
import com.lefen58.lefenmall.http.AccountNetRequest;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.PreferenceUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends BaseActivity {

	@ViewInject(R.id.etphone)
	private EditText etphone;

	@ViewInject(R.id.etpassword)
	private EditText etpassword;

	AccountNetRequest netRequest;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//		 // 创建状态栏的管理实例  
		//	    SystemBarTintManager tintManager = new SystemBarTintManager(this);  
		//	    // 激活状态栏设置  
		//	    tintManager.setStatusBarTintEnabled(true);  
		//	    // 激活导航栏设置  
		//	    tintManager.setNavigationBarTintEnabled(true);  

		setContentView(R.layout.activity_login);
		ViewUtils.inject(this);
		netRequest = new AccountNetRequest(context);
	}

	public void onBack(View view){
		onBackPressed();
	}

	public void login(final View view){
		// 登陆
		if (!CommonUtils.passwordVerify(etpassword.getText().toString())) {
			Toast.makeText(LoginActivity.this, "密码不符合规则", Toast.LENGTH_SHORT).show();
			return;
		}

		startMyDialog();
		String password=CommonUtils.getMD5Str(etpassword.getText().toString())
				+CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(context));
		log.i("登陆时发送的盐"+RequestOftenKey.getServerSalt(context));
		netRequest.login(etphone.getText().toString(), password.toLowerCase(), RegisterAccount.class, new RequestCallBack<RegisterAccount>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
			}

			@Override
			public void onSuccess(ResponseInfo<RegisterAccount> arg0) {
				
				switch (arg0.result.code) {
				case 0:
					stopMyDialog();
					showToast("异常");
					break;
				
				case 1:
					stopMyDialog();
					PreferenceUtils.writeStrConfig(Constants.SPKEY_TOKEN, arg0.result.token, context);
					PreferenceUtils.writeBoolConfig(Constants.SPKEY_STATE, true, context);
					PreferenceUtils.writeStrConfig(Constants.SPKEY_PHONE, etphone.getText().toString(), context);
					RequestOftenKey.getUserInfor(context, sp);
					startActivity(new Intent(context, HomeActivity.class));
					finish();
					break;
				case -16:
					stopMyDialog();
					showToast("改手机号还未注册,请注册后登陆");
					break;
				case -5:
					stopMyDialog();
					showToast("密码验证失败");
					break;
				case -3:

					new Thread(new Runnable() {
						public void run() {
							try {
								Thread.sleep(5000);
								login(view);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}).start();
					break;

				}
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
				showToast("网络异常，请检查网络后重新登录");
			}
		});

	}

	// 去注册界面
	public void toRegistered(View view){
		startActivity(new Intent(LoginActivity.this, RegisteredActivity.class));
		finish();
	}
	// 手机快捷登陆界面
	public void phoneLogin(View view){
		Log.i("infor", "手机快捷登陆界面");
		startActivity(new Intent(LoginActivity.this, PhoneLoginActivity.class));
		finish();
	}
	// 找回密码
	public void backPassword(View view){
		Intent intent = new Intent(LoginActivity.this, RetrievePasswordActivity.class);
		intent.putExtra("title", "找回密码");
		startActivity(intent);
	}

}

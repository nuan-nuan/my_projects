package com.lefen58.lefenmall.ui;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.NearDataAdapter;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.AreaInfo;
import com.lefen58.lefenmall.entity.FilialeList;
import com.lefen58.lefenmall.entity.MerchantList;
import com.lefen58.lefenmall.entity.NearDataBase;
import com.lefen58.lefenmall.entity.NearDataFiliale;
import com.lefen58.lefenmall.entity.NearDataMerchant;
import com.lefen58.lefenmall.entity.StoreAllList;
import com.lefen58.lefenmall.entity.StoreClass;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.MyLoading;
import com.lefen58.lefenmall.widgets.NoScrollListview;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.pulltorefresh.library.PullToRefreshBase;
import com.pulltorefresh.library.PullToRefreshBase.Mode;
import com.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.pulltorefresh.library.PullToRefreshScrollView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

public class NearActivity extends BaseActivity{

	/**
	 * 附近
	 */
	private LogUtil log = LogUtil.lLog();

	@ViewInject(R.id.radio_area_select)
	private CheckBox checkBoxAreaSelect;

	@ViewInject(R.id.radio_store_class)
	private CheckBox checkBoxStoreClass;

	@ViewInject(R.id.imgView_no_date)
	ImageView mImgNoData;

	private PopupWindow storeClassPopupWindow;

	private PopupWindow areaPopupWindow;

	private PopupWindow storePopupWindow;

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	@ViewInject(R.id.ll_check_box)
	private LinearLayout llCheckBox;

	ArrayList<AreaInfo> county ;

	ArrayList<StoreClass> storeClasses;
	ArrayList<StoreClass> stores;

	ArrayList<MerchantList> merchantLists;

	ArrayList<FilialeList> filialeLists;

	private NearDataAdapter nearDataAdapter;

	ArrayList<NearDataBase> mData;

	private HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
	private HashMap<Integer, Integer> mapStores = new HashMap<Integer, Integer>();
	private HashMap<Integer, Integer> mapStoreClasss = new HashMap<Integer, Integer>();
	static int i;

	private int pageIndex=0;

	@ViewInject(R.id.lv_near_data)
	private ListView lvNearData;

	@ViewInject(R.id.refreshable_view)
	private PullToRefreshScrollView refreshable_view;

	private static SharedPreferences sp;

	// 商家类型 的背景数组
	private int[] mStoreClass = { 
			R.drawable.near_store_class_onclick_all_class, // 全部分类
			//R.drawable.near_store_class_onclick_duihuan, // 兑换中心
			R.drawable.near_store_class_onclick_food, // 美食
			R.drawable.near_store_class_onclick_play, // 休闲娱乐
			R.drawable.near_store_class_onclick_hotel, // 酒店
			R.drawable.near_store_class_onclick_life_service, // 生活服务
			R.drawable.near_store_class_onclick_meirong, // 美容
			R.drawable.near_store_class_onclick_baihuo, // 百货
			R.drawable.near_store_class_onclick_furniture, // 家具房产
			R.drawable.near_store_class_onclick_education, // 学习培训
			R.drawable.near_store_class_onclick_car, // 汽车
			R.drawable.near_store_class_onclick_other}; // 其他

	private MyLoading myloading;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_near);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		MyLoading.createLoadingDialog(NearActivity.this);
		this.mData = new ArrayList<NearDataBase>();
		Listener();
		getStoreData();

		//		refreshable_view.setOnRefreshListener(new PullToRefreshListener() {
		//
		//			@Override
		//			public void onRefresh() {
		//				getStoreData();
		//			}
		//		}, 0);
		refreshable_view.setMode(Mode.BOTH);
		refreshable_view.getLoadingLayoutProxy(true, false).setPullLabel("下拉刷新");
		refreshable_view.getLoadingLayoutProxy(false, true).setPullLabel("上拉加载更多");
		refreshable_view.setOnRefreshListener(new OnRefreshListener2<ScrollView>() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				pageIndex=0;
				getStoreData();
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				getStoreData();
			}
		});

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if (merchantLists!=null) {
			if (merchantLists.size()>0) {
				getStoreData();
			}
		}
	}

	private void Listener() {

		// listview 点击事件
		lvNearData.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				int itemType = nearDataAdapter.getItemViewType(position);
				log.i(itemType);
				Intent intent = new Intent(NearActivity.this, MerchantActivity.class);
				intent.putExtra("itemType", itemType+"");
				intent.putExtra("merchant_id", itemType==1?
						((NearDataFiliale)mData.get(position)).getFilialeList().getShop_index():
							((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_id()
						);
				startActivity(intent);

			}
		});

		//商家分类
		checkBoxStoreClass.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					checkBoxAreaSelect.setChecked(false);
					getStoreClassPopupWindow();
					storeClassPopupWindow.showAtLocation(llCheckBox, Gravity.TOP, -(llCheckBox.getWidth()/2), tvBack.getHeight()+llCheckBox.getHeight()+CommonUtils.getStatusBarHeight(NearActivity.this));

				}
			}
		});

		//区域选择
		checkBoxAreaSelect.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					startMyDialog();
					new Thread(
							new Runnable() {
								public void run() {
									checkBoxStoreClass.setChecked(false);
									getAreaPopupWindow(llCheckBox.getWidth());
									runOnUiThread(new Runnable() {
										public void run() {
											areaPopupWindow.showAtLocation(llCheckBox, Gravity.TOP,-(llCheckBox.getWidth()/2), tvBack.getHeight()+llCheckBox.getHeight()+CommonUtils.getStatusBarHeight(NearActivity.this));
										}
									});
								}
							}).start();
				}
			}
		});
	}

	/**
	 * 获取商家分类的popupwindow
	 */
	private void getStoreClassPopupWindow() {
		if (null != storeClassPopupWindow) {  
			storeClassPopupWindow.dismiss();  
			return;  
		} else {  
			initStoreClassPopuptWindow();  
		}

	}


	/**
	 * 搜索
	 */
	public void find(View view){
		Intent intent = new Intent(NearActivity.this, FindActivity.class);
		intent.putExtra("flag", "g");
		startActivity(intent);
	}


	/**
	 * 商家分类的popupwindow
	 */
	private void initStoreClassPopuptWindow() {  
		final JSONArray js;
		try {
			// 获取 assets 文件 （商家类型数据源）
			InputStream is = getResources().getAssets().open("config_industry.json");
			byte [] buffer = new byte[is.available()] ; 
			is.read(buffer);
			String json = new String(buffer,"utf-8");

			storeClasses = new ArrayList<StoreClass>();
			js = new JSONArray(json);
			Gson gson = new Gson();
			// 取前12位。判断前12为的getIndustry_name() 是否小于0
			for (int i = 0; i < 12; i++) {
				if (gson.fromJson(js.getJSONObject(i).toString(), StoreClass.class).getIndustry_parent().equals("0")) {
					storeClasses.add(gson.fromJson(js.getJSONObject(i).toString(),StoreClass.class));
					log.e("desp============0++"+gson.fromJson(js.getJSONObject(i).toString(),StoreClass.class).getIndustry_name());
				}
			}


			// TODO Auto-generated method stub  
			// 获取自定义布局文件popupwindow_amenduserphoto.xml的视图  
			View popupWindow_view = getLayoutInflater().inflate(R.layout.popupwindow_near_two, null, false);  
			// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
			NoScrollListview lv_storeClasses = (NoScrollListview) popupWindow_view.findViewById(R.id.lv_popup_two);
			final NoScrollListview lv_stores = (NoScrollListview) popupWindow_view.findViewById(R.id.lv_popup_stors);
			final LvStoreClasseAdapter lvStoreClassAdapter = new LvStoreClasseAdapter(NearActivity.this, storeClasses,mStoreClass);
			final TextView tvPopupLocationDescribe = (TextView) popupWindow_view.findViewById(R.id.tv_popup_locationdescribe);
			//			tvPopupLocationDescribe.setText(sp.getString("locationdescribe", "定位失败！"));
			lv_storeClasses.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, final int arg2,
						long arg3) {
					RadioHolder holder = new RadioHolder(arg1);
					holder.radioStoreClasss.setChecked(true);
					mapStoreClasss.clear();
					mapStoreClasss.put(arg2, 100);
					lvStoreClassAdapter.notifyDataSetChanged();
					pageIndex = 0;
					mapStores.clear();
					
					if (arg2==0) {
						lv_stores.setVisibility(View.INVISIBLE);
						sp.edit().putString("industry_top", "0").commit();
						sp.edit().putString("industry_son", "0").commit();
						
						getStoreData();
						storeClassPopupWindow.dismiss();
						checkBoxStoreClass.setChecked(false);
					} else {
						 log.d("............>>>>>>>>>>>>>>>点击");
						lv_stores.setVisibility(View.VISIBLE);
						//storePopupWindow.showAtLocation(llCheckBox, Gravity.TOP,(llCheckBox.getWidth()/2), tvBack.getHeight()+llCheckBox.getHeight()+CommonUtils.getStatusBarHeight(NearActivity.this));
						Gson gson = new Gson();
						// 取前12位。判断前12为的getIndustry_name() 是否小于0
						try {
							stores = new ArrayList<StoreClass>();
							stores.clear();
							for (int i = 11; i < js.length(); i++) {
								if (gson.fromJson(js.getJSONObject(i).toString(), StoreClass.class).getIndustry_parent().equals(storeClasses.get(arg2).getIndustry_id())) {
									stores.add(gson.fromJson(js.getJSONObject(i).toString(),StoreClass.class));
								}
							}
							final StoreAdapter lvStoreAdapter = new StoreAdapter(NearActivity.this, stores);
							lv_stores.setAdapter(lvStoreAdapter);

							lv_stores.setOnItemClickListener(new OnItemClickListener() {

								@Override
								public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
									pageIndex = 0;
									mapStores.clear();
									mapStores.put(position, 100);
									lvStoreAdapter.notifyDataSetChanged();
									sp.edit().putString("industry_top", stores.get(position).getIndustry_parent()).commit();
									sp.edit().putString("industry_son", stores.get(position).getIndustry_id()).commit();
									sp.edit().putString("sotre_type", "1").commit();

									storeClassPopupWindow.dismiss();
									checkBoxStoreClass.setChecked(false);
									getStoreData();
								}
							});

						} catch (JsonSyntaxException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							stores.clear();
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							stores.clear();
						}

					}
				}
			});


			storeClassPopupWindow = new PopupWindow(popupWindow_view, llCheckBox.getWidth(), LayoutParams.WRAP_CONTENT, true); 
			// 设置动画效果  
			//popupWindow.setAnimationStyle(R.style.AnimationFade);  

			lv_storeClasses.setAdapter(lvStoreClassAdapter);
			// popup ListView 点击事件
			// storeClassPopupWindow.setBackgroundDrawable(new ColorDrawable(0x00000000));
			// storeClassPopupWindow.setOutsideTouchable(true);
			storeClassPopupWindow.setFocusable(true);
			// 点击其他地方消失
			popupWindow_view.setOnTouchListener(new OnTouchListener() {  
				@Override  
				public boolean onTouch(View v, MotionEvent event) {  
					// TODO Auto-generated method stub  
					if (storeClassPopupWindow != null && storeClassPopupWindow.isShowing()) {  
						storeClassPopupWindow.dismiss();  
						checkBoxStoreClass.setChecked(false);
						checkBoxAreaSelect.setChecked(false);
						storeClassPopupWindow = null;  
						mapStoreClasss.clear();
					}  
					return false;  
				}  
			});  

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*** 
	 * 获取PopupWindow实例 
	 */  
	private void getAreaPopupWindow(int width) {  
		if (null != areaPopupWindow) {  
			areaPopupWindow.dismiss();  
			return;  
		} else {  
			initAreaPopuptWindow(width);  
		}
	}  

	/** 
	 * 创建区域选择 PopupWindow 
	 */  
	protected void initAreaPopuptWindow(int width) {  
		JSONArray js;
		if (county == null) {
			try {
				InputStream is = getResources().getAssets().open("config_region.json");
				byte [] buffer = new byte[is.available()] ; 
				is.read(buffer);
				String json = new String(buffer,"utf-8");
				county = new ArrayList<AreaInfo>();
				js = new JSONArray(json);
				Gson gson = new Gson();
				for (int i = 0; i < js.length(); i++) {
					if (sp.getString("cityId", "").equals(
							gson.fromJson(js.getJSONObject(i).toString(), AreaInfo.class).getParent_id())) {
						county.add(gson.fromJson(js.getJSONObject(i).toString(), AreaInfo.class));
						log.i(gson.fromJson(js.getJSONObject(i).toString(), AreaInfo.class).getRegion_name());
					}
				}

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub  
		// 获取自定义布局文件popupwindow_amenduserphoto.xml的视图
		View popupWindow_view = getLayoutInflater().inflate(R.layout.popupwindow_near_store_classs, null,  
				false);  
		// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
		ListView lv_area = (ListView) popupWindow_view.findViewById(R.id.lv_popup_one);
		final LvAreaAdapter lvAreaAdapter = new LvAreaAdapter(NearActivity.this, county);
		lv_area.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				pageIndex = 0;
				RadioHolder holder = new RadioHolder(arg1);
				holder.radio.setChecked(true);
				map.clear();
				map.put(arg2, 100);
				lvAreaAdapter.notifyDataSetChanged();
				sp.edit().putString("countyId", county.get(arg2).getRegion_id());
				areaPopupWindow.dismiss();  
				checkBoxStoreClass.setChecked(false);
				checkBoxAreaSelect.setChecked(false);
				areaPopupWindow = null; 
				getStoreData();
			}
		});
		stopMyDialog();
		areaPopupWindow = new PopupWindow(popupWindow_view, width, llCheckBox.getHeight()*10, true); 
		// 设置动画效果  
		//popupWindow.setAnimationStyle(R.style.AnimationFade);  

		lv_area.setAdapter(lvAreaAdapter);
		// 点击其他地方消失
		popupWindow_view.setOnTouchListener(new OnTouchListener() {  
			@Override  
			public boolean onTouch(View v, MotionEvent event) {  
				// TODO Auto-generated method stub  
				if (areaPopupWindow != null && areaPopupWindow.isShowing()) {  
					areaPopupWindow.dismiss();  
					checkBoxStoreClass.setChecked(false);
					checkBoxAreaSelect.setChecked(false);
					areaPopupWindow = null; 
					map.clear();
				}  
				return false;  
			}  
		});  
	}  

	class RadioHolder{
		private RadioButton radio;
		private RadioButton radioStoreClasss;
		private RadioButton radioStores;
		public RadioHolder(View view){
			this.radioStoreClasss  = (RadioButton) view.findViewById(R.id.popup_store_class_lv_cb);
			this.radio = (RadioButton) view.findViewById(R.id.popup_near_area_lv_checkbox);
			this.radioStores = (RadioButton) view.findViewById(R.id.popup_near_area_lv_radiobutton);
		}
	}

	class poponDismissListener implements PopupWindow.OnDismissListener{  

		@Override  
		public void onDismiss() {  
			// TODO Auto-generated method stub  
			//Log.v("List_noteTypeActivity:", "我是关闭事件");
			checkBoxStoreClass.setChecked(false);
			checkBoxAreaSelect.setChecked(false);

		}  
	}

	/**
	 *  地区选择
	 * @author lauyk
	 *
	 */
	private class LvAreaAdapter extends BaseAdapter{
		private Context mContext;
		private ArrayList<AreaInfo> mList;
		private LayoutInflater inflater;

		public LvAreaAdapter(Context context,ArrayList<AreaInfo> mList) {  
			this.mContext = context;  
			this.mList = mList;
			this.inflater = LayoutInflater.from(context);
		}  

		@Override
		public int getCount() {
			if (mList == null) {
				return 0;
			} else {
				return this.mList.size();
			}
		}

		@Override
		public Object getItem(int position) {
			if (mList == null) {
				return null;
			} else {
				return this.mList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			RadioHolder holder;
			if(convertView == null) {
				convertView = inflater.inflate(R.layout.popupwindow_near_area_lv, null);
				holder = new RadioHolder(convertView);
				convertView.setTag(holder);
			} else {
				holder = (RadioHolder) convertView.getTag();
			}
			holder.radio.setChecked(map.get(position) == null ? false : true);
			holder.radio.setText(mList.get(position).getRegion_name());
			return convertView;
		}

	}

	/**
	 *  商家类型选择
	 * @author lauyk
	 *
	 */
	private class LvStoreClasseAdapter extends BaseAdapter{
		private Context mContext;
		private ArrayList<StoreClass> mList;
		private LayoutInflater inflater;
		private int[] mStoreClass;

		public LvStoreClasseAdapter(Context context,ArrayList<StoreClass> mList,int[] mStoreClass) {  
			this.mContext = context;
			this.mList = mList;
			this.inflater = LayoutInflater.from(context);
			this.mStoreClass = mStoreClass;
		}  

		@Override
		public int getCount() {
			if (mList == null) {
				return 0;
			} else {
				return this.mList.size();
			}
		}

		@Override
		public Object getItem(int position) {
			if (mList == null) {
				return null;
			} else {
				return this.mList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub

			RadioHolder holder;
			if(convertView == null) {
				convertView = inflater.inflate(R.layout.popupwindow_store_class_lv, null);
				holder = new RadioHolder(convertView);
				convertView.setTag(holder);
			} else {
				holder = (RadioHolder) convertView.getTag();
			}
			holder.radioStoreClasss.setChecked(mapStoreClasss.get(position) == null ? false : true);
			if (this.mList != null) {
				holder.radioStoreClasss.setText(mList.get(position).getIndustry_name());

				Drawable rightDrawable = getResources().getDrawable(mStoreClass[position]);  
				rightDrawable.setBounds(0, 0, rightDrawable.getMinimumWidth(), rightDrawable.getMinimumHeight());  
				holder.radioStoreClasss.setCompoundDrawables(rightDrawable, null, null, null); 
			}


			//			holder.radioStoreClasss.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			//
			//				@Override
			//				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			//					if (position<2) {
			//						log.i(""+ mList.get(position).getIndustry_name() +"--"+position);
			//						
			//						if (mList.get(position).getIndustry_id().equals("2")) {
			//							sp.edit().putString("type", "0").commit();
			//						} else {
			//							sp.edit().putString("type", "1").commit();
			//						}
			//						
			//						getStoreData();
			//						
			//					} else {
			//						
			//						getStorePopupWindow(mList.get(position).getIndustry_id());
			//						log.i(""+mList.get(position).getIndustry_name());
			//						runOnUiThread(new Runnable() {
			//							public void run() {
			//								storePopupWindow.showAtLocation(llCheckBox, Gravity.TOP,(llCheckBox.getWidth()/2), tvBack.getHeight()+llCheckBox.getHeight()+CommonUtils.getStatusBarHeight(NearActivity.this));
			//							}
			//						});
			//					}
			//					
			//
			//				}
			//			});

			return convertView;
		}

	}

	private class StoreAdapter extends BaseAdapter{
		private Context mContext;
		private ArrayList<StoreClass> mList;
		private LayoutInflater inflater;

		public StoreAdapter(Context context,ArrayList<StoreClass> stores) {  
			this.mContext = context;  
			this.mList = stores;
			this.inflater = LayoutInflater.from(context);
		}  

		@Override
		public int getCount() {
			if (mList == null) {
				return 0;
			} else {
				return this.mList.size();
			}
		}

		@Override
		public Object getItem(int position) {
			if (mList == null) {
				return null;
			} else {
				return this.mList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			RadioHolder holder;
			if(convertView == null) {
				convertView = inflater.inflate(R.layout.popupwindow_near_store_lv, null);
				holder = new RadioHolder(convertView);
				convertView.setTag(holder);
			} else {
				holder = (RadioHolder) convertView.getTag();
			}
			holder.radioStores.setChecked(mapStores.get(position) == null ? false : true);
			holder.radioStores.setText(mList.get(position).getIndustry_name());
			return convertView;
		}

	}

	private void getStoreData(){

		if (filialeLists!=null) {
			filialeLists.clear();
		}

		if (merchantLists!=null) {
			merchantLists.clear();
		}
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("industry_top", sp.getString("industry_top", ""));
		params.addBodyParameter("industry_son", sp.getString("industry_son", ""));
		params.addBodyParameter("page", pageIndex +"");
		params.addBodyParameter("type", "1");
		//params.addBodyParameter("county", "0");
		params.addBodyParameter("county", sp.getString("countyId", "0"));
		params.addBodyParameter("city", sp.getString("cityId", "0"));
		log.e("page==========" + pageIndex);
		//params.addBodyParameter("city", "149");
		HttpUtils http = new HttpUtils();
		http.send(HttpMethod.POST, Ip.url+"nearby.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i(arg0.getExceptionCode()+"--"+arg1);
				refreshable_view.onRefreshComplete();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i(arg0.result);
				refreshable_view.onRefreshComplete();
				StoreAllList storeAlls = new Gson().fromJson(arg0.result, StoreAllList.class);

				if (storeAlls.getCode().equals("1")) {
					if (pageIndex==0) {
						mData.clear();
					}
					++pageIndex;
					if (storeAlls.getFiliale_list()!=null) {
						filialeLists = new ArrayList<FilialeList>();
						for (int i = 0; i < storeAlls.getFiliale_list().size(); i++) {
							filialeLists.add(storeAlls.getFiliale_list().get(i));
						}
					}
					if (storeAlls.getMerchant_list()!=null) {
						merchantLists = new ArrayList<MerchantList>();
						for (int i = 0; i < storeAlls.getMerchant_list().size(); i++) {
							merchantLists.add(storeAlls.getMerchant_list().get(i));
						}
					}
				}
				init(filialeLists, merchantLists);
			}
		});
	}

	private void init(ArrayList<FilialeList> filialeLists,ArrayList<MerchantList> merchantLists){
		//		this.mData = new ArrayList<NearDataBase>();
		if (filialeLists!=null) {
			for (int i = 0; i < filialeLists.size(); i++) {
				this.mData.add(new NearDataFiliale("兑换中心",1, filialeLists.get(i)));
				log.i("filialeLists"+i);
			}
		}

		if (merchantLists!=null) {
			for (int i = 0; i < merchantLists.size(); i++) {
				this.mData.add(new NearDataMerchant("联盟商家",2, merchantLists.get(i)));
				log.i("merchantLists"+i);
			}
		}

		if (mData.size()>0) {
			this.nearDataAdapter = new NearDataAdapter(this, this.mData);
			this.lvNearData.setAdapter(this.nearDataAdapter);
			CommonUtils.setListViewHeightBasedOnChildren(lvNearData);
			lvNearData.setVisibility(View.VISIBLE);
			mImgNoData.setVisibility(View.GONE);
		} else {
			lvNearData.setVisibility(View.GONE);
			mImgNoData.setVisibility(View.VISIBLE);
		}
	}

}

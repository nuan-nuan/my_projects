package com.lefen58.lefenmall.ui;


import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 修改昵称界面
 * @author Administrator
 *
 */
public class AmendUserinfoActivity extends BaseActivity{

	private static SharedPreferences sp;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.right_textview)
	private TextView right_textview;

	@ViewInject(R.id.edit_user_info)
	private EditText edit_user_info;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_amend_userinfor);

		ViewUtils.inject(this);
		//		right_textview.setGravity(Gravity.RIGHT);
		sp = getSharedPreferences("UserInfor", 0);
		tv_back.setText(this.getIntent().getStringExtra("title"));
		//		right_textview.setText("保存");
	}

	public void save(View view){
		startMyDialog();
		JSONObject object = new JSONObject();
		try {
			object.put(this.getIntent().getStringExtra("key"), edit_user_info.getText());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestParams params = new RequestParams();
		HttpUtils http = new HttpUtils();
		params.addBodyParameter("c", "set_user_info");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token", RequestOftenKey.getToken(context));
		params.addBodyParameter("user_info",object.toString());
		// 保存信息
		http.send(HttpMethod.POST, Ip.url+"account.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i("infor"+ arg0.getExceptionCode()+"--"+arg1);
				stopMyDialog();
				Toast.makeText(context, "网络连接失败，请检查网络~", 0).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
				Get_SMS_code get_SMS_code = new Gson().fromJson(arg0.result, Get_SMS_code.class);
				if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
					Toast.makeText(context, "修改成功！", Toast.LENGTH_SHORT).show();
					sp.edit().putString(AmendUserinfoActivity.this.getIntent().getStringExtra("key").toString(), edit_user_info.getText().toString()).commit();
					finish();
				}
			}
		});
	}

}

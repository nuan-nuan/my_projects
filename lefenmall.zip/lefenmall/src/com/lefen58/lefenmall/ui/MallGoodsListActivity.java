package com.lefen58.lefenmall.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.entity.GoodsList;
import com.lefen58.lefenmall.entity.MallGoodsList;
import com.lefen58.lefenmall.http.MallNetRequest;
import com.lefen58.lefenmall.image.RoundImageDrawable;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.TextView;

public class MallGoodsListActivity extends BaseActivity {
	private PopupWindow popupWindow;

	private MallNetRequest mallNetRequest;
	
	private HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

	private MallGoodsListAdapter mallGoodsListAdapter;
	
	ArrayList<String> mallComprehensives = new ArrayList<String>();

	@ViewInject(R.id.lv_mall_goods)
	private ListView lvMallGoods;
	
	/**
	 * 商品列表加载过程中显示的占位图
	 */
	BitmapDisplayConfig bitmap;

	/**
	 * 综合
	 */
	@ViewInject(R.id.tv_mall_comprehensive)
	private TextView tvMallComprehensive;

	/**
	 * 人气
	 */
	@ViewInject(R.id.tv_mall_popularity)
	private TextView tvMallPopularity;

	/**
	 * 价格
	 */
	@ViewInject(R.id.cb_mall_price)
	private CheckBox cbMallPrice;
	
	/**
	 * 排序容器
	 */
	@ViewInject(R.id.ll)
	private LinearLayout ll;
	
	/**
	 * title 容器
	 */
	@ViewInject(R.id.index_top_layout)
	private LinearLayout title;
	
	@ViewInject(R.id.mall_list_no_data)
	private ImageView mallListNoData;

	GoodsList result;

	ArrayList<MallGoodsList> mallGoodsLists;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mall_goods_list);
		ViewUtils.inject(this);
		getGoodsList();
		Listener();
		tvMallComprehensive.setSelected(true);
		Drawable drawable= getResources().getDrawable(R.drawable.near_radio_btn_on);
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
		tvMallComprehensive.setCompoundDrawables(null,null,drawable,null);
	}

	/**
	 * 人气排名
	 */
	public void MallPopularity(View view){
		tvMallComprehensive.setTextColor(Color.parseColor("#848484"));
		cbMallPrice.setTextColor(Color.parseColor("#848484"));

		tvMallPopularity.setTextColor(Color.parseColor("#548adf"));
		Drawable drawable= getResources().getDrawable(R.drawable.mall_on);  
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());  
		cbMallPrice.setCompoundDrawables(null,null,drawable,null);
		
		drawable = getResources().getDrawable(R.drawable.near_radio_btn_off);
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
		tvMallComprehensive.setCompoundDrawables(null,null,drawable,null);
		map.clear();
		Collections.sort(result.list, new Comparator<MallGoodsList>() {
			@Override
			public int compare(MallGoodsList lhs, MallGoodsList rhs) {
				// TODO Auto-generated method stub
				return  (Integer.parseInt(rhs.goodsViewedCount)-Integer.parseInt(lhs.goodsViewedCount));
			}
		});
		if (mallGoodsListAdapter!=null) {
			mallGoodsListAdapter.notifyDataSetChanged();
		}
	}

	/**
	 * 综合排序
	 */
	public void MallComprehensive(View view){
		// 显示 popupWindow
		getPopupWindow();
		popupWindow.showAtLocation(view, Gravity.TOP,0, title.getHeight()+ll.getHeight()+CommonUtils.getStatusBarHeight(MallGoodsListActivity.this));
	}
	
	/**
	 * 扫码点击事件
	 * @param view
	 */
	public void scanCamera(View view) {
		Intent intent = new Intent();
		intent.setClass(MallGoodsListActivity.this, MipcaActivityCapture.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivityForResult(intent, 1);
	}
	
	/**
	 * 搜索
	 */
	public void find(View view) {
		Intent intent = new Intent(MallGoodsListActivity.this, FindActivity.class);
		intent.putExtra("flag", "goods");
		startActivity(intent);
	}

	private void Listener() {
		/**
		 * 价格排序
		 */
		cbMallPrice.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				
				tvMallComprehensive.setTextColor(Color.parseColor("#848484"));
				tvMallPopularity.setTextColor(Color.parseColor("#848484"));
				
				cbMallPrice.setTextColor(Color.parseColor("#548adf"));
				Drawable drawable= getResources().getDrawable(R.drawable.mall_btn_radio);  
				drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());  
				/// 这一步必须要做,否则不会显示. 
				cbMallPrice.setCompoundDrawables(null,null,drawable,null);
				
				drawable = getResources().getDrawable(R.drawable.near_radio_btn_off);
				drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
				tvMallComprehensive.setCompoundDrawables(null,null,drawable,null);
				map.clear();
				 
				if (isChecked) {
					Collections.sort(result.list, new Comparator<MallGoodsList>() {
						@Override
						public int compare(MallGoodsList lhs, MallGoodsList rhs) {
							// TODO Auto-generated method stub
							return  (Integer.parseInt(rhs.goodsIntegralPrice)-Integer.parseInt(lhs.goodsIntegralPrice));
						}
					});
				} else {
					Collections.sort(result.list, new Comparator<MallGoodsList>() {
						@Override
						public int compare(MallGoodsList lhs, MallGoodsList rhs) {
							// TODO Auto-generated method stub
							return  (Integer.parseInt(lhs.goodsIntegralPrice)-Integer.parseInt(rhs.goodsIntegralPrice));
						}
					});
				}
				if (mallGoodsListAdapter!=null) {
					mallGoodsListAdapter.notifyDataSetChanged();
				}
			}
		});
		
		lvMallGoods.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				String goodsId= ((MallGoodsList)parent.getItemAtPosition(position)).goodsId;
				Intent intent=new Intent(context, CommodityDetailActivity.class);
				intent.putExtra("good_id", goodsId);
				startActivity(intent);
			}
		});
	}

	private void getGoodsList() {
		if (mallNetRequest == null) {
			mallNetRequest = new MallNetRequest(context);
		}
		
		mallNetRequest.getMallGoodsList(this.getIntent().getStringExtra("classifyId"), GoodsList.class, new RequestCallBack<GoodsList>() {
			
			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}
			
			@Override
			public void onSuccess(ResponseInfo<GoodsList> arg0) {
				stopMyDialog();
				result = arg0.result;
				log.i(result);
				if (result == null || result.list == null) {
					return;
				}
				switch (result.code) {
				case 1:
					log.i(result.list == null);
					log.i(result.list.size()==0);
					if (result.list == null || result.list.size()==0) {
						mallListNoData.setVisibility(View.VISIBLE);
						lvMallGoods.setVisibility(View.GONE);
						return;
					}else{
						lvMallGoods.setVisibility(View.VISIBLE);
						mallListNoData.setVisibility(View.GONE);
						if (mallGoodsListAdapter == null) {
							mallGoodsListAdapter = new MallGoodsListAdapter(context, result.list);
						}
						
					}
					
					if (mallGoodsListAdapter == null) {
						mallGoodsListAdapter = new MallGoodsListAdapter(context, arg0.result.list);
					}
					lvMallGoods.setAdapter(mallGoodsListAdapter);
					mallGoodsLists = result.list;
					
					break;
				default:
					break;
				}
				
			}
			
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
			}
		});
		
	}
	
	class MallGoodsListAdapter extends BaseAdapter{
		private ArrayList<MallGoodsList> mList;
		private Context context;
		public MallGoodsListAdapter(Context context,ArrayList<MallGoodsList> mList) {  

			this.context = context;  
			this.mList = mList;
			
			bitmap = new BitmapDisplayConfig();
			bitmap.setLoadingDrawable(getResources().getDrawable(R.drawable.zhanweitu));
		}  


		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			final ViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.listview_mall_goods_item, null);
				holder .ivGoodsIcon = (ImageView) convertView.findViewById(R.id.iv_goods_icon);
				holder.tvGoosName = (TextView) convertView.findViewById(R.id.tv_goos_name);
				holder.rbGoodsGrade = (RatingBar) convertView.findViewById(R.id.rb_goods_grade);
				holder.tvGoodsGrade = (TextView) convertView.findViewById(R.id.tv_goods_grade);
				holder.tvGoodsIntegralPrice = (TextView) convertView.findViewById(R.id.tv_goods_integral_price);
				holder.tvGoodsViewedCount = (TextView) convertView.findViewById(R.id.tv_goods_viewed_count);
				holder.tvGoodsSalesVolume = (TextView) convertView.findViewById(R.id.tv_goods_sales_volume);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (this.mList != null) {
				if (holder.ivGoodsIcon!= null) {
					bitmapUtils.display(holder.ivGoodsIcon, "http://cdn.image.huyongle.com/"+mList.get(position).goods_icon,bitmap,new BitmapLoadCallBack<View>() {

						@Override
						public void onLoadCompleted(View arg0, String arg1, Bitmap arg2, BitmapDisplayConfig arg3,
								BitmapLoadFrom arg4) {
							((ImageView)arg0).setImageDrawable(new RoundImageDrawable(arg2));
							
						}

						@Override
						public void onLoadFailed(View arg0, String arg1, Drawable arg2) {
							// TODO Auto-generated method stub

						}
					});
					
				}
				if (holder.tvGoosName!= null) {
					holder.tvGoosName.setText(mList.get(position).goodsName);
				}
				if (holder.rbGoodsGrade!= null) {
					holder.rbGoodsGrade.setRating(Float.parseFloat(mList.get(position).goodsGrade.substring(0, 1)));
				}
				if (holder.tvGoodsGrade!= null) {
					holder.tvGoodsGrade.setText(Float.parseFloat(mList.get(position).goodsGrade.substring(0, 1))+"分");
				}
				if (holder.tvGoodsIntegralPrice!= null) {
					holder.tvGoodsIntegralPrice.setText(mList.get(position).goodsIntegralPrice);
				}
				if (holder.tvGoodsViewedCount!= null) {
					holder.tvGoodsViewedCount.setText(mList.get(position).goodsViewedCount+"人已浏览");
				}
				if (holder.tvGoodsSalesVolume!= null) {
					holder.tvGoodsSalesVolume.setText("月销量"+mList.get(position).goodsSalesVolume+"笔");
				}

			}

			return convertView;
		}
	}

	private static class ViewHolder {
		ImageView ivGoodsIcon;
		TextView tvGoosName;
		RatingBar rbGoodsGrade;
		TextView tvGoodsGrade;
		TextView tvGoodsIntegralPrice;
		TextView tvGoodsViewedCount;
		TextView tvGoodsSalesVolume;
	}
	
	/*** 
	 * 获取PopupWindow实例 
	 */  
	private void getPopupWindow() {  
		if (null != popupWindow) {  
			popupWindow.dismiss();  
			return;  
		} else {  
			initPopuptWindow();  
		}
	}  
	
	/** 
	 * 创建PopupWindow 
	 */  
	protected void initPopuptWindow() {
		// TODO Auto-generated method stub  
		// 获取自定义布局文件popupwindow_amenduserphoto.xml的视图  
		View popupWindow_view = getLayoutInflater().inflate(R.layout.popupwindow_near_store_classs, null,
				false);
		ListView lv_area = (ListView) popupWindow_view.findViewById(R.id.lv_popup_one);
		lv_area.setDivider(null);//设置隐藏listView的分割线
		// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
		popupWindow = new PopupWindow(popupWindow_view, LayoutParams.MATCH_PARENT, -2, true); 
		backgroundAlpha(0.2f);
		// 点击其他地方消失
		popupWindow_view.setOnTouchListener(new OnTouchListener() {  
			@Override  
			public boolean onTouch(View v, MotionEvent event) {  
				// TODO Auto-generated method stub  
				if (popupWindow != null && popupWindow.isShowing()) {  
					popupWindow.dismiss();  
					backgroundAlpha(1f);
					popupWindow = null;  
				}  
				return false;  
			}
		});
		
		mallComprehensives.clear();
		mallComprehensives.add("综合");
		mallComprehensives.add("上架时间");
		
		final MallComprehensiveAdapter adapter = new MallComprehensiveAdapter(context, mallComprehensives);
		DisplayMetrics dm;
		dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);

		lv_area.setAdapter(adapter);
		CommonUtils.setListViewHeightBasedOnChildren(lv_area);
		View view = popupWindow_view.findViewById(R.id.v1);
		int height=dm.heightPixels-(title.getHeight()+ll.getHeight()+CommonUtils.getStatusBarHeight(MallGoodsListActivity.this)+lv_area.getLayoutParams().height);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
		view.setLayoutParams(lp);
		
		lv_area.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				
				tvMallPopularity.setTextColor(Color.parseColor("#848484"));
				cbMallPrice.setTextColor(Color.parseColor("#848484"));
				
				tvMallComprehensive.setTextColor(Color.parseColor("#548adf"));
				tvMallComprehensive.setText(mallComprehensives.get(position));
				Drawable drawable= getResources().getDrawable(R.drawable.mall_on);  
				drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
				cbMallPrice.setCompoundDrawables(null,null,drawable,null);
				
				drawable= getResources().getDrawable(R.drawable.near_radio_btn_on);
				drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
				tvMallComprehensive.setCompoundDrawables(null,null,drawable,null);
				
				RadioHolder holder = new RadioHolder(view);
				holder.radio.setChecked(true);
				map.clear();
				map.put(position, 100);
				adapter.notifyDataSetChanged();
				popupWindow.dismiss();  
				backgroundAlpha(1f);
				popupWindow = null; 
				
			}
		});
		
	}  
	
	
	class RadioHolder{
		private RadioButton radio;
		public RadioHolder(View view){
			this.radio = (RadioButton) view.findViewById(R.id.popup_near_area_lv_checkbox);
		}
	}
	
	class poponDismissListener implements PopupWindow.OnDismissListener{
		@Override  
		public void onDismiss() {
			// TODO Auto-generated method stub  
			//Log.v("List_noteTypeActivity:", "我是关闭事件");  
			backgroundAlpha(1f);  
		}  
	}

	public void backgroundAlpha(float bgAlpha){  
		//WindowManager.LayoutParams lp = getWindow().getAttributes();  
		//lp.alpha = bgAlpha; //0.0-1.0  
		
		lvMallGoods.setAlpha(bgAlpha);
		
		//getWindow().setAttributes(lp);
	}
	
	/**
	 *  地区选择
	 * @author lauyk
	 *
	 */
	private class MallComprehensiveAdapter extends BaseAdapter{
		private Context mContext;
		private ArrayList<String> mList;
		private LayoutInflater inflater;

		public MallComprehensiveAdapter(Context context,ArrayList<String> mList) {  
			this.mContext = context;  
			this.mList = mList;
			this.inflater = LayoutInflater.from(context);
		}  

		@Override
		public int getCount() {
			if (mList == null) {
				return 0;
			} else {
				return this.mList.size();
			}
		}

		@Override
		public Object getItem(int position) {
			if (mList == null) {
				return null;
			} else {
				return this.mList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			RadioHolder holder;
			if(convertView == null) {
				convertView = inflater.inflate(R.layout.popupwindow_near_area_lv, null);
				holder = new RadioHolder(convertView);
				convertView.setTag(holder);
			} else {
				holder = (RadioHolder) convertView.getTag();
			}

//			convertView.setMinimumHeight(CommonUtils.dip2px(context,45));
			holder.radio.setChecked(map.get(position) == null ? false : true);
			holder.radio.setText(mList.get(position));
			return convertView;
		}

	}


}

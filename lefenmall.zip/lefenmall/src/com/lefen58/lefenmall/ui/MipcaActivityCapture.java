package com.lefen58.lefenmall.ui;

import java.io.IOException;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.ObtainIntegral;
import com.lefen58.lefenmall.entity.ScanCode;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.mining.app.zxing.camera.CameraManager;
import com.mining.app.zxing.decoding.CaptureActivityHandler;
import com.mining.app.zxing.decoding.InactivityTimer;
import com.mining.app.zxing.view.ViewfinderView;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;
/**
 * Initial the camera
 * @author Ryan.Tang
 */
public class MipcaActivityCapture extends BaseActivity implements Callback {

	LogUtil Log = LogUtil.lLog();

	private CaptureActivityHandler handler;
	private ViewfinderView viewfinderView;
	private boolean hasSurface;
	private Vector<BarcodeFormat> decodeFormats;
	private String characterSet;
	private InactivityTimer inactivityTimer;
	private MediaPlayer mediaPlayer;
	private boolean playBeep;
	private static final float BEEP_VOLUME = 0.10f;
	private boolean vibrate;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_scan_camera);
		//ViewUtil.addTopView(getApplicationContext(), this, R.string.scan_card);
		CameraManager.init(getApplication());
		viewfinderView = (ViewfinderView) findViewById(R.id.viewfinder_view);

		TextView mButtonBack = (TextView) findViewById(R.id.tv_back);
		mButtonBack.setText("二维码/条形码");
		mButtonBack.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				MipcaActivityCapture.this.finish();

			}
		});
		hasSurface = false;
		inactivityTimer = new InactivityTimer(this);
	}



	@Override
	protected void onResume() {
		super.onResume();
		SurfaceView surfaceView = (SurfaceView) findViewById(R.id.preview_view);
		SurfaceHolder surfaceHolder = surfaceView.getHolder();
		if (hasSurface) {
			initCamera(surfaceHolder);
		} else {
			surfaceHolder.addCallback(this);
			surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		}
		decodeFormats = null;
		characterSet = null;

		playBeep = true;
		AudioManager audioService = (AudioManager) getSystemService(AUDIO_SERVICE);
		if (audioService.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) {
			playBeep = false;
		}
		initBeepSound();
		vibrate = true;

	}

	@Override
	protected void onPause() {
		super.onPause();
		if (handler != null) {
			handler.quitSynchronously();
			handler = null;
		}
		CameraManager.get().closeDriver();
	}

	@Override
	protected void onDestroy() {
		inactivityTimer.shutdown();
		super.onDestroy();
	}

	/**
	 * 处理扫描结果
	 * @param result
	 * @param barcode
	 */
	public void handleDecode(Result result, Bitmap barcode) {
		inactivityTimer.onActivity();
		playBeepSoundAndVibrate();
		String resultString = result.getText();
		if (resultString.equals("")) {
			Toast.makeText(MipcaActivityCapture.this, "扫描失败!", Toast.LENGTH_SHORT).show();
			finish();
		} else {
			log.i(resultString);
			try {
				ScanCode scanCode = new Gson().fromJson(resultString, ScanCode.class);
				Intent intent;
				switch (scanCode.getType()) {
				case "pay_integral"://扫一扫启动积分支付
					if (sp.getBoolean("state", false)) {
						intent = new Intent(MipcaActivityCapture.this, PayLefenActivity.class);
						intent.putExtra("name", scanCode.getName());
						intent.putExtra("order_id", scanCode.getOrder_id());
						intent.putExtra("order_integral", scanCode.getOrder_integral());
					}else{
						intent = new Intent(context, LoginActivity.class);
					}
					startActivity(intent);
					break;
				case "play_activity": // 扫一扫显示活动参与界面
					if (sp.getBoolean("state", false)) {
						if (scanCode.getActivity_type().equals("1")) {
							intent = new Intent(MipcaActivityCapture.this, DaZhuanPanDetailActivity.class);
							intent.putExtra("activity_index", scanCode.getActivity_id());
						} else if (scanCode.getActivity_type().equals("4")) {
							intent = new Intent(MipcaActivityCapture.this, YaoYiYaoActivity.class);
							intent.putExtra("activity_index", scanCode.getActivity_id());
						} else {
							intent = new Intent(MipcaActivityCapture.this, ListActivity.class);
							Toast.makeText(context, "没有该活动，去看看其他活动吧", 0).show();
						}
					}else{
						intent = new Intent(context, LoginActivity.class);
					}
					startActivity(intent);
					break;
				case "show_merchant": // 扫一扫显示联盟商家详情
					intent = new Intent(MipcaActivityCapture.this, MerchantActivity.class);
					intent.putExtra("itemType", "2");
					intent.putExtra("merchant_id", scanCode.getMerchant_id());
					startActivity(intent);
					break;
				case "show_filiale": // 扫一扫显示兑换中心商家详情页
					intent = new Intent(MipcaActivityCapture.this, MerchantActivity.class);
					intent.putExtra("itemType", "1");
					intent.putExtra("merchant_id", scanCode.getFiliale_id());
					startActivity(intent);
					break;
				case "obtain_integral": // 扫一扫获得兑换中心赠送积分
					if (sp.getBoolean("state", false)) {
						obtainIntegral(scanCode.getGiven_index(), scanCode.getFiliale_id());
					} else {
						intent = new Intent(context, LoginActivity.class);
						startActivity(intent);
					}
					break;
				}

			} catch (JsonSyntaxException e) {
				Toast.makeText(MipcaActivityCapture.this, "扫描失败!", Toast.LENGTH_SHORT).show();
			}

			finish();
		}

	}

	private void initCamera(SurfaceHolder surfaceHolder) {
		try {
			CameraManager.get().openDriver(surfaceHolder);
		} catch (IOException ioe) {
			return;
		} catch (RuntimeException e) {
			return;
		}
		if (handler == null) {
			handler = new com.mining.app.zxing.decoding.CaptureActivityHandler(this, decodeFormats,
					characterSet);
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {

	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		if (!hasSurface) {
			hasSurface = true;
			initCamera(holder);
		}

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		hasSurface = false;

	}

	public ViewfinderView getViewfinderView() {
		return viewfinderView;
	}

	public Handler getHandler() {
		return handler;
	}

	public void drawViewfinder() {
		viewfinderView.drawViewfinder();

	}

	private void initBeepSound() {
		if (playBeep && mediaPlayer == null) {
			// The volume on STREAM_SYSTEM is not adjustable, and users found it
			// too loud,
			// so we now play on the music stream.
			setVolumeControlStream(AudioManager.STREAM_MUSIC);
			mediaPlayer = new MediaPlayer();
			mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaPlayer.setOnCompletionListener(beepListener);

			AssetFileDescriptor file = getResources().openRawResourceFd(
					R.raw.beep);
			try {
				mediaPlayer.setDataSource(file.getFileDescriptor(),
						file.getStartOffset(), file.getLength());
				file.close();
				mediaPlayer.setVolume(BEEP_VOLUME, BEEP_VOLUME);
				mediaPlayer.prepare();
			} catch (IOException e) {
				mediaPlayer = null;
			}
		}
	}

	private static final long VIBRATE_DURATION = 200L;

	private void playBeepSoundAndVibrate() {
		if (playBeep && mediaPlayer != null) {
			mediaPlayer.start();
		}
		if (vibrate) {
			Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
			vibrator.vibrate(VIBRATE_DURATION);
		}
	}

	/**
	 * When the beep has finished playing, rewind to queue up another one.
	 */
	private final OnCompletionListener beepListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mediaPlayer) {
			mediaPlayer.seekTo(0);
		}
	};

	public void obtainIntegral(String given_index,String filiale_id){
		HttpUtils http = new HttpUtils();
		// 扫描二维码获取积分
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "obtain_integral");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token",RequestOftenKey.getToken(context));
		params.addBodyParameter("given_index", given_index);
		params.addBodyParameter("filiale_id", filiale_id);

		http.send(HttpMethod.POST, Ip.url+"service.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Toast.makeText(context, "网络连接失败，获取积分失败", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i(arg0.result);
				ObtainIntegral obtainIntegral = new Gson().fromJson(arg0.result, ObtainIntegral.class);
				if (CommonUtils.NetworkRequestReturnCode(context, obtainIntegral.getCode())) {
					switch (obtainIntegral.getStatus()) {
					case "0":
						Toast.makeText(context, "活动未开始", 0).show();
						break;
					case "1":
						sp.edit().putString("integral", obtainIntegral.getIntegral_balance()).commit();
						sp.edit().putString("given_integral", obtainIntegral.getGiven_integral()).commit();
						Toast.makeText(context, "成功领取"+obtainIntegral.getGiven_integral()+"乐分", 0).show();
						break;
					case "2":
						Toast.makeText(context, "活动暂停，请稍后", 0).show();
						break;
					case "3":
						Toast.makeText(context, "来晚喽，活动已结束", 0).show();
						break;
					case "4":
						Toast.makeText(context, "您已经领过了，做人不可以贪心哦~", 0).show();
						break;

					default:
						break;
					}
				}

			}
		});
	}

}
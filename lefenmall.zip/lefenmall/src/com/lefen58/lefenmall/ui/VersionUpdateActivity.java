package com.lefen58.lefenmall.ui;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.entity.Get_newest_version_info;
import com.lefen58.lefenmall.http.OtherNetRequest;
import com.lefen58.lefenmall.service.UpdateService;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.widgets.VersionDialog;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 版本更新
 */
public class VersionUpdateActivity extends BaseActivity {
	private OtherNetRequest mAppNetRequest;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.tv_version)
	private TextView tv_version;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_version_update);
		ViewUtils.inject(this);
		tv_back.setText("关于我们");
		try {
			tv_version.setText("当前版本 :"+this.getPackageManager().getPackageInfo("com.lefen58.lefenmall", 0).versionName);
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void onBack(View view){
		onBackPressed();
	}

	// 跳到协议界面
	public void jumpAgreement(View view){
		Intent intent = new Intent(context, AgreementActivity.class);
		intent.putExtra("title", "用户协议");
		intent.putExtra("url", Constants.UserAgreement);
		startActivity(intent);
	}

	// 拨打 4000910365
	public void callPhone(View view){
		Log.i("infor", "callPhone");
		Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:4000012411"));  
		startActivity(intent);
	}

	// 检查更新
	public void checkUpdata(View view){

//
//		HttpUtils http = new HttpUtils();
//		// 短信验证
//		http.send(HttpMethod.POST, Ip.url+"/service.php?c=get_newest_version_info&os_type=0",
//				null, new RequestCallBack<String>(){
//
//			@Override
//			public void onFailure(HttpException arg0, String arg1) {
//				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
//			}
//
//			@Override
//			public void onSuccess(ResponseInfo<String> arg0) {
//				Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
//				Log.i("infor", "checkUpdata");
//				
//				if (arg0.statusCode == 200) {
//					
//					Gson gson = new Gson();
//					Get_newest_version_info info = gson.fromJson(arg0.result, Get_newest_version_info.class);
//					
//					if (info.getCode().equals("1")) {
//						String latestVersion=sp.getString(Constants.SPKEY_LATEST_VERSION, "");
//						if (latestVersion.equals(CommonUtils.getAppVersion(context))) {
//							Toast.makeText(context, "当前已是最新版本", Toast.LENGTH_LONG).show();
//							return;
//						}
//						VersionDialog.Builder builder = new VersionDialog.Builder(VersionUpdateActivity.this);
//						builder.setTitle("新版本升级");
//						builder.setMessage(info.getInfo());
//						builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialog, int which) {
//								Intent intent=new Intent(VersionUpdateActivity.this, UpdateService.class);
//								startService(intent);
//								dialog.dismiss();
//							}
//						});
//						builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialog, int which) {
//								dialog.dismiss();
//							}
//						});
//						builder.create().show();
//					} else {
//						Toast.makeText(VersionUpdateActivity.this, "异常："+info.getCode(), Toast.LENGTH_SHORT).show();
//					}
//					
//				} else {
//					Toast.makeText(VersionUpdateActivity.this, "异常："+arg0.statusCode, Toast.LENGTH_SHORT).show();
//				}
//				
//				
//			}
//		});

		
		String latestVersion=sp.getString(Constants.SPKEY_LATEST_VERSION, "");
		if (latestVersion.compareTo(CommonUtils.getAppVersion(context))<=0) {
			Toast.makeText(context, "当前已是最新版本", Toast.LENGTH_LONG).show();
			return;
		}

	if (mAppNetRequest==null) {
		mAppNetRequest=new OtherNetRequest(context);
	}
	mAppNetRequest.getNewVersionInfo(new RequestCallBack<Get_newest_version_info>() {
		
		@Override
		public void onSuccess(ResponseInfo<Get_newest_version_info> arg0) {
			// TODO Auto-generated method stub

			Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
			Log.i("infor", "checkUpdata");
			
			if (arg0.statusCode == 200) {
				
				Get_newest_version_info info = arg0.result;
				
				if (info.getCode()==1) {
					VersionDialog.Builder builder = new VersionDialog.Builder(VersionUpdateActivity.this);
					builder.setTitle("新版本升级");
					builder.setMessage(info.getInfo());
					builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							Intent intent=new Intent(VersionUpdateActivity.this, UpdateService.class);
							startService(intent);
							dialog.dismiss();
						}
					});
					builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					});
					builder.create().show();
				} else {
					Toast.makeText(VersionUpdateActivity.this, "异常："+info.getCode(), Toast.LENGTH_SHORT).show();
				}
				
			} else {
				Toast.makeText(VersionUpdateActivity.this, "异常："+arg0.statusCode, Toast.LENGTH_SHORT).show();
			}
		
		}
		
		@Override
		public void onFailure(HttpException arg0, String arg1) {
			// TODO Auto-generated method stub
			Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
		}
	});

	}

}

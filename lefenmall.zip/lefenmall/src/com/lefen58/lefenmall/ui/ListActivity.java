package com.lefen58.lefenmall.ui;

import java.util.ArrayList;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.ActivityList;
import com.lefen58.lefenmall.entity.MainActivityList;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.pulltorefresh.library.PullToRefreshBase;
import com.pulltorefresh.library.PullToRefreshBase.Mode;
import com.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.pulltorefresh.library.PullToRefreshScrollView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

public class ListActivity extends BaseActivity {

	private int pageIndex=0;

	/**
	 * 活动list界面
	 */

	@ViewInject(R.id.refreshable_view)
	private PullToRefreshScrollView refreshable_view;

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	ArrayList<MainActivityList> mainActivitys;

	private static SharedPreferences sp;

	@ViewInject(R.id.lv_activity)
	private ListView lvActivity;

	@ViewInject(R.id.right_textview)
	private TextView rightTextView;

	@ViewInject(R.id.imgView_no_date)
	ImageView mImgNoData;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_list);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		final String activityType = this.getIntent().getStringExtra("activityType");
		tvBack.setText(this.getIntent().getStringExtra("activityName"));
		log.i("infor"+"activityType = "+activityType);
		startMyDialog();
		setActivityList(activityType);

		if (activityType.equals("5")) {
			rightTextView.setText("");
		}
		if (this.getIntent().getStringExtra("activityName").equals("消息")) {
			mImgNoData.setImageDrawable(getResources().getDrawable(R.drawable.no_info));
		}
		mainActivitys = new ArrayList<MainActivityList>();
		//		refreshable_view.setOnRefreshListener(new PullToRefreshListener() {
		//			@Override
		//			public void onRefresh() {
		//				runOnUiThread(new Runnable() {
		//					public void run() {
		//						startMyDialog();
		//					}
		//				});
		//				setActivityList(activityType);
		//			}
		//		}, 0);

		refreshable_view.setMode(Mode.BOTH);
		refreshable_view.getLoadingLayoutProxy(true, false).setPullLabel("下拉刷新");
		refreshable_view.getLoadingLayoutProxy(false, true).setPullLabel("上拉加载更多");
		refreshable_view.setOnRefreshListener(new OnRefreshListener2<ScrollView>() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				pageIndex=0;
				setActivityList(activityType);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				setActivityList(activityType);
			}
		});

		lvActivity.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				MainActivityList activity= (MainActivityList) parent.getItemAtPosition(position);

				Intent i;
				if (activity.getActivity_type().equals("4")) {
					i = new Intent(ListActivity.this, YaoYiYaoActivity.class);
					i.putExtra("activity_index", activity.getActivity_index());
					startActivity(i);
				} if (activity.getActivity_type().equals("1")) {
					i = new Intent(ListActivity.this, DaZhuanPanDetailActivity.class);
					i.putExtra("activity_index", activity.getActivity_index());
					startActivity(i);
				}

			}
		});
	}

	public void rightTextview(View v){
		Intent intent = new Intent(context, AgreementActivity.class);
		intent.putExtra("title", "活动规则");
		intent.putExtra("url", Constants.ActivityRules);
		startActivity(intent);
	}

	/**
	 * 获取首页活动list
	 */
	int i = 0;
	private void setActivityList(String activityType) {
		
		RequestParams params = new RequestParams();
		HttpUtils http = new HttpUtils();
		params.addBodyParameter("c", "list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(ListActivity.this));
		params.addBodyParameter("type", activityType);
		params.addBodyParameter("city", sp.getString("cityId", "0"));
		//params.addBodyParameter("county", sp.getString("countyId", ""));
		params.addBodyParameter("county", sp.getString("county", "0"));
		params.addBodyParameter("page",pageIndex+"");
		log	.i("infor" +i+"");
		http.send(HttpMethod.POST, Ip.url+"activity.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				//				refreshable_view.finishRefreshing();
				log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
								stopMyDialog();
				refreshable_view.onRefreshComplete();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				//				refreshable_view.finishRefreshing();
				log.i("infor"+ arg0.result);
								stopMyDialog();
				refreshable_view.onRefreshComplete();
				try {
					ActivityList activityList = new Gson().fromJson(arg0.result, ActivityList.class);
					if (activityList.getCode().equals("1")) {
						if (pageIndex==0) {
							mainActivitys.clear();
						}
						++pageIndex;

						for (int i = 0; i < activityList.getList().size(); i++) {
							mainActivitys.add(activityList.getList().get(i));
						}
					}
					log.i(mainActivitys.size());
					if (mainActivitys.size()>0) {

						lvActivity.setAdapter(new activityAdapter(ListActivity.this, mainActivitys));
						CommonUtils.setListViewHeightBasedOnChildren(lvActivity);
						lvActivity.setVisibility(View.VISIBLE);
						mImgNoData.setVisibility(View.GONE);
					} else {
						lvActivity.setVisibility(View.GONE);
						mImgNoData.setVisibility(View.VISIBLE);
					}
				} catch (JsonSyntaxException e) {
					mImgNoData.setVisibility(View.VISIBLE);
				}
			}
		});

	}
	class activityAdapter extends BaseAdapter{
		private ArrayList<MainActivityList> mainActivitys;
		private Context context;
		public activityAdapter(Context context,ArrayList<MainActivityList> mList) {  

			this.context = context;  
			this.mainActivitys = mList;
		}


		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mainActivitys.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mainActivitys.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.listview_main_acitivity, null);
				holder.activity_iv_prize = (ImageView) convertView.findViewById(R.id.activity_iv_prize);
				holder.activity_name = (TextView) convertView.findViewById(R.id.activity_name);
				holder.activity_sponsor_name = (TextView) convertView.findViewById(R.id.activity_sponsor_name);
				holder.activity_start_time = (TextView) convertView.findViewById(R.id.activity_start_time);
				holder.activity_status = (TextView) convertView.findViewById(R.id.activity_status);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (this.mainActivitys != null) {
				if (holder.activity_iv_prize!= null) {
					bitmapUtils.display(holder.activity_iv_prize, "http://cdn.image.huyongle.com/"+mainActivitys.get(position).getActivity_prize_url());
				}
				if (holder.activity_name!= null) {
					holder.activity_name.setText(mainActivitys.get(position).getActivity_name());
				}
				if (holder.activity_start_time!= null) {
					CharSequence startTime= DateFormat.format("yyyy-MM-dd  HH:mm:ss", new Date(Long.parseLong(mainActivitys.get(position).getActivity_start_time())*1000));
					holder.activity_start_time.setText(startTime);
				}
				if (holder.activity_status!= null) {
					if (mainActivitys.get(position).getActivity_status().equals("0")) {
						holder.activity_status.setText("（未开始）");
					}else{
						if (mainActivitys.get(position).getActivity_type().equals("4")) {
							Long startTime = Long.parseLong(mainActivitys.get(position).getActivity_start_time());
							Long serverTime = Long.parseLong(mainActivitys.get(position).getActivity_server_time());
							if (serverTime<startTime) {
								holder.activity_status.setText("（活动未开始）");
							}else{
								holder.activity_status.setText("（正在进行中）");
							}
						}else{
							holder.activity_status.setText("（正在进行中）");
						}
					}

				}
				if (holder.activity_sponsor_name!= null) {
					holder.activity_sponsor_name.setText(mainActivitys.get(position).getActivity_sponsor_name());
				}
			}
			return convertView;
		}
	}

	private static class ViewHolder {
		ImageView activity_iv_prize;
		TextView activity_name;
		TextView activity_sponsor_name;
		TextView activity_start_time;
		TextView activity_status;
	}

}

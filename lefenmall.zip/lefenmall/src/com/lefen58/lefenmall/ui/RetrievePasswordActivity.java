package com.lefen58.lefenmall.ui;

import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.lefen58.lefenmall.AppManager;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.receiver.SMSBroadcastReceiver;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class RetrievePasswordActivity extends BaseActivity {

	private SMSBroadcastReceiver mSMSBroadcastReceiver;

	private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";

	@ViewInject(R.id.etphone)
	private EditText etphone;

	@ViewInject(R.id.etphonecode)
	private EditText etphonecode;

	@ViewInject(R.id.bt_sendphonecode)
	private Button bt_sendphonecode;

	@ViewInject(R.id.bt_retrievePassword)
	private Button bt_retrievePassword;

	@ViewInject(R.id.etpassword)
	private EditText etpassword;

	@ViewInject(R.id.etpasswordtest)
	private EditText etpasswordtest;

	@ViewInject(R.id.img_retrievepassword)
	private ImageView img_retrievepassword;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.tv_send_phone_code)
	private TextView tv_send_phone_code;

	@ViewInject(R.id.ll_retrievepassword_one)
	private LinearLayout ll_retrievepassword_one;

	@ViewInject(R.id.ll_retrievepassword_two)
	private LinearLayout ll_retrievepassword_two;

	static int time = 60;
	private Timer timer;

	private static final int SEND_PHONE_CODE_TIME = 1001;

	private static SharedPreferences sp;


	Handler handler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SEND_PHONE_CODE_TIME:
				time = time-1;
				if (time<=0) {
					timer.cancel();
					bt_sendphonecode.setEnabled(true);
					bt_sendphonecode.setBackgroundResource(R.drawable.blu);
					bt_sendphonecode.setTextColor(0xffffffff);
					time = 60;
					bt_sendphonecode.setText("点击发送验证码");

				} else {
					bt_sendphonecode.setText("("+time+"s)重新发送");
					bt_sendphonecode.setBackgroundResource(R.drawable.bgtwo);
					bt_sendphonecode.setTextColor(0xffacacac);
				}

				break;

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_retrievepassword);

		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);

		tv_back.setText(this.getIntent().getStringExtra("title"));

		etphone.addTextChangedListener(new watcher(etphone));
		etphonecode.addTextChangedListener(new watcher(etphonecode));
		etpassword.addTextChangedListener(new watcher(etpassword));
		etpasswordtest.addTextChangedListener(new watcher(etpasswordtest));

		if (this.getIntent().getStringExtra("title").equals("设置密码")&&!sp.getString("phone", "1").equals("1")) {
			etphone.setText(sp.getString("phone", ""));
			etphone.setFocusable(false);
		}

	}


	public void onBack(View view){
		onBackPressed();
	}

	public void sendPhoneCode(View view){
		// 获取验证码
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())) {
			view.setEnabled(false);

			startMyDialog();
			HttpUtils http = new HttpUtils();
			// 短信验证
			http.send(HttpMethod.POST, Ip.get_SMS_code+"verify_type=2"
					+"&phone="+etphone.getText().toString()
					+"&device_index="+sp.getString("device_index", "0"),
					null, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
					etphonecode.setEnabled(true);
					stopMyDialog();
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					stopMyDialog();
					try {
						Gson gson = new Gson();
						Log.i("infor", arg0.result);
						Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
						if (CommonUtils.NetworkRequestReturnCode(context,get_SMS_code.getCode())) {
							//生成广播处理
							mSMSBroadcastReceiver = new SMSBroadcastReceiver();
							//实例化过滤器并设置要过滤的广播
							IntentFilter intentFilter = new IntentFilter(ACTION);
							intentFilter.setPriority(Integer.MAX_VALUE);
							//注册广播
							RetrievePasswordActivity.this.registerReceiver(mSMSBroadcastReceiver, intentFilter);

							mSMSBroadcastReceiver.setOnReceivedMessageListener(new SMSBroadcastReceiver.MessageListener() {
								@Override
								public void onReceived(String message) {
									String regEx="[^0-9]";
					            	Pattern p = Pattern.compile(regEx);   
					            	Matcher m = p.matcher(message);   
					            	System.out.println( m.replaceAll("").trim());
									etphonecode.setText(m.replaceAll("").trim());
									if (bt_retrievePassword.getText().equals("验 证")) {
										retrievePassword(bt_retrievePassword);
									}
								}
							});

							Toast.makeText(RetrievePasswordActivity.this, "发送成功", Toast.LENGTH_SHORT).show();
							img_retrievepassword.setImageResource(R.drawable.retrievepasswordtwo);
							timer = new Timer(true);
							timer.schedule(new TimerTask(){  
								public void run() {  
									Message msg=handler.obtainMessage(SEND_PHONE_CODE_TIME);
									handler.sendMessage(msg);
								}  
							},1000, 1000);
						} else {
							etphonecode.setEnabled(true);
						}
					} catch (Exception e) {
						// TODO: handle exception
					}

				}
			});

		} else {
			Toast.makeText(RetrievePasswordActivity.this, "手机号不合法", Toast.LENGTH_SHORT).show();
		}

	}

	public void retrievePassword(View view){

		String password = CommonUtils.getMD5Str(etpassword.getText().toString())
				+CommonUtils.getMD5Str(etphonecode.getText().toString());

		if (!((Button)view).getText().equals("验 证")) {
			log.i(!etpassword.getText().toString().equals(etpasswordtest.getText().toString()));
			if (!etpassword.getText().toString().equals(etpasswordtest.getText().toString())) {
				Toast.makeText(context, "两次密码不一样", 0).show();
				return;
			}

			if (!CommonUtils.passwordVerify(etpassword.getText().toString())) {
				Toast.makeText(context, "密码应是6-18位数字加字母组合", 0).show();
				return;
			}
		}

		// 找回密码
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())) {

			HttpUtils http = new HttpUtils();

			// Ip.reset_login_password
			//+"account="+etphone.getText().toString()
			//+"&SMS_code="+etphonecode.getText().toString()
			//+"&login_password="+password.toLowerCase(),
			String url;
			if (!((Button)view).getText().equals("确定")) {
				url = Ip.verify_SMS_code+"phone="+etphone.getText().toString()
						+"&SMS_code="+etphonecode.getText().toString();
			} else {
				url = Ip.reset_login_password_ios+"account="+etphone.getText().toString()
						+"&login_password="+password.toLowerCase();
			}

			Log.i("infor", url);
			http.send(HttpMethod.POST, url,
					null, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
					stopMyDialog();
					Toast.makeText(context, "网络异常", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					log.i("arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
					try {
						Gson gson = new Gson();
						Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
						if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
							if (bt_retrievePassword.getText().equals("确定")) {
								Toast.makeText(context, "找回密码成功，请登录", 0).show();
								startActivity(new Intent(RetrievePasswordActivity.this, LoginActivity.class));
								AppManager.getInstance().killAllActivity();
							} else {
								Log.i("infor", "验证成功");
								ll_retrievepassword_one.setVisibility(View.GONE);
								ll_retrievepassword_two.setVisibility(View.VISIBLE);
								bt_retrievePassword.setText("确定");
							}
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			});

		} else {
			Toast.makeText(RetrievePasswordActivity.this, "手机号不合法", Toast.LENGTH_SHORT).show();
		}

	}

	public class watcher implements TextWatcher{

		private EditText edit = null;

		public watcher (EditText ed){
			this.edit = ed;
		}

		@Override
		public void afterTextChanged(Editable s) {


			if (edit == etphone) {

				if (CommonUtils.isPhoneNumer(etphone.getText().toString()) && time == 60) {
					bt_sendphonecode.setEnabled(true);
					bt_sendphonecode.setTextColor(0xffffffff);
					bt_sendphonecode.setBackgroundResource(R.drawable.blu);

				} else if(etphone.getText().toString().length()==11 &&
						!(CommonUtils.isPhoneNumer(etphone.getText().toString()))) {
					Toast.makeText(RetrievePasswordActivity.this, "手机号输入不合法", Toast.LENGTH_SHORT).show();
					bt_sendphonecode.setEnabled(false);
				} else {
					bt_sendphonecode.setEnabled(false);
				}

			} else {
				if (etphonecode.getText().toString().length()==6 && 
						CommonUtils.isPhoneNumer(etphone.getText().toString()) && 
						etpassword.getText().toString().equals(etpasswordtest.getText().toString())) {
					bt_retrievePassword.setEnabled(true);
				} else {
					bt_retrievePassword.setEnabled(false);
				}
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
		}
	}

}

package com.lefen58.lefenmall.ui;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Payment;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.GridPasswordView;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

public class PayLefenActivity extends BaseActivity{

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.pay_tishi)
	private TextView payTishi;

	@ViewInject(R.id.right_textview)
	private TextView right_textview;
	private GridPasswordView gridPasswordView;
	
	private String storeName;
	private String dealIntrargl;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_pay_lefen);
		ViewUtils.inject(this);
		tv_back.setText("积分确认支付");
		right_textview.setText("取消");
		right_textview.setGravity(Gravity.RIGHT);  
		
		storeName = this.getIntent().getStringExtra("name");
		dealIntrargl = this.getIntent().getStringExtra("order_integral")+"乐分";
		
		payTishi.setText("您在乐分商场"+storeName
				+"兑换产品需要支付"+dealIntrargl);

		gridPasswordView = (GridPasswordView) findViewById(R.id.gv);
	}

	public void payOk(View view){

		RequestParams params = new RequestParams();
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token", RequestOftenKey.getToken(context));
		params.addBodyParameter("order_id", this.getIntent().getStringExtra("order_id"));
		params.addBodyParameter("pay_pwd", CommonUtils.getMD5Str(gridPasswordView.getPassWord()).toLowerCase()+CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(context)));

		HttpUtils http = new HttpUtils();
		http.send(HttpMethod.POST, Ip.payment,
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
				Toast.makeText(context, "网络异常", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i(arg0.result);
				Payment payment = new Gson().fromJson(arg0.result, Payment.class);
				if (CommonUtils.NetworkRequestReturnCode(context, payment.getCode())) {
					Intent intent = new Intent(PayLefenActivity.this, PayOKActivity.class);
					intent.putExtra("store_name", storeName);
					intent.putExtra("deal_id", payment.getDeal_id());
					intent.putExtra("deal_time", payment.getDeal_time());
					intent.putExtra("deal_intrgral", dealIntrargl);
					startActivity(intent);
					finish();
				}
			}
		});
	}
	
	public void onBack(View view){
		onBackPressed();
	}
	
	public void rightTextview(View v){
		finish();
	}

	//不让用户按后退键    
	@Override  
	public boolean onKeyDown(int keyCode, KeyEvent event) {  
		// TODO Auto-generated method stub  
		//屏蔽后退键    
		if(KeyEvent.KEYCODE_BACK == event.getKeyCode())    
		{    
			return true;//阻止事件继续向下分发    
		}    
		return super.onKeyDown(keyCode, event);   
	}


}

package com.lefen58.lefenmall.ui;

import java.util.Date;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.entity.ActivityInfo;
import com.lefen58.lefenmall.entity.GetActivityInfoResult;
import com.lefen58.lefenmall.entity.ShakeResult;
import com.lefen58.lefenmall.http.ActivityNetRequest;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.CountDownClock;
import com.lefen58.lefenmall.widgets.CountDownClock.CountDownListener;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.app.AlertDialog;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class YaoYiYaoActivity extends BaseActivity {

	private SensorManager sensorManager;
	private Vibrator vibrator;
	private AlertDialog mResultDialog;
	private ShakeResult mResult;
	private BitmapUtils mBitmapUtils;
	private ActivityInfo mActivityInfo;
	private MediaPlayer mPlayer;
	private MediaPlayer mWinPlayer;

	private ActivityNetRequest mActivityNetRequest;

	private static final int SENSOR_SHAKE = 10;

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	@ViewInject(R.id.right_textview)
	private TextView mTvTitle;

	@ViewInject(R.id.vf_shake)
	ViewFlipper mVfShake;

	@ViewInject(R.id.txt_go_shake)
	TextView mTxtGoShake;

	@ViewInject(R.id.llayout_count_down)
	View mViewCountDown;

	@ViewInject(R.id.clock_count_down)
	CountDownClock mClock;

	@ViewInject(R.id.llayout_quiet)
	View mViewQuiet;

	@ViewInject(R.id.llayout_floating)
	View mViewFloating;

	@ViewInject(R.id.imgView_up)
	ImageView mImgUp;

	@ViewInject(R.id.imgView_down)
	View mImgDown;

	@ViewInject(R.id.imgView_shake_middle)
	ImageView mImgMiddle;

	@ViewInject(R.id.tv_go_prize_list)
	TextView tvGoPrizeList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_yaoyiyao);
		ViewUtils.inject(this);

		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

		mPlayer=MediaPlayer.create(this, R.raw.shark);//MediaPlayer.create(context,resId)这个方式配置数据源后，就完成了初始化，所以不用prepare可以直接start了
		mWinPlayer=MediaPlayer.create(this, R.raw.shake_win);
		
		mTvTitle.setText("全民惠行动 快来摇一摇");

		mTxtGoShake.setOnClickListener(mClickListener);
		tvGoPrizeList.setOnClickListener(mClickListener);
		getActivityInfo();
	}

	OnClickListener mClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.txt_go_shake:
				if (!sp.getBoolean("state", false)) {
					Toast.makeText(YaoYiYaoActivity.this, "请先登录", Toast.LENGTH_SHORT).show();
					return;
				}
				if (mActivityInfo != null && mActivityInfo.startTime <=mActivityInfo.serverTime) {
					goShake();
				} else {
					Toast.makeText(YaoYiYaoActivity.this, "活动未开始", Toast.LENGTH_SHORT).show();
					return;
				}
				break;
			case R.id.imgView_close_lose:
				hideShakeResultDialog();
				break;
			case R.id.imgView_close_win:
				hideShakeResultDialog();
				break;
			case R.id.imgBtn_get_prize:

				hideShakeResultDialog();
				startActivity(new Intent(YaoYiYaoActivity.this, PrizeVoucherActivity.class));
				break;
			case R.id.imgBtn_shake_again:
				hideShakeResultDialog();
				break;
			case R.id.imgBtn_see_other:
				finish();
				break;
			case R.id.tv_go_prize_list:
				hideShakeResultDialog();
				Intent intent = new Intent(YaoYiYaoActivity.this, PrizeListActivity.class);
				intent.putExtra("activity_index", getIntent().getStringExtra("activity_index"));
				startActivity(intent);
				break;

			default:
				break;
			}
		}
	};
	

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if (mVfShake.getDisplayedChild() == 1) {// 当前展示的是第二个界面
			registerShakeListener();
		}
	}

	@Override
	protected void onPause() {
		super.onStop();
		unregisterShakeListener();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (mClock.isRun()) {
			mClock.stopRun();
		}
		if (mPlayer!=null) {
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			mPlayer.release();
		}
		if (mWinPlayer!=null) {
			if (mWinPlayer.isPlaying()) {
				mWinPlayer.stop();
			}
			mWinPlayer.release();
		}
		super.onDestroy();
	}

	public void registerShakeListener() {
		if (sensorManager != null) {// 注册监听器
			sensorManager.registerListener(sensorEventListener,
					sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
			// 第一个参数是Listener，第二个参数是所得传感器类型，第三个参数值获取传感器信息的频率
		}
	}

	public void unregisterShakeListener() {
		if (sensorManager != null) {// 取消监听器
			sensorManager.unregisterListener(sensorEventListener);
		}
	}

	/**
	 * 重力感应监听
	 */
	private SensorEventListener sensorEventListener = new SensorEventListener() {

		@Override
		public void onSensorChanged(SensorEvent event) {
			// 传感器信息改变时执行该方法
			float[] values = event.values;
			float x = values[0]; // x轴方向的重力加速度，向右为正
			float y = values[1]; // y轴方向的重力加速度，向前为正
			float z = values[2]; // z轴方向的重力加速度，向上为正
			// 一般在这三个方向的重力加速度达到40就达到了摇晃手机的状态。
			int medumValue = 14;// 如果不敏感请自行调低该数值,低于10的话就不行了,因为z轴上的加速度本身就已经达到10了
			if (Math.abs(x) > medumValue || Math.abs(y) > medumValue || Math.abs(z) > medumValue) {
				vibrator.vibrate(200);
				Message msg = new Message();
				msg.what = SENSOR_SHAKE;
				mHandler.sendMessage(msg);
			}
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	};

	/**
	 * 动作执行
	 */
	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case SENSOR_SHAKE:
				hideShakeResultDialog();
				unregisterShakeListener();//检测到摇晃之后不再处理摇晃，动画结束后再处理下次摇晃
				startShakeAnimation();
				playShakeSound();
				break;
			}
		}

	};

	public void onBack(View view) {
		onBackPressed();
	}



	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if (mVfShake.getDisplayedChild() == 0) {// 当前展示的是第一个界面
			//			onBackPressed();
			super.onBackPressed();
		} else {
			exitShake();
		}
	}

	/**
	 * 进入摇一摇
	 */
	private void goShake() {
		mVfShake.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.layout_in_from_right));
		mVfShake.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.layout_out_to_left));
		mVfShake.showNext();
		mTvTitle.setText("爱的大放送  就来摇一摇");

		registerShakeListener();
	}

	/**
	 * 退出摇一摇
	 */
	private void exitShake() {
		mVfShake.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.layout_in_from_left));
		mVfShake.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.layout_out_to_right));
		mVfShake.showPrevious();
		mTvTitle.setText("全民惠行动 快来摇一摇");

		unregisterShakeListener();
	}

	public void playShakeSound() {
		if (mPlayer.isPlaying()) {
			mPlayer.stop();
		}
			mPlayer.start();
	}
	
	public void playWinSound() {
		if (mWinPlayer.isPlaying()) {
			mWinPlayer.stop();
		}
		mWinPlayer.start();
	}

	/**
	 * 仿微信摇一摇动画
	 */
	private void startShakeAnimation() {
		float yValue = mImgMiddle.getHeight() / 2;
		mViewQuiet.setVisibility(View.GONE);
		mViewFloating.setVisibility(View.VISIBLE);
		mImgMiddle.setVisibility(View.VISIBLE);

		AnimationSet animup = new AnimationSet(true);
		TranslateAnimation mup0 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.ABSOLUTE, -yValue);
		mup0.setDuration(500);
		TranslateAnimation mup1 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.ABSOLUTE, +yValue);
		mup1.setDuration(500);
		// 延迟执行1秒
		mup1.setStartOffset(1000);
		animup.addAnimation(mup0);
		animup.addAnimation(mup1);
		// 上图片的动画效果的添加
		mImgUp.startAnimation(animup);

		AnimationSet animdn = new AnimationSet(true);
		TranslateAnimation mdn0 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.ABSOLUTE, +yValue);
		mdn0.setDuration(500);
		TranslateAnimation mdn1 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.ABSOLUTE, -yValue);
		mdn1.setDuration(500);
		// 延迟执行1秒
		mdn1.setStartOffset(1000);
		animdn.addAnimation(mdn0);
		animdn.addAnimation(mdn1);
		animdn.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
				mViewQuiet.setVisibility(View.VISIBLE);
				mViewFloating.setVisibility(View.GONE);
				mImgMiddle.setVisibility(View.GONE);
				getShakeResult();
				registerShakeListener();
			}
		});

		// 下图片动画效果的添加
		mImgDown.startAnimation(animdn);
	}

	private void getShakeResult() {
		//		SharedPreferences sp = getSharedPreferences("UserInfor", 0);
		String activityIndex = getIntent().getStringExtra("activity_index");
		//		RequestParams params = new RequestParams();
		//		HttpUtils http = new HttpUtils();
		//		params.addBodyParameter("c", "shake");
		//		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(this));
		//		params.addBodyParameter("token", RequestOftenKey.getToken(this));
		//		params.addBodyParameter("activity_index", activityIndex);
		//
		//		http.send(HttpMethod.POST, Ip.url + "activity.php", params, new RequestCallBack<String>() {
		//
		//			@Override
		//			public void onStart() {
		//				// TODO Auto-generated method stub
		//				super.onStart();
		//				startMyDialog();
		//			}
		//
		//			@Override
		//			public void onFailure(HttpException arg0, String arg1) {
		//				Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
		//				stopMyDialog();
		//			}
		//
		//			@Override
		//			public void onSuccess(ResponseInfo<String> arg0) {
		//				Log.i("infor", arg0.result);
		//				stopMyDialog();
		////				exitShake();
		//				mResult = new Gson().fromJson(arg0.result, ShakeResult.class);
		//				log.i(arg0.result);
		//				switch (mResult.code) {
		//				case 1:
		//					if (mResult.prizeVoucher == 0) {
		//						showLoseDialog();
		//					} else {
		//						showWinDialog();
		//					}
		//					break;
		//
		//				default:
		//					CommonUtils.NetworkRequestReturnCode(YaoYiYaoActivity.this, String.valueOf(mResult.code));
		//					break;
		//				}
		//			}
		//		});

		if (mActivityNetRequest==null) {
			mActivityNetRequest=new ActivityNetRequest(context);
		}

		mActivityNetRequest.getShakeActivityResult(RequestOftenKey.getDeviceIndex(this), activityIndex, ShakeResult.class, new RequestCallBack<ShakeResult>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<ShakeResult> arg0) {
				// TODO Auto-generated method stub
				stopMyDialog();
				//				exitShake();
				mResult = arg0.result;
				log.i(arg0.result);
				switch (mResult.code) {
				case 1:
					if (mResult.prizeVoucher == 0) {
						showLoseDialog();
					} else {
						showWinDialog();
						playWinSound();
					}
					break;

				default:
					CommonUtils.NetworkRequestReturnCode(YaoYiYaoActivity.this, String.valueOf(mResult.code));
					break;
				}
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
				stopMyDialog();
			}
		});
	}

	public void getActivityInfo() {
		String activityIndex = getIntent().getStringExtra("activity_index");

		if (mActivityNetRequest==null) {
			mActivityNetRequest=new ActivityNetRequest(context);
		}
		mActivityNetRequest.getActivityInfo(RequestOftenKey.getDeviceIndex(this), activityIndex, GetActivityInfoResult.class, new RequestCallBack<GetActivityInfoResult>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
				stopMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<GetActivityInfoResult> arg0) {
				stopMyDialog();
				GetActivityInfoResult result = arg0.result;
				if (result == null || result.activity == null) {
					return;
				}
				mActivityInfo = result.activity;
				switch (result.code) {
				case 1:
					if (result.activity.startTime > result.activity.serverTime) {
						mViewCountDown.setVisibility(View.VISIBLE);
						mClock.setTimes(result.activity.startTime - result.activity.serverTime);
						mClock.setCountDownListener(new CountDownListener() {
							
							@Override
							public void onStop() {
								// TODO Auto-generated method stub
								mViewCountDown.setVisibility(View.INVISIBLE);
							}
						});
						if (!mClock.isRun()) {
							mClock.beginRun();
						}
					} else {
						mViewCountDown.setVisibility(View.INVISIBLE);
					}
					break;

				default:
					break;
				}
			}
		});
	}

	/**
	 * 显示中奖弹框
	 */
	private void showWinDialog() {

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int scrWidth = dm.widthPixels;
		int scrHeight = dm.heightPixels;

		View view = getLayoutInflater().inflate(R.layout.dialog_shake_win, null);
		ImageView prizeIcon = (ImageView) view.findViewById(R.id.imgView_prize_icon);
		TextView txtPrizeName = (TextView) view.findViewById(R.id.txt_prize_name);
		TextView txtPrizeDeadline = (TextView) view.findViewById(R.id.txt_prize_deadline);
		ImageButton imgBtnGetPrize=(ImageButton) view.findViewById(R.id.imgBtn_get_prize);
		ImageView imgClose = (ImageView) view.findViewById(R.id.imgView_close_win);
		imgBtnGetPrize.setOnClickListener(mClickListener);
		imgClose.setOnClickListener(mClickListener);

		CharSequence startTime= DateFormat.format("yyyy-MM-dd", new Date(Long.parseLong(mResult.voucherValidTime)*1000));

		if (mResult != null) {
			txtPrizeName.setText(mResult.prizeName);
			txtPrizeDeadline.setText(startTime+"之前兑换");

			if (mBitmapUtils == null) {
				mBitmapUtils = new BitmapUtils(this);
				mBitmapUtils.display(prizeIcon, "http://cdn.image.huyongle.com/"+mResult.prizeImgUrl);
			}
		}
		if (mResultDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			mResultDialog = builder.create();
			// mWinDialog.setView(view);
			mResultDialog.setCanceledOnTouchOutside(false);
		}
		mResultDialog.show();
		Window window = mResultDialog.getWindow();
		window.setContentView(view);
		//window.setLayout((int) (scrWidth * 1f), (int) (scrHeight * 0.7f));
	}

	/**
	 * 未中奖弹框
	 */
	private void showLoseDialog() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int scrWidth = dm.widthPixels;
		int scrHeight = dm.heightPixels;

		View view = getLayoutInflater().inflate(R.layout.dialog_shake_lose, null);
		ImageButton imgBtnShakeAgain = (ImageButton) view.findViewById(R.id.imgBtn_shake_again);
		ImageButton imgBtnOther = (ImageButton) view.findViewById(R.id.imgBtn_see_other);
		ImageView imgClose = (ImageView) view.findViewById(R.id.imgView_close_lose);
		imgBtnShakeAgain.setOnClickListener(mClickListener);
		imgBtnOther.setOnClickListener(mClickListener);
		imgClose.setOnClickListener(mClickListener);
		if (mResultDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			mResultDialog = builder.create();
			mResultDialog.setCanceledOnTouchOutside(false);
		}
		mResultDialog.show();
		Window window = mResultDialog.getWindow();
		window.setContentView(view);
		window.setLayout((int) (scrWidth * 0.9f), (int) (scrHeight * 0.7f));
	}

	/**
	 * 隐藏摇奖结果弹框
	 */
	private void hideShakeResultDialog() {
		if (mResultDialog!=null&&mResultDialog.isShowing()) {
			mResultDialog.dismiss();
		}
	}
}

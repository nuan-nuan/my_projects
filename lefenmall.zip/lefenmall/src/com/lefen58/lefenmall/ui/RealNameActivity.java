package com.lefen58.lefenmall.ui;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.IsCardId;
import com.lefen58.lefenmall.entity.Submit_card_info;
import com.lefen58.lefenmall.entity.Upload_image_data;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.PreferenceUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RealNameActivity extends BaseActivity {
	private LogUtil log = LogUtil.lLog();
	private static String ImageName;

	private static String front_reverse;

	@ViewInject(R.id.bt_next)
	private Button bt_next;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.card_id)
	private EditText card_id;

	@ViewInject(R.id.sp_year)
	private Spinner sp_year;

	@ViewInject(R.id.sp_month)
	private Spinner sp_month;

	@ViewInject(R.id.sp_day)
	private Spinner sp_day;

	@ViewInject(R.id.iv_realname)
	private ImageView iv_realname;

	@ViewInject(R.id.iv_card_front)
	private ImageView iv_card_front;

	@ViewInject(R.id.iv_card_reverse)
	private ImageView iv_card_reverse;

	@ViewInject(R.id.tv_realname_hint_front)
	private TextView tv_realname_hint_front;

	@ViewInject(R.id.tv_realname_hint_reverse)
	private TextView tv_realname_hint_reverse;

	@ViewInject(R.id.ll_card_front)
	private LinearLayout ll_card_front;

	@ViewInject(R.id.ll_card_reverse)
	private LinearLayout ll_card_reverse;

	@ViewInject(R.id.realname_linearlayout_one)
	private LinearLayout realname_linearlayout_one;

	@ViewInject(R.id.realname_ll_two)
	private LinearLayout realname_ll_two;

	@ViewInject(R.id.temporaryCard)
	private RadioButton temporaryCard;

	@ViewInject(R.id.erdaiCard)
	private RadioButton erdaiCard;

	@ViewInject(R.id.card_name)
	private EditText card_name;

	@ViewInject(R.id.ll_content)
	private LinearLayout ll_content;

	@ViewInject(R.id.ll_hint_one)
	private LinearLayout ll_hint_one;

	@ViewInject(R.id.ll_hint_two)
	private LinearLayout ll_hint_two;
	@ViewInject(R.id.right_textview)
	private TextView rightTextView;

	private ArrayList<String> dataYear = new ArrayList<String>();  
	private ArrayList<String> dataMonth = new ArrayList<String>();  
	private ArrayList<String> dataDay = new ArrayList<String>();  
	private ArrayAdapter<String> adapterSpYear;  
	private ArrayAdapter<String> adapterSpMonth;  
	private ArrayAdapter<String> adapterSpDay;  

	private static SharedPreferences sp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_realname);

		ViewUtils.inject(this);
		tv_back.setText("实名认证");
		sp = getSharedPreferences("UserInfor", 0);
		log.i(sp.getString("card_index", "0"));
		if (!sp.getString("card_index", "0").equals("0")) {
			if (!sp.getString("card_name", "0").equals("")) {

			}else{

			}
			ll_hint_two.setVisibility(View.VISIBLE);
			ll_hint_one.setVisibility(View.GONE);
			bt_next.setVisibility(View.GONE);
			ll_content.setVisibility(View.GONE);
			rightTextView.setVisibility(View.VISIBLE);
		} else {
			setSpinnerData();
			erdaiCard.setChecked(true);
			rightTextView.setVisibility(View.GONE);
		}
		
		rightTextView.setText("完成");
		rightTextView.setGravity(Gravity.RIGHT);
		
		

	}

	public void rightTextview(View v){
		finish();
	}

	private void setSpinnerData() throws NumberFormatException {
		// 年份设定为当年的后20年  
		Calendar cal = Calendar.getInstance();  
		dataYear.add("年");
		dataMonth.add("月");
		dataDay.add("日");

		for (int i = 0; i < 20; i++) {  
			dataYear.add("" + (cal.get(Calendar.YEAR) + i));  
		} 

		adapterSpYear = new ArrayAdapter<String>(this, R.layout.feedback_spinner, dataYear);  
		adapterSpYear.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		sp_year.setAdapter(adapterSpYear);  
		sp_year.setSelection(0);// 默认选中今年  



		sp_year.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				dataDay.clear();
				dataDay.add("日");

				sp_month.setSelection(0);
				adapterSpDay.notifyDataSetChanged();

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}
		});

		// 12个月  
		for (int i = 1; i <= 12; i++) {  
			dataMonth.add("" + i);  
		}  

		adapterSpMonth = new ArrayAdapter<String>(this, R.layout.feedback_spinner, dataMonth);  
		adapterSpMonth.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		sp_month.setAdapter(adapterSpMonth);  

		adapterSpDay = new ArrayAdapter<String>(this, R.layout.feedback_spinner, dataDay);  
		adapterSpDay.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		sp_day.setAdapter(adapterSpDay);  

		sp_month.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				dataDay.clear();  
				dataDay.add("日");
				if (!sp_year.getSelectedItem().toString().equals("年")&&!sp_year.getSelectedItem().toString().equals("月")) {

					Calendar cal = Calendar.getInstance();  
					cal.set(Calendar.YEAR, Integer.valueOf(sp_year.getSelectedItem().toString()));  
					cal.set(Calendar.MONTH, position-1);  
					int dayofm = cal.getActualMaximum(Calendar.DAY_OF_MONTH);  
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
					String s = sdf.format(new Date(Long.valueOf("000")));  

					for (int i = 1; i <= dayofm; i++) {  
						dataDay.add("" + i);  
					}  
					adapterSpDay.notifyDataSetChanged();
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}
		});

	}

	public void onBack(View view){
		onBackPressed();
	}

	public void clear_card_id(View view){
		card_id.setText("");
	}

	public void clear_card_name(View view){
		card_name.setText("");
	}

	// 删除身份证正面
	public void deleteFront(View view){
		ll_card_front.setVisibility(View.GONE);
		tv_realname_hint_front.setVisibility(View.VISIBLE);
	}

	// 删除身份证反面
	public void deleteReverse(View view){
		ll_card_reverse.setVisibility(View.GONE);
		tv_realname_hint_front.setVisibility(View.VISIBLE);
	}

	public void Next(View view) throws Exception{
		if (bt_next.getText().equals("下一步")) {
			if (card_id.getText().toString().length()!=18) {
				Toast.makeText(RealNameActivity.this, "身份证不合法，仅支持18位身份证号	", Toast.LENGTH_SHORT).show();
				return;
			}
			if (sp_year.getSelectedItem().toString().equals("年")||
					sp_day.getSelectedItem().toString().equals("月")||
					sp_month.getSelectedItem().toString().equals("日"))
			{
				Toast.makeText(RealNameActivity.this, "请选择到期时间~", Toast.LENGTH_SHORT).show();
				return;
			}
			if (!erdaiCard.isChecked()&&!temporaryCard.isChecked()) {
				Toast.makeText(RealNameActivity.this, "请选择身份证类型~", Toast.LENGTH_SHORT).show();
				return;
			}
			startMyDialog();
			String httpUrl = "http://apis.baidu.com/apistore/idservice/id";
			String httpArg = "id="+card_id.getText().toString();
			new BaiduTask().execute(new String[]{httpUrl,httpArg});
		}

		// 立即提交
		if (bt_next.getText().equals("立即提交")) {
			if (ll_card_front.getVisibility()==View.GONE||ll_card_reverse.getVisibility()==View.GONE) {
				Toast.makeText(RealNameActivity.this, "请上传身份证正反面", Toast.LENGTH_SHORT).show();
				return;
			}
			startMyDialog();
//			ImageUtils.uploadImage(RealNameActivity.this, img1, "card_front", 
//					PreferenceUtils.getPrefString(RealNameActivity.this, "phone", "0"));
//			log.i("infor"+"phone="+PreferenceUtils.getPrefString(RealNameActivity.this, "phone", "0"));
//
//			ImageUtils.uploadImage(RealNameActivity.this, img2, "card_front", 
//					PreferenceUtils.getPrefString(RealNameActivity.this, "phone", "0"));
//			log.i("infor"+"phone="+PreferenceUtils.getPrefString(RealNameActivity.this, "phone", "0"));


			HttpUtils http = new HttpUtils();
			RequestParams params = new RequestParams();
			params.addBodyParameter("c", "upload_image_data");
			params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(RealNameActivity.this));
			params.addBodyParameter("token", RequestOftenKey.getToken(RealNameActivity.this));
			params.addBodyParameter("image_data", img1);
			params.addBodyParameter("image_size", img1.length()+"");
			params.addBodyParameter("image_role", "card_front");
			params.addBodyParameter("image_type", "image/png");
			params.addBodyParameter("image_name", PreferenceUtils.readStrConfig("phone", RealNameActivity.this)+"card_front.png");
			http.send(HttpMethod.POST, Ip.url+"account.php",
					params, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					Toast.makeText(RealNameActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
					log.i("infor"+ arg0.getExceptionCode()+"--"+arg1);
					stopMyDialog();
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					Upload_image_data upload_image_data = 
							new Gson().fromJson(arg0.result, Upload_image_data.class);
					if (CommonUtils.NetworkRequestReturnCode(RealNameActivity.this, upload_image_data.getCode())) {
						HttpUtils http = new HttpUtils();
						RequestParams params = new RequestParams();
						params.addBodyParameter("c", "upload_image_data");
						params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(RealNameActivity.this));
						params.addBodyParameter("token", RequestOftenKey.getToken(RealNameActivity.this));
						params.addBodyParameter("image_data", img2);
						params.addBodyParameter("image_size", img2.length()+"");
						params.addBodyParameter("image_role", "card_reverse");
						params.addBodyParameter("image_type", "image/png");
						params.addBodyParameter("image_name", PreferenceUtils.readStrConfig("phone", context)+"card_reverse.png");
						http.send(HttpMethod.POST, Ip.url+"account.php",
								params, new RequestCallBack<String>(){

							@Override
							public void onFailure(HttpException arg0, String arg1) {
								Toast.makeText(RealNameActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
								log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
								stopMyDialog();
							}

							@Override
							public void onSuccess(ResponseInfo<String> arg0) {
								Upload_image_data upload_image_data = 
										new Gson().fromJson(arg0.result, Upload_image_data.class);
								stopMyDialog();
								if (CommonUtils.NetworkRequestReturnCode(RealNameActivity.this, upload_image_data.getCode())) {
									Toast.makeText(RealNameActivity.this, "上传成功", Toast.LENGTH_SHORT).show();
									startActivity(new Intent(context, RealNameActivity.class));
									finish();
								}else{
									Toast.makeText(RealNameActivity.this, "上传失败", Toast.LENGTH_SHORT).show();
								}
							}
						});
					}
				}
			}
					);
		}

	}
	private PopupWindow popupWindow;
	private String img1;

	private String img2;

	public void realNameFront(View view){
		getPopupWindow(R.layout.popupwindow_amenduserphoto,-1,-2,R.style.AnimationFade);  
		// 这里是位置显示方式,在屏幕的左侧  
		popupWindow.showAtLocation(view, Gravity.BOTTOM, 0, 0);  
		front_reverse = "front";

	}

	public void realNameReverse(View view){
		getPopupWindow(R.layout.popupwindow_amenduserphoto,-1,-2,R.style.AnimationFade);  
		// 这里是位置显示方式,在屏幕的左侧  
		popupWindow.showAtLocation(view, Gravity.BOTTOM, 0, 0);  
		front_reverse = "reverse";
	}
	/**
	 * 拍照
	 * @param view
	 */

	public void camera(View view){
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		ImageName = System.currentTimeMillis()+".jpg";
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
				Environment.getExternalStorageDirectory()
				, ImageName)));

		startActivityForResult(intent, 1);
		if (popupWindow!=null) {
			popupWindow.dismiss();
		}
		backgroundAlpha(1f);  

	}
	/**
	 * 跳转至相册选择
	 * @param view
	 */
	public void photoalbum(View view){
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		startActivityForResult(intent, 2);
		if (popupWindow!=null) {
			popupWindow.dismiss();
		}
		backgroundAlpha(1f);  
	}



	private class BaiduTask extends AsyncTask<String, Void, String>  {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {
			String httpUrl = params[0];
			String httpArg = params[1];
			BufferedReader reader = null;
			String result = null;
			StringBuffer sbf = new StringBuffer();
			httpUrl = httpUrl + "?" + httpArg;

			try {
				URL url = new URL(httpUrl);
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setRequestMethod("GET");
				// 填入apikey到HTTP header
				connection.setRequestProperty("apikey", "424363bf5b041bf4de130724263e0d63");
				connection.connect();
				InputStream is = connection.getInputStream();
				reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				String strRead = null;
				while ((strRead = reader.readLine()) != null) {
					sbf.append(strRead);
					sbf.append("\r\n");
				}
				reader.close();
				result = sbf.toString();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}


		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			log.i("infor"+ result);  //此处没有值输出
			Gson gson = new Gson();
			IsCardId isCardId = gson.fromJson(result, IsCardId.class);
			//IsCardIdRetData isCardIdRetData = isCardId.getRetData();

			//Log.i("infor", isCardIdRetData.getSex()+"--"+isCardIdRetData.getBirthday()+"--"+isCardIdRetData.getAddress());

			if (isCardId.getErrNum().equals("0")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				log.i(isCardId.getErrNum().equals("0"));
				HttpUtils http = new HttpUtils();
				RequestParams params = new RequestParams();
				params.addBodyParameter("c", "submit_card_info");
				params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(RealNameActivity.this));
				params.addBodyParameter("token", RequestOftenKey.getToken(RealNameActivity.this));
				params.addBodyParameter("card_id", card_id.getText().toString());
				params.addBodyParameter("card_name",card_name.getText().toString());
				params.addBodyParameter("card_type",erdaiCard.isChecked() ? "1" : "0" );
				try {
					params.addBodyParameter("card_validity",String.valueOf(sdf.parse(
							sp_year.getSelectedItem().toString()+"-"+
									sp_day.getSelectedItem().toString()+"-"+
									sp_month.getSelectedItem().toString()).getTime()/1000));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				http.send(HttpMethod.POST, Ip.url+"account.php",
						params, new RequestCallBack<String>(){

					@Override
					public void onFailure(HttpException arg0, String arg1) {
						log.i("infor"+ arg0.getExceptionCode()+"--"+arg1);
						stopMyDialog();
					}

					@Override
					public void onSuccess(ResponseInfo<String> arg0) {
						log.i(arg0.result);
						stopMyDialog();
						Submit_card_info submit_card_info = new Gson().fromJson(arg0.result, Submit_card_info.class);
						if (CommonUtils.NetworkRequestReturnCode(RealNameActivity.this, submit_card_info.getCode())||
								submit_card_info.getCode().equals("-12")) {
							
							sp.edit().putString("card_index", submit_card_info.getCard_index()).commit();
							iv_realname.setImageResource(R.drawable.realnametwo);
							realname_linearlayout_one.setVisibility(View.GONE);
							realname_ll_two.setVisibility(View.VISIBLE);
							bt_next.setText("立即提交");
						}
					}
				});

			} else {
				stopMyDialog();
				Toast.makeText(RealNameActivity.this, isCardId.getRetMsg(), Toast.LENGTH_SHORT).show();
			}

		}
	}

	/*** 
	 * 获取PopupWindow实例 
	 */  
	private void getPopupWindow(int resource,int width, int height,int animationStyle) {  
		if (null != popupWindow) {
			popupWindow.dismiss();  
			return;  
		} else {
			initPopuptWindow(resource, width, height,animationStyle);  
		}  
	}  

	/** 
	 * 创建PopupWindow 
	 */  
	protected void initPopuptWindow(int resource,int width, int height,int animationStyle) {  
		// TODO Auto-generated method stub  
		// 获取自定义布局文件activity_popupwindow_left.xml的视图  
		View popupWindow_view = getLayoutInflater().inflate(resource, null,  
				false);  
		// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
		popupWindow = new PopupWindow(popupWindow_view,width, height, true);  
		// 设置动画效果  
		popupWindow.setAnimationStyle(animationStyle);  
		backgroundAlpha(0.5f);
		// 点击其他地方消失  
		popupWindow_view.setOnTouchListener(new OnTouchListener() {  
			@Override  
			public boolean onTouch(View v, MotionEvent event) {  
				// TODO Auto-generated method stub  
				if (popupWindow != null && popupWindow.isShowing()) {  
					popupWindow.dismiss(); 
					backgroundAlpha(1f);
					popupWindow = null;  
				}  
				return false;  
			}  
		});  
	}  

	/** 
	 * 设置添加屏幕的背景透明度 
	 * @param bgAlpha 
	 */  
	public void backgroundAlpha(float bgAlpha){  
		WindowManager.LayoutParams lp = getWindow().getAttributes();  
		lp.alpha = bgAlpha; //0.0-1.0  
		getWindow().setAttributes(lp);  
	} 

	class poponDismissListener implements PopupWindow.OnDismissListener{  

		@Override  
		public void onDismiss() {  
			// TODO Auto-generated method stub  
			//Log.v("List_noteTypeActivity:", "我是关闭事件");  
			backgroundAlpha(1f);  
		}  

	} 


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == 1){
			if (data == null) {
				File picture = new File(Environment.getExternalStorageDirectory()+
						File.separator+ImageName);
				Uri uri = Uri.fromFile(picture);
				startImageZoom(uri);
				return;
			} else {
				Bundle extras = data.getExtras();
				if (extras != null) {
					Bitmap bm = extras.getParcelable("data");
					Uri uri = saveBitmap(bm);
				}
			}
		}else if(requestCode == 2){
			if(data == null)
			{
				return;
			}
			Uri uri;
			uri = data.getData();
			Uri fileUri = convertUri(uri);
			startImageZoom(fileUri);
		}else if(requestCode == 3){
			if(data == null)
			{
				return;
			}
			Bundle extras = data.getExtras();
			if(extras == null){
				return;
			}
			Bitmap bm = extras.getParcelable("data");

			if (front_reverse.equals("front")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				bm.compress(Bitmap.CompressFormat.PNG, 60, stream);
				byte[] bytes = stream.toByteArray();
				img1 = new String(Base64.encodeToString(bytes, Base64.DEFAULT));

				iv_card_front.setImageBitmap(bm);
				tv_realname_hint_front.setVisibility(View.GONE);
				ll_card_front.setVisibility(View.VISIBLE);
			} else if (front_reverse.equals("reverse")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				bm.compress(Bitmap.CompressFormat.PNG, 60, stream);
				byte[] bytes = stream.toByteArray();
				img2 = new String(Base64.encodeToString(bytes, Base64.DEFAULT));

				iv_card_reverse.setImageBitmap(bm);
				tv_realname_hint_reverse.setVisibility(View.GONE);
				ll_card_reverse.setVisibility(View.VISIBLE);

			} else {
				Toast.makeText(RealNameActivity.this, "选择失败", Toast.LENGTH_SHORT).show();
			}

			//user_photo.setImageBitmap(bm);
		}
	}

	private Uri convertUri(Uri uri){
		InputStream is = null;
		try {
			is = getContentResolver().openInputStream(uri);
			Bitmap bitmap = BitmapFactory.decodeStream(is);
			is.close();
			return saveBitmap(bitmap);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	private Uri saveBitmap(Bitmap bm){
		File tmpDir = new File(Environment.getExternalStorageDirectory() + "/com.lefen58.userphoto");
		if(!tmpDir.exists())
		{
			tmpDir.mkdir();
		}
		File img = new File(tmpDir.getAbsolutePath() + "user.png");
		try {
			FileOutputStream fos = new FileOutputStream(img);
			bm.compress(Bitmap.CompressFormat.PNG, 10, fos);
			fos.flush();
			fos.close();
			return Uri.fromFile(img);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private void startImageZoom(Uri uri){
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 16);
		intent.putExtra("aspectY", 10);
		intent.putExtra("outputX", 336);
		intent.putExtra("outputY", 210);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, 3);
	}
//0x8086 

}

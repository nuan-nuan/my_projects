package com.lefen58.lefenmall.ui;

import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.AppManager;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.entity.RegisterAccount;
import com.lefen58.lefenmall.http.AccountNetRequest;
import com.lefen58.lefenmall.receiver.SMSBroadcastReceiver;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.PreferenceUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ResourceAsColor")
public class PhoneLoginActivity extends BaseActivity {
	private static SharedPreferences sp;

	private SMSBroadcastReceiver mSMSBroadcastReceiver;

	AccountNetRequest netRequest;

	private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";

	@ViewInject(R.id.etphone)
	private EditText etphone;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.etphonecode)
	private EditText etphonecode;

	@ViewInject(R.id.bt_sendphonecode)
	private Button bt_sendphonecode;

	@ViewInject(R.id.bt_testandlogin)
	private Button bt_testandlogin;

	static int time = 60;
	private Timer timer;

	private static final int SEND_PHONE_CODE_TIME = 1001;

	Handler handler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SEND_PHONE_CODE_TIME:
				time = time-1;
				if (time<=0) {
					timer.cancel();
					bt_sendphonecode.setEnabled(true);
					bt_sendphonecode.setBackgroundResource(R.drawable.blu);
					bt_sendphonecode.setTextColor(0xffffffff);
					time = 60;
					bt_sendphonecode.setText("发送验证码");

				} else {
					bt_sendphonecode.setText("("+time+"s)重新发送");
					bt_sendphonecode.setBackgroundResource(R.drawable.bgtwo);
				}

				break;

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_phone_login);
		ViewUtils.inject(this);
		tv_back.setText("手机号快捷登陆");
		sp = getSharedPreferences("UserInfor", 0);
		etphone.addTextChangedListener(new watcher(etphone));
		etphonecode.addTextChangedListener(new watcher(etphonecode));
		try {
			etphone.setText(((TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE)).getLine1Number().substring(3));
		} catch (Exception e) {
			// TODO: handle exception
		}
		netRequest = new AccountNetRequest(context);

	}

	public void onBack(View view){
		onBackPressed();
	}

	public void sendPhoneCode(final View view){
		// 获取验证码
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())) {
			view.setEnabled(false);
			((TextView)view).setTextColor(0xffb3b3b3);
			startMyDialog();
			HttpUtils http = new HttpUtils();
			// 短信验证
			log.i("device_index="+sp.getString("device_index", "0")+"phone="+etphone.getText().toString());
			http.send(HttpMethod.POST, Ip.get_SMS_code+"verify_type=1"
					+"&device_index="+sp.getString("device_index", "0")
					+"&phone="+etphone.getText().toString(),
					null, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					stopMyDialog();
					Toast.makeText(context, "请检查网络", Toast.LENGTH_SHORT).show();
					log.i(arg0.getExceptionCode()+"--"+arg1);
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					log.i("statusCode"+arg0.statusCode+"服务器返回"+arg0.result);
					stopMyDialog();
					if (arg0.statusCode == 200) {
						Gson gson = new Gson();
						Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
						if (get_SMS_code.getCode().equals("1")) {
							//生成广播处理
							mSMSBroadcastReceiver = new SMSBroadcastReceiver();

							//实例化过滤器并设置要过滤的广播
							IntentFilter intentFilter = new IntentFilter(ACTION);
							intentFilter.setPriority(Integer.MAX_VALUE);
							//注册广播
							PhoneLoginActivity.this.registerReceiver(mSMSBroadcastReceiver, intentFilter);

							mSMSBroadcastReceiver.setOnReceivedMessageListener(new SMSBroadcastReceiver.MessageListener() {
								@Override
								public void onReceived(String message) {
									String regEx="[^0-9]";   
									Pattern p = Pattern.compile(regEx);   
									Matcher m = p.matcher(message);   
									System.out.println( m.replaceAll("").trim());
									etphonecode.setText(m.replaceAll("").trim());

									testAndLogin(etphonecode);
								}
							});

							Toast.makeText(PhoneLoginActivity.this, "发送成功", Toast.LENGTH_SHORT).show();
							timer = new Timer(true);
							timer.schedule(new TimerTask(){  
								public void run() {  
									Message msg=handler.obtainMessage(SEND_PHONE_CODE_TIME);
									handler.sendMessage(msg);
								}  
							},1000, 1000);
						} else if (get_SMS_code.getCode().equals("-1")) {
							Toast.makeText(PhoneLoginActivity.this, "操作频繁", Toast.LENGTH_SHORT).show();
							view.setEnabled(true);
							view.setBackgroundResource(R.drawable.button_three);
							bt_sendphonecode.setTextColor(0xffffffff);
						} else if (get_SMS_code.getCode().equals("-2")) {
							Toast.makeText(PhoneLoginActivity.this, "系统限制", Toast.LENGTH_SHORT).show();
							view.setEnabled(true);
							view.setBackgroundResource(R.drawable.button_three);
							bt_sendphonecode.setTextColor(0xffffffff);
						} else if (get_SMS_code.getCode().equals("-6")||get_SMS_code.getCode().equals("-3")) {
							Toast.makeText(PhoneLoginActivity.this, "发送失败，请新发送", Toast.LENGTH_SHORT).show();
							view.setEnabled(true);
							view.setBackgroundResource(R.drawable.button_three);
							bt_sendphonecode.setTextColor(0xffffffff);
						} else {
							Toast.makeText(PhoneLoginActivity.this, "异常", Toast.LENGTH_SHORT).show();
							view.setEnabled(true);
							view.setBackgroundResource(R.drawable.button_three);
							bt_sendphonecode.setTextColor(0xffffffff);
						}
					} else {
						Toast.makeText(PhoneLoginActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
						view.setEnabled(true);
						view.setBackgroundResource(R.drawable.button_three);
						bt_sendphonecode.setTextColor(0xffffffff);
					}

				}
			});

		} else {
			Toast.makeText(PhoneLoginActivity.this, "手机号不合法", Toast.LENGTH_SHORT).show();
		}

	}

	/**
	 * 快捷登陆
	 * @param view
	 */
	public void testAndLogin(final View view){
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())) {

			netRequest.quickLogin(etphone.getText().toString(), etphonecode.getText().toString(), RegisterAccount.class, new RequestCallBack<RegisterAccount>() {

				@Override
				public void onSuccess(ResponseInfo<RegisterAccount> arg0) {
					switch (arg0.result.code) {
					case 1:
						PreferenceUtils.writeStrConfig("token", arg0.result.token, context);
						PreferenceUtils.writeStrConfig("given_integral", arg0.result.given_integral, context);
						PreferenceUtils.writeStrConfig("integral_balance", arg0.result.integral_balance, context);

						PreferenceUtils.writeBoolConfig("state", true, context);

						RequestOftenKey.getUserInfor(context, sp);

						AppManager.getInstance().killAllActivity();
						Intent intent = new Intent();
						intent.setClass(PhoneLoginActivity.this, HomeActivity.class);
						startActivity(intent);
						break;
					case 0:

						break;
					case -3:
						new Thread(new Runnable() {
							public void run() {
								try {
									Thread.sleep(5000);
									testAndLogin(view);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();
						break;
					case -5:
						showToast("验证码失败");
						break;
					}
				}

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					showToast("网络异常，请检查网络后重新登录");

				}
			});
		} else {
			Toast.makeText(PhoneLoginActivity.this, "手机号不合法", Toast.LENGTH_SHORT).show();
		}
	}

	public void back(View view){
		finish();
	}

	public class watcher implements TextWatcher{

		private EditText edit = null;

		public watcher (EditText ed){
			this.edit = ed;
		}

		@Override
		public void afterTextChanged(Editable s) {


			if (edit == etphone) {

				if (CommonUtils.isPhoneNumer(etphone.getText().toString()) && time == 60) {
					bt_sendphonecode.setEnabled(true);
					bt_sendphonecode.setBackgroundResource(R.drawable.button_three);
					bt_sendphonecode.setTextColor(0xffffffff);

				} else if(etphone.getText().toString().length()==11 &&
						!(CommonUtils.isPhoneNumer(etphone.getText().toString()))) {
					Toast.makeText(PhoneLoginActivity.this, "手机号输入不合法", Toast.LENGTH_SHORT).show();
					bt_sendphonecode.setEnabled(false);
					bt_sendphonecode.setBackgroundResource(R.drawable.button_one);
					bt_sendphonecode.setTextColor(0xffb3b3b3);
				} else {
					bt_sendphonecode.setEnabled(false);
					bt_sendphonecode.setBackgroundResource(R.drawable.button_one);
					bt_sendphonecode.setTextColor(0xffb3b3b3);
				}

			} else if (edit == etphonecode&&CommonUtils.isPhoneNumer(etphone.getText().toString())) {
				if (etphonecode.getText().toString().length()==6) {
					bt_testandlogin.setEnabled(true);
					bt_testandlogin.setBackgroundResource(R.drawable.button_three);
					bt_testandlogin.setTextColor(0xffffffff);
				} else {
					bt_testandlogin.setEnabled(false);
					bt_testandlogin.setBackgroundResource(R.drawable.button_two);
					bt_testandlogin.setTextColor(0xffffffff);
				}
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		//注销短信监听广播
		if (mSMSBroadcastReceiver!=null) {
			this.unregisterReceiver(mSMSBroadcastReceiver);
		}
	}




}

package com.lefen58.lefenmall.ui;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.utils.DataCleanManager;
import com.lefen58.lefenmall.utils.FileUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.MyToggle;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingActivity extends BaseActivity {

	private LogUtil log = LogUtil.lLog();
	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.imageView1)
	private ImageView imageView1;

	@ViewInject(R.id.nickname)
	private TextView nickname;

	@ViewInject(R.id.phone)
	private TextView phone;

	@ViewInject(R.id.toggle)
	private MyToggle toggle;

	/*@ViewInject(R.id.toggletwo)
	private MyToggle toggletwo;*/


	private static SharedPreferences sp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_setting);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);

	}

	private void setData() {
		/*//设置开关显示所用的图片
		toggle.setImageRes(R.drawable.btnred, R.drawable.btngray, R.drawable.btnwhite);
		toggletwo.setImageRes(R.drawable.btnred, R.drawable.btngray, R.drawable.btnwhite);
		//设置开关的默认状态    true开启状态
		toggle.setToggleState(false);
		toggletwo.setToggleState(false);*/
		tv_back.setText("设置");
		
		Log.e("昵称=========", sp.getString("name","暂无昵称"));
		String nickName=sp.getString("name","暂无昵称");
		if (TextUtils.isEmpty(nickName)) {
			nickname.setText("暂无昵称");
			
		}else {
			nickname.setText(nickName);
		}
		
		phone.setText(sp.getString("phone", ""));

		Bitmap bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
		if (bitmap!=null) {
			imageView1.setImageBitmap(bitmap);
		}else{
			if (!sp.getString("photo", "").equals("")) {
				ImageUtils.getNetworkBitmap("http://app.huyongle.com/"+sp.getString("photo", ""), "/com.lefen58/userphoto/", "userphoto.png");
				bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
				if (bitmap!=null) {
					imageView1.setImageBitmap(bitmap);
				} else {
					imageView1.setImageDrawable(getResources().getDrawable(R.drawable.userinfor_photo));
				}
			}else{
				imageView1.setImageDrawable(getResources().getDrawable(R.drawable.userinfor_photo));
			}
		}

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setData();
		RequestOftenKey.getUserInfor(SettingActivity.this, sp);
		log.i("onResume");
	}

	public void onBack(View view){
		onBackPressed();
	}

	// more
	public void more(View view){
		startActivity(new Intent(SettingActivity.this, MoreActivity.class));
	}

	// 个人信息
	public void changeUserInfor(View view){
		startActivity(new Intent(SettingActivity.this, UserInfoActivity.class));
	}

	// 账号与安全
	public void accountSecurity(View view){
		startActivity(new Intent(SettingActivity.this, AccountSecurityActivity.class));
	}

	// 消息
	public void infor(View view){
		// startActivity(new Intent(UserInforActivity.this, SettingActivity.class));
	}

	// 退出
	public void exit(View view){
		startMyDialog();
		HttpUtils http = new HttpUtils();
		// 短信验证
		Long token = Long.valueOf(sp.getString("token", "0"))+Long.valueOf(sp.getString("server_salt", "0"));
		http.send(HttpMethod.POST, Ip.login_out+
				"device_index="+sp.getString("device_index", "0")
				+"&token="+String.valueOf(token),
				null, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
				Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
				Gson gson = new Gson();
				try {
					Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
					if (get_SMS_code.getCode().equals("1")) {
						sp.edit().putBoolean("state",false).commit();
						Toast.makeText(SettingActivity.this, "您已退出登录状态", Toast.LENGTH_SHORT).show();
						finish();
						DataCleanManager.cleanSharedPreference(context);
						FileUtils.delFile("/com.lefen58/userphoto/userphoto.png");
					}else{
						Toast.makeText(SettingActivity.this, "退出失败，原因："+get_SMS_code.getCode(), Toast.LENGTH_SHORT).show();
					}
				} catch (Exception e) {
					// TODO: handle exception
				}

			}
		});
	}


}

package com.lefen58.lefenmall.ui;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

public class PayOKActivity extends BaseActivity{
	
	/**
	 * 支付成功
	 */
	@ViewInject(R.id.store_name)
	private TextView storeName;
	
	@ViewInject(R.id.deal_id)
	private TextView dealId;
	
	@ViewInject(R.id.deal_time)
	private TextView dealTime;
	
	@ViewInject(R.id.deal_intrgral)
	private TextView dealIntrargl;
	
	@ViewInject(R.id.tv_back)
	private TextView tvBack;
	
	@ViewInject(R.id.right_textview)
	private TextView rightTextView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pay_ok);
		ViewUtils.inject(this);
		
		tvBack.setText("交易详情");
		rightTextView.setText("完成");
		rightTextView.setGravity(Gravity.RIGHT);
		
		storeName.setText(this.getIntent().getStringExtra("store_name"));
		dealId.setText(this.getIntent().getStringExtra("deal_id"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		String time = sdf.format(new Date(Long.valueOf(this.getIntent().getStringExtra("deal_time"))));
		dealTime.setText(time);
		dealIntrargl.setText(this.getIntent().getStringExtra("deal_intrargl"));
	}
	
	public void rightTextview(View view){
		finish();
	}
	
	public void onBack(View view){
		finish();
	}
	
};

package com.lefen58.lefenmall.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.RecordObtainJifenListBean;
import com.lefen58.lefenmall.entity.RecordObtainJifenListBean.JifenRecordListBean;
import com.lefen58.lefenmall.utils.DateUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.pulltorefresh.library.PullToRefreshBase;
import com.pulltorefresh.library.PullToRefreshBase.Mode;
import com.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.pulltorefresh.library.PullToRefreshListView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

/**
 * 积分记录list界面
 */
public class RecordJifenObtainActivity extends BaseActivity {

	private static final String TAG = "RecordJifenObtainActivity";
	private ArrayList<JifenRecordListBean> jifenRecordList;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;
	@ViewInject(R.id.no_jifenobtain)
	private ImageView no_jifenobtain;
	@ViewInject(R.id.lv_jifenrecord_activity)
	private PullToRefreshListView lv_jifenrecord_activity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_record_obtainjifen_list);
		ViewUtils.inject(this);
		tv_back.setText("乐分获得记录明细");
		initListView();

		getRecordList();
		jifenRecordAdapter = new JifenRecordAdapter(this, jifenRecordList);
	}

	private void initListView() {
		lv_jifenrecord_activity.setMode(Mode.PULL_FROM_START);
		lv_jifenrecord_activity.setOnRefreshListener(new OnRefreshListener<ListView>() {

			@Override
			public void onRefresh(PullToRefreshBase<ListView> refreshView) {
				// TODO Auto-generated method stub
				getRecordList();
			}
		});
	}

	public void getRecordList() {
		startMyDialog();
		jifenRecordList = new ArrayList<JifenRecordListBean>();
		RequestParams params = new RequestParams();
		HttpUtils http = new HttpUtils();
		params.addBodyParameter("device_index", sp.getString("device_index", ""));
		params.addBodyParameter("c", "obtain_list");
		params.addBodyParameter("token", getToken());
		http.send(HttpMethod.POST, Ip.url + "service.php", params, new RequestCallBack<String>() {
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
				lv_jifenrecord_activity.onRefreshComplete();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
				log.e(arg0.result);
				try {
					RecordObtainJifenListBean getJifenRecordList = new Gson().fromJson(arg0.result,
							RecordObtainJifenListBean.class);
					if (getJifenRecordList.getCode().equals("1") && getJifenRecordList.getList() != null) {
						for (int i = 0; i < getJifenRecordList.getList().size(); i++) {
							jifenRecordList.add(getJifenRecordList.getList().get(i));
						}
						//list l = new list();
						//Collections.sort(jifenRecordList,l);
					}
					if (getJifenRecordList.getList() == null || jifenRecordList.size() == 0
							|| jifenRecordList == null) {
						no_jifenobtain.setVisibility(View.VISIBLE);
						lv_jifenrecord_activity.setVisibility(View.GONE);
					} else {
						no_jifenobtain.setVisibility(View.GONE);
						lv_jifenrecord_activity.setVisibility(View.VISIBLE);
					}

					// 按时间排序
					Collections.sort(jifenRecordList, new Comparator<JifenRecordListBean>() {

						@Override
						public int compare(JifenRecordListBean lhs, JifenRecordListBean rhs) {
							// Log.e("lhs.getPaticipate_time()",
							// lhs.getPaticipate_time());
							// Log.e("rhs.getPaticipate_time()",
							// rhs.getPaticipate_time());
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String d1 = sdf.format(new Date(Long.valueOf(lhs.getMerchant_give_time() + "000")));
							String d2 = sdf.format(new Date(Long.valueOf(rhs.getMerchant_give_time() + "000")));
							// Log.e("d1=========", d1);
							// Log.e("d2=========", d2);
							Date date1 = DateUtils.stringToDate(d1);
							Date date2 = DateUtils.stringToDate(d2);
							// Log.e("date1======", date1+"");
							// Log.e("date2======", date2+"");
							if (date1 != null && date2 != null) {
								if (date1.before(date2)) {
									return 1;
								}
							}
							return -1;
						}
					});

					lv_jifenrecord_activity.setAdapter(jifenRecordAdapter);
				} catch (JsonSyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lv_jifenrecord_activity.onRefreshComplete();
			}
		});
	}

	private JifenRecordAdapter jifenRecordAdapter;

	private class JifenRecordAdapter extends BaseAdapter {

		private ArrayList<JifenRecordListBean> jifenList;
		private Context context;

		public JifenRecordAdapter(Context context, ArrayList<JifenRecordListBean> jList) {

			this.context = context;
			this.jifenList = jList;
		}

		@Override
		public int getCount() {
			return jifenList.size();

		}

		@Override
		public Object getItem(int position) {
			return jifenList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.activity_record_obtainjifen_item, null);
				holder.merchant_name = (TextView) convertView.findViewById(R.id.merchant_name);
				holder.merchant_goods = (TextView) convertView.findViewById(R.id.merchant_goods);
				holder.merchant_income = (TextView) convertView.findViewById(R.id.merchant_income);
				holder.merchant_give_integral = (TextView) convertView.findViewById(R.id.merchant_give_integral);
				holder.tv_data = (TextView) convertView.findViewById(R.id.tv_data);
				holder.time_title = (TextView) convertView.findViewById(R.id.time_title);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			if (jifenList != null) {

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy - MM - dd HH : mm : ss");

				String time = sdf
						.format(new Date(Long.valueOf(jifenList.get(position).getMerchant_give_time() + "000")));

				// Log.e(TAG, time +"======================");
				String oldtime;
				try {
					oldtime = sdf
							.format(new Date(Long.valueOf(jifenList.get(position - 1).getMerchant_give_time() + "000")))
							.substring(0, 14);
				} catch (ArrayIndexOutOfBoundsException e) {
					oldtime = "";
				}

				if (holder.merchant_name != null) {
					holder.merchant_name.setText(jifenList.get(position).getMerchant_name());
				}
				if (holder.merchant_goods != null) {
					holder.merchant_goods.setText("( " + jifenList.get(position).getMerchant_goods() + " )");
				}
				if (holder.merchant_income != null) {
					if (jifenList.get(position).getMerchant_income().equals("0")
							|| jifenList.get(position).getMerchant_income().equals(" ")
							|| jifenList.get(position).getMerchant_income().equals("")) {
						holder.merchant_income.setText("0.00");
					} else {
						holder.merchant_income.setText(Integer.parseInt(jifenList.get(position).getMerchant_income()) / 100 + ".00");
					}
				}
				if (holder.merchant_give_integral != null) {
					holder.merchant_give_integral.setText(jifenList.get(position).getMerchant_give_integral() + ".00");
				}
				if (holder.tv_data != null) {
					holder.tv_data.setText(time.subSequence(15, time.length()));
				}
				if (holder.time_title != null) {
					holder.time_title.setText(time.subSequence(0, 14));
				}
				if (oldtime.equals(time.subSequence(0, 14))) {
					holder.time_title.setVisibility(View.GONE);
				} else {
					holder.time_title.setVisibility(View.VISIBLE);
				}
			}

			return convertView;
		}
	}

	private static class ViewHolder {
		TextView merchant_name;
		TextView merchant_goods;
		TextView merchant_income;
		TextView merchant_give_integral;
		TextView tv_data;
		TextView time_title;
	}
	
	
	class list implements Comparator{

		@Override
		public int compare(Object lhs, Object rhs) {
			JifenRecordListBean bean0 = (JifenRecordListBean)lhs;
			JifenRecordListBean bean1 = (JifenRecordListBean)rhs;
			int flag = bean0.getMerchant_give_time().compareTo(bean1.getMerchant_give_time());
			return flag;
		}
		
	}
}

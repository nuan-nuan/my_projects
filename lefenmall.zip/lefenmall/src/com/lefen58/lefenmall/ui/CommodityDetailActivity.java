package com.lefen58.lefenmall.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.entity.BaseEntity;
import com.lefen58.lefenmall.entity.GetGoodInfoResult;
import com.lefen58.lefenmall.entity.GoodsSkuProperty;
import com.lefen58.lefenmall.entity.MallGoodsInfo;
import com.lefen58.lefenmall.http.MallNetRequest;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.FlowLayout;
import com.lefen58.lefenmall.widgets.NoScrollListview;
import com.lefen58.lefenmall.widgets.ScreenNumView;
import com.lefen58.lefenmall.widgets.ScrollViewContainer;
import com.lefen58.lefenmall.widgets.ScrollViewContainer.SwitchCallback;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ImageView.ScaleType;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 商品详情页
 * 
 * @author Administrator
 *
 */
public class CommodityDetailActivity extends BaseActivity implements SwitchCallback {
	 private ImageLoader imageLoader = ImageLoader.getInstance();
		private DisplayImageOptions options;

	/**
	 * 标题
	 */
	@ViewInject(R.id.tv_back)
	TextView mTvTitle;
	/**
	 * 商品图片
	 */
	@ViewInject(R.id.vp_commodity_img)
	ViewPager mViewPagerAlbum;

	/**
	 * 商品图片指示器
	 */
	@ViewInject(R.id.pager_indicator)
	ScreenNumView mIndicator;

	/**
	 * 商品描述
	 */
	@ViewInject(R.id.tv_description)
	TextView mTvDescription;

	/**
	 * 商品收藏按钮
	 */
	@ViewInject(R.id.tv_collect)
	TextView mTvCollect;

	/**
	 * 商品价格
	 */
	@ViewInject(R.id.tv_price)
	TextView mTvPrice;

	/**
	 * 商品评分条
	 */
	@ViewInject(R.id.ratingBar_grade)
	RatingBar mRateBarGrade;

	/**
	 * 商品评分
	 */
	@ViewInject(R.id.tv_grade)
	TextView mTvGrade;

	/**
	 * 商品销量
	 */
	@ViewInject(R.id.tv_sales_volume)
	TextView mTvSales;

	/**
	 * 商品品牌
	 */
	@ViewInject(R.id.tv_commodity_brand)
	TextView mTvBrand;

	/**
	 * 商品货号
	 */
	@ViewInject(R.id.tv_commodity_number)
	TextView mTvNumber;

	/**
	 * 商品属性列表
	 */
	@ViewInject(R.id.lv_commodity_property)
	NoScrollListview mLvProperty;

	/**
	 * 继续拖动图片
	 */
	@ViewInject(R.id.imgView_pull_up)
	ImageView mImgPullUp;

	/**
	 * 商品详细信息导航栏
	 */
	@ViewInject(R.id.rg_commodity_detail)
	RadioGroup mRgDetails;

	/**
	 * 图文详情按钮
	 */
	@ViewInject(R.id.rb_img_text)
	RadioButton mRbImgText;

	/**
	 * 商品参数按钮
	 */
	@ViewInject(R.id.rb_commodity_param)
	RadioButton mRbCommodityParam;

	/**
	 * 图文详情列表
	 */
	@ViewInject(R.id.lv_img_text)
	NoScrollListview mLvImageText;

	/**
	 * 返回顶部按钮
	 */
	@ViewInject(R.id.imgView_go_top)
	ImageView mImgViewGoTop;

	/**
	 * 上下拉切换控件
	 */
	@ViewInject(R.id.sv_container)
	ScrollViewContainer mSvContainer;

	/**
	 * 上部布局
	 */
	@ViewInject(R.id.sv_top)
	ScrollView mSvTop;
	
	/**
	 * 无数据展示的视图
	 */
	@ViewInject(R.id.layout_no_data)
	View mViewNoData;
	
	/**
	 * 无数据时的文本
	 */
	@ViewInject(R.id.tv_no_data)
	TextView mTvNoData;

	private String mCommodityId;//商品id
	private MallNetRequest mMallRequest;
	private MallGoodsInfo mGoodInfo;
	private List<String> mAlbum;
	private List<String> mImgTextList;
	private BitmapUtils mBitmapUtil;
	private BitmapDisplayConfig mBitmapDisplayConfig;
	private boolean mIsCollected = false;// 是否收藏
	private boolean mIsLogin=false;//登录状态时候有效

	private OnClickListener mOnClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.tv_collect:
				if (!isLogin()) {
					showToast(R.string.login_first);
					return;
				}
				if (!mIsCollected) {
					collectCommodity();
				} else {
					cancelCollectCommodity();
				}
				break;
			case R.id.imgView_go_top:
				mSvContainer.rollToTop();
				mSvTop.scrollTo(0, 0);
				break;

			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_commodity_detail);
		ViewUtils.inject(this);
		imageLoader.init(ImageLoaderConfiguration.createDefault(this));
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.zw)
				.showImageForEmptyUri(R.drawable.zw)
				.showImageOnFail(R.drawable.zw)
				// 这里的三张状态用一张替代
				.cacheInMemory().imageScaleType(ImageScaleType.EXACTLY)
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565)

				.build();
		init();
		registerEvents();
		getCommodityDetails();
	}

	private void init() {
		mCommodityId=getIntent().getStringExtra("good_id");
		mTvTitle.setText(R.string.commodity_details);
		mBitmapUtil = new BitmapUtils(context);
		mMallRequest = new MallNetRequest(context);
		mBitmapDisplayConfig=new BitmapDisplayConfig();
		Drawable drawable=getResources().getDrawable(R.drawable.zw);
//		mBitmapDisplayConfig.setLoadingDrawable(drawable);
		mBitmapDisplayConfig.setLoadFailedDrawable(drawable);
	}

	private void registerEvents() {
		mTvCollect.setOnClickListener(mOnClickListener);
		mImgViewGoTop.setOnClickListener(mOnClickListener);
		mSvContainer.setSwitchCallbak(this);
		mRgDetails.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			private Drawable drawableBottom=getResources().getDrawable(R.drawable.blue_underline);


			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				drawableBottom.setBounds(0, 0, drawableBottom.getMinimumWidth(), drawableBottom.getMinimumHeight());
				switch (checkedId) {
				case R.id.rb_img_text:
					mRbImgText.setCompoundDrawables(null, null, null, drawableBottom);
					mRbCommodityParam.setCompoundDrawables(null, null, null, null);
					if (mImgTextList==null) {
						return;
					}
					if (mImgTextList.size()==0) {
						mLvImageText.setVisibility(View.GONE);
						mViewNoData.setVisibility(View.VISIBLE);
						mTvNoData.setText("很抱歉，暂无图文详情！");
					}else {
						mViewNoData.setVisibility(View.GONE);
						mLvImageText.setVisibility(View.VISIBLE);
					}
					break;
				case R.id.rb_commodity_param:
					mRbImgText.setCompoundDrawables(null, null, null, null);
					mRbCommodityParam.setCompoundDrawables(null, null, null, drawableBottom);
					mLvImageText.setVisibility(View.GONE);
					mViewNoData.setVisibility(View.VISIBLE);
					mTvNoData.setText("很抱歉，暂无产品参数！");
					break;

				default:
					break;
				}
			}
		});

		mViewPagerAlbum.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				mIndicator.snapToPage(arg0);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});
	}

	/**
	 * 获取商品详情
	 */
	private void getCommodityDetails() {

		mMallRequest.getGoodsInfo(mCommodityId, GetGoodInfoResult.class, new RequestCallBack<GetGoodInfoResult>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<GetGoodInfoResult> arg0) {
				// TODO Auto-generated method stub
				stopMyDialog();
				if (arg0.result == null) {
					return;
				}
				if (arg0.result.code == 1) {
					mGoodInfo = arg0.result.good;
					if (arg0.result.yetCollect == 0) {
						mIsCollected = false;
					} else if (arg0.result.yetCollect == 1) {
						mIsCollected = true;
					}
					if (arg0.result.loginState==0) {
						mIsLogin=false;
					}else if (arg0.result.loginState==1) {
						mIsLogin=true;
					}
					initCommodityInfo();
				}
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				stopMyDialog();
			}
		});
	}

	/**
	 * 收藏
	 */
	private void collectCommodity() {
		mMallRequest.goodsCollect(RequestOftenKey.getDeviceIndex(context), RequestOftenKey.getToken(context), mCommodityId,
				BaseEntity.class, new RequestCallBack<BaseEntity>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				mTvCollect.setClickable(false);
			}

			@Override
			public void onSuccess(ResponseInfo<BaseEntity> arg0) {
				// TODO Auto-generated method stub
				mTvCollect.setClickable(true);
				Drawable topDrawable = getResources().getDrawable(R.drawable.onstar_collect);
				topDrawable.setBounds(0, 0, topDrawable.getMinimumWidth(), topDrawable.getMinimumHeight());
				mTvCollect.setCompoundDrawables(null, topDrawable, null, null);
				mIsCollected = true;
				showToast("收藏成功");
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				mTvCollect.setClickable(true);
				showToast("收藏失败");
			}
		});
	}

	/**
	 * 取消收藏
	 */
	private void cancelCollectCommodity() {
		mMallRequest.goodsCancelCollect(RequestOftenKey.getDeviceIndex(context), RequestOftenKey.getToken(context),
				mCommodityId, BaseEntity.class, new RequestCallBack<BaseEntity>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				mTvCollect.setClickable(false);
			}

			@Override
			public void onSuccess(ResponseInfo<BaseEntity> arg0) {
				// TODO Auto-generated method stub
				mTvCollect.setClickable(true);
				Drawable topDrawable = getResources().getDrawable(R.drawable.star_collect);
				topDrawable.setBounds(0, 0, topDrawable.getMinimumWidth(), topDrawable.getMinimumHeight());
				mTvCollect.setCompoundDrawables(null, topDrawable, null, null);
				mIsCollected = false;
				showToast("取消收藏成功");
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				mTvCollect.setClickable(true);
				showToast("取消收藏失败");
			}
		});
	}

	/**
	 * 加载商品信息
	 */
	private void initCommodityInfo() {
		if (mGoodInfo != null) {
			mTvDescription.setText(mGoodInfo.goods_name);
			mTvPrice.setText(mGoodInfo.goodsIntegralPrice+".00");
			mTvGrade.setText(Float.parseFloat(mGoodInfo.goods_grade.substring(0, 1))+"评分");
			mTvSales.setText(getString(R.string.sales_volume_month, mGoodInfo.goodsSalesVolume));
			mTvBrand.setText(mGoodInfo.goodsBrand);
			mTvNumber.setText(mGoodInfo.goodsId);
			mRateBarGrade.setRating(Float.parseFloat(mGoodInfo.goods_grade.substring(0, 1)));
			mAlbum = mGoodInfo.goods_album;
			mImgTextList = mGoodInfo.goodsIntroduce;

			AlbumAdapter albumAdapter=new AlbumAdapter();
			mViewPagerAlbum.setAdapter(albumAdapter);
			mIndicator.initScreen(albumAdapter.getCount());

			mLvProperty.setAdapter(new PropertyAdapter());

//			if (mImgTextList==null||mImgTextList.size()==0) {
//				mLvImageText.setVisibility(View.GONE);
//				mViewNoData.setVisibility(View.VISIBLE);
//				mTvNoData.setText("很抱歉，暂无图文详情！");
//			}else {
//				mLvImageText.setAdapter(new ImageTextAdapter());
////				CommonUtils.setListViewHeightBasedOnChildren(mLvImageText);
//			}
		}

		if (mIsCollected) {
			Drawable topDrawable = getResources().getDrawable(R.drawable.onstar_collect);
			topDrawable.setBounds(0, 0, topDrawable.getMinimumWidth(), topDrawable.getMinimumHeight());
			mTvCollect.setCompoundDrawables(null, topDrawable, null, null);
		} else {
			Drawable topDrawable = getResources().getDrawable(R.drawable.star_collect);
			topDrawable.setBounds(0, 0, topDrawable.getMinimumWidth(), topDrawable.getMinimumHeight());
			mTvCollect.setCompoundDrawables(null, topDrawable, null, null);
		}
	}

	class AlbumAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (mAlbum != null) {
				return mAlbum.size();
			}
			return 0;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0 == arg1;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			// TODO Auto-generated method stub
			container.removeView((View) object);
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			// TODO Auto-generated method stub
			ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
					ViewGroup.LayoutParams.MATCH_PARENT);
			ImageView imageView = new ImageView(context);
			imageView.setScaleType(ScaleType.CENTER_CROP);
			mBitmapUtil.display(imageView, Constants.ImageUrl + mAlbum.get(position),mBitmapDisplayConfig);
			imageView.setScaleType(ScaleType.CENTER_CROP);
			container.addView(imageView, lp);
			return imageView;
		}

	}

	class PropertyAdapter extends BaseAdapter {

		private List<GoodsSkuProperty> mPropertys = mGoodInfo.goods_sku_property;
		private List<GoodsSkuProperty> mValues = mGoodInfo.goods_sku_values;
		private List<String> mValueFilter = new ArrayList<String>();

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (mPropertys != null) {
				return mPropertys.size();
			}
			return 0;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (mPropertys != null) {
				return mPropertys.get(position);
			}
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			mValueFilter.clear();
			convertView = getLayoutInflater().inflate(R.layout.item_commodity_property_list, null);
			TextView tvPropertyName = (TextView) convertView.findViewById(R.id.tv_property_name);
			FlowLayout layoutPropertyValue = (FlowLayout) convertView.findViewById(R.id.flayout_property_values);
			GoodsSkuProperty property = mPropertys.get(position);
			if (property != null) {
				tvPropertyName.setText("该商品提供的"+property.skuName);
				for (GoodsSkuProperty value : mValues) {
					if (property.skuId == null) {
						continue;
					}
					if (property.skuId.equals(value.skuParentId)) {
						mValueFilter.add(value.skuName);
					}
				}

				Collections.sort(mValueFilter, new Comparator<String>() {

					@Override
					public int compare(String lhs, String rhs) {
						// TODO Auto-generated method stub
						return lhs.length()-rhs.length();
					}
				});
				for (String str : mValueFilter) {
					layoutPropertyValue.addView(getValueView(str));
				}
			}

			return convertView;
		}

		class ViewHolder {
			TextView tvPropertyName;
			FlowLayout layoutPropertyValue;
		}

		private View getValueView(String value) {
			TextView tv = new TextView(context);
			MarginLayoutParams mlp = new MarginLayoutParams(MarginLayoutParams.WRAP_CONTENT,
					CommonUtils.dip2px(context, 27));
			int margin = CommonUtils.dip2px(context, 4.5F);

			mlp.setMargins(0, CommonUtils.dip2px(context, 8.3F), CommonUtils.dip2px(context, 10F), CommonUtils.dip2px(context, 8.3F));
			tv.setLayoutParams(mlp);
			tv.setTextSize(12);
			tv.setTextColor(0xff999999);
			tv.setText(value);
			tv.setBackgroundResource(R.drawable.commodity_property_item_bg);
			return tv;
		}
	}

	class ImageTextAdapter extends BaseAdapter {
		
		int imgHeight;
		
		public ImageTextAdapter() {
			// TODO Auto-generated constructor stub
//			DisplayMetrics dMetrics=new DisplayMetrics();
//			getWindowManager().getDefaultDisplay().getRealMetrics(dMetrics);
//			screenWith=dMetrics.widthPixels;
			
			WindowManager wm = getWindowManager();
			 
			imgHeight = wm.getDefaultDisplay().getWidth();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (mImgTextList != null) {
				return mImgTextList.size();
			}
			return 0;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (mImgTextList != null) {
				return mImgTextList.get(position);
			}
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
//			ViewHolder viewHolder;
//			ImageView imageView;
			if (convertView == null) {
//				viewHolder =new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.item_commodity_img_text_list, null);
//				convertView.setTag(viewHolder);
			}
			ImageView imageView = (ImageView) convertView.findViewById(R.id.imgView_img_text);
				ViewGroup.LayoutParams lp=imageView.getLayoutParams();
				lp.height=imgHeight;
				imageView.setLayoutParams(lp);
			imageLoader.displayImage(Constants.ImageUrl + mImgTextList.get(position), imageView, options,
					new SimpleImageLoadingListener() {
						@Override
						public void onLoadingStarted(String imageUri, View view) {
						}

						@Override
						public void onLoadingFailed(String imageUri, View view,
								FailReason failReason) {
							String message = null;
							switch (failReason.getType()) {
							case IO_ERROR:
							case DECODING_ERROR:
							case NETWORK_DENIED:
							case OUT_OF_MEMORY:
							case UNKNOWN:
								message = "图片加载错误";
								break;
							}
						}

						@Override
						public void onLoadingComplete(String imageUri,
								View view, Bitmap loadedImage) {
							
						}
					});
			//mBitmapUtil.display(imageView, Constants.ImageUrl + mImgTextList.get(position),mBitmapDisplayConfig);
			return convertView;
		}

		class ViewHolder{
			ImageView imageView;
		}
	}

	@Override
	public void onEnd(int currentViewIndex, View topView, View bottomView) {
		// TODO Auto-generated method stub
		if (currentViewIndex == 0) {
			mImgViewGoTop.setVisibility(View.INVISIBLE);
		} else if (currentViewIndex == 1) {
			mImgViewGoTop.setVisibility(View.VISIBLE);
			if (mImgTextList==null||mImgTextList.size()==0) {
				mLvImageText.setVisibility(View.GONE);
				mViewNoData.setVisibility(View.VISIBLE);
				mTvNoData.setText("很抱歉，暂无图文详情！");
			}else {
				mLvImageText.setAdapter(new ImageTextAdapter());
//				CommonUtils.setListViewHeightBasedOnChildren(mLvImageText);
			}
			bottomView.requestFocus();
		}
	}
}

package com.lefen58.lefenmall.ui;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.baidu.location.LocationClient;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.LeFenMallApplication;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.ViewPagerAdapter;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.ActivityList;
import com.lefen58.lefenmall.entity.Feedback;
import com.lefen58.lefenmall.entity.Get_newest_version_info;
import com.lefen58.lefenmall.entity.MainActivityList;
import com.lefen58.lefenmall.http.OtherNetRequest;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.service.UpdateService;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.widgets.VersionDialog;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.pulltorefresh.library.PullToRefreshBase;
import com.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.pulltorefresh.library.PullToRefreshScrollView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends BaseActivity implements OnPageChangeListener {

	private LocationClient mLocationClient;

	private Context mContext;// 上下文

	private int width;

	private int newWidth;

	private int padding;

	private final static int SCANNIN_GREQUEST_CODE = 1;

	private static SharedPreferences sp;

	private ViewPagerAdapter mViewPagerAdp;

	private ArrayList<Bitmap> bitmaps;
	private ArrayList<String> urlString;

	private ImageView[] mDots;

	private int pageIndex=0;

	private OtherNetRequest mAppNetRequest;

	@ViewInject(R.id.viewpager)
	private ViewPager mViewpager;

	@ViewInject(R.id.ll_points)
	private LinearLayout layoutDots;

	@ViewInject(R.id.iv_dajiacai)
	private ImageView ivDajiacai;

	private final long delay = 3 * 1000;

	private final int AUTO = 0;

	@ViewInject(R.id.tv_address)
	private TextView tv_address;

	@ViewInject(R.id.lv_main_activity)
	private ListView lv_main_activity;
	private int one;
	ArrayList<MainActivityList> mainActivitys;
	LeFenMallApplication app;
	/**
	 * 上下拉scrollview
	 */
	@ViewInject(R.id.sv_pull_refresh)
	private PullToRefreshScrollView mScrollView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = this;

		setContentView(R.layout.activity_main);
		ViewUtils.inject(this);
		mainActivitys = new ArrayList<MainActivityList>();
		app = (LeFenMallApplication) getApplication();
		sp = getSharedPreferences("UserInfor", 0);

		width = getResources().getDisplayMetrics().widthPixels;

		newWidth = (int) (divideWidth(width, 1080, 6) * 17);

		padding = (int) (divideWidth(width, 1080, 6) * 7);

		// set listener
		mViewpager.setOnPageChangeListener(this);
		getViewPager();

		lv_main_activity.setFocusable(false);
		initScrollView();
		setActivityList();
		checkUpadte();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		return;
	}

	private void checkUpadte() {
		String latestVersion=sp.getString(Constants.SPKEY_LATEST_VERSION, "");
		if (latestVersion.equals("")) {
			return;
		}
		if (latestVersion.compareTo(CommonUtils.getAppVersion(context))<=0) {
			//			Toast.makeText(context, "当前已是最新版本", Toast.LENGTH_LONG).show();
			return;
		}

		if (mAppNetRequest==null) {
			mAppNetRequest=new OtherNetRequest(context);
		}
		mAppNetRequest.getNewVersionInfo(new RequestCallBack<Get_newest_version_info>() {

			@Override
			public void onSuccess(ResponseInfo<Get_newest_version_info> arg0) {
				// TODO Auto-generated method stub

				log.i("infor+arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
				log.i("infor+checkUpdata");

				if (arg0.statusCode == 200) {

					Get_newest_version_info info = arg0.result;

					if (info.getCode()==1) {
						VersionDialog.Builder builder = new VersionDialog.Builder(context);
						builder.setTitle("新版本升级");
						builder.setMessage(info.getInfo());
						builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								Intent intent=new Intent(context, UpdateService.class);
								startService(intent);
								dialog.dismiss();
							}
						});
						builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								dialog.dismiss();
							}
						});
						builder.create().show();
					} else {
						Toast.makeText(context, "异常："+info.getCode(), Toast.LENGTH_SHORT).show();
					}

				} else {
					Toast.makeText(context, "异常："+arg0.statusCode, Toast.LENGTH_SHORT).show();
				}

			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
			}
		});
	}

	/**
	 * 获取viewpager网络url
	 */
	private void getViewPager() {

		urlString = new ArrayList<String>();
		bitmaps = new ArrayList<Bitmap>();

		HttpUtils httpUtils = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("device_index", sp.getString("device_index", ""));
		params.addBodyParameter("city", sp.getString("cityId", "0"));
		params.addBodyParameter("county", sp.getString("countyId", "0"));
		params.addBodyParameter("c", "view_pager");
		httpUtils.send(HttpMethod.POST, Ip.url + "service.php", params, new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i(arg0);

			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i(arg0.result);
				urlString.clear();
				bitmaps.clear();
				layoutDots.removeAllViews();
				mHandler.removeMessages(AUTO);
				Feedback feedback = new Gson().fromJson(arg0.result, Feedback.class);
				if (feedback.getCode().equals("1") && feedback.getList() != null) {
					for (int i = 0; i < feedback.getList().size(); i++) {
						urlString.add(feedback.getList().get(i));
					}
				}

				for (int i = 0; i < urlString.size(); i++) {
					one = urlString.get(i).lastIndexOf("/");
					if (ImageUtils.getLoacalBitmap(
							Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
							urlString.get(i).substring((one+1),urlString.get(i).length())) != null) {
						bitmaps.add(ImageUtils.getLoacalBitmap(
								Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
								urlString.get(i).substring((one+1),urlString.get(i).length())));
						log.i("从本地加载图片==============");
					} else {
						log.i("网络获取图片并保存在本地========================");
						ImageUtils.getNetworkBitmap(urlString.get(i), "/com.lefen58/userphoto/",
								urlString.get(i).substring((one+1),urlString.get(i).length()));
						bitmaps.add(ImageUtils.getLoacalBitmap(
								Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
								urlString.get(i).substring((one+1),urlString.get(i).length())));
					}
				}
				initDots();
				initViewPager();
			}
		});
	}

	/**
	 * @author
	 * 
	 * 		初始化ViewPager的底部小点
	 * 
	 */
	private void initDots() {
		mDots = new ImageView[urlString.size()];
		if(urlString.size() <= 0)
			return;
		for (int i = 0; i < urlString.size(); i++) {
			ImageView iv = new ImageView(mContext);
			LayoutParams lp = new LayoutParams(newWidth, newWidth);
			lp.leftMargin = padding;
			lp.rightMargin = padding;
			lp.topMargin = padding;
			lp.bottomMargin = padding;

			iv.setLayoutParams(lp);
			iv.setImageResource(R.drawable.circle_off);
			layoutDots.addView(iv);
			mDots[i] = iv;
		}
		mDots[0].setImageResource(R.drawable.circle_on);
	}

	/**
	 * @author
	 * 
	 * 		初始化ViewPager
	 * 
	 */
	private void initViewPager() {
		int imgSize;
		if(urlString.size() <= 0)
		{
			mViewpager.setVisibility(View.GONE);
			return;
		}
		if (urlString.size() < 3) {
			imgSize = urlString.size() * 3;
		} else {
			imgSize = urlString.size();
		}
		ImageView[] imgs = new ImageView[imgSize];
		for (int i = 0; i < imgs.length; i++) {
			ImageView iv = new ImageView(mContext);
			iv.setScaleType(ScaleType.FIT_XY);
			iv.setImageBitmap(bitmaps.get(i%urlString.size()));
			imgs[i]=iv;
		}

		mViewPagerAdp = new ViewPagerAdapter(imgs, urlString);
		mViewpager.setAdapter(mViewPagerAdp);
		//mViewpager.setCurrentItem(100);
		mHandler.sendEmptyMessageDelayed(AUTO, delay);
	}

	public void initScrollView() {
		mScrollView.setMode(com.pulltorefresh.library.PullToRefreshBase.Mode.BOTH);
		mScrollView.getLoadingLayoutProxy(true, false).setPullLabel("下拉刷新");
		mScrollView.getLoadingLayoutProxy(false, true).setPullLabel("上拉加载更多");
		mScrollView.setOnRefreshListener(new OnRefreshListener2<ScrollView>() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				pageIndex=0;
				setActivityList();
				getViewPager();
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
				// TODO Auto-generated method stub
				setActivityList();
			}
		});

		lv_main_activity.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				MainActivityList activity = (MainActivityList) parent.getItemAtPosition(position);

				Intent i;
				if (activity.getActivity_type().equals("4")) {
					i = new Intent(MainActivity.this, YaoYiYaoActivity.class);
					i.putExtra("activity_index", activity.getActivity_index());
					startActivity(i);
				}
				if (activity.getActivity_type().equals("1")) {
					i = new Intent(MainActivity.this, DaZhuanPanDetailActivity.class);
					i.putExtra("activity_index", activity.getActivity_index());
					startActivity(i);
				}

			}
		});
	}

	/**
	 * 搜索
	 */
	public void find(View view) {
		Intent intent = new Intent(MainActivity.this, FindActivity.class);
		intent.putExtra("flag", "g");
		startActivity(intent);
	}

	/**
	 * 跳转至附近
	 */
	public void near(View view) {
		// HomeActivity.getInstance();
		if (HomeActivity.mChangePageListener != null) {
			HomeActivity.mChangePageListener.changeListener();
		}

	}

	public interface ChangePageListener {
		public void changeListener();
	}

	private ChangePageListener changePageListener;

	public void setChangeValueListener(ChangePageListener changePageListener) {
		this.changePageListener = changePageListener;
	}

	/**
	 * 摇一摇
	 */
	public void YaoYiYao(View view) {
		Intent intent = new Intent(MainActivity.this, ListActivity.class);
		intent.putExtra("activityName", "摇一摇");
		intent.putExtra("activityType", "4");
		startActivity(intent);
	}

	/**
	 * 大转盘
	 */
	public void dazhuanpan(View view) {
		Intent intent = new Intent(MainActivity.this, ListActivity.class);
		intent.putExtra("activityName", "大转盘");
		intent.putExtra("activityType", "1");
		startActivity(intent);
	}

	/**
	 * 兑换中心
	 * 
	 * @param view
	 */
	public void duihuan(View view) {
		Intent intent = new Intent(MainActivity.this, MerchantActivity.class);
		intent.putExtra("itemType", "1");
		intent.putExtra("merchant_id", "0");
		startActivity(intent);
	}

//	/**
//	 * 刮刮卡
//	 * 
//	 * @param view
//	 */
//	public void guaguaka(View view) {
//		Intent intent = new Intent(MainActivity.this, ListActivity.class);
//		intent.putExtra("activityName", "刮刮卡");
//		intent.putExtra("activityType", "3");
//		startActivity(intent);
//	}

	/**
	 * 活动
	 * 
	 * @param view
	 */
	public void activity(View view) {
		Intent intent = new Intent(MainActivity.this, ListActivity.class);
		intent.putExtra("activityName", "活动中心");
		intent.putExtra("activityType", "0");
		startActivity(intent);
	}

	/**
	 * 消息
	 * 
	 * @param view
	 */
	public void info(View view) {
		Intent intent = new Intent(MainActivity.this, ListActivity.class);
		intent.putExtra("activityName", "消息");
		intent.putExtra("activityType", "5");
		startActivity(intent);
	}

	/**
	 * 大家猜
	 * 
	 * @param view
	 */
	public void dajiacai(View view) {
		Intent intent = new Intent(MainActivity.this, ListActivity.class);
		intent.putExtra("activityName", "大家猜");
		intent.putExtra("activityType", "2");
		startActivity(intent);
	}

	/**
	 * 获取首页活动list
	 */
	int i = 0;

	private void setActivityList() {

		RequestParams params = new RequestParams();
		HttpUtils http = new HttpUtils();

		// "device_index\":\"3\",\"c\":\"list\",\"token\":\"17667\",\"type\":\"0\",\"city\":\"\",\"county\":\"0\",\"page\":\"0\"}"}

		params.addBodyParameter("device_index", sp.getString("device_index", ""));
		params.addBodyParameter("c", "list");
		// params.addBodyParameter("token", String.valueOf(token));
		params.addBodyParameter("type", "0");
		params.addBodyParameter("city", sp.getString("cityId", "0"));
		// params.addBodyParameter("county", sp.getString("countyId", ""));
		params.addBodyParameter("county", sp.getString("countyId", "0"));
		params.addBodyParameter("page", pageIndex+"");
		http.send(HttpMethod.POST, Ip.url + "activity.php", params, new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i("infor" + arg0.getExceptionCode() + "--" + arg1);
				mScrollView.onRefreshComplete();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i("infor" + arg0.result);
				try {
					ActivityList activityList = new Gson().fromJson(arg0.result, ActivityList.class);
					if (activityList.getCode().equals("1")) {
						if (pageIndex==0) {
							mainActivitys.clear();
						}
						++pageIndex;
						for (int i = 0; i < activityList.getList().size(); i++) {
							mainActivitys.add(activityList.getList().get(i));
						}
					}
					lv_main_activity.setAdapter(new activityAdapter(MainActivity.this, mainActivitys));
					CommonUtils.setListViewHeightBasedOnChildren(lv_main_activity);
				} catch (JsonSyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mScrollView.onRefreshComplete();
			}
		});

	}

	@Override
	protected void onResume() {
		super.onStart();
		log.i(sp.getString("city", "未定位"));
		tv_address.setText(sp.getString("city", "未定位"));
		if (!tv_address.getText().equals("未定位")) {
			setActivityList();
		}
	}

	public void scanCamera(View view) {
		Intent intent = new Intent();
		intent.setClass(MainActivity.this, MipcaActivityCapture.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivityForResult(intent, SCANNIN_GREQUEST_CODE);
	}

	public void editAddress(View view) {
		Intent intent = new Intent(this, AreaSelectionActivity.class);
		startActivity(intent);

	}

	/**
	 * 
	 * 
	 * @param screenWidth
	 *            手机屏幕的宽度
	 * 
	 * @param picWidth
	 *            原始图片所用分辨率的宽度
	 * 
	 * @param retainValue
	 *            保留小数位
	 * 
	 * @return 手机屏幕分辨率与原始图片分辨率的宽度比
	 * 
	 */
	public double divideWidth(int screenWidth, int picWidth, int retainValue) {
		BigDecimal screenBD = new BigDecimal(Double.toString(screenWidth));
		BigDecimal picBD = new BigDecimal(Double.toString(picWidth));
		return screenBD.divide(picBD, retainValue, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	private Handler mHandler = new Handler() {

		@Override
		public void dispatchMessage(Message msg) {

			switch (msg.what) {
			case AUTO:
				int index = mViewpager.getCurrentItem();
				mViewpager.setCurrentItem(index + 1);
				mHandler.sendEmptyMessageDelayed(AUTO, delay);
				break;

			default:
				break;
			}

		};
	};

	@Override
	public void onPageScrollStateChanged(int arg0) {

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {

	}

	@Override
	public void onPageSelected(int position) {

		if (urlString.size() > 0) {
			setCurrentDot(position % urlString.size());
		}

	}

	/**
	 * @author
	 * 
	 * 		设置ViewPager当前的底部小点
	 * 
	 * 
	 */
	private void setCurrentDot(int currentPosition) {

		for (int i = 0; i < mDots.length; i++) {
			if (i == currentPosition) {
				mDots[i].setImageResource(R.drawable.circle_on);
			} else {
				mDots[i].setImageResource(R.drawable.circle_off);
			}
		}
	}

	class activityAdapter extends BaseAdapter {
		private ArrayList<MainActivityList> mainActivitys;
		private Context context;

		public activityAdapter(Context context, ArrayList<MainActivityList> mList) {

			this.context = context;
			this.mainActivitys = mList;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mainActivitys.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mainActivitys.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.listview_main_acitivity, null);
				holder.activity_iv_prize = (ImageView) convertView.findViewById(R.id.activity_iv_prize);
				holder.activity_name = (TextView) convertView.findViewById(R.id.activity_name);
				holder.activity_sponsor_name = (TextView) convertView.findViewById(R.id.activity_sponsor_name);
				holder.activity_start_time = (TextView) convertView.findViewById(R.id.activity_start_time);
				holder.activity_status = (TextView) convertView.findViewById(R.id.activity_status);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (this.mainActivitys != null) {
				if (holder.activity_iv_prize != null) {
					bitmapUtils.display(holder.activity_iv_prize,
							"http://cdn.image.huyongle.com/" + mainActivitys.get(position).getActivity_prize_url());
				}
				if (holder.activity_name != null) {
					holder.activity_name.setText(mainActivitys.get(position).getActivity_name());
				}

				if (holder.activity_start_time != null) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String startTime = sdf.format(new Date(Long.valueOf(mainActivitys.get(position).getActivity_start_time() + "000")));

					holder.activity_start_time.setText(startTime);
				}
				if (holder.activity_status != null) {
					if (mainActivitys.get(position).getActivity_status().equals("0")) {
						holder.activity_status.setText("（未开始）");
					} else {
						holder.activity_status.setText("（正在进行中）");
					}

				}
				if (holder.activity_sponsor_name != null) {
					holder.activity_sponsor_name.setText(mainActivitys.get(position).getActivity_sponsor_name());
				}
			}
			return convertView;
		}
	}

	private static class ViewHolder {
		ImageView activity_iv_prize;
		TextView activity_name;
		TextView activity_sponsor_name;
		TextView activity_start_time;
		TextView activity_status;
	}

}

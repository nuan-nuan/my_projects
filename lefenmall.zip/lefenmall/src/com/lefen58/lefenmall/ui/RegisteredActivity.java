package com.lefen58.lefenmall.ui;

import java.util.Timer;
import java.util.TimerTask;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.entity.RegisterAccount;
import com.lefen58.lefenmall.http.AccountNetRequest;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.PreferenceUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisteredActivity extends BaseActivity {

	AccountNetRequest netRequest;

	/**
	 * 注册界面
	 */
	@ViewInject(R.id.tv_sendphonecode)
	private TextView tv_sendphonecode;

	@ViewInject(R.id.etphone)
	private EditText etphone;

	@ViewInject(R.id.etphonecode)
	private EditText etphonecode;

	@ViewInject(R.id.etpassword)
	private EditText etpassword;

	@ViewInject(R.id.etpasswordtest)
	private EditText etpasswordtest;

	@ViewInject(R.id.cbAgreement)
	private CheckBox cbAgreement;

	static int time = 60;
	private Timer timer;

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	@ViewInject(R.id.right_textview)
	private TextView rightTextView;

	private static final int SEND_PHONE_CODE_TIME = 1001;

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SEND_PHONE_CODE_TIME:
				time = time - 1;
				if (time <= 0) {
					timer.cancel();
					tv_sendphonecode.setEnabled(true);
					time = 60;
					tv_sendphonecode.setText("点击发送验证码");


				} else {
					tv_sendphonecode.setText("(" + time + "s)重新发送");
					tv_sendphonecode.setTextColor(0xff69768d);
				}

				break;

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_registered);
		ViewUtils.inject(this);

		tvBack.setText("新用户注册");
	}

	public void sendPhoneCode(View view) {

		// 获取验证码
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())
				&&CommonUtils.passwordVerify(etpassword.getText().toString())
				&&etpassword.getText().toString().equals(etpasswordtest.getText().toString())) {
			startMyDialog();
			tv_sendphonecode.setEnabled(false);

			HttpUtils http = new HttpUtils();
			// 短信验证
			http.send(
					HttpMethod.POST, Ip.get_SMS_code + "verify_type=0" + "&device_index="
							+ sp.getString("device_index", "0") + "&phone=" + etphone.getText().toString(),
							null, new RequestCallBack<String>() {

						@Override
						public void onFailure(HttpException arg0, String arg1) {
							Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
							Toast.makeText(context, "请求失败", 0).show();
							stopMyDialog();
						}

						@Override
						public void onSuccess(ResponseInfo<String> arg0) {
							stopMyDialog();
							log.i(arg0.result);
							Gson gson = new Gson();
							Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
							if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
								Toast.makeText(RegisteredActivity.this, "发送成功", Toast.LENGTH_SHORT).show();
								timer = new Timer(true);
								timer.schedule(new TimerTask() {
									public void run() {
										Message msg = handler.obtainMessage(SEND_PHONE_CODE_TIME);
										handler.sendMessage(msg);
									}
								}, 1000, 1000);
							} else{
								tv_sendphonecode.setEnabled(true);
							}

						}
					});

		} else {
			Toast.makeText(RegisteredActivity.this, "手机号或密码不合法", Toast.LENGTH_SHORT).show();
		}

	}

	public void registered(View view) {
		if (netRequest==null) {
			netRequest=new AccountNetRequest(context);
		}
		final View regView=view;
		if (CommonUtils.isPhoneNumer(etphone.getText().toString())) {

			String password = CommonUtils.getMD5Str(etpassword.getText().toString())
					+ CommonUtils.getMD5Str(etphonecode.getText().toString());
			netRequest.registerAccoiunt(etphone.getText().toString(), etphonecode.getText().toString(),
					password.toLowerCase(), RegisterAccount.class, new RequestCallBack<RegisterAccount>() {

				@Override
				public void onStart() {
					// TODO Auto-generated method stub
					super.onStart();
					startMyDialog();
				}

				@Override
				public void onSuccess(ResponseInfo<RegisterAccount> arg0) {
					// TODO Auto-generated method stub

					switch (arg0.result.code) {
					case 1:
						stopMyDialog();
						PreferenceUtils.writeStrConfig("token", arg0.result.token, context);
						PreferenceUtils.writeStrConfig("given_integral", arg0.result.given_integral, context);
						PreferenceUtils.writeStrConfig("integral_balance", arg0.result.integral_balance, context);

						PreferenceUtils.writeBoolConfig("state", true, context);
						RequestOftenKey.getUserInfor(context, sp);
						Intent intent = new Intent(RegisteredActivity.this, HomeActivity.class);
						startActivity(intent);
						finish();
						break;

					case -3:
						new Thread(new Runnable() {
							public void run() {
								try {
									Thread.sleep(5000);
									registered(regView);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();
						break;

					case -5:
						stopMyDialog();
						showToast("验证码验证失败");
						break;
					case -12:
						stopMyDialog();
						showToast("账号已注册");
						break;
					}

				}

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					stopMyDialog();
					showToast("网络异常，请检查网络后重新登录");
				}
			});
		} else {
			Toast.makeText(RegisteredActivity.this, "手机号不合法", Toast.LENGTH_SHORT).show();
		}
	}


	public void showAgreement(View view) {
		Intent intent = new Intent(context, AgreementActivity.class);
		intent.putExtra("title", "用户协议");
		intent.putExtra("url", Constants.UserAgreement);
		startActivity(intent);
	}

}

package com.lefen58.lefenmall.ui;

import java.util.ArrayList;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.ShakePrize;
import com.lefen58.lefenmall.entity.ShakePrize.PrizeList;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PrizeListActivity extends BaseActivity{

	@ViewInject(R.id.lv_prize_details)
	private ListView lvPrizeDetails;
	
	ArrayList<PrizeList> prizelists; 
	
	@ViewInject(R.id.tv_back)
	private TextView tvBack;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_prize_details);
		ViewUtils.inject(this);
		
		setPrizeDetails(this.getIntent().getStringExtra("activity_index"));
		tvBack.setText("奖品列表");
	}

	void setPrizeDetails(String index){


		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "shake_prize");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token", RequestOftenKey.getToken(context));
		params.addBodyParameter("activity_index", index);

		HttpUtils http = new HttpUtils();
		http.send(HttpMethod.POST, Ip.url+"activity.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
				Toast.makeText(context, "网络异常", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i(arg0.result);
				ShakePrize shakePrize = new Gson().fromJson(arg0.result, ShakePrize.class);
				if (CommonUtils.NetworkRequestReturnCode(context, shakePrize.getCode())) {
					prizelists = new ArrayList<PrizeList>();
					for (int i = 0; i < shakePrize.getList().size(); i++) {
						prizelists.add(shakePrize.getList().get(i));
					}
					lvPrizeDetails.setAdapter(new PrizeListAdapter(context, prizelists));
					
				}

			}
		});

	};
	
	
	class PrizeListAdapter extends BaseAdapter{
		private ArrayList<PrizeList> mList;
		private Context context;
		public PrizeListAdapter(Context context,ArrayList<PrizeList> mList) {  

			this.context = context;  
			this.mList = mList;
		}  


		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.listitem_prizelist, null);
				holder.iv_prize = (ImageView) convertView.findViewById(R.id.iv_prize);
				holder.iv_store_tel = (ImageView) convertView.findViewById(R.id.iv_store_tel);
				holder.prize_name = (TextView) convertView.findViewById(R.id.prize_name);
				holder.store_name = (TextView) convertView.findViewById(R.id.store_name);
				holder.store_address = (TextView) convertView.findViewById(R.id.store_address);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (this.mList != null) {
				if (holder.iv_prize!= null) {
					bitmapUtils.display(holder.iv_prize, "http://cdn.image.huyongle.com/"+mList.get(position).getPrize_url());
				}
				if (holder.prize_name!= null) {
					holder.prize_name.setText(mList.get(position).getPrize_name());
				}
				if (holder.store_name!= null) {
					holder.store_name.setText(mList.get(position).getPrize_sponsor_name());
				}

				if (holder.store_address!= null) {
					holder.store_address.setText(mList.get(position).getPrize_address());
				}
				
			}
			
			holder.iv_store_tel.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_DIAL,
							Uri.parse("tel:"+mList.get(position).getPrize_tel()));  
					context.startActivity(intent);
				}
			});
			return convertView;
		}
	}
	
	private static class ViewHolder {
		ImageView iv_prize;
		ImageView iv_store_tel;
		TextView prize_name;
		TextView store_name;
		TextView store_address;
	}


}

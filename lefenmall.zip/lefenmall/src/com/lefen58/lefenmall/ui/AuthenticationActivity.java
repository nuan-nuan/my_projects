package com.lefen58.lefenmall.ui;

import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.client.methods.HttpUriRequest;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.receiver.SMSBroadcastReceiver;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AuthenticationActivity extends BaseActivity {
	/**
	 * 设置支付密码时的身份验证
	 */

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.etphonecode)
	private EditText etphonecode;

	@ViewInject(R.id.bt_sendphonecode)
	private Button bt_sendphonecode;

	static int time = 60;
	private Timer timer;

	private SMSBroadcastReceiver mSMSBroadcastReceiver;

	private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";


	private static final int SEND_PHONE_CODE_TIME = 1001;

	Handler handler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SEND_PHONE_CODE_TIME:
				time = time-1;
				if (time<=0) {
					timer.cancel();
					bt_sendphonecode.setEnabled(true);
					bt_sendphonecode.setBackgroundResource(R.drawable.button_three);
					bt_sendphonecode.setTextColor(0xffffffff);
					time = 60;
					bt_sendphonecode.setText("发送验证码");

				} else {
					bt_sendphonecode.setText("("+time+"s)重新发送");
				}

				break;

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_authentication);
		
		ViewUtils.inject(this);
		tv_back.setText("身份验证");

	}

	public void Next(View view){
		if (etphonecode.getText().toString().length()!=6) {
			Toast.makeText(context, "请输入六位验证码", 0).show();
			return;
		}
		startMyDialog();
		HttpUtils http = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "verify_SMS_code");
		params.addBodyParameter("phone", sp.getString("phone", "0"));
		params.addBodyParameter("SMS_code", etphonecode.getText().toString());
		http.send(HttpMethod.POST, Ip.url+"account.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i(arg0.getExceptionCode()+"--"+arg1);
				Toast.makeText(context, "请输入支付密码", Toast.LENGTH_SHORT).show();
				stopMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
			log.i("verify_SMS_code == "+arg0.statusCode + "arg0.result"+arg0.result);
				try {
					Gson gson = new Gson();
					Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
					if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
						stopMyDialog();
						log.i("验证成功");
						Intent intent = new Intent(AuthenticationActivity.this, PhonePayPasswordActivity.class);
						intent.putExtra("titleName", "手机支付密码");
						startActivity(intent);
						finish();
					}

				} catch (Exception e) {
					// TODO: handle exception
				}
				

			}
		});

	}

	public void sendPhoneCode(final View view){
		// 获取验证码
		startMyDialog();
		HttpUtils http = new HttpUtils();
		// 短信验证
		http.send(HttpMethod.POST, Ip.get_SMS_code+"verify_type=2"
				+"&device_index="+sp.getString("device_index", "0")
				+"&phone="+sp.getString("phone", "0"),
				null, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
				log.i( arg0.getExceptionCode()+"--"+arg1);
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				log.i("statusCode"+arg0.statusCode+"服务器返回"+arg0.result);
				stopMyDialog();
				if (arg0.statusCode == 200) {
					Gson gson = new Gson();
					Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
					if (get_SMS_code.getCode().equals("1")) {
						view.setEnabled(false);
						((TextView)view).setTextColor(0xffb3b3b3);
						((TextView)view).setBackgroundResource(R.drawable.bgtwo);
						Toast.makeText(AuthenticationActivity.this, "发送成功", Toast.LENGTH_SHORT).show();
						timer = new Timer(true);
						timer.schedule(new TimerTask(){  
							public void run() {  
								Message msg=handler.obtainMessage(SEND_PHONE_CODE_TIME);
								handler.sendMessage(msg);
							}  
						},1000, 1000);
					} else if (get_SMS_code.getCode().equals("-1")) {
						Toast.makeText(AuthenticationActivity.this, "操作频繁", Toast.LENGTH_SHORT).show();
						view.setEnabled(true);
						view.setBackgroundResource(R.drawable.button_three);
						bt_sendphonecode.setTextColor(0xffffffff);
					} else if (get_SMS_code.getCode().equals("-2")) {
						Toast.makeText(AuthenticationActivity.this, "系统限制", Toast.LENGTH_SHORT).show();
						view.setEnabled(true);
						view.setBackgroundResource(R.drawable.button_three);
						bt_sendphonecode.setTextColor(0xffffffff);
					} else if (get_SMS_code.getCode().equals("-6")||get_SMS_code.getCode().equals("-3")) {
						Toast.makeText(AuthenticationActivity.this, "发送失败，请新发送", Toast.LENGTH_SHORT).show();
						view.setEnabled(true);
						view.setBackgroundResource(R.drawable.button_three);
						bt_sendphonecode.setTextColor(0xffffffff);
					} else {
						Toast.makeText(AuthenticationActivity.this, "异常", Toast.LENGTH_SHORT).show();
						view.setEnabled(true);
						view.setBackgroundResource(R.drawable.button_three);
						bt_sendphonecode.setTextColor(0xffffffff);
					}
				} else {
					Toast.makeText(AuthenticationActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
				}

			}
		});

	}

	@Override
	protected void onStart() {
		super.onStart();
		//生成广播处理
		mSMSBroadcastReceiver = new SMSBroadcastReceiver();

		//实例化过滤器并设置要过滤的广播
		IntentFilter intentFilter = new IntentFilter(ACTION);
		intentFilter.setPriority(Integer.MAX_VALUE);
		//注册广播
		this.registerReceiver(mSMSBroadcastReceiver, intentFilter);

		mSMSBroadcastReceiver.setOnReceivedMessageListener(new SMSBroadcastReceiver.MessageListener() {
			@Override
			public void onReceived(String message) {

				etphonecode.setText(message.subSequence(11, 17));

				Next(etphonecode);
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		//注销短信监听广播
		this.unregisterReceiver(mSMSBroadcastReceiver);
	}

}

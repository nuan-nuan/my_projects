package com.lefen58.lefenmall.ui;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityLeXin extends BaseActivity{
	
	private Button gotosee;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lexin);
		gotosee = (Button) findViewById(R.id.gotosee);
		
	}
	public void GoToSee(View view){
		HomeActivity.getInstance();
	}

}

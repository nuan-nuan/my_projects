package com.lefen58.lefenmall.ui;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.AreaListAdapter;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.AreaInfo;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.MyLoading;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

public class AreaSelectionActivity extends BaseActivity {
	/**
	 * 地区选择 ：省
	 */

	private static SharedPreferences sp;

	static ArrayList<AreaInfo> areaInfos_province;

	private AreaListAdapter adapter;

	@ViewInject(R.id.right_textview)
	private TextView right_textview;

	@ViewInject(R.id.list_province)
	private ListView list_province;

	@ViewInject(R.id.positionAddress)
	private TextView positionAddress;

	String locationCity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_area_selection);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		Drawable drawable= getResources().getDrawable(R.drawable.area_location);  
		/// 这一步必须要做,否则不会显示.  
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());  
		right_textview.setCompoundDrawables(drawable,null,null,null);
		right_textview.setGravity(Gravity.CENTER_VERTICAL);  
		right_textview.setTextColor((Color.parseColor("#f0f0f0")));
		locationCity = sp.getString("locationCity", "未定位");
		right_textview.setText("当前城市:"+locationCity);
		positionAddress.setText(locationCity);
		startMyDialog();

		setListener();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onStart();
		new Thread(
				new Runnable() {
					public void run() {
						setData();
					}
				}).start();
	}

	public void positionAddress(View view) throws JSONException{
		if (!sp.getString("locationCity", "未定位").equals("未定位")) {
			sp.edit().putString("cityId", sp.getString("locationCityId", "0")).commit();
			String cityId = sp.getString("cityId", "0");
			sp.edit().putString("city", sp.getString("locationCity", "未定位")).commit();
			sp.edit().putString("countyId", "0").commit();
			log.i(sp.getString("cityId", "0")+"=="+sp.getString("countyId", "0"));
			if (!cityId.equals("0")) {
				JSONObject object = new JSONObject();
				object.put("city",cityId);
				HttpUtils http = new HttpUtils();
				RequestParams params = new RequestParams();
				params.addBodyParameter("c", "set_user_info");
				params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
				params.addBodyParameter("token", RequestOftenKey.getToken(context));
				params.addBodyParameter("user_info", object.toString());
				// 保存信息
				http.send(HttpMethod.POST,Ip.url+"account.php",
						params, new RequestCallBack<String>(){

					@Override
					public void onFailure(HttpException arg0, String arg1) {
						log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
					}

					@Override
					public void onSuccess(ResponseInfo<String> arg0) {
						log.i(arg0.result);
					}
				});
				finish();
			}
		}
	}

	private void setListener() {
		list_province.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent intent = new Intent();  
				intent.putExtra("region_id",areaInfos_province.get(position).getRegion_id());
				sp.edit().putString("province_name", areaInfos_province.get(position).getRegion_name()).commit();
				intent.setClass(AreaSelectionActivity.this, AreaCitySelectionAcitivty.class);  
				startActivity(intent); 

			}
		});
	}

	private void setData() {
		JSONArray js;
		try {
			InputStream is = getResources().getAssets().open("config_region.json");
			byte [] buffer = new byte[is.available()] ; 
			is.read(buffer);
			String json = new String(buffer,"utf-8");
			areaInfos_province = new ArrayList<AreaInfo>();
			js = new JSONArray(json);
			Gson gson = new Gson();
			for (int index = 1; index < 35; index++) {
				Log.i("infor", js.getJSONObject(index).toString());
				areaInfos_province.add(gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class));
				//Log.i("infor", "areaInfos-"+"index = "+areaInfos.get(index).toString());
			}

		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		adapter = new AreaListAdapter(AreaSelectionActivity.this, areaInfos_province);
		runOnUiThread(new Runnable() {
			public void run() {
				list_province.setAdapter(adapter);
				stopMyDialog();
			}
		});
	}

	public void rightTextview(View view){
		onBackPressed();
	}


}

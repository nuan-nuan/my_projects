package com.lefen58.lefenmall.ui;

import com.google.gson.Gson;
import com.lefen58.lefenmall.AppManager;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ChangePasswordActivity extends BaseActivity {
	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.etpassword)
	private EditText etpassword;

	@ViewInject(R.id.etnewpassword)
	private EditText etnewpassword;

	@ViewInject(R.id.etnewpasswordtest)
	private EditText etnewpasswordtest;

	private static SharedPreferences sp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_changepassword);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		tv_back.setText("修改密码");
	}

	public void onBack(View view) {
		onBackPressed();
	}

	public void changePassword(View view) {
		
		HttpUtils http = new HttpUtils();
		// 修改密码
		if (!etnewpassword.getText().toString().equals(etnewpasswordtest.getText().toString())) {
			Toast.makeText(context, "两次密码不一样", 0).show();
			return ;
		}
		if (!CommonUtils.passwordVerify(etnewpassword.getText().toString())) {
			Toast.makeText(context, "密码应是6-18位数字加字母组合", 0).show();
			return;
		}
		startMyDialog();
		String newpassword = (CommonUtils.getMD5Str(etnewpassword.getText().toString())
				+ CommonUtils.getMD5Str(sp.getString("server_salt", "0"))).toLowerCase();
		Log.i("infor", newpassword);
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "amend_login_password");
		params.addBodyParameter("device_index",RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token",RequestOftenKey.getToken(context));
		params.addBodyParameter("old_login_password",CommonUtils.getMD5Str(etpassword.getText().toString()).toLowerCase());
		params.addBodyParameter("new_login_password",newpassword);
		http.send(HttpMethod.POST,Ip.url + "account.php",params, new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
				stopMyDialog();
				Toast.makeText(context, "网络连接失败", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				Log.i("infor", arg0.result);
				Gson gson = new Gson();
				stopMyDialog();
				try {
					Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
					if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
						Toast.makeText(context, "修改成功，请您重新登录", Toast.LENGTH_SHORT)
						.show();
						sp.edit().putBoolean("state", false).commit();
						startActivity(new Intent(ChangePasswordActivity.this, LoginActivity.class));
						AppManager.getInstance().killAllActivity();
					}
				} catch (Exception e) {
					Toast.makeText(ChangePasswordActivity.this, "异常代码=" + arg0.result, Toast.LENGTH_SHORT)
					.show();
				}
			}
		});
	}

}

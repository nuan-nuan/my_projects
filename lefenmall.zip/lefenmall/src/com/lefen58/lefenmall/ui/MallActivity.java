package com.lefen58.lefenmall.ui;

import java.util.List;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.entity.ClassifyList;
import com.lefen58.lefenmall.entity.MallThreeClass;
import com.lefen58.lefenmall.entity.MallTopClass;
import com.lefen58.lefenmall.entity.MallTwoClass;
import com.lefen58.lefenmall.entity.TopClassifyList;
import com.lefen58.lefenmall.http.MallNetRequest;
import com.lefen58.lefenmall.widgets.NoScrollGridView;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 商城的activity
 * 
 * @author Administrator
 */
public class MallActivity extends BaseActivity {
	private String TAG = "======ShangChengActivity======";
	public Context context;

	private final static int SCANNIN_GREQUEST_CODE = 1;

	private ListView first_list_id;
	private ListView second_list_id;
	private TextView loding;
	private Button re_loading;
	private LinearLayout classify_linearLayout;
	private TextView loding_failure;

	private List<MallTopClass> mallTopClassList;
	private List<MallTwoClass> mallTwoClassList;

	private MallNetRequest mallNetRequest;

	private FirstListAdapter firstListAdapter;

	private BitmapUtils bitmapUtils;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		context = this;
		bitmapUtils = new BitmapUtils(context);
		setContentView(R.layout.activity_shangcheng);
		first_list_id = (ListView) findViewById(R.id.first_list_id);
		second_list_id = (ListView) findViewById(R.id.second_list_id);
		loding = (TextView) findViewById(R.id.loding);
		
		re_loading = (Button) findViewById(R.id.re_loading);
		classify_linearLayout = (LinearLayout) findViewById(R.id.classify_linearLayout);
		
		loding_failure = (TextView) findViewById(R.id.loding_failure);
		
		re_loading.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				re_loading.setVisibility(View.GONE);
				classify_linearLayout.setVisibility(View.VISIBLE);
				getFirstClassify();
				
			}
		});

		getFirstClassify();

		first_list_id.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

					MallTopClass mallTopClass = mallTopClassList.get(position);
					String classifyFirstId = mallTopClass.classifyId;
					
					getRightData(position, classifyFirstId);

			}

		});

	}

	/**
	 * 获取左侧分类数据
	 */
	private void getFirstClassify() {

		if (mallNetRequest == null) {
			mallNetRequest = new MallNetRequest(context);
		}

		startMyDialog();
		mallNetRequest.getMallTopClass(TopClassifyList.class, new RequestCallBack<TopClassifyList>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				
			}
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.i(arg0.getExceptionCode());
				stopMyDialog();
				Toast.makeText(context, "联网失败", 0).show();
				re_loading.setVisibility(View.VISIBLE);
				classify_linearLayout.setVisibility(View.GONE);
			}

			@Override
			public void onSuccess(ResponseInfo<TopClassifyList> arg0) {
				stopMyDialog();
				log.i(arg0.result.list);
				switch (arg0.result.code) {
				case 1:

					// for (int i = 0; i < 5; i++) {//测试listView定位
					// arg0.result.list.add(arg0.result.list.get(i));
					// }

					mallTopClassList = arg0.result.list;
					break;

				default:
					break;
				}
				firstListAdapter = new FirstListAdapter(context, mallTopClassList);
				first_list_id.setAdapter(firstListAdapter);
				if (mallTopClassList != null && !mallTopClassList.isEmpty()) {
					String classifyFirstId = mallTopClassList.get(0).classifyId;// 第一条的分类id
					getRightData(0, classifyFirstId);// 右侧默认显示第一条对应的子分类
				}
			}
		});

	}

	/**
	 * 获取右侧数据
	 * 
	 * @param position
	 * @param classifyFirstId
	 */
	private void getRightData(int position, String classifyFirstId) {
		if (mallNetRequest == null) {
			mallNetRequest = new MallNetRequest(context);
		}

		mallNetRequest.getMallTwoClass(classifyFirstId, ClassifyList.class, new RequestCallBack<ClassifyList>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				loding.setVisibility(View.VISIBLE);
				loding_failure.setVisibility(View.GONE);
				second_list_id.setVisibility(View.GONE);
				first_list_id.setEnabled(false);
			}
			
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				log.e(TAG + "onFailure===========");
				loding.setVisibility(View.GONE);
				loding_failure.setVisibility(View.VISIBLE);
				second_list_id.setVisibility(View.GONE);
				first_list_id.setEnabled(true);
			}

			@Override
			public void onSuccess(ResponseInfo<ClassifyList> arg0) {
				loding.setVisibility(View.GONE);
				loding_failure.setVisibility(View.GONE);
				second_list_id.setVisibility(View.VISIBLE);
				first_list_id.setEnabled(true);
				switch (arg0.result.code) {
				case 1:
					log.e("================" + arg0.result.list);
					mallTwoClassList = arg0.result.list;

					for (int i = 0; i < mallTwoClassList.size(); i++) {
						MallTwoClass mallTwoClass = mallTwoClassList.get(i);
						List<MallThreeClass> threeClasses = mallTwoClass.classifyList;
						if (threeClasses.size() == 0) {// 当没有三级分类的时候，重构三级分类的内容
							MallThreeClass mallThree = new MallThreeClass();
							mallThree.classifyId = mallTwoClassList.get(i).classifyId;
							mallThree.classifyName = mallTwoClassList.get(i).classifyname;
							mallThree.logoPath = mallTwoClassList.get(i).logoPath;
							threeClasses.add(mallThree);
							mallTwoClass.classifyList = threeClasses;
							mallTwoClassList.set(i, mallTwoClass);
						}
					}

					break;

				default:
					break;
				}
				second_list_id.setAdapter(new SecondListAdapter(context, mallTwoClassList));
			}
		});

		firstListAdapter.setSelectedPosition(position);
		firstListAdapter.notifyDataSetChanged();
		first_list_id.setSelection(position);// 让ListView定位到指定Item的位置
	}

	/**
	 * 左侧listView的适配器
	 * 
	 * @author Administrator
	 */
	private class FirstListAdapter extends BaseAdapter {

		private Context context;
		private List<MallTopClass> mallTopClassList;
		private int selectedPosition = 0;// 默认选中的是第一条

		public FirstListAdapter(Context context, List<MallTopClass> mallTopClassList) {
			super();
			this.context = context;
			this.mallTopClassList = mallTopClassList;
		}

		public int getSelectedPosition() {
			return selectedPosition;
		}

		public void setSelectedPosition(int selectedPosition) {
			this.selectedPosition = selectedPosition;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (mallTopClassList != null) {
				return mallTopClassList.size();
			}
			return 0;

		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mallTopClassList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view;
			ViewHolder1 viewHolder1;
			if (convertView == null) {
				view = View.inflate(context, R.layout.shangcheng_left__list_item, null);
				viewHolder1 = new ViewHolder1();
				viewHolder1.classifyName1 = (TextView) view.findViewById(R.id.classify_name1);
				viewHolder1.blueline = view.findViewById(R.id.blue_line);
				viewHolder1.gray_line = view.findViewById(R.id.gray_line);
				view.setTag(viewHolder1);
			} else {
				view = convertView;
				viewHolder1 = (ViewHolder1) view.getTag();
			}
			if (mallTopClassList.get(position) != null) {
				
				viewHolder1.classifyName1.setText(mallTopClassList.get(position).classifyName);
			}

			if (position == selectedPosition) {
				view.setBackgroundColor(context.getResources().getColor(R.color.white_color));
				viewHolder1.classifyName1.setTextColor(context.getResources().getColor(R.color.blue_color));
				viewHolder1.blueline.setVisibility(View.VISIBLE);
				viewHolder1.gray_line.setVisibility(View.GONE);
			} else {
				view.setBackgroundColor(context.getResources().getColor(R.color.bg_text_color));
				viewHolder1.classifyName1.setTextColor(context.getResources().getColor(R.color.black_color));
				viewHolder1.blueline.setVisibility(View.GONE);
				viewHolder1.gray_line.setVisibility(View.VISIBLE);
			}
			return view;
		}

		class ViewHolder1 {
			TextView classifyName1;
			View blueline;
			View gray_line;
		}
	}

	/**
	 * 右侧listview的适配器
	 * 
	 * @author Administrator
	 *
	 */
	class SecondListAdapter extends BaseAdapter {

		private Context context;
		private List<MallTwoClass> mallTwoClassList;

		private int selectedPosition = 0;

		private List<MallThreeClass> thirdBeanList;

		public SecondListAdapter(Context context, List<MallTwoClass> mallTwoClassList) {
			super();
			this.context = context;
			this.mallTwoClassList = mallTwoClassList;

		}

		public int getSelectedPosition() {
			return selectedPosition;
		}

		public void setSelectedPosition(int selectedPosition) {
			this.selectedPosition = selectedPosition;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (mallTwoClassList != null) {
				return mallTwoClassList.size();
			}
			return 0;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mallTwoClassList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view;
			ViewHolder2 viewHolder2;
			if (convertView == null) {
				view = View.inflate(context, R.layout.shangcheng_right_list_item, null);
				viewHolder2 = new ViewHolder2();
				viewHolder2.classify_name2 = (TextView) view.findViewById(R.id.classify_name2);
				viewHolder2.second_grid_id = (NoScrollGridView) view.findViewById(R.id.second_grid_id);
				viewHolder2.second_grid_id.setSelector(new ColorDrawable(Color.TRANSPARENT));// 取消点击背景颜色
				view.setTag(viewHolder2);
			} else {
				view = convertView;
				viewHolder2 = (ViewHolder2) view.getTag();
			}
			if (mallTwoClassList.get(position) != null) {
				viewHolder2.classify_name2.setText(mallTwoClassList.get(position).classifyname);// 二级分类名称

				thirdBeanList = mallTwoClassList.get(position).classifyList;// 三级分类列表

				viewHolder2.second_grid_id.setAdapter(new ThirdGridAdapter(context, thirdBeanList));

				// viewHolder2.second_grid_id.setOnItemClickListener(new
				// OnItemClickListener() {
				//
				// @Override
				// public void onItemClick(AdapterView<?> parent, View view, int
				// position, long id) {

				// Toast.makeText(context,
				// thirdBeanList.get(position).classifyName +
				// thirdBeanList.get(position).classifyId, 0).show();

				// }
				// });
			}

			return view;
		}

		class ViewHolder2 {
			private TextView classify_name2;
			private NoScrollGridView second_grid_id;
		}

		/**
		 * 右侧gridView的适配器
		 * 
		 * @author Administrator
		 *
		 */
		class ThirdGridAdapter extends BaseAdapter {

			private Context context;
			private List<MallThreeClass> thirdBeanList;
			private int selectedPosition = 0;

			public ThirdGridAdapter(Context context, List<MallThreeClass> thirdBeanList) {
				super();
				this.context = context;
				this.thirdBeanList = thirdBeanList;
			}

			public int getSelectedPosition() {
				return selectedPosition;
			}

			public void setSelectedPosition(int selectedPosition) {
				this.selectedPosition = selectedPosition;
			}

			@Override
			public int getCount() {
				// TODO Auto-generated method stub
				if (thirdBeanList != null) {
					return thirdBeanList.size();
				}
				return 0;
			}

			@Override
			public Object getItem(int position) {
				// TODO Auto-generated method stub
				return thirdBeanList.get(position);
			}

			@Override
			public long getItemId(int position) {
				// TODO Auto-generated method stub
				return position;
			}

			@Override
			public View getView(final int position, View convertView, ViewGroup parent) {
				View view;
				ViewHolder3 viewHolder3;
				if (convertView == null) {
					view = View.inflate(context, R.layout.shangcheng_right_grid_item, null);
					viewHolder3 = new ViewHolder3();
					viewHolder3.right_imageview_id = (ImageView) view.findViewById(R.id.right_imageview_id);
					viewHolder3.right_textview_name_id = (TextView) view.findViewById(R.id.right_textview_name_id);
					view.setTag(viewHolder3);

				} else {
					view = convertView;
					viewHolder3 = (ViewHolder3) view.getTag();
				}

				if (thirdBeanList.get(position) != null) {
					viewHolder3.right_textview_name_id.setText(thirdBeanList.get(position).classifyName);
					bitmapUtils.display(viewHolder3.right_imageview_id,Constants.ImageUrl + thirdBeanList.get(position).logoPath);

					viewHolder3.right_imageview_id.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {

							Intent intent = new Intent(MallActivity.this, MallGoodsListActivity.class);

							intent.putExtra("classifyId", thirdBeanList.get(position).classifyId);

							startActivity(intent);
						}
					});
				}

				return view;
			}
		}

		class ViewHolder3 {
			private ImageView right_imageview_id;
			private TextView right_textview_name_id;
		}
	}

	/**
	 * 搜索
	 * 
	 * @param view
	 */
	public void find(View view) {
		Intent intent = new Intent(context, FindActivity.class);
		intent.putExtra("flag", "goods");
		startActivity(intent);
	}

	/**
	 * 扫描二维码
	 * 
	 * @param view
	 */
	public void scanCamera(View view) {
		Intent intent = new Intent();
		intent.setClass(context, MipcaActivityCapture.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivityForResult(intent, SCANNIN_GREQUEST_CODE);

	}
	
}

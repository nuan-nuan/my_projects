package com.lefen58.lefenmall.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.PrizeVoucherDetailBean;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/*
 * 获奖凭证详情
 */
public class PrizeVoucherDetailActivity extends BaseActivity{
	private static final String TAG = "===PrizeVoucherDetailActivity";
	
	@ViewInject(R.id.tv_back)
	private TextView tv_back;
	
	@ViewInject(R.id.prize_tiaoxinma)
	private ImageView tiaoxinma;//条形码
	
	@ViewInject(R.id.vocher_secret)
	private TextView secret;//奖品凭证编号
	
	@ViewInject(R.id.voucher_prize_name)
	private TextView prize_name;//奖品名字
	
	@ViewInject(R.id.voucher_grant_time)
	private TextView grant_time;//中奖时间
	
	@ViewInject(R.id.voucher_valid_time)
	private TextView valid_time;//过期时间
	@ViewInject(R.id.activity_name)
	private TextView activity_name;//过期时间
	
	@ViewInject(R.id.voucher_adderss)
	private TextView adderss;//兑换地址
	
	@ViewInject(R.id.vocher_tel)
	private TextView tel;//联系电话
	@ViewInject(R.id.voucher_filiale_name)
	private TextView filiale_name;//商家名字
	
	private static SharedPreferences sp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_huojiangpingzheng_detail);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		tv_back.setText("获奖凭证详情");
		getVoucherDetail();
	}

	private void getVoucherDetail() {
		HttpUtils httpUtils = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("device_index", sp.getString("device_index", ""));//设备编号
		params.addBodyParameter("token", getToken());//用户登录凭证(token值+盐做数学运算)
		params.addBodyParameter("prize_voucher",getIntent().getStringExtra("voucher_index"));//奖品凭证编号
		params.addBodyParameter("c", "prize_voucher_info");
		httpUtils.send(HttpMethod.POST, Ip.url+"service.php", params,new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				
//				Log.e(TAG, "onFailure==========");
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
//				Log.e(TAG, "onSuccess==========");
//				Log.e(TAG, arg0.result);
				PrizeVoucherDetailBean prizeVoucherDetail = new Gson().fromJson(arg0.result, PrizeVoucherDetailBean.class);
				
				if (prizeVoucherDetail.getCode().equals("1")) {
					
					String code = prizeVoucherDetail.getCode();
					String voucher_prize_name = prizeVoucherDetail.getVoucher_prize_name();
					String voucher_grant_time = prizeVoucherDetail.getVoucher_grant_time();
					String voucher_valid_time = prizeVoucherDetail.getVoucher_valid_time();
					String prize_status = prizeVoucherDetail.getPrize_status();
					String vocher_secret = prizeVoucherDetail.getVoucher_vocher_secret();
					String voucher_filiale_name = prizeVoucherDetail.getVoucher_filiale_name();
					String voucher_address = prizeVoucherDetail.getVoucher_address();
					String voucher_tel = prizeVoucherDetail.getVoucher_tel();
//					sp.edit().putString("code", code).commit();
//					sp.edit().putString("voucher_prize_name", voucher_prize_name).commit();
//					sp.edit().putString("voucher_grant_time", voucher_grant_time).commit();
//					sp.edit().putString("voucher_valid_time", voucher_valid_time).commit();
//					sp.edit().putString("prize_status", prize_status).commit();
//					sp.edit().putString("voucher_vocher_secret", vocher_secret).commit();
//					sp.edit().putString("voucher_filiale_name", voucher_filiale_name).commit();
//					sp.edit().putString("voucher_address", voucher_address).commit();
//					sp.edit().putString("voucher_tel", voucher_tel).commit();
					
					BitMatrix matrix;
					try {
						DisplayMetrics dm = new DisplayMetrics();
						getWindowManager().getDefaultDisplay().getMetrics(dm);
						int scrWidth = dm.widthPixels;
						int scrHeight = dm.heightPixels;
						matrix = new MultiFormatWriter().encode(vocher_secret, BarcodeFormat.CODE_128, scrWidth, 120);
						tiaoxinma.setImageBitmap(ImageUtils.toBitmap(matrix));
						
						//saveBitmap(ImageUtils.toBitmap(matrix));
					} catch (WriterException e) {
						Toast.makeText(PrizeVoucherDetailActivity.this, "条形码生成失败", 0 ).show();
					}
					
					StringBuffer sb = null;
					if (vocher_secret.length()>8) {
						int f = vocher_secret.length() / 4;
						int y = vocher_secret.length() % 4;
						sb = new StringBuffer();
						for (int j = 0; j < f - 1; j++) {
							sb.append(vocher_secret.substring(j * 4, (j + 1) * 4) + "   ");
						}
						sb.append(vocher_secret.substring(vocher_secret.length() - 4 - y, vocher_secret.length()));
						secret.setText(sb);
					}else {
						secret.setText(vocher_secret);
					}

					
					prize_name.setText(voucher_prize_name);
					
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
					String timeGrant = sdf.format(new Date(Long.valueOf(voucher_grant_time+"000"))).substring(0,10);
					String timeValid = sdf.format(new Date(Long.valueOf(voucher_valid_time+"000"))).substring(0,10);					
					grant_time.setText(timeGrant);
					valid_time.setText(timeValid);
					
					activity_name.setText(getIntent().getStringExtra("activity_name"));
					adderss.setText(voucher_address);
					tel.setText(voucher_tel);
					filiale_name.setText(voucher_filiale_name);
				}
			}
		
		});
	}
	
	private Uri saveBitmap(Bitmap bm){
		File tmpDir = new File(Environment.getExternalStorageDirectory() + "/com.lefen58/test/");
		if(!tmpDir.exists()){
			tmpDir.mkdirs();
		}
		File img = new File(tmpDir.getAbsolutePath() + "1.png");
		try {
			FileOutputStream fos = new FileOutputStream(img);
			bm.compress(Bitmap.CompressFormat.PNG, 90, fos);
			fos.flush();
			fos.close();
			return Uri.fromFile(img);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}

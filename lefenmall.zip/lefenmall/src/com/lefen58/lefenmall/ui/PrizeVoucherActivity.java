package com.lefen58.lefenmall.ui;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.PrizeVoucherListAdapter;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.GetPrizeVoucherListResult;
import com.lefen58.lefenmall.entity.PrizeVoucher;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class PrizeVoucherActivity extends BaseActivity implements OnClickListener {


	@ViewInject(R.id.tv_back)
	TextView mTxtTitle;

	@ViewInject(R.id.list_vouchers)
	ListView mListVouchers;

	@ViewInject(R.id.layout_no_data)
	View mViewNoData;

	/**
	 * 去看看
	 */
	@ViewInject(R.id.imgView_see)
	ImageView mImgViewSee;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_prize_voucher);
		ViewUtils.inject(this);
		init();
		registerEvents();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		getPrizeVouchers();
	}

	public void init() {
		mTxtTitle.setText("兑换凭证");
	}

	public void registerEvents() {
		mImgViewSee.setOnClickListener(this);
	}

	public void getPrizeVouchers() {
		RequestParams params = new RequestParams();
		HttpUtils http = new HttpUtils();
		params.addBodyParameter("c", "prize_voucher_list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(this));
		params.addBodyParameter("token", RequestOftenKey.getToken(this));

		http.send(HttpMethod.POST, Ip.url + "service.php", params, new RequestCallBack<String>() {

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode() + "--" + arg1);
				stopMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				Log.i("infor", arg0.result);
				stopMyDialog();
				GetPrizeVoucherListResult result = new Gson().fromJson(arg0.result, GetPrizeVoucherListResult.class);
				if (result==null) {
					return;
				} if (result.code==1) {
					if (result.vouchers==null||result.vouchers.size()==0) {
						mViewNoData.setVisibility(View.VISIBLE);
						mListVouchers.setVisibility(View.GONE);
					} else {
						mViewNoData.setVisibility(View.GONE);
						mListVouchers.setVisibility(View.VISIBLE);
						Collections.sort(result.vouchers, new Comparator<PrizeVoucher>() {

							@Override
							public int compare(PrizeVoucher lhs, PrizeVoucher rhs) {
								// TODO Auto-generated method stub
								return (int) (rhs.validTime-lhs.validTime);
							}
						});
						PrizeVoucherListAdapter adapter = new PrizeVoucherListAdapter(PrizeVoucherActivity.this, result.vouchers);
						mListVouchers.setAdapter(adapter);
					}
				}
			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.imgView_see:
			Intent intent = new Intent(this, ListActivity.class);
			intent.putExtra("activityName", "活动中心");
			intent.putExtra("activityType", "0");
			startActivity(intent);
			break;

		default:
			break;
		}
	}


}

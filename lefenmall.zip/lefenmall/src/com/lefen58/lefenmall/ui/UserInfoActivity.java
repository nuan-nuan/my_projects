package com.lefen58.lefenmall.ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;  

public class UserInfoActivity extends BaseActivity {

	private LogUtil log = LogUtil.lLog();

	private static SharedPreferences sp;
	private static String ImageName;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.nickname)
	private TextView nickname;

	@ViewInject(R.id.sex)
	private TextView sex;

	@ViewInject(R.id.user_photo)
	private ImageView user_photo;

	@ViewInject(R.id.phone)
	private TextView phone;

	@ViewInject(R.id.amendAddress)
	private TextView amendAddress;

	@ViewInject(R.id.card_name)
	private TextView cardName;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_user_info);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		tv_back.setText("个人信息");
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setData();
		RequestOftenKey.getUserInfor(UserInfoActivity.this, sp);
		log.i("onResume");
	}

	// 实名认证
	public void Authentication(View view){
		startActivity(new Intent(context, RealNameActivity.class));
	}

	private void setData() {
		if (!sp.getString("card_index", "0").equals("0")) {
			if (!sp.getString("card_name", "").equals("")) {
				cardName.setText(sp.getString("card_name", ""));
				cardName.setClickable(false);
			}else{
				cardName.setText("审核中");
			}
		} else {
			cardName.setText("未设置");
		}

		nickname.setText(sp.getString("name", "未设置"));
		if (sp.getString("sex", "未知").equals("2")) {
			sex.setText("女");
		} else if (sp.getString("sex", "未知").equals("1")){
			sex.setText("男");
		}else{
			sex.setText("未设置");
		}
		phone.setText(sp.getString("phone", ""));
		log.i(sp.getString("name","未设置"));
		amendAddress.setText(sp.getString("city", "未设置"));
		Bitmap bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
		if (bitmap!=null) {
			user_photo.setImageBitmap(bitmap);
		}else{
			if (!sp.getString("photo", "").equals("")) {
				ImageUtils.getNetworkBitmap("http://app.huyongle.com/"+sp.getString("photo", ""), "/com.lefen58/userphoto/", "userphoto.png");
				bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
				if (bitmap!=null) {
					user_photo.setImageBitmap(bitmap);
				} else {
					user_photo.setImageDrawable(getResources().getDrawable(R.drawable.userinfor_photo));
				}
			}else{
				user_photo.setImageDrawable(getResources().getDrawable(R.drawable.userinfor_photo));
			}
		}
	}

	/**
	 * 修改昵称
	 * @param view
	 */
	public void amendName(View view){
		Intent intent = new Intent(UserInfoActivity.this, AmendUserinfoActivity.class);
		intent.putExtra("key", "name");
		intent.putExtra("title", "修改昵称");
		startActivity(intent);

	}

	/**
	 * 修改性别
	 * @param view
	 */
	public void amendSex(View view){
		getSexPopupWindow(R.layout.popupwindow_sex,-2,-2,R.style.AnimationSEX);
		// 这里是位置显示方式,在屏幕的左侧
		popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
		popupWindow.setOnDismissListener(new poponDismissListener());
	}

	/**
	 * 修改地址
	 * @param view
	 */
	public void amendAddress(View view){
		startActivity(new Intent(UserInfoActivity.this, AreaSelectionActivity.class));
	}

	private PopupWindow popupWindow;
	public void amendUserPhoto(View view){
		getPhotoPopupWindow(R.layout.popupwindow_amenduserphoto,-1,400,R.style.AnimationFade);
		// 这里是位置显示方式,在屏幕的左侧
		popupWindow.showAtLocation(view, Gravity.BOTTOM, 0, 0);

	}

	class poponDismissListener implements PopupWindow.OnDismissListener{  

		@Override  
		public void onDismiss() {
			backgroundAlpha(1f);
		}  

	}  

	/** 
	 * 创建PopupWindow 
	 */  
	protected void initSexPopuptWindow(int resource,int width, int height,int animationStyle) {  
		// 获取自定义布局文件activity_popupwindow_left.xml的视图  
		View popupWindow_view = getLayoutInflater().inflate(resource, null,
				false);  
		// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
		RadioButton radioGirl = (RadioButton) popupWindow_view.findViewById(R.id.girl);
		RadioButton radioBoy = (RadioButton) popupWindow_view.findViewById(R.id.boy);
		log.i(sp.getString("sex", "0"));
		if (sp.getString("sex", "0").equals("1")) {
			log.i("男");
			radioBoy.setChecked(true);
			radioGirl.setChecked(false);
		}else if (sp.getString("sex", "0").equals("2")) {
			log.i("女");
			radioBoy.setChecked(false);
			radioGirl.setChecked(true);
		} else {
			log.i("未知");
			radioBoy.setChecked(false);
			radioGirl.setChecked(false);
		}
		backgroundAlpha(0.5f);
		popupWindow = new PopupWindow(popupWindow_view,width, height, true);
		// 点击其他地方消失
		popupWindow_view.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (popupWindow != null && popupWindow.isShowing()) {
					popupWindow.dismiss();
					backgroundAlpha(1f);
					popupWindow = null;
				}  
				return false;  
			}  
		});  
	}  


	/*** 
	 * 获取SexPopupWindow实例 
	 */  
	private void getSexPopupWindow(int resource,int width, int height,int animationStyle) {  
		if (null != popupWindow) {  
			popupWindow.dismiss();  
			return;  
		} else {  
			initSexPopuptWindow(resource, width, height,animationStyle);  
		}
	}  
	
	/** 
	 * 创建PopupWindow 
	 */  
	protected void initPhotoPopuptWindow(int resource,int width, int height,int animationStyle) {  
		// 获取自定义布局文件activity_popupwindow_left.xml的视图  
		View popupWindow_view = getLayoutInflater().inflate(resource, null,
				false);  
		popupWindow = new PopupWindow(popupWindow_view,width, height, true);
		// 设置动画效果
		popupWindow.setAnimationStyle(animationStyle);
		backgroundAlpha(0.5f);
		// 点击其他地方消失
		popupWindow_view.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (popupWindow != null && popupWindow.isShowing()) {
					popupWindow.dismiss();
					backgroundAlpha(1f);
					popupWindow = null;
				}  
				return false;  
			}  
		});  
	} 
	
	/*** 
	 * 获取PopupWindow实例 
	 */  
	private void getPhotoPopupWindow(int resource,int width, int height,int animationStyle) {  
		if (null != popupWindow) {  
			popupWindow.dismiss();  
			return;  
		} else {  
			initPhotoPopuptWindow(resource, width, height,animationStyle);  
		}
	}  
	/** 
	 * 设置添加屏幕的背景透明度 
	 * @param bgAlpha 
	 */  
	public void backgroundAlpha(float bgAlpha){  
		WindowManager.LayoutParams lp = getWindow().getAttributes();  
		lp.alpha = bgAlpha; //0.0-1.0  
		getWindow().setAttributes(lp);  
	} 
	/**
	 * 跳转至相册选择
	 * @param view
	 */
	public void photoalbum(View view){
		Intent intent = new Intent(this,DialogImageActivity.class);
		intent.setType("image/*");
		startActivityForResult(intent, 2);
		if (popupWindow != null && popupWindow.isShowing()) {  
			popupWindow.dismiss();  
			backgroundAlpha(1f);
		} 
	}

	/**
	 * 修改性别
	 * @param view
	 * @throws UnsupportedEncodingException
	 */
	public void man(View view) throws UnsupportedEncodingException{
		JSONObject object = new JSONObject();

		try {
			object.put("sex", "1");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		popupWindow.dismiss();  
		HttpUtils http = new HttpUtils();

		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "set_user_info");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token", RequestOftenKey.getToken(context));
		params.addBodyParameter("user_info",object.toString());
		// 保存信息
		http.send(HttpMethod.POST, Ip.url+"account.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				Get_SMS_code get_SMS_code = new Gson().fromJson(arg0.result, Get_SMS_code.class);
				if (CommonUtils.NetworkRequestReturnCode(context, get_SMS_code.getCode())) {
					Toast.makeText(context, "修改成功！", Toast.LENGTH_SHORT).show();
					sp.edit().putString("sex", "1").commit();
					finish();
				} 
			}
		});


	}

	public void woman(View view) throws UnsupportedEncodingException{
		JSONObject object = new JSONObject();

		try {
			object.put("sex", "2");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Long token = Long.valueOf(sp.getString("token", "0"))+Long.valueOf(sp.getString("server_salt", "0"));
		popupWindow.dismiss();  
		HttpUtils http = new HttpUtils();
		Log.i("infor", "http_url:"+Ip.set_user_info
				+"device_index="+sp.getString("device_index", "0")
				+"&token="+String.valueOf(token)
				+"&user_info="+object.toString());

		String url = Ip.set_user_info
				+"device_index="+sp.getString("device_index", "0")
				+"&token="+String.valueOf(token)
				+"&user_info=";
		String encodedurl = URLEncoder.encode(url,"UTF-8");
		Log.i("infor", encodedurl);
		//			String edurl = URLEncoder.encode(url, "UTF-8");
		Log.i("infor", "Thread="+Thread.currentThread().getId()+"name="+Thread.currentThread().getName());
		// 保存信息
		http.send(HttpMethod.POST, url+URLEncoder.encode(object.toString(),"UTF-8"),
				null, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				if (arg0.statusCode==200) {
					Get_SMS_code get_SMS_code = new Gson().fromJson(arg0.result, Get_SMS_code.class);
					if (get_SMS_code.getCode().equals("1")) {
						Toast.makeText(UserInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
						sp.edit().putString("sex","2").commit();
						sex.setText("女");
					} else if (get_SMS_code.getCode().equals("-3")) {
						Toast.makeText(UserInfoActivity.this, "系统繁忙！", Toast.LENGTH_SHORT).show();
					} else if (get_SMS_code.getCode().equals("-4")) {
						Toast.makeText(UserInfoActivity.this, "登陆状态失效，请重新登陆！", Toast.LENGTH_SHORT).show();

					}
				}else{
					Toast.makeText(UserInfoActivity.this, "错误代码！"+arg0.statusCode, Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	public void camera(View view){
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		ImageName = System.currentTimeMillis()+".jpg";
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
				Environment.getExternalStorageDirectory()
				, ImageName)));
		startActivityForResult(intent, 1);
		if (popupWindow != null && popupWindow.isShowing()) {  
			popupWindow.dismiss();  
			backgroundAlpha(1f);	
		} 
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == 1){
			if (data == null) {
				File picture = new File(Environment.getExternalStorageDirectory()+
						File.separator+ImageName);
				Uri uri = Uri.fromFile(picture);
				startImageZoom(uri);
				//startCropImage(uri.toString());
				return;
			} else {
				Bundle extras = data.getExtras();
				if (extras != null) {
					Bitmap bm = extras.getParcelable("data");
					Uri uri = saveBitmap(bm);
				}
			}
		}else if(requestCode == 2){
			if(data == null)
			{
				return;
			}
			startCropImage(data.getStringExtra("path"));

		}else if(requestCode == 3){
			if(data == null)
			{
				return;
			}
			Bundle extras = data.getExtras();
			if(extras == null){
				return;
			}
			Bitmap bm = extras.getParcelable("data");

			user_photo.setImageBitmap(bm);
			File f = new File(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/", "userphoto.png");

			if (f.exists()) {
				f.delete();
			}

			if (bm == null) {
				return;
			}

			try {
				FileOutputStream out = new FileOutputStream(f);
				bm.compress(Bitmap.CompressFormat.PNG, 90, out);
				out.flush();
				out.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			sendImage(bm);
		}
	}
	public void startCropImage(String photoPath) {
		Intent intent = new Intent(context, CropImageActivity.class);
		intent.putExtra(CropImageActivity.IMAGE_PATH, photoPath);
		intent.putExtra(CropImageActivity.SCALE, true);
		intent.putExtra(CropImageActivity.ASPECT_X, 3);
		intent.putExtra(CropImageActivity.ASPECT_Y, 2);
		startActivityForResult(intent,3);
	}
	private Uri convertUri(Uri uri){
		InputStream is = null;
		try {
			is = getContentResolver().openInputStream(uri);
			Bitmap bitmap = BitmapFactory.decodeStream(is);
			is.close();
			return saveBitmap(bitmap);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	private Uri saveBitmap(Bitmap bm) {
		File tmpDir = new File(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/");
		if(!tmpDir.exists()){
			tmpDir.mkdirs();
		}
		File img = new File(tmpDir.getAbsolutePath() + "user.png");
		try {
			FileOutputStream fos = new FileOutputStream(img);
			bm.compress(Bitmap.CompressFormat.PNG, 90, fos);
			fos.flush();
			fos.close();
			return Uri.fromFile(img);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	private void startImageZoom(Uri uri) {
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", 210);
		intent.putExtra("outputY", 210);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, 3);
	}

	private void sendImage(Bitmap bm) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 60, stream);
		byte[] bytes = stream.toByteArray();
		String img = new String(Base64.encodeToString(bytes, Base64.DEFAULT));
		startMyDialog();
		ImageUtils.uploadImage(context, img, "head","userPhoto.png");

	}

}

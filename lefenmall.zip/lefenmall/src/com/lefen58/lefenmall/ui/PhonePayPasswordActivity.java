package com.lefen58.lefenmall.ui;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.GridPasswordView;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PhonePayPasswordActivity extends BaseActivity {
	/**
	 * 设置支付密码
	 */


	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.gv)
	private GridPasswordView gv;

	@ViewInject(R.id.tv_hint)
	private TextView tvHint;

	String titleName;
	String oldPayPassword = "";
	String newPayPassword = "";
	String payPassword = "";

	private AlertDialog mResultDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_phone_pay_password);
		ViewUtils.inject(this);
		titleName = this.getIntent().getStringExtra("titleName");
		if (!titleName.equals("手机支付密码")) {
			tvHint.setText("请输入旧支付密码");
		}

		tv_back.setText(titleName);
	}

	public void Next(View view){

		if (titleName.equals("手机支付密码")) {
			if (gv.getPassWord().length()!=6) {
				Toast.makeText(context, "请输入支付密码", Toast.LENGTH_SHORT).show();
				return;
			}

			if (((Button)view).getText().equals("下一步")) {
				if (gv.getPassWord().length()==6) {
					oldPayPassword = CommonUtils.getMD5Str(gv.getPassWord())+
							CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(PhonePayPasswordActivity.this));
					((Button)view).setText("完成");
					gv.clearPassword();
					tvHint.setText("请再次输入的支付密码");
				} else {
					Toast.makeText(PhonePayPasswordActivity.this, "请输入支付密码", Toast.LENGTH_SHORT).show();
				}
			} else {
				if (gv.getPassWord().length()==6) {
					newPayPassword = CommonUtils.getMD5Str(gv.getPassWord())+
							CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(PhonePayPasswordActivity.this));
					if (!newPayPassword.equals(oldPayPassword)) {
						Toast.makeText(PhonePayPasswordActivity.this, "两次输入不一致", Toast.LENGTH_SHORT).show();
						return;
					}
					startMyDialog();
					HttpUtils http = new HttpUtils();
					http.send(HttpMethod.POST, Ip.reset_pay_password
							+"device_index="+sp.getString("device_index", "0")
							+"&token="+RequestOftenKey.getToken(PhonePayPasswordActivity.this)
							+"&new_pay_password="+((CommonUtils.getMD5Str(gv.getPassWord())+CommonUtils.getMD5Str(sp.getString("server_salt", "0"))).toLowerCase()),
							null, new RequestCallBack<String>(){

						@Override
						public void onFailure(HttpException arg0, String arg1) {
							stopMyDialog();
							Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
							Toast.makeText(context, "网络异常", Toast.LENGTH_SHORT).show();
						}

						@Override
						public void onSuccess(ResponseInfo<String> arg0) {
							stopMyDialog();
							Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
							try {
								if (arg0.statusCode == 200) {
									Gson gson = new Gson();
									Get_SMS_code get_SMS_code = gson.fromJson(arg0.result, Get_SMS_code.class);
									if (get_SMS_code.getCode().equals("1")) {

										sp.edit().putBoolean("pay_password", true).commit();
										showDialog();
									}else if (get_SMS_code.getCode().equals("0")) {
										Toast.makeText(PhonePayPasswordActivity.this, "错误代码：0", Toast.LENGTH_SHORT).show();
									} else if (get_SMS_code.getCode().equals("-3")) {
										Toast.makeText(PhonePayPasswordActivity.this, "系统繁忙，请稍后重试", Toast.LENGTH_SHORT).show();
									} else if (get_SMS_code.getCode().equals("-5")) {
										Toast.makeText(PhonePayPasswordActivity.this, "验证失败", Toast.LENGTH_SHORT).show();
									} else {
										Toast.makeText(PhonePayPasswordActivity.this, "异常", Toast.LENGTH_SHORT).show();
									}

								} else {
									Toast.makeText(PhonePayPasswordActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
								}
							} catch (Exception e) {
								// TODO: handle exception
							}
						}
					});

				} else {
					Toast.makeText(PhonePayPasswordActivity.this, "请再次输入支付密码", Toast.LENGTH_SHORT).show();
				}
			}

		} else {
			if (((Button)view).getText().equals("下一步")) {
				if (gv.getPassWord().length()==6) {
					oldPayPassword = CommonUtils.getMD5Str(gv.getPassWord())+
							CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(PhonePayPasswordActivity.this));
					((Button)view).setText("继续");
					gv.clearPassword();
					tvHint.setText("请输入新的支付密码");
				} else {
					Toast.makeText(PhonePayPasswordActivity.this, "请输入旧的支付密码", Toast.LENGTH_SHORT).show();
				}
			} else if(((Button)view).getText().equals("继续")) {
				if (gv.getPassWord().length()==6) {
					newPayPassword = CommonUtils.getMD5Str(gv.getPassWord())+
							CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(PhonePayPasswordActivity.this));
					((Button)view).setText("完成");
					gv.clearPassword();
					tvHint.setText("请再次输入新的支付密码");
				} else {
					Toast.makeText(PhonePayPasswordActivity.this, "请输入支付密码", Toast.LENGTH_SHORT).show();
				}
			} else if(((Button)view).getText().equals("完成")) {
				if (gv.getPassWord().length()==6) {
					payPassword = CommonUtils.getMD5Str(gv.getPassWord())+
							CommonUtils.getMD5Str(RequestOftenKey.getServerSalt(PhonePayPasswordActivity.this));
					if (payPassword.equals(newPayPassword)) {
						startMyDialog();
						amendPayPassword();
					}else{
						
						Toast.makeText(PhonePayPasswordActivity.this, "两次输入不一致", Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(PhonePayPasswordActivity.this, "请输入支付密码", Toast.LENGTH_SHORT).show();
				}
			}

		}

	}

	void amendPayPassword() {
		HttpUtils http = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "amend_pay_password");
		params.addBodyParameter("device_index", 
				RequestOftenKey.getDeviceIndex(PhonePayPasswordActivity.this));
		params.addBodyParameter("token", RequestOftenKey.getToken(PhonePayPasswordActivity.this));
		params.addBodyParameter("old_pay_password", oldPayPassword.toLowerCase());
		params.addBodyParameter("new_pay_password", newPayPassword.toLowerCase());
		// 短信验证
		http.send(HttpMethod.POST, Ip.url+""+"account.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
				Get_SMS_code get_SMS_code = new Gson().fromJson(arg0.result, Get_SMS_code.class);
				if (CommonUtils.NetworkRequestReturnCode(PhonePayPasswordActivity.this, get_SMS_code.getCode())) {
					stopMyDialog();
					onBackPressed();
					Toast.makeText(PhonePayPasswordActivity.this, "修改成功，请牢记！", Toast.LENGTH_SHORT).show();
				}

			}
		});

	}

	/**
	 * 支付密码设置成功
	 */
	private void showDialog() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int scrWidth = dm.widthPixels;
		int scrHeight = dm.heightPixels;

		View view = getLayoutInflater().inflate(R.layout.dialog_hint, null);
		TextView msg = (TextView) view.findViewById(R.id.message);
		msg.setText(Html.fromHtml("<font color=\'#333333\'>恭喜您手机支付密码已经设置成功，将用于<br></font><font color=\'#e12323\'>积分支付　　　　　　　　　　　　　　　</font>"));
		if (mResultDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			mResultDialog = builder.create();
			mResultDialog.setCanceledOnTouchOutside(false);
		}
		mResultDialog.show();
		Window window = mResultDialog.getWindow();
		window.setContentView(view);
		window.setLayout((int) (scrWidth * 0.85f), (int) (scrHeight * 0.5f));
	}

	public void tvColos(View view){
		hideShakeResultDialog();
		finish();
	}

	/**
	 * 隐藏弹框
	 */
	private void hideShakeResultDialog() {
		if (mResultDialog!=null&&mResultDialog.isShowing()) {
			mResultDialog.dismiss();
		}
	}

}

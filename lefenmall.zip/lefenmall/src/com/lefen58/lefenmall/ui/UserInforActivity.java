package com.lefen58.lefenmall.ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class UserInforActivity extends BaseActivity {


	private SharedPreferences sp;
	private static String ImageName;

	@ViewInject(R.id.user_photo)
	private ImageView user_photo;

	@ViewInject(R.id.nickname)
	private TextView nickname;

	@ViewInject(R.id.tv_jifen)
	private TextView tv_jifen;

	@ViewInject(R.id.layout_ticket)
	View mViewTicket;

	LogUtil log = LogUtil.lLog();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_user_infor);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);

		nickname.setText(sp.getString("name", ""));

	}
	private PopupWindow popupWindow;
	// 设置
	public void login(View view){
		if (sp.getBoolean("state", false)) {
			getPopupWindow();
			// 这里是位置显示方式,在屏幕的左侧  
			popupWindow.showAtLocation(view, Gravity.BOTTOM, 0, 0);
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
		/*UmengDialog dialog1 = new UmengDialog(context,
				R.style.DialogControl, new UmengGloble().getAllIconModels());
		dialog1.setItemLister(new OnListItemClickListener() {
			@Override
			public void OnItemClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3, Object arg4) {
				String content = getResources().getString(R.string.appshare);
				new ShareUtile(context, ((IconModel)arg4).getType(), content, null, "http://www.uupaotui.com/user_fxy.html").share();
			}
		});
		dialog1.show();*/
		
	}

	@Override
	protected void onResume() {
		super.onStart();
		setData();
	}

	void setData(){
		if (sp.getBoolean("state", false)) {
			RequestOftenKey.getUserInfor(UserInforActivity.this, sp);
			tv_jifen.setVisibility(View.VISIBLE);
			tv_jifen.setText("  "+sp.getString("integral", "暂无")+"乐分"+"  ");
			tv_jifen.setGravity(Gravity.CENTER);
			nickname.setText(sp.getString("phone", ""));
			Bitmap bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
			if (bitmap!=null) {
				log.i("取本地图片");
				user_photo.setImageBitmap(bitmap);
			}else{
				log.i("取网络图片");
				if (!sp.getString("photo", "").equals("")) {
					log.i("获取网络图片");
					ImageUtils.getNetworkBitmap(Constants.ImageUrl+sp.getString("photo", ""), "/com.lefen58/userphoto/", "userphoto.png");
					bitmap = ImageUtils.getLoacalBitmap(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/" , "userphoto.png");
					if (bitmap!=null) {
						log.i("网络图片获取成功");
						user_photo.setImageBitmap(bitmap);
					} else {
						log.i("网络图片获取失败，使用本地图片");
						user_photo.setImageDrawable(getResources().getDrawable(R.drawable.photo));
					}
				}else{
					log.i("用户没有头像，使用默认头像");
					user_photo.setImageDrawable(getResources().getDrawable(R.drawable.photo));
				}
			}
		} else {
			tv_jifen.setVisibility(View.GONE);
			user_photo.setImageDrawable(getResources().getDrawable(R.drawable.photo));
			nickname.setText("请点击登录");
		}

	}


	/*** 
	 * 获取PopupWindow实例 
	 */  
	private void getPopupWindow() {  
		if (null != popupWindow) {  
			popupWindow.dismiss();  
			return;  
		} else {  
			initPopuptWindow();  
		}
	}  

	/** 
	 * 创建PopupWindow 
	 */  
	protected void initPopuptWindow() {  
		// TODO Auto-generated method stub  
		// 获取自定义布局文件popupwindow_amenduserphoto.xml的视图  
		View popupWindow_view = getLayoutInflater().inflate(R.layout.popupwindow_amenduserphoto, null,  
				false);  
		// 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度  
		popupWindow = new PopupWindow(popupWindow_view, LayoutParams.MATCH_PARENT, -2, true); 
		// 设置动画效果  
		popupWindow.setAnimationStyle(R.style.AnimationFade);  
		backgroundAlpha(0.5f);
		// 点击其他地方消失

		popupWindow_view.setOnTouchListener(new OnTouchListener() {  
			@Override  
			public boolean onTouch(View v, MotionEvent event) {  
				// TODO Auto-generated method stub  
				if (popupWindow != null && popupWindow.isShowing()) {  
					popupWindow.dismiss();  
					backgroundAlpha(1f);
					popupWindow = null;  
				}  
				return false;  
			}  
		});  
	}  

	// 设置
	public void setting(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, SettingActivity.class));
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
	}

	// 乐券卡包
	public void jumpToVouchers(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, PrizeVoucherActivity.class));
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
	}

	// 消息通知
	public void mail(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, SettingActivity.class));
		} else {
			Toast.makeText(UserInforActivity.this, "请您先登陆", Toast.LENGTH_SHORT).show();
		}
	}

	// 参与活动记录
	public void participateActivitysRecord(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, RecordPaticipateActivity.class));
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
	}

	// 兑换积分记录
	public void jumpTojifenExchange(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, RecordJifenExchangeActivity.class));
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
	}

	// 获得积分记录
	public void jumpTojifen(View view){
		if (sp.getBoolean("state", false)) {
			startActivity(new Intent(UserInforActivity.this, RecordJifenObtainActivity.class));
		} else {
			startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
		}
	}
	// 我的收藏列表
		public void layout_collect(View view){
			if (sp.getBoolean("state", false)) {
				startActivity(new Intent(UserInforActivity.this, CollectListActivity.class));
			} else {
				startActivity(new Intent(UserInforActivity.this, LoginActivity.class));
			}
		}
	public void photoalbum(View view){
		Intent intent = new Intent(this,DialogImageActivity.class);
		intent.setType("image/*");
		startActivityForResult(intent, 2);
		if (popupWindow != null && popupWindow.isShowing()) {  
			popupWindow.dismiss();  
			backgroundAlpha(1f);
		} 
	}

	public void camera(View view){
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		ImageName = System.currentTimeMillis()+".jpg";
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
				Environment.getExternalStorageDirectory()
				, ImageName)));
		startActivityForResult(intent, 1);
		if (popupWindow != null && popupWindow.isShowing()) {  
			popupWindow.dismiss();  
			backgroundAlpha(1f);	
		} 
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == 1){
			if (data == null) {
				File picture = new File(Environment.getExternalStorageDirectory()+
						File.separator+ImageName);
				Uri uri = Uri.fromFile(picture);
				startImageZoom(uri);
				//startCropImage(uri.toString());
				return;
			} else {
				Bundle extras = data.getExtras();
				if (extras != null) {
					Bitmap bm = extras.getParcelable("data");
					Uri uri = saveBitmap(bm);
				}
			}
		}else if(requestCode == 2){
			if(data == null)
			{
				return;
			}
			startCropImage(data.getStringExtra("path"));

		}else if(requestCode == 3){
			if(data == null)
			{
				return;
			}
			Bundle extras = data.getExtras();
			if(extras == null){
				return;
			}
			Bitmap bm = extras.getParcelable("data");

			user_photo.setImageBitmap(bm);
			File f = new File(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/", "userphoto.png");
			
			if (f.exists()) {
				f.delete();
			}
			
			if (bm == null) {
				return;
			}

			try {
				FileOutputStream out = new FileOutputStream(f);
				bm.compress(Bitmap.CompressFormat.PNG, 90, out);
				out.flush();
				out.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			sendImage(bm);
		}
	}
	public void startCropImage(String photoPath) {
		Intent intent = new Intent(UserInforActivity.this, CropImageActivity.class);
		intent.putExtra(CropImageActivity.IMAGE_PATH, photoPath);
		intent.putExtra(CropImageActivity.SCALE, true);
		intent.putExtra(CropImageActivity.ASPECT_X, 3);
		intent.putExtra(CropImageActivity.ASPECT_Y, 2);
		startActivityForResult(intent,3);
	}
	private Uri convertUri(Uri uri){
		InputStream is = null;
		try {
			is = getContentResolver().openInputStream(uri);
			Bitmap bitmap = BitmapFactory.decodeStream(is);
			is.close();
			return saveBitmap(bitmap);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	private Uri saveBitmap(Bitmap bm){
		File tmpDir = new File(Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/");
		if(!tmpDir.exists()){
			tmpDir.mkdirs();
		}
		File img = new File(tmpDir.getAbsolutePath() + "user.png");
		try {
			FileOutputStream fos = new FileOutputStream(img);
			bm.compress(Bitmap.CompressFormat.PNG, 90, fos);
			fos.flush();
			fos.close();
			return Uri.fromFile(img);
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	private void startImageZoom(Uri uri){
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", 210);
		intent.putExtra("outputY", 210);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, 3);
	}

	private void sendImage(Bitmap bm){
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 60, stream);
		byte[] bytes = stream.toByteArray();
		String img = new String(Base64.encodeToString(bytes, Base64.DEFAULT));
		startMyDialog();
		ImageUtils.uploadImage(UserInforActivity.this, img, "head","userPhoto.png");

	}

	class poponDismissListener implements PopupWindow.OnDismissListener{
		@Override  
		public void onDismiss() {
			// TODO Auto-generated method stub  
			//Log.v("List_noteTypeActivity:", "我是关闭事件");  
			backgroundAlpha(1f);  
		}  
	}

	public void backgroundAlpha(float bgAlpha){  
		WindowManager.LayoutParams lp = getParent().getWindow().getAttributes();  
		lp.alpha = bgAlpha; //0.0-1.0  
		getParent().getWindow().setAttributes(lp);  
	}


}

package com.lefen58.lefenmall.ui;

import java.lang.annotation.Annotation;
import java.util.ArrayList;

import com.baidu.navisdk.logic.commandparser.CmdRoutePlanCommonGetRouteInfo;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.entity.GoodsCollectList;
import com.lefen58.lefenmall.entity.GoodsCollectListInfor;
import com.lefen58.lefenmall.http.MallNetRequest;
import com.lefen58.lefenmall.image.RoundImageDrawable;
import com.lefen58.lefenmall.ui.MainActivity.ChangePageListener;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.CircleImageView;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnChildClick;
import com.pulltorefresh.library.PullToRefreshBase;
import com.pulltorefresh.library.PullToRefreshBase.Mode;
import com.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.pulltorefresh.library.PullToRefreshScrollView;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class CollectListActivity extends BaseActivity implements OnItemClickListener {

	GoodsCollectList goodscollect;

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	@ViewInject(R.id.iv_near_title_search)
	private ImageView iv_near_title_search;

	ArrayList<GoodsCollectListInfor> mainActivitys;

	private static SharedPreferences sp;

	@ViewInject(R.id.collect_lv_activity)
	private ListView lvActivity;

	@ViewInject(R.id.right_textview)
	private TextView rightTextView;
	
	@ViewInject(R.id.collect_bac)
	private ImageView collect_bac;
	
	@ViewInject(R.id.collect_button)
    private Button collect_button;
	private MallNetRequest mActivityNetRequest;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_collect_list);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		tvBack.setText("我的收藏");
		startMyDialog();

		mainActivitys = new ArrayList<GoodsCollectListInfor>();
		
		lvActivity.setOnItemClickListener(this);
	}

	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setActivityList();
	}


	/**
	 * 获取收藏列表
	 */

	private void setActivityList() {
		if (mActivityNetRequest == null) {
			mActivityNetRequest = new MallNetRequest(context);
		}

		mActivityNetRequest.getGoodsCollectList(RequestOftenKey.getDeviceIndex(this), GoodsCollectList.class,
				new RequestCallBack<GoodsCollectList>() {

					@Override
					public void onStart() {
						super.onStart();
						startMyDialog();
					}

					@Override
					public void onSuccess(ResponseInfo<GoodsCollectList> arg0) {
						stopMyDialog();
						
						goodscollect = arg0.result;
						if (goodscollect == null) {
							return;
						}
						switch (goodscollect.code) {
						case 1:
                            if(goodscollect.infor.size() <= 0)
                            {
                            	lvActivity.setVisibility(View.GONE);
                            	collect_bac.setVisibility(View.VISIBLE);
                            	collect_button.setVisibility(View.VISIBLE);
                            	collect_button.setOnClickListener(new OnClickListener() {
									@Override
									public void onClick(View v) {
										
											if (HomeActivity.ChangePageListener != null) {
												HomeActivity.ChangePageListener.changeListener();
										}

									finish();
									}
								});
                            }else
                            {
                            	mainActivitys.clear();
                            	lvActivity.setVisibility(View.VISIBLE);
							for (int i = 0; i < goodscollect.infor.size(); i++) {
								mainActivitys.add(goodscollect.infor.get(i));
							}
							activityAdapter activityAdapter = new activityAdapter(CollectListActivity.this,
									mainActivitys);
							lvActivity.setAdapter(activityAdapter);
							activityAdapter.notifyDataSetChanged();
                            }
							break;

						}
					}

					@Override
					public void onFailure(HttpException arg0, String arg1) {

					}
				});
	}
	public interface ChangePageListener {
		public void changeListener();
	}

	private ChangePageListener changePageListener;

	public void setChangeValueListener(ChangePageListener changePageListener) {
		this.changePageListener = changePageListener;
	}
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		/*Intent intent = new Intent(this, CommodityDetailActivity.class);
		intent.putExtra("good_id", mainActivitys.get(position).collectGoodsId);
		startActivity(intent);*/
	}

}

class activityAdapter extends BaseAdapter {
	private ArrayList<GoodsCollectListInfor> mainActivitys;
	private Context context;

	public activityAdapter(Context context, ArrayList<GoodsCollectListInfor> mList) {

		this.context = context;
		this.mainActivitys = mList;
	}

	@Override
	public int getCount() {
		return mainActivitys.size();
	}

	@Override
	public Object getItem(int position) {
		return mainActivitys.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		BitmapUtils bitmapUtils = new BitmapUtils(context);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.collect_list_item, null);
			holder.activity_iv_prize = (CircleImageView) convertView.findViewById(R.id.activity_iv_prize);
			holder.activity_name = (TextView) convertView.findViewById(R.id.activity_name);
			holder.activity_start_time = (TextView) convertView.findViewById(R.id.activity_start_time);
			holder.activity_status = (Button) convertView.findViewById(R.id.activity_status);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		if (this.mainActivitys != null) {
			if (holder.activity_iv_prize != null) {
				bitmapUtils.display(holder.activity_iv_prize,
						"http://cdn.image.huyongle.com/" + mainActivitys.get(position).collectGoodsIcon,
						new BitmapLoadCallBack<ImageView>() {
							@Override
							public void onLoadCompleted(ImageView arg0, String arg1, Bitmap arg2, BitmapDisplayConfig arg3,
									BitmapLoadFrom arg4) {
								arg0.setImageDrawable(new RoundImageDrawable(arg2));
								
							}

							@Override
							public void onLoadFailed(ImageView arg0, String arg1, Drawable arg2) {

							}
						});
			}
			
			
			if (holder.activity_name != null) {
				holder.activity_name.setText(mainActivitys.get(position).collectGoodsName);
			}

			if (holder.activity_start_time != null) {

				holder.activity_start_time.setText(mainActivitys.get(position).collectGoodsIntegral+".00");
			}
		}
		holder.activity_status.setOnClickListener(new lookOnClick(position, context));
		return convertView;
	}

	class lookOnClick implements OnClickListener {
		int position;
		Context context;

		public lookOnClick(int position, Context context) {
			this.position = position;
			this.context = context;
		}

		@Override
		public void onClick(View v) {
			Intent intent = new Intent(context, CommodityDetailActivity.class);
			intent.putExtra("good_id", mainActivitys.get(position).collectGoodsId);
			context.startActivity(intent);
		}
	}

	private static class ViewHolder {
		CircleImageView activity_iv_prize;
		TextView activity_name;
		TextView activity_start_time;
		Button activity_status;
	}
}
package com.lefen58.lefenmall.ui;


import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.widget.TextView;

public class AgreementActivity extends BaseActivity {

	@ViewInject(R.id.tv_back)
	private TextView tv_back;
	
	@ViewInject(R.id.webview)
	private WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_agreement);
		ViewUtils.inject(this);
		tv_back.setText(getIntent().getStringExtra("title"));
		webView.loadUrl(getIntent().getStringExtra("url"));
		webView.getSettings().setJavaScriptEnabled(true);

	}
	public void onBack(View view){
		onBackPressed();
	}

}

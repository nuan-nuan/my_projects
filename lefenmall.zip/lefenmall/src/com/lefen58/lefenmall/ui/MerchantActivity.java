package com.lefen58.lefenmall.ui;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.baidu.navisdk.adapter.BNOuterTTSPlayerCallback;
import com.baidu.navisdk.adapter.BNRoutePlanNode;
import com.baidu.navisdk.adapter.BNRoutePlanNode.CoordinateType;
import com.baidu.navisdk.adapter.BaiduNaviManager;
import com.baidu.navisdk.adapter.BaiduNaviManager.NaviInitListener;
import com.baidu.navisdk.adapter.BaiduNaviManager.RoutePlanListener;
import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.LeFenMallApplication;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.ViewPagerAdapter;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.FilialeCode;
import com.lefen58.lefenmall.entity.FilialeDetails;
import com.lefen58.lefenmall.entity.MerchantDetails;
import com.lefen58.lefenmall.entity.NearDetails;
import com.lefen58.lefenmall.entity.NearFilialeDetails;
import com.lefen58.lefenmall.entity.NearMerchantDetails;
import com.lefen58.lefenmall.image.ImageUtils;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MerchantActivity extends BaseActivity implements OnPageChangeListener {

	private static SharedPreferences sp;
	private LogUtil log = LogUtil.lLog();

	@ViewInject(R.id.ll_merchant_scope)
	private LinearLayout llMerchantScope;// 经营范围 LinearLayout 用于这个item 显示或者隐藏

	@ViewInject(R.id.tv_songjifen)
	private TextView tv_songjifen;

	@ViewInject(R.id.tv_merchant_scope)
	private TextView tvMerchantScope;// 经营范围 textview

	@ViewInject(R.id.tv_shop_desp)
	private TextView tvShopDesp;// 商家详情

	@ViewInject(R.id.tv_merchant_address)
	private TextView tvMerchantAddress;// 地址

	@ViewInject(R.id.tv_merchant_distance)
	private TextView tvMerchantDistance;// 距离

	@ViewInject(R.id.tv_work_time)
	private TextView tvWorkTime;// 工作时间

	@ViewInject(R.id.merchant_ratingBar_graded)
	private RatingBar merchantRatingBarGraded;// 星级评分

	@ViewInject(R.id.tv_graded)
	private TextView tvGraded; // 文字评分

	@ViewInject(R.id.tv_merchant_name)
	private TextView tvMerchantName; // 名字

	@ViewInject(R.id.tv_back)
	private TextView tvBack;

	@ViewInject(R.id.viewpager)
	private ViewPager mViewpager;

	@ViewInject(R.id.lls_points)
	private LinearLayout layoutDots;

	@ViewInject(R.id.iv_no_data)
	private ImageView ivNoData;

	@ViewInject(R.id.sv_data)
	private ScrollView svData;

	private ArrayList<String> urlString;
	private Context mContext;// 上下文
	private ArrayList<Bitmap> bitmaps;
	private ViewPagerAdapter mViewPagerAdp;
	private final long delay = 3 * 1000;
	private final int AUTO = 0;
	private ImageView[] mDots;
	private int width;
	private int newWidth;
	private int padding;
	private int one;
	private FilialeDetails filialeDetails;

	private MerchantDetails merchantDetails;

	private String latitude, longitude;

	private static final String APP_FOLDER_NAME = "com.lefen58.lefenmall";
	private String mSDCardPath = null;

	public static final String ROUTE_PLAN_NODE = "routePlanNode";
    LeFenMallApplication app;
    
    private ImageLoader imageLoader = ImageLoader.getInstance();
	private DisplayImageOptions options;

	/**
	 * 联盟商家详情
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_merchant);
		app = (LeFenMallApplication) getApplication();
		if (initDirs()) {
			initNavi();
		}
		sp = getSharedPreferences("UserInfor", 0);
		ViewUtils.inject(this);
		mContext = this;
		width = getResources().getDisplayMetrics().widthPixels;

		newWidth = (int) (divideWidth(width, 1080, 6) * 17);

		padding = (int) (divideWidth(width, 1080, 6) * 9);
		mViewpager.setOnPageChangeListener(this);
		imageLoader.init(ImageLoaderConfiguration.createDefault(this));
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.zw)
				.showImageForEmptyUri(R.drawable.zw)
				.showImageOnFail(R.drawable.zw)
				// 这里的三张状态用一张替代
				.cacheInMemory().imageScaleType(ImageScaleType.EXACTLY)
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565)

				.build();
	}

	public double divideWidth(int screenWidth, int picWidth, int retainValue) {
		BigDecimal screenBD = new BigDecimal(Double.toString(screenWidth));
		BigDecimal picBD = new BigDecimal(Double.toString(picWidth));
		return screenBD.divide(picBD, retainValue, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	// 导航
	public void goTo(View view) {
		if (TextUtils.isEmpty(latitude) || TextUtils.isEmpty(longitude)) {
			return;
		}
		startMyDialog();
		if (BaiduNaviManager.isNaviInited()) {
			routeplanToNavi(CoordinateType.GCJ02);
		}
	}

	// 联系商户
	public void callTel(View view) {

		String tel = this.getIntent().getStringExtra("itemType").equals("1") ? filialeDetails.getShop_tel()
				: merchantDetails.getMerchant_tel();
		if (TextUtils.isEmpty(tel)) {
			Toast.makeText(context, "没有电话号码~", Toast.LENGTH_LONG).show();
			return;
		}
		Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tel));
		this.startActivity(intent);

	}

	public void onBack(View view) {
		finish();
	}

	public void rightTextview(View view) {

	}

	/**
	 * @author
	 * 
	 * 		初始化ViewPager的底部小点
	 * 
	 */
	private void initDots() {
		if (urlString.size() <= 0)
			return;
		mDots = new ImageView[urlString.size()];
		for (int i = 0; i < urlString.size(); i++) {
			ImageView iv = new ImageView(mContext);
			LayoutParams lp = new LayoutParams(newWidth, newWidth);
			lp.leftMargin = padding;
			lp.rightMargin = padding;
			lp.topMargin = padding;
			lp.bottomMargin = padding;
			iv.setLayoutParams(lp);
			iv.setImageResource(R.drawable.circle_off);
			layoutDots.addView(iv);
			mDots[i] = iv;
		}
		mDots[0].setImageResource(R.drawable.circle_on);
	}
	
	
	/**
	 * @author
	 * 
	 * 		初始化ViewPager
	 * 
	 */
	private void initViewPager() {
		int imgSize;
		if (urlString.size() <= 0) {
			mViewpager.setVisibility(View.GONE);
			return;
		}
		if (urlString.size() <= 3) {
			imgSize = urlString.size() * 3;
		} else {
			imgSize = urlString.size();
		}
		ImageView[] imgs = new ImageView[imgSize];
		for (int i = 0; i < imgs.length; i++) {
			ImageView iv = new ImageView(mContext);
			iv.setScaleType(ScaleType.CENTER_CROP);
			imageLoader.displayImage(urlString.get(i%urlString.size()), iv, options,
					new SimpleImageLoadingListener() {
						@Override
						public void onLoadingStarted(String imageUri, View view) {
						}

						@Override
						public void onLoadingFailed(String imageUri, View view,
								FailReason failReason) {
							String message = null;
							switch (failReason.getType()) {
							case IO_ERROR:
							case DECODING_ERROR:
							case NETWORK_DENIED:
							case OUT_OF_MEMORY:
							case UNKNOWN:
								message = "图片加载错误";
								break;
							}
						}

						@Override
						public void onLoadingComplete(String imageUri,
								View view, Bitmap loadedImage) {
						}
					});
		//	iv.setImageBitmap(bitmaps.get(i % urlString.size()));
			imgs[i] = iv;
		}

		mViewPagerAdp = new ViewPagerAdapter(imgs, urlString);
		mViewpager.setAdapter(mViewPagerAdp);
		// mViewpager.setCurrentItem(10*imgSize);
		mHandler.sendEmptyMessageDelayed(AUTO, delay);
	}

	private Handler mHandler = new Handler() {

		@Override
		public void dispatchMessage(Message msg) {

			switch (msg.what) {
			case AUTO:
				int index = mViewpager.getCurrentItem();
				mViewpager.setCurrentItem(index + 1);
				mHandler.sendEmptyMessageDelayed(AUTO, delay);
				break;

			default:
				break;
			}

		};
	};

	/**
	 * @author
	 * 
	 * 		设置ViewPager当前的底部小点
	 * 
	 * 
	 */
	private void setCurrentDot(int currentPosition) {

		for (int i = 0; i < mDots.length; i++) {
			if (i == currentPosition) {
				mDots[i].setImageResource(R.drawable.circle_on);
			} else {
				mDots[i].setImageResource(R.drawable.circle_off);
			}
		}
	}

	@Override
	protected void onStart() {
		super.onStart();

		if (CommonUtils.isNetworkAvailable(context) == 0) {
			Toast.makeText(context, R.string.net_work_not_available, Toast.LENGTH_LONG).show();
			return;
		}
		startMyDialog();
		if (this.getIntent().getStringExtra("merchant_id").equals("0")) {
			llMerchantScope.setVisibility(View.GONE);
			urlString = new ArrayList<String>();
			bitmaps = new ArrayList<Bitmap>();
			HttpUtils http = new HttpUtils();
			RequestParams params = new RequestParams();
			params.addBodyParameter("c", "filiale");
			params.addBodyParameter("device_index", sp.getString("device_index", ""));
			// params.addBodyParameter("county", "0");
			params.addBodyParameter("county", sp.getString("countyId", "0"));
			// params.addBodyParameter("city", "149");
			params.addBodyParameter("city", sp.getString("cityId", "0"));
			http.send(HttpMethod.POST, Ip.url + "nearby.php", params, new RequestCallBack<String>() {

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					log.i("infor"+arg0.getExceptionCode() + "--" + arg1);
					stopMyDialog();
					ivNoData.setVisibility(View.VISIBLE);
					svData.setVisibility(View.GONE);
				}

				@SuppressLint("NewApi")
				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					stopMyDialog();
					log.i(arg0.result);
					FilialeCode filialeCode = new Gson().fromJson(arg0.result, FilialeCode.class);

					if (CommonUtils.NetworkRequestReturnCode(MerchantActivity.this, filialeCode.getCode())) {
						if (filialeCode.getFiliale_id().equals("0")) {
							ivNoData.setVisibility(View.VISIBLE);
							svData.setVisibility(View.GONE);

						} else {
							ivNoData.setVisibility(View.GONE);
							svData.setVisibility(View.VISIBLE);
							urlString.clear();
							bitmaps.clear();
							layoutDots.removeAllViews();
							mHandler.removeMessages(AUTO);
							filialeDetails = filialeCode.getInfo();
							for (int i = 0; i < filialeDetails.getImages().size(); i++) {
								urlString.add("http://cdn.image.huyongle.com/"
										+ filialeDetails.getImages().get(i).getPhoto_path());
							}
							for (int i = 0; i < urlString.size(); i++) {
								one = urlString.get(i).lastIndexOf("/");
								if (ImageUtils.getLoacalBitmap(
										Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
										urlString.get(i).substring((one + 1), urlString.get(i).length())) != null) {
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								} else {
									ImageUtils.getNetworkBitmap(urlString.get(i), "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length()));
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								}
							}
							initView(filialeDetails.getShop_worktime(), filialeDetails.getShop_name(),
									filialeDetails.getShop_address(), filialeDetails.getShop_desp(),
									Float.parseFloat(filialeDetails.getGraded()), filialeDetails.getGraded(),
									filialeDetails.getShop_latitude(), filialeDetails.getShop_longitude(), null, null);
						}
					}
				}
			});
		} else {
			urlString = new ArrayList<String>();
			bitmaps = new ArrayList<Bitmap>();
			HttpUtils http = new HttpUtils();
			RequestParams params = new RequestParams();
			params.addBodyParameter("c", "details");
			params.addBodyParameter("device_index", sp.getString("device_index", ""));
			if (this.getIntent().getStringExtra("itemType").equals("1")) {
				params.addBodyParameter("merchant_type", "2");
			} else {
				params.addBodyParameter("merchant_type", "1");
				llMerchantScope.setVisibility(View.VISIBLE);

			}
			params.addBodyParameter("merchant_id", this.getIntent().getStringExtra("merchant_id"));
			http.send(HttpMethod.POST, Ip.url + "/nearby.php", params, new RequestCallBack<String>() {

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					stopMyDialog();
					log.i("infor"+ arg0.getExceptionCode() + "--" + arg1);
					ivNoData.setVisibility(View.VISIBLE);
					svData.setVisibility(View.GONE);
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					stopMyDialog();
					log.i("infor"+ "arg0.statusCode == " + arg0.statusCode + "arg0.result" + arg0.result);
					NearDetails nearDetails = new Gson().fromJson(arg0.result, NearDetails.class);
					if (nearDetails.getCode().equals("1")) {
						if (nearDetails.getMerchant_type().equals("1")) {
							svData.setVisibility(View.VISIBLE);
							NearMerchantDetails nearMerchantDetails = new Gson().fromJson(arg0.result,
									NearMerchantDetails.class);
							urlString.clear();
							bitmaps.clear();
							layoutDots.removeAllViews();
							mHandler.removeMessages(AUTO);
							merchantDetails = nearMerchantDetails.getInfo();
							for (int i = 0; i < merchantDetails.getImages().size(); i++) {
								urlString.add("http://cdn.image.huyongle.com/"
										+ merchantDetails.getImages().get(i).getPhoto_path());
							}
							for (int i = 0; i < urlString.size(); i++) {
								one = urlString.get(i).lastIndexOf("/");
								if (ImageUtils.getLoacalBitmap(
										Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
										urlString.get(i).substring((one + 1), urlString.get(i).length())) != null) {
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								} else {
									ImageUtils.getNetworkBitmap(urlString.get(i), "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length()));
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								}
							}
							initView(merchantDetails.getMerchant_worktime(), merchantDetails.getMerchant_name(),
									merchantDetails.getMerchant_address(), merchantDetails.getMerchant_desp(),
									Float.parseFloat(merchantDetails.getGraded()), merchantDetails.getGraded(),
									merchantDetails.getMerchant_latitude(), merchantDetails.getMerchant_longitude(),
									merchantDetails.getMerchant_scope(), merchantDetails.getMerchant_percent());

						} else {
							log.i("兑换中心");
							llMerchantScope.setVisibility(View.GONE);
							NearFilialeDetails nearFilialeDetails = new Gson().fromJson(arg0.result,
									NearFilialeDetails.class);
							urlString.clear();
							bitmaps.clear();
							layoutDots.removeAllViews();
							mHandler.removeMessages(AUTO);
							filialeDetails = nearFilialeDetails.getInfo();
							for (int i = 0; i < filialeDetails.getImages().size(); i++) {
								urlString.add("http://lefen.huyongle.com/"
										+ filialeDetails.getImages().get(i).getPhoto_path());
							}
							for (int i = 0; i < urlString.size(); i++) {
								one = urlString.get(i).lastIndexOf("/");
								if (ImageUtils.getLoacalBitmap(
										Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
										urlString.get(i).substring((one + 1), urlString.get(i).length())) != null) {
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								} else {
									ImageUtils.getNetworkBitmap(urlString.get(i), "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length()));
									bitmaps.add(ImageUtils.getLoacalBitmap(
											Environment.getExternalStorageDirectory() + "/com.lefen58/userphoto/",
											urlString.get(i).substring((one + 1), urlString.get(i).length())));
								}
							}

							initView(filialeDetails.getShop_worktime(), filialeDetails.getShop_name(),
									filialeDetails.getShop_address(), filialeDetails.getShop_desp(),
									Float.parseFloat(filialeDetails.getGraded()), filialeDetails.getGraded(),
									filialeDetails.getShop_latitude(), filialeDetails.getShop_longitude(), null, null);
						}
					}
				}
			});
		}

	}

	void initView(String WorkTime, String MerchantName, String MerchantAddress, String desp, Float RatingBarGraded,
			String Graded, String latitude, String longitude, String MerchantScope, String Merchantercent) {

		this.latitude = latitude;
		this.longitude = longitude;
		tvWorkTime.setText(WorkTime);
		tvMerchantName.setText(MerchantName);
		tvMerchantAddress.setText(MerchantAddress);
		tvMerchantScope.setText(MerchantScope);
		merchantRatingBarGraded.setRating(RatingBarGraded);
		tvShopDesp.setText(desp);
		if (Merchantercent == null) {
			tv_songjifen.setVisibility(View.GONE);
		}
		tv_songjifen.setText(Merchantercent + "%乐分");

		String grand1 = Graded.subSequence(0, 1) + "." + Graded.substring(1);
		tvGraded.setText(grand1 + "分");

		tvBack.setText(MerchantName + "详情");

		LatLng latLng1 = new LatLng(Float.parseFloat(latitude), Float.parseFloat(longitude));
		LatLng latLng2 = new LatLng(((LeFenMallApplication)getApplication()).getLatitude(),
				((LeFenMallApplication)getApplication()).getLongitude());

		if (((LeFenMallApplication)getApplication()).getLongitude() == 0.0) {
			tvMerchantDistance.setText("距离计算失败 ");
		}else{
			tvMerchantDistance
			.setText(new DecimalFormat("0.0").format(DistanceUtil.getDistance(latLng1, latLng2) / 1000) + "Km");
		}
		initDots();
		initViewPager();
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {

	}

	@Override
	public void onPageSelected(int arg0) {

		if (urlString.size() > 0) {
			setCurrentDot(arg0 % urlString.size());
		}

	};

	/**
	 * 导航部分
	 * 
	 */

	private boolean initDirs() {
		mSDCardPath = getSdcardDir();
		if (mSDCardPath == null) {
			return false;
		}
		File f = new File(mSDCardPath, APP_FOLDER_NAME);
		if (!f.exists()) {
			try {
				f.mkdir();
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	String authinfo = null;

	private void initNavi() {
		BaiduNaviManager.getInstance().setNativeLibraryPath(mSDCardPath + "/BaiduNaviSDK_SO");
		BaiduNaviManager.getInstance().init(this, mSDCardPath, APP_FOLDER_NAME, new NaviInitListener() {
			@Override
			public void onAuthResult(int status, String msg) {
				if (0 == status) {
					authinfo = "key校验成功!";
				} else {
					authinfo = "key校验失败, " + msg;
				}
				MerchantActivity.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// Toast.makeText(MerchantActivity.this, authinfo,
						// Toast.LENGTH_LONG).show();
					}
				});

			}

			public void initSuccess() {

			}

			public void initStart() {
			}

			public void initFailed() {
				stopMyDialog();
				Toast.makeText(MerchantActivity.this, "百度导航引擎初始化失败", Toast.LENGTH_SHORT).show();
			}
		}, mTTSCallback);
	}

	private String getSdcardDir() {
		if (Environment.getExternalStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED)) {
			return Environment.getExternalStorageDirectory().toString();
		}
		return null;
	}

	private void routeplanToNavi(CoordinateType coType) {
		BNRoutePlanNode sNode = null;
		BNRoutePlanNode eNode = null;
		switch (coType) {
		case GCJ02: {

			sNode = new BNRoutePlanNode(((LeFenMallApplication)getApplication()).getLongitude(),
					((LeFenMallApplication)getApplication()).getLatitude(), 
					"乐分总部", null, coType);

			eNode = new BNRoutePlanNode(
					Float.parseFloat(this.getIntent().getStringExtra("itemType").equals("1")
							? filialeDetails.getShop_longitude() : merchantDetails.getMerchant_longitude()),
					Float.parseFloat(this.getIntent().getStringExtra("itemType").equals("1")
							? filialeDetails.getShop_latitude() : merchantDetails.getMerchant_latitude()),
					this.getIntent().getStringExtra("itemType").equals("1") ? filialeDetails.getShop_name()
							: merchantDetails.getMerchant_name(),
							null, coType);
			break;
		}
		}
		if (sNode != null && eNode != null) {
			List<BNRoutePlanNode> list = new ArrayList<BNRoutePlanNode>();
			list.add(sNode);
			list.add(eNode);
			BaiduNaviManager.getInstance().launchNavigator(this, list, 1, true, new DemoRoutePlanListener(sNode));
		}
	}

	public class DemoRoutePlanListener implements RoutePlanListener {

		private BNRoutePlanNode mBNRoutePlanNode = null;

		public DemoRoutePlanListener(BNRoutePlanNode node) {
			mBNRoutePlanNode = node;
		}

		@Override
		public void onJumpToNavigator() {
			stopMyDialog();
			Intent intent = new Intent(MerchantActivity.this, BNGuideActivity.class);
			Bundle bundle = new Bundle();
			bundle.putSerializable(ROUTE_PLAN_NODE, (BNRoutePlanNode) mBNRoutePlanNode);
			intent.putExtras(bundle);
			startActivity(intent);
		}

		@Override
		public void onRoutePlanFailed() {
			log.i("onRoutePlanFailed");
		}
	}

	private BNOuterTTSPlayerCallback mTTSCallback = new BNOuterTTSPlayerCallback() {

		@Override
		public void stopTTS() {

		}

		@Override
		public void resumeTTS() {

		}

		@Override
		public void releaseTTSPlayer() {

		}

		@Override
		public int playTTSText(String speech, int bPreempt) {
			return 0;
		}

		@Override
		public void phoneHangUp() {

		}

		@Override
		public void phoneCalling() {

		}

		@Override
		public void pauseTTS() {

		}

		@Override
		public void initTTSPlayer() {

		}

		@Override
		public int getTTSState() {
			return 0;
		}
	};

}

package com.lefen58.lefenmall.ui;

import java.text.DecimalFormat;
import java.util.ArrayList;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.GoodsList;
import com.lefen58.lefenmall.entity.MallGoodsList;
import com.lefen58.lefenmall.entity.MerchantList;
import com.lefen58.lefenmall.entity.Search;
import com.lefen58.lefenmall.http.MallNetRequest;
import com.lefen58.lefenmall.image.RoundImageDrawable;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class FindActivity extends BaseActivity {

	@ViewInject(R.id.ed_keyword)
	private EditText edKeyWord;

	@ViewInject(R.id.lv_find_data)
	private ListView lvFindData;

	@ViewInject(R.id.imgView_no_date)
	private ImageView imgView_no_date;

	@ViewInject(R.id.find_record_linear)
	private LinearLayout find_record_linear;
	
	@ViewInject(R.id.lv_find_record)
	private ListView lv_find_record;
	
	private String[] recordList;
	
	

	ArrayList<MerchantList> merchantLists;
	
//	private SharedPreferences spRecord;
	
	private MallNetRequest mallNetRequest;
	
	
	/**
	 * 商品列表加载过程中显示的占位图
	 */
	BitmapDisplayConfig bitmap;
	private MallGoodsListAdapter mallGoodsListAdapter;
	
	/**
	 * 搜索
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_find);
		ViewUtils.inject(this);
		
		lvFindData.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if ("goods".equals(getIntent().getStringExtra("flag"))) {
					Intent intent = new Intent(FindActivity.this, CommodityDetailActivity.class);
					intent.putExtra("good_id", ((MallGoodsList)parent.getItemAtPosition(position)).goodsId);
					startActivity(intent);
				}else {
					Intent intent = new Intent(FindActivity.this, MerchantActivity.class);
					intent.putExtra("itemType", "2");
					intent.putExtra("merchant_id", merchantLists.get(position).getMerchant_id());
					startActivity(intent);
				}
			}
		});
		
		lv_find_record.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				String word=(String) parent.getItemAtPosition(position);
				edKeyWord.setText(word);
				if ("goods".equals(getIntent().getStringExtra("flag"))) {
					getGoodsList(word);
				}else{
					getData(word);
				}
			}
		});

		merchantLists = new ArrayList<MerchantList>();
		
		if ("goods".equals(getIntent().getStringExtra("flag"))) {
			showSearchHistory(Constants.SPKEY_GOODS_SEARCH_HISTORY);
			edKeyWord.setHint("输入商品名或商品关键字");
		}else{
			showSearchHistory(Constants.SPKEY_MERCHANT_SEARCH_HISTORY);
		}
	}
	
	private void showSearchHistory(String type) {
		String historyStr=sp.getString(type, "");
		if (TextUtils.isEmpty(historyStr)) {
			return;
		}
		recordList=historyStr.split("\\|");
		if (recordList!=null&&recordList.length>0) {
			lv_find_record.setAdapter(new SearchReordAdapter());
			find_record_linear.setVisibility(View.VISIBLE);
		}
	}
	
	private void saveSearchHistory(String word,String type) {
		if (!TextUtils.isEmpty(word)) {
			String historyStr=sp.getString(type, "");
			String []historyArr=historyStr.split("\\|");
			for (int i = 0; i < historyArr.length; i++) {
				if (word.equals(historyArr[i])) {
					return;
				}
			}
			if (historyStr.length()>0) {
				sp.edit().putString(type, historyStr+"|"+word).commit();
			}else {
				sp.edit().putString(type, historyStr+word).commit();
			}
		}
	}

	public void find(View view) {

		String keyWord = edKeyWord.getText().toString();
		
		if (keyWord.equals("")) {
			Toast.makeText(context, "请输入搜索内容", Toast.LENGTH_SHORT).show();
		} else {
			if ("goods".equals(getIntent().getStringExtra("flag"))) {
				getGoodsList(keyWord);
			}else{
				getData(keyWord);
			}
			
		}
	}
	
	/**
	 * 搜索商品
	 */
	private void getGoodsList(final String keyWord) {
		if (mallNetRequest == null) {
			mallNetRequest = new MallNetRequest(context);
		}
		
		mallNetRequest.getSearchGoodsList(keyWord, GoodsList.class, new RequestCallBack<GoodsList>() {
			
			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				startMyDialog();
			}
			
			@Override
			public void onSuccess(ResponseInfo<GoodsList> arg0) {
				stopMyDialog();
				if (arg0.result == null || arg0.result.list == null) {
					return;
				}
				switch (arg0.result.code) {
				case 1:
					if (arg0.result.list == null || arg0.result.list.size()==0) {
						imgView_no_date.setVisibility(View.VISIBLE);
						imgView_no_date.setImageDrawable(getResources().getDrawable(R.drawable.mall_list_nodata));
						lvFindData.setVisibility(View.GONE);
					}else{
						lvFindData.setVisibility(View.VISIBLE);
						imgView_no_date.setVisibility(View.GONE);
					}
					find_record_linear.setVisibility(View.GONE);
					
					
					mallGoodsListAdapter = new MallGoodsListAdapter(context, arg0.result.list);
					lvFindData.setAdapter(mallGoodsListAdapter);
					
					saveSearchHistory(keyWord,Constants.SPKEY_GOODS_SEARCH_HISTORY);
					break;
				default:
					
					break;
				}
				
			}
			
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				stopMyDialog();
			}
		});
		
	}
	
	
	class MallGoodsListAdapter extends BaseAdapter{
		private ArrayList<MallGoodsList> mList;
		private Context context;
		public MallGoodsListAdapter(Context context,ArrayList<MallGoodsList> mList) {  

			this.context = context;  
			this.mList = mList;
			
			bitmap = new BitmapDisplayConfig();
			bitmap.setLoadingDrawable(getResources().getDrawable(R.drawable.zhanweitu));
		}  


		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			final GoodsViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				holder = new GoodsViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.listview_mall_goods_item, null);
				holder.ivGoodsIcon = (ImageView) convertView.findViewById(R.id.iv_goods_icon);
				holder.tvGoosName = (TextView) convertView.findViewById(R.id.tv_goos_name);
				holder.rbGoodsGrade = (RatingBar) convertView.findViewById(R.id.rb_goods_grade);
				holder.tvGoodsGrade = (TextView) convertView.findViewById(R.id.tv_goods_grade);
				holder.tvGoodsIntegralPrice = (TextView) convertView.findViewById(R.id.tv_goods_integral_price);
				holder.tvGoodsViewedCount = (TextView) convertView.findViewById(R.id.tv_goods_viewed_count);
				holder.tvGoodsSalesVolume = (TextView) convertView.findViewById(R.id.tv_goods_sales_volume);
				convertView.setTag(holder);
			} else {
				holder = (GoodsViewHolder) convertView.getTag();
			}

			if (this.mList != null) {
				if (holder.ivGoodsIcon!= null) {
					bitmapUtils.display(holder.ivGoodsIcon, "http://cdn.image.huyongle.com/"+mList.get(position).goods_icon,bitmap,new BitmapLoadCallBack<View>() {

						@Override
						public void onLoadCompleted(View arg0, String arg1, Bitmap arg2, BitmapDisplayConfig arg3,
								BitmapLoadFrom arg4) {
							((ImageView)arg0).setImageDrawable(new RoundImageDrawable(arg2));
							
						}

						@Override
						public void onLoadFailed(View arg0, String arg1, Drawable arg2) {
							// TODO Auto-generated method stub

						}
					});
					
				}
				if (holder.tvGoosName!= null) {
					holder.tvGoosName.setText(mList.get(position).goodsName);
				}
				if (holder.rbGoodsGrade!= null) {
					holder.rbGoodsGrade.setRating(Float.parseFloat(mList.get(position).goodsGrade.substring(0, 1)));
				}
				if (holder.tvGoodsGrade!= null) {
					holder.tvGoodsGrade.setText(Float.parseFloat(mList.get(position).goodsGrade.substring(0, 1))+"分");
				}
				if (holder.tvGoodsIntegralPrice!= null) {
					holder.tvGoodsIntegralPrice.setText(mList.get(position).goodsIntegralPrice);
				}
				if (holder.tvGoodsViewedCount!= null) {
					holder.tvGoodsViewedCount.setText(mList.get(position).goodsViewedCount+"人已浏览");
				}
				if (holder.tvGoodsSalesVolume!= null) {
					holder.tvGoodsSalesVolume.setText("月销量"+mList.get(position).goodsSalesVolume+"笔");
				}

			}

			return convertView;
		}
	}
	
	private static class GoodsViewHolder {
		ImageView ivGoodsIcon;
		TextView tvGoosName;
		RatingBar rbGoodsGrade;
		TextView tvGoodsGrade;
		TextView tvGoodsIntegralPrice;
		TextView tvGoodsViewedCount;
		TextView tvGoodsSalesVolume;
	}

	
	
	/**
	 * 搜索商家
	 * @param keyWord
	 */
	private void getData(final String keyWord) {

		startMyDialog();
		HttpUtils http = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "search");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("city", sp.getString("cityId", "0"));
		params.addBodyParameter("county", "0");
		params.addBodyParameter("keyword", keyWord);
		http.send(HttpMethod.POST, Ip.url + "nearby.php", params, new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Toast.makeText(context, "网络连接失败", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
				Search search = new Gson().fromJson(arg0.result, Search.class);
				if (CommonUtils.NetworkRequestReturnCode(context, search.getCode())) {
					merchantLists.clear();
					if (search.getMerchant_list().size() == 0) {
						imgView_no_date.setVisibility(View.VISIBLE);
						lvFindData.setVisibility(View.GONE);
					} else {
						imgView_no_date.setVisibility(View.GONE);
						lvFindData.setVisibility(View.VISIBLE);
						for (int i = 0; i < search.getMerchant_list().size(); i++) {
							merchantLists.add(search.getMerchant_list().get(i));
						}
						lvFindData.setAdapter(new MerchantAdapter(context, merchantLists));
					}
					find_record_linear.setVisibility(View.GONE);
					saveSearchHistory(keyWord,Constants.SPKEY_MERCHANT_SEARCH_HISTORY);
				}

			}
		});
	
	}

	class MerchantAdapter extends BaseAdapter {

		private ArrayList<MerchantList> merchantLists;
		private Context context;

		public MerchantAdapter(Context context, ArrayList<MerchantList> mList) {

			this.context = context;
			this.merchantLists = mList;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return merchantLists.size();
		}

		@Override
		public Object getItem(int position) {
			if (merchantLists == null) {
				return null;
			} else {
				return this.merchantLists.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			BitmapUtils bitmapUtils = new BitmapUtils(context);
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(R.layout.near_lv_merchant, null);
				holder = new ViewHolder(convertView);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			holder.merchant_name.setText(merchantLists.get(position).getMerchant_name());
			holder.merchant_address.setText(merchantLists.get(position).getMerchant_address());
			holder.merchant_ratingBar.setRating(Float.parseFloat(merchantLists.get(position).getGraded()));
			bitmapUtils.display(holder.merchant_iv_prize,
					"http://cdn.image.huyongle.com/" + merchantLists.get(position).getMerchant_image());

			String latitude = merchantLists.get(position).getMerchant_latitude();
			String longitude = merchantLists.get(position).getMerchant_longitude();
			LatLng latLng1 = new LatLng(Float.parseFloat(latitude), Float.parseFloat(longitude));
			LatLng latLng2 = new LatLng(34.751645, 113.783965);
			holder.merchant_distance.setText(
					"距离 " + new DecimalFormat("0.0").format(DistanceUtil.getDistance(latLng1, latLng2) / 1000) + "Km");
			return convertView;
		}
	}

	class ViewHolder {
		public ImageView merchant_iv_prize = null;
		public TextView merchant_name = null;
		public RatingBar merchant_ratingBar = null;
		public TextView merchant_address = null;
		public TextView merchant_distance = null;
		public TextView title = null;

		public ViewHolder(View view) {
			// 商店地址
			merchant_address = (TextView) view.findViewById(R.id.merchant_address);
			// 图片
			merchant_iv_prize = (ImageView) view.findViewById(R.id.merchant_iv_prize);
			// 评分
			merchant_ratingBar = (RatingBar) view.findViewById(R.id.merchant_ratingBar);
			// 距离
			merchant_distance = (TextView) view.findViewById(R.id.merchant_distance);
			// 名称
			merchant_name = (TextView) view.findViewById(R.id.merchant_name);
		}
	}

	class SearchReordAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			if (recordList!=null) {
				return recordList.length;
			}
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (recordList!=null&&recordList.length>position) {
				return recordList[position];
			}
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(R.layout.activity_find_record_item, null);

				holder1 = new ViewHolder1();
				holder1.find_record_item_tv = (TextView) convertView.findViewById(R.id.find_record_item_tv);
				convertView.setTag(holder1);
			} else {
				holder1 = (ViewHolder1) convertView.getTag();
			}

			holder1.find_record_item_tv.setText(recordList[position]);

			return convertView;

		}

	}
	private ViewHolder1 holder1;
	private class ViewHolder1 {
		private TextView find_record_item_tv;
	}

	public void clear(View view) {
		if ("goods".equals(getIntent().getStringExtra("flag"))) {
			sp.edit().putString(Constants.SPKEY_GOODS_SEARCH_HISTORY, "").commit();
		}else{
			sp.edit().putString(Constants.SPKEY_MERCHANT_SEARCH_HISTORY, "").commit();
		}
		find_record_linear.setVisibility(View.GONE);
	}

}

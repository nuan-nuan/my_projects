package com.lefen58.lefenmall.ui;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Feedback;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FeedbackActivity extends BaseActivity {
	private SharedPreferences sp;
	/**
	 * 意见反馈
	 */
	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	@ViewInject(R.id.spinner1)
	private Spinner spinner1;

	@ViewInject(R.id.contact)
	private EditText contact;

	@ViewInject(R.id.content)
	private EditText content;

	private static List<HashMap<String,String>> a;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_feedback);
		ViewUtils.inject(this);
		tv_back.setText("意见反馈");
		sp = getSharedPreferences("UserInfor", 0);
		setData();


	}

	private void setData() {
		contact.setHint(sp.getString("phone", ""));
		HttpUtils http = new HttpUtils();
		startMyDialog();
		// 获取反馈类型
		http.send(HttpMethod.POST, Ip.url+"/service.php?c=get_feedback_type",
				null, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
				stopMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				stopMyDialog();
				Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
				if (arg0.statusCode==200) {
					Gson gson = new Gson();
					Feedback feedback = gson.fromJson(arg0.result, Feedback.class);
					if (feedback.getCode().equals("1")) {
						ArrayAdapter<String> adapter = new ArrayAdapter<String>(FeedbackActivity.this, R.layout.feedback_spinner);

						for (int i = 0; i < feedback.getList().size(); i++) {
							adapter.add(feedback.getList().get(i));
						}
						adapter.setDropDownViewResource(R.layout.drop_down_checked_text);//(android.R.layout.simple_spinner_dropdown_item);
						spinner1.setAdapter(adapter);
					}

				}else{
					Toast.makeText(FeedbackActivity.this, "网络异常："+arg0.statusCode, Toast.LENGTH_SHORT).show();
				}

			}
		});

	}

	public void onBack(View view){
		onBackPressed();
	}

	public void pushOpinions(View view){
		String tel;
		if (content.getText().toString().length()<5) {
			Toast.makeText(FeedbackActivity.this, "反馈内容不应小于5个字", Toast.LENGTH_SHORT).show();
			Log.i("infor", "反馈内容不应小于5个字");
			return;
		}

		if (!CommonUtils.isPhoneNumer(contact.getHint().toString())) {
			tel = contact.getText().toString();
		} else {
			tel = contact.getHint().toString();
		}

		if (!CommonUtils.isPhoneNumer(tel)) {
			Toast.makeText(FeedbackActivity.this, "联系方式有误", Toast.LENGTH_SHORT).show();
			Log.i("infor", "联系方式有误");
			return;
		}

		startMyDialog();
		HttpUtils http = new HttpUtils();
		// 获取反馈类型
		RequestParams params = null;
		try {
			params = new RequestParams();
			//params.addBodyParameter("c","submit_feedback");
			params.addBodyParameter("device_index", sp.getString("device_index", ""));//客户端运行设备的唯一自增编号
			params.addBodyParameter("token", RequestOftenKey.getToken(context));//客户端登录凭证(token值+盐做数学运算)
			params.addBodyParameter("type", 
					URLEncoder.encode(
							spinner1.getSelectedItem().toString()
							,"UTF-8")
					);//反馈类型
			params.addBodyParameter("content",
					URLEncoder.encode(content.getText().toString()
							,"UTF-8")
					);//反馈内容
			params.addBodyParameter("contact", tel);//联系方式
			Log.i("infor", "tel"+tel);

			http.send(HttpMethod.POST, Ip.url+"/service.php?c=submit_feedback",
					params, new RequestCallBack<String>(){

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					Log.i("infor", arg0.getExceptionCode()+"--"+arg1);
					stopMyDialog();
					Toast.makeText(FeedbackActivity.this, "请您检查网络", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					stopMyDialog();
					Log.i("infor", "arg0.statusCode == "+arg0.statusCode + "arg0.result"+arg0.result);
					if (arg0.statusCode==200) {
						Gson gson = new Gson();
						Get_SMS_code code = gson.fromJson(arg0.result, Get_SMS_code.class);
						if (code.getCode().equals("1")) {
							Toast.makeText(FeedbackActivity.this, "谢谢您的反馈~", Toast.LENGTH_SHORT).show();
							finish();
						}

					}else{
						Toast.makeText(FeedbackActivity.this, "网络异常："+arg0.statusCode, Toast.LENGTH_SHORT).show();

					}

				}
			});
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

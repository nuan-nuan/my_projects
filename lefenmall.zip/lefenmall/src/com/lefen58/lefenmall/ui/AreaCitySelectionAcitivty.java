package com.lefen58.lefenmall.ui;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.adapter.ListViewGridViewAdapter;
import com.lefen58.lefenmall.entity.AreaInfo;
import com.lefen58.lefenmall.widgets.MyLoading;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ListView;
import android.widget.TextView;

public class AreaCitySelectionAcitivty extends BaseActivity{

	/**
	 * 地区选择：市县
	 */

	ArrayList<AreaInfo> city ;
	//ArrayList<AreaInfo> areaInfos ;

	private static SharedPreferences sp;

	@ViewInject(R.id.tv_back)
	private TextView tv_back;

	ListView listview_city_county;

	ListViewGridViewAdapter treeViewAdapter;
	private ArrayList<ArrayList<HashMap<String,AreaInfo>>> mArrayList;

	private MyLoading myloading;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_area_city_selection);
		ViewUtils.inject(this);
		sp = getSharedPreferences("UserInfor", 0);
		tv_back.setText(sp.getString("province_name", "")+"省");
		startMyDialog();

	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		new Thread(new Runnable() {
			public void run() {
				setData();
			}
		}).start();
	}
	private void setData() {
		// Log.i("infor", this.getIntent().getStringExtra("region_id"));
		JSONArray js;
		try {
			InputStream is = getResources().getAssets().open("config_region.json");
			byte [] buffer = new byte[is.available()] ; 
			is.read(buffer);
			String json = new String(buffer,"utf-8");
			city = new ArrayList<AreaInfo>();
			js = new JSONArray(json);
			AreaInfo[] areaInfos = new AreaInfo[js.length()] ;
			Gson gson = new Gson();
			for (int i = 0; i < areaInfos.length; i++) {
				areaInfos[i] = gson.fromJson(js.getJSONObject(i).toString(), AreaInfo.class);
			}
			for (int index = 30; index < js.length(); index++) {
				if (AreaCitySelectionAcitivty.this.getIntent().getStringExtra("region_id").equals(
						gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getParent_id())) {
					city.add(gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class));
					Log.i("infor", gson.fromJson(js.getJSONObject(index).toString(), AreaInfo.class).getRegion_name());
				}
			}

			mArrayList=new ArrayList<ArrayList<HashMap<String,AreaInfo>>>();
			HashMap<String, AreaInfo> hashMap=null;
			ArrayList<HashMap<String,AreaInfo>> arrayListForEveryGridView;

			for (int i = 0; i < city.size(); i++) {
				arrayListForEveryGridView=new ArrayList<HashMap<String,AreaInfo>>();
				for (int j = 397; j < areaInfos.length; j++) {
					hashMap=new HashMap<String, AreaInfo>();
					if (city.get(i).getRegion_id().equals(
							areaInfos[j].getParent_id())) {
						hashMap.put("content", areaInfos[j]);
						arrayListForEveryGridView.add(hashMap);
					}
				}
				mArrayList.add(arrayListForEveryGridView);
			}
			Log.i("infor", "mArrayList"+mArrayList.size());

		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		treeViewAdapter = new ListViewGridViewAdapter(AreaCitySelectionAcitivty.this,city,mArrayList);
		listview_city_county = (ListView) this
				.findViewById(R.id.listview_city_county);
		runOnUiThread(new Runnable() {
			public void run() {
				listview_city_county.setAdapter(treeViewAdapter);
				stopMyDialog();
			}
		});
	}

	public void onBack(View view){
		onBackPressed();
	}

}

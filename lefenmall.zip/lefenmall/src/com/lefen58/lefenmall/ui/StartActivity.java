package com.lefen58.lefenmall.ui;

import com.igexin.sdk.PushManager;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lefen58.lefenmall.entity.RegisterDevice;
import com.lefen58.lefenmall.entity.Start_app;
import com.lefen58.lefenmall.http.AccountNetRequest;
import com.lefen58.lefenmall.receiver.PushGetuiReceiver;
import com.lefen58.lefenmall.utils.PreferenceUtils;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class StartActivity extends BaseActivity {

	DisplayMetrics dm;

	PushGetuiReceiver pushGetuiReceiver;
	AccountNetRequest netRequset;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
				WindowManager.LayoutParams.FLAG_FULLSCREEN); 
		setContentView(R.layout.activity_start);
		ViewUtils.inject(this);

		// 注册个推
		PushManager.getInstance().initialize(this.getApplicationContext());

		initConfig();
		new Thread(
				new Runnable() {
					public void run() {
						try {
							Thread.sleep(2000);
							// 欢迎界面显示2秒,如果不是首次安装，就不显示引导页
							if (sp.getBoolean(Constants.SPKEY_IS_FIRST, true)) {
								startActivity(new Intent(StartActivity.this, GuideActivity.class));
							}else {
								startActivity(new Intent(StartActivity.this, HomeActivity.class));
							}
							finish();
						} catch (InterruptedException e) {
						}
					}
				}).start();
	}



	/**
	 * 如果是首次启动进行设备注册
	 * 如果不是直接执行 startApp()
	 */
	private void initConfig() {
		if (netRequset == null) {
			netRequset = new AccountNetRequest(context);
		}
		
		// 如果是首次打开，注册设备
		if (PreferenceUtils.readBoolConfig(Constants.SPKEY_IS_FIRST, context)||PreferenceUtils.readStrConfig(Constants.SPKEY_DEVICE_INDEX, context).equals("")) {
			//之后在程序中通过以下代码获取设备屏幕分辨率UserInfor
			dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
			netRequset.registerDevice(dm.widthPixels, dm.heightPixels, RegisterDevice.class, new RequestCallBack<RegisterDevice>() {

				@Override
				public void onSuccess(ResponseInfo<RegisterDevice> arg0) {
					switch (arg0.result.code) {
					case 1: // 请求成功
						PreferenceUtils.writeStrConfig(Constants.SPKEY_DEVICE_INDEX, arg0.result.deviceIndex, context);
						startApp();
						break;

					case -12: // 设备已注册
						PreferenceUtils.writeStrConfig(Constants.SPKEY_DEVICE_INDEX, arg0.result.deviceIndex, context);
						startApp();
						break;

					case -3: // 系统繁忙，3-10秒重试
						new Thread(new Runnable() {
							public void run() {
								try {
									Thread.sleep(5000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								initConfig();
							}
						}).start();
						break;
					}

				}

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					log.i(arg0.getExceptionCode());
					// 请求失败的原因如果是请求超时则重新执行
					if (arg0.getExceptionCode()==408) {
						initConfig();
					}
				}
			});
		}else{
			startApp();
		}
	}

	/**
	 * APP 每次启动的时候调用
	 * 获取 盐值，验证 Token
	 */
	private void startApp(){
		// 各推推送标示 id
		String push_id = sp.getString(Constants.SPKEY_CLIENTID, "0");
		// 网络请求
		netRequset.appStart("0", push_id, Start_app.class, new RequestCallBack<Start_app>() {

			@Override
			public void onSuccess(ResponseInfo<Start_app> arg0) {

				switch (arg0.result.code) {
				case 1: //  请求成功
					log.i("本次启动服务器返回的盐"+arg0.result.serverSalt);
					/* 存储服务器返回的盐值 */
					PreferenceUtils.writeStrConfig(Constants.SPKEY_SERVER_SALT, arg0.result.serverSalt, context);
					PreferenceUtils.writeStrConfig(Constants.SPKEY_LATEST_VERSION, arg0.result.newestVersion, context);

					/* arg0.result.loginStatus 登录状态,0表示失效,1表示有效
					 存储本地用于做是否登录状态判断
					 */
					if (arg0.result.loginStatus.equals("1")) {
						PreferenceUtils.writeBoolConfig(Constants.SPKEY_STATE, true, context);
						RequestOftenKey.getUserInfor(context, sp);
					} else {
						PreferenceUtils.writeBoolConfig(Constants.SPKEY_STATE, false, context);
					}
					break;
				case 3: //  系统繁忙，3-10秒重试
					
					if (arg0.result.loginStatus.equals("1")) {
						PreferenceUtils.writeBoolConfig(Constants.SPKEY_STATE, true, context);
						RequestOftenKey.getUserInfor(context, sp);
					} else {
						PreferenceUtils.writeBoolConfig(Constants.SPKEY_STATE, false, context);
					}
					new Thread(new Runnable() {
						public void run() {
							try {
								Thread.sleep(5000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							startApp();
						}
					}).start();
					break;
				}

			}

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// 请求失败的原因如果是请求超时则重新执行
				if (arg0.getExceptionCode()==408) {
					startApp();
				}
			}
		});

	}

}

package com.lefen58.lefenmall.ui;

import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

public class GuideActivity extends BaseActivity {
	
    @ViewInject(R.id.viewPager_guide_img)
	ViewPager mViewPager;
	
    
    private Context mContext=GuideActivity.this;
    private int[] imgs={R.drawable.guide_01,R.drawable.guide_02,R.drawable.guide_03};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_guide);
		ViewUtils.inject(this);
		GuideViewPagerAdapter adapter=new GuideViewPagerAdapter();
		mViewPager.setAdapter(adapter);
	}
	
	class GuideViewPagerAdapter extends PagerAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return imgs.length;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0==arg1;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			// TODO Auto-generated method stub
			container.removeView((View) object);
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			// TODO Auto-generated method stub
			ViewGroup.LayoutParams lp=new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			ImageView mView=new ImageView(mContext);
			mView.setScaleType(ScaleType.FIT_XY);
			mView.setBackgroundResource(imgs[position]);
			mView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Editor editor=sp.edit();
					editor.putBoolean(Constants.SPKEY_IS_FIRST, false);
					editor.commit();
					startActivity(new Intent(mContext, HomeActivity.class));
					finish();
				}
			});
			container.addView(mView,lp);
			return mView;
		}
		
		
	}
}

package com.lefen58.lefenmall.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.lefen58.lefenmall.AppManager;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.AreaInfo;
import com.lefen58.lefenmall.ui.HomeActivity;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.widgets.NoScrollGridView;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ListViewGridViewAdapter extends BaseAdapter{
	private LayoutInflater inflater;
	private ArrayList<ArrayList<HashMap<String, AreaInfo>>> mList;
	private ArrayList<AreaInfo> citys;
	private Context context; // 上下文
	private static SharedPreferences sp;
	LogUtil Log = LogUtil.lLog();

	public ListViewGridViewAdapter(Context context, ArrayList<AreaInfo> citys,ArrayList<ArrayList<HashMap<String, AreaInfo>>> mList) {
		this.context = context;
		this.mList = mList;
		this.inflater = LayoutInflater.from(context);
		this.citys = citys;

	}

	@Override
	public int getCount() {
		if (mList == null) {
			return 0;
		} else {
			return this.mList.size();
		}
	}

	@Override
	public Object getItem(int position) {
		if (mList == null) {
			return null;
		} else {
			return this.mList.get(position);
		}
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.area_city_list, null);
			holder = new ViewHolder();
			holder.city = (TextView) convertView.findViewById(R.id.city);
			holder.noScrollGridView = (NoScrollGridView) convertView.findViewById(R.id.NoScrollGridView);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		if (this.mList != null) {
			if (holder.city != null) {
				holder.city.setText(citys.get(position).getRegion_name());;
			}
			if (holder.noScrollGridView != null) {
				final ArrayList<HashMap<String, AreaInfo>> arrayListForEveryGridView = mList.get(position);
				GridViewAdapter gridViewAdapter=new GridViewAdapter(context, arrayListForEveryGridView);
				holder.noScrollGridView.setAdapter(gridViewAdapter);
				holder.noScrollGridView.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int p, long id) {
						android.util.Log.i("gridviewOnClick", (arrayListForEveryGridView.get(p).get("content")).getRegion_name());
						
						Toast.makeText(context, "当前选中的是:" + 
					
								(arrayListForEveryGridView.get(p).get("content")).getRegion_name(), Toast.LENGTH_SHORT)
						.show();
						
						sp = context.getSharedPreferences("UserInfor", 0);
						sp.edit().putString("cityId", citys.get(position).getRegion_id()).commit();
						sp.edit().putString("countyId", 
								arrayListForEveryGridView.get(p).get("content").getRegion_id()).commit();
						Log.i(citys.get(position).getRegion_name());
						sp.edit().putString("city", citys.get(position).getRegion_name()).commit();
						
						sp.edit().putString("countyName", 
								arrayListForEveryGridView.get(p).get("content").getRegion_name()).commit();
						JSONObject object = new JSONObject();
						try {
							object.put("city",citys.get(position).getRegion_id());
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						HttpUtils http = new HttpUtils();
						RequestParams params = new RequestParams();
						params.addBodyParameter("c", "set_user_info");
						params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
						params.addBodyParameter("token", RequestOftenKey.getToken(context));
						params.addBodyParameter("user_info", object.toString());
						// 保存信息
						http.send(HttpMethod.POST,Ip.url+"account.php",
								params, new RequestCallBack<String>(){

							@Override
							public void onFailure(HttpException arg0, String arg1) {
								Log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
							}

							@Override
							public void onSuccess(ResponseInfo<String> arg0) {
								
							}
						});
						context.startActivity(new Intent(context, HomeActivity.class));
						AppManager.getInstance().killAllActivity();
					}
				});
			}

		}

		return convertView;
	}

	private static class ViewHolder {
		public TextView city;
		public TextView area_city_gridview_city;
		public NoScrollGridView noScrollGridView;
	}

	private class GridViewAdapter extends BaseAdapter{
		private Context mContext;
		private ArrayList<HashMap<String, AreaInfo>> mList;

		public GridViewAdapter(Context context,ArrayList<HashMap<String, AreaInfo>> mList) {  
			this.mContext = context;  
			this.mList = mList;
		}  

		@Override
		public int getCount() {
			if (mList == null) {
				return 0;
			} else {
				return this.mList.size();
			}
		}

		@Override
		public Object getItem(int position) {
			if (mList == null) {
				return null;
			} else {
				return this.mList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder holder;
			if (convertView == null) {
				convertView = inflater.inflate(R.layout.area_city_gridview, null);
				holder = new ViewHolder();
				holder.area_city_gridview_city = (TextView) convertView.findViewById(R.id.area_city_gridview_city);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (this.mList != null) {
				HashMap<String, AreaInfo> hashMap = mList.get(position);
				if (holder.area_city_gridview_city!= null) {
					if (hashMap.get("content") != null) {
						holder.area_city_gridview_city.setText(hashMap.get("content").getRegion_name());
					}else{
						Log.i("infor hashMap is null");
					}

				}
			}
			return convertView;
		}
	}

}
package com.lefen58.lefenmall.adapter;

import java.text.DecimalFormat;
import java.util.List;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.lefen58.lefenmall.LeFenMallApplication;
import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.entity.NearDataBase;
import com.lefen58.lefenmall.entity.NearDataFiliale;
import com.lefen58.lefenmall.entity.NearDataMerchant;
import com.lefen58.lefenmall.ui.MerchantActivity;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lidroid.xutils.BitmapUtils;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Kent on 2014/12/12.
 */
public class NearDataAdapter extends BaseAdapter {
	private LogUtil log = LogUtil.lLog();
	private Context mContext = null;
	private LayoutInflater mInflater = null;
	
	private SharedPreferences sp ;

	private List<NearDataBase> mData = null;//要显示的数据

	public NearDataAdapter(Context context, List<NearDataBase> data){
		this.mInflater = LayoutInflater.from(context);
		this.mData = data;
		this.mContext = context;
	}

	//添加新的Item，并通知listview进行显示刷新
	public void addItem(NearDataBase newItem){
		this.mData.add(newItem);
		this.notifyDataSetChanged();
	}

	@Override
	public int getItemViewType(int position) {

		try {
			return mData.get(position).getItem_type();
		} catch (ArrayIndexOutOfBoundsException e) {
			log.i("getItemViewType");
			return position;
		}

	}

	@Override
	public int getViewTypeCount() {
		return 3;
	}

	@Override
	public int getCount() {
		if(mData == null){
			return 0;
		}
		try {
			return this.mData.size();
		} catch (Exception e) {
			// TODO: handle exception
			log.i("getCount");
			return this.mData.size();
		}

	}

	@Override
	public Object getItem(int i) {

		try {

			return mData.get(i);
		} catch (ArrayIndexOutOfBoundsException e) {
			log.i("getItem");
			return mData.get(i);
		}
	}

	@Override
	public long getItemId(int i) {

		try {
			return i;

		} catch (ArrayIndexOutOfBoundsException e) {
			log.i("getItemId");
			// TODO: handle exception
			return i;
		}
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup viewGroup) {
		try {
			View viewItem1 = null;
			View viewItem2 = null;
			BitmapUtils bitmapUtils = new BitmapUtils(mContext);
			int itemType = this.getItemViewType(position);
			if(itemType == 1){
				//兑换中心
				ViewHolder1 viewHolder1 = null;
				if(convertView == null){
					//没有缓存
					viewHolder1 = new ViewHolder1();
					viewItem1 = this.mInflater.inflate(R.layout.near_lv_filiale, null, false);
					// 地址
					viewHolder1.filiale_address = (TextView)viewItem1.findViewById(R.id.
							filiale_address);
					// 图片
					viewHolder1.filiale_iv_prize = (ImageView)viewItem1.findViewById(R.id.
							filiale_iv_prize);
					// 距离
					viewHolder1.filiale_distance = (TextView)viewItem1.findViewById(R.id.
							filiale_distance);
					// 兑换处名称
					viewHolder1.filiale_name = (TextView)viewItem1.findViewById(R.id.
							filiale_name);
					// 电话
					viewHolder1.filiale_tel = (TextView)viewItem1.findViewById(R.id.
							filiale_tel);
					// 到这去
					viewHolder1.filiale_to = (TextView)viewItem1.findViewById(R.id.
							filiale_to);


					viewItem1.setTag(viewHolder1);
					convertView = viewItem1;
				}else{
					viewHolder1 = (ViewHolder1)convertView.getTag();
				}

				viewHolder1.filiale_address.setText(((NearDataFiliale)mData.get(position)).getFilialeList().getShop_address());
				viewHolder1.filiale_name.setText(((NearDataFiliale)mData.get(position)).getFilialeList().getShop_name());
				bitmapUtils.display(viewHolder1.filiale_iv_prize,
						"http://cdn.image.huyongle.com/"+((NearDataFiliale)mData.get(position)).getFilialeList().getShop_image());
				String latitude = ((NearDataFiliale)mData.get(position)).getFilialeList().getShop_latitude();
				String longitude = ((NearDataFiliale)mData.get(position)).getFilialeList().getShop_longitude();
				LatLng latLng1 = new LatLng(Float.parseFloat(latitude),Float.parseFloat(longitude));
				LatLng latLng2 = new LatLng(((LeFenMallApplication)mContext.getApplicationContext()).getLatitude(),
						((LeFenMallApplication)mContext.getApplicationContext()).getLongitude());
				if (((LeFenMallApplication)mContext.getApplicationContext()).getLatitude() == 0.0) {
					viewHolder1.filiale_distance.setText("距离计算失败");
				}{
					viewHolder1.filiale_distance.setText("距离 "+new DecimalFormat("0.0").format(DistanceUtil.getDistance(latLng1, latLng2)/1000)+"Km");
				}
				/**
				 * 到这去
				 */
				viewHolder1.filiale_to.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(mContext,
								MerchantActivity.class);
						intent.putExtra("latitude", ((NearDataFiliale)mData.get(position)).getFilialeList().getShop_latitude());
						intent.putExtra("longitude",((NearDataFiliale)mData.get(position)).getFilialeList().getShop_longitude());
						mContext.startActivity(intent);
					}
				});

				/**
				 * 打电话
				 */
				viewHolder1.filiale_tel.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// 获取电话，判断电话号码是否存在。
						String tel = ((NearDataFiliale)mData.get(position)).getFilialeList().getShop_tel();
						if (tel.length()>7) {
							Intent intent = new Intent(Intent.ACTION_DIAL,
									Uri.parse("tel:"+tel));  
							mContext.startActivity(intent);
						} else {
							Toast.makeText(mContext, "没有电话号码~", Toast.LENGTH_SHORT).show();
						}
					}
				});

			}else if(itemType == 2){
				//第二种item
				ViewHolder2 viewHolder2 = null;
				if(convertView == null){
					//没有缓存
					viewHolder2 = new ViewHolder2();
					viewItem2 = this.mInflater.inflate(R.layout.near_lv_merchant, null, false);
					// 商店地址
					viewHolder2.merchant_address = (TextView)viewItem2.findViewById(R.id.
							merchant_address);
					// 图片
					viewHolder2.merchant_iv_prize = (ImageView)viewItem2.findViewById(R.id.
							merchant_iv_prize);
					// 评分
					viewHolder2.merchant_ratingBar = (RatingBar) viewItem2.findViewById(R.id.
							merchant_ratingBar);
					viewHolder2.tv_graded = (TextView) viewItem2.findViewById(R.id.tv_graded);
					// 距离
					viewHolder2.merchant_distance = (TextView)viewItem2.findViewById(R.id.
							merchant_distance);
					// 名称
					viewHolder2.merchant_name = (TextView)viewItem2.findViewById(R.id.
							merchant_name);
					// 送积分
					viewHolder2.merchant_songjifen = (TextView)viewItem2.findViewById(R.id.tv_songjifen);
					viewItem2.setTag(viewHolder2);
					convertView = viewItem2;
				}else{
					viewHolder2 = (ViewHolder2)convertView.getTag();
				}

				viewHolder2.merchant_songjifen.setText(((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_percent()+"%乐分");
				viewHolder2.merchant_name.setText(((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_name());
				viewHolder2.merchant_address.setText(((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_address());
				viewHolder2.merchant_ratingBar.setRating(Float.parseFloat(((NearDataMerchant)mData.get(position)).getMerchantList().getGraded()));
				
				String grand = ((NearDataMerchant)mData.get(position)).getMerchantList().getGraded();
				String grand1 = grand.subSequence(0, 1)+"."+grand.substring(1);
				viewHolder2.tv_graded.setText(grand1+"分");
				
				bitmapUtils.display(viewHolder2.merchant_iv_prize,
						"http://cdn.image.huyongle.com/"+((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_image());
				String latitude = ((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_latitude();
				String longitude = ((NearDataMerchant)mData.get(position)).getMerchantList().getMerchant_longitude();
				LatLng latLng1 = new LatLng(Float.parseFloat(latitude),Float.parseFloat(longitude));
				LatLng latLng2 = new LatLng(((LeFenMallApplication)mContext.getApplicationContext()).getLatitude(),
						((LeFenMallApplication)mContext.getApplicationContext()).getLongitude());
				if (((LeFenMallApplication)mContext.getApplicationContext()).getLatitude() == 0.0) {
					viewHolder2.merchant_distance.setText("距离计算失败");
				}{
					viewHolder2.merchant_distance.setText(new DecimalFormat("0.0").format(DistanceUtil.getDistance(latLng1, latLng2)/1000)+"Km");
				}
				
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
		}
		return convertView;
	}

	class ViewHolder1 {
		public ImageView filiale_iv_prize = null;
		public TextView filiale_name = null;
		public TextView filiale_address = null;
		public TextView filiale_distance = null;
		public TextView filiale_to = null;
		public TextView filiale_tel = null;

	}

	class ViewHolder2 {
		public ImageView merchant_iv_prize = null;
		public TextView merchant_name = null;
		public RatingBar merchant_ratingBar = null;
		public TextView merchant_address = null;
		public TextView merchant_distance = null;
		public TextView merchant_songjifen = null;
		public TextView tv_graded = null;
	}

}

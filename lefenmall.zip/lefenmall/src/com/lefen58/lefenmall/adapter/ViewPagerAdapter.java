package com.lefen58.lefenmall.adapter;

import java.util.ArrayList;

import com.lefen58.lefenmall.utils.LogUtil;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;

public class ViewPagerAdapter extends PagerAdapter {

	private ArrayList<String> list;
	private ImageView []imgs;
	LogUtil Log = LogUtil.lLog();

	public ViewPagerAdapter(ImageView[] imageViews, ArrayList<String> list) {
		this.imgs = imageViews;
		this.list = list;
	}

	@Override
	public int getCount() {
		return Integer.MAX_VALUE;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		ViewGroup.LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		container.addView(imgs[position%imgs.length],params);
		return imgs[position%imgs.length];
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		container.removeView(imgs[position%imgs.length]);
	}
}

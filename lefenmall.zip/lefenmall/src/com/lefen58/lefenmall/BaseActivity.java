package com.lefen58.lefenmall;

import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.widgets.MyLoading;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

public class BaseActivity extends Activity {

	public SharedPreferences sp;
	private MyLoading myloading;
	public Context context;
	public LogUtil log;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//		//透明状态栏
		//		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		//		//透明导航栏
		//		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		AppManager.getInstance().addActivity(this);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		sp = getSharedPreferences("UserInfor", 0);
		context = this;
		log = LogUtil.lLog();

	}
	public String getToken(){
		Long token = Long.valueOf(sp.getString("token", "0"))+Long.valueOf(sp.getString("server_salt", "0"));
		return String.valueOf(token);
	}
	
	/**
	 * 判断是否登录
	 */
	public boolean isLogin() {
		return sp.getBoolean("state", false);
	}

	public void onBack(View v){
		finish();
	}

	public void rightTextview(View v){
	}
	
	/**
	 * dialog 启动
	 */
	public void startMyDialog(){
		if (myloading == null){
			myloading = MyLoading.createLoadingDialog(context);
		}
		myloading.show();
	}
	/**
	 * dialog 销毁
	 */
	public void stopMyDialog(){
		if (myloading != null){
			myloading.dismiss();
			myloading = null;
		}
	}
	
	public void showToast(String msg) {
		Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();;
	}
	
	public void showToast(int strId) {
		Toast.makeText(context, strId, Toast.LENGTH_SHORT).show();;
	}
}

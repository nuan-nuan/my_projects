package com.lefen58.lefenmall.image;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.http.Header;

import com.google.gson.Gson;
import com.google.zxing.common.BitMatrix;
import com.lefen58.lefenmall.BaseActivity;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Upload_image_data;
import com.lefen58.lefenmall.utils.CommonUtils;
import com.lefen58.lefenmall.utils.LogUtil;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Environment;
import android.widget.Toast;

public class ImageUtils {

	public static final String TAG = "ImageUtils=======";
	
	static LogUtil Log = LogUtil.lLog();

	/**
	 * 根据宽度等比例缩放图片
	 * 
	 * @param defaultBitmap
	 * @param width
	 * @return
	 */
	public static Bitmap resizeImageByWidth(Bitmap defaultBitmap,
			int targetWidth) {
		int rawWidth = defaultBitmap.getWidth();
		int rawHeight = defaultBitmap.getHeight();
		float targetHeight = targetWidth * (float) rawHeight / (float) rawWidth;
		float scaleWidth = targetWidth / (float) rawWidth;
		float scaleHeight = targetHeight / (float) rawHeight;
		Matrix localMatrix = new Matrix();
		localMatrix.postScale(scaleHeight, scaleWidth);
		return Bitmap.createBitmap(defaultBitmap, 0, 0, rawWidth, rawHeight,
				localMatrix, true);
	}

	/**
	 * 上传图片
	 * @param context 上下文
	 * @param Data 图片数据（base64位）
	 * @param imageRole 类型
	 * @param imageName 名称
	 * @param myloading 过渡的dialog
	 * @return 是否上传成功
	 */
	public static void uploadImage(final Context context,String Data,
			final String imageRole,String imageName
			){
		HttpUtils http = new HttpUtils();
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "upload_image_data");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(context));
		params.addBodyParameter("token", RequestOftenKey.getToken(context));
		params.addBodyParameter("image_data", Data);
		params.addBodyParameter("image_size", Data.length()+"");
		params.addBodyParameter("image_role", imageRole);
		params.addBodyParameter("image_type", "image/png");
		params.addBodyParameter("image_name", imageName);
		http.send(HttpMethod.POST, Ip.url+"account.php",
				params, new RequestCallBack<String>(){

			@Override
			public void onFailure(HttpException arg0, String arg1) {
				Toast.makeText(context, "上传失败", Toast.LENGTH_SHORT).show();
				Log.i("infor"+arg0.getExceptionCode()+"--"+arg1);
				((BaseActivity) context).stopMyDialog();
			}

			@Override
			public void onSuccess(ResponseInfo<String> arg0) {
				Log.i(arg0.result);
				((BaseActivity) context).stopMyDialog();
				Upload_image_data upload_image_data = 
						new Gson().fromJson(arg0.result, Upload_image_data.class);
				if (CommonUtils.NetworkRequestReturnCode(context, upload_image_data.getCode())) {
					if (imageRole.equals("head")) {
						context.getSharedPreferences("UserInfor", 0).edit().putString("photo", upload_image_data.getFilename());
					}
					Toast.makeText(context, "上传成功", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	/**
	 *  获取本地图片
	 * @param name 文件名称
	 * @return bitmap
	 */
	public static Bitmap getLoacalBitmap(String path,String name) {
		try {
			File f = new File(path);
			FileInputStream fis = new FileInputStream(path + name);
			return BitmapFactory.decodeStream(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 *  获取网络图片，并保存
	 */
	public static void getNetworkBitmap(String url,final String path,final String bitmapName){
		AsyncHttpClient client= new AsyncHttpClient();
		client.get(url, new AsyncHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
				if (statusCode == 200) {
					//创建工厂对象
					BitmapFactory bitmapFactory = new BitmapFactory();
					//工厂对象的decodeByteArray把字节转换成Bitmap对象
					Bitmap bitmap = bitmapFactory.decodeByteArray(responseBody, 0, responseBody.length);
					File f = new File(Environment.getExternalStorageDirectory() + path);
					if (!f.exists()) {
						f.mkdirs();
					}
					File img = new File(f.getAbsolutePath() + "/"+bitmapName);
					try {
						FileOutputStream out = new FileOutputStream(img);
						bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
						out.flush();
						out.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers,
					byte[] responseBody, Throwable error) {
				error.printStackTrace();
			}
		});

	}
	
	/**
	 * 把bitmap保存到本地
	 */
	public void saveBitmap(Bitmap bitmap,String url){


	}


	/**
	 * 生成条形码（一维码）
	 * @param byteMatrix
	 * @return
	 */
	public static Bitmap toBitmap(BitMatrix byteMatrix) { 
		// 定义位图的宽和高 
		int width = byteMatrix.getWidth(); 
		int height = byteMatrix.getHeight(); 
		int[] pixels = new int[width * height];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				if (byteMatrix.get(x, y)) {
					pixels[y * width + x] = 0xff000000;
				}
			}
		}
		Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		// 通过像素数组生成bitmap,具体参考api
		bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
		return bitmap;  
	} 


}

package com.lefen58.lefenmall.http;

import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lefen58.lefenmall.entity.BaseEntity;
import com.lefen58.lefenmall.entity.ClassifyList;
import com.lefen58.lefenmall.entity.GoodsCollectList;
import com.lefen58.lefenmall.entity.GoodsList;
import com.lefen58.lefenmall.entity.MallGoodsInfo;
import com.lefen58.lefenmall.entity.TopClassifyList;
import com.lefen58.lefenmall.entity.GetGoodInfoResult;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

public class MallNetRequest extends BaseNetRequest {
	
	
	private static final String URL=Ip.url+"mall.php";

	public MallNetRequest(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**	
	 * 获取商品一级分类列表
	 * @param callBack
	 */
	public void getMallTopClass(Class<TopClassifyList> cls,RequestCallBack<TopClassifyList> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "top_classify_list");
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取一级分类下的二级分类和三级分类列表
	 * @param  calssify_id 一级分类ID
	 * @param cls
	 * @param callBack
	 */
	public void getMallTwoClass(String calssifyId,Class<ClassifyList> cls,RequestCallBack<ClassifyList> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "classify_list");
		params.addBodyParameter("classify_id", calssifyId);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取二级分类或三级分类下的商品列表
	 * @param calssify_id 二级或三级分类ID
	 * @param cls
	 * @param callBack
	 */
	public void getMallGoodsList(String classifyId,Class<GoodsList> cls,RequestCallBack<GoodsList> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "goods_list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("classify_id", classifyId);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 搜索商品
	 * @param keyword 关键字
	 * @param cls
	 * @param callBack
	 */
	public void getSearchGoodsList(String keyword,Class<GoodsList> cls,RequestCallBack<GoodsList> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "search_list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("keyword", keyword);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取商品详情
	 * @param goods_id 商品id
	 * @param code 验证码
	 */
	public void getGoodsInfo(String goodsId,Class<GetGoodInfoResult> cls,RequestCallBack<GetGoodInfoResult> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "goods_info");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		params.addBodyParameter("goods_id", goodsId);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 收藏商品
	 * @param deviceIndex 设备编号
	 * @param token 用户登录凭证
	 * @param goodsId 商品id
	 * @param cls
	 * @param callBack
	 */
	public void goodsCollect(String deviceIndex,String token,String goodsId,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack){
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "goods_collect_add");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		params.addBodyParameter("goods_id", goodsId);
		postRequest(URL, params, cls, callBack);
	}
	/**
	 * 取消收藏商品
	 * @param deviceIndex 设备编号
	 * @param token 用户登录凭证
	 * @param goodsId 商品id
	 * @param cls
	 * @param callBack
	 */
	public void goodsCancelCollect(String deviceIndex,String token,String goodsId,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack){
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "goods_collect_cancel");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("goods_id", goodsId);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 用户商品收藏列表
	 * @param deviceIndex 设备编号
	 * @param cls
	 * @param callBack
	 */
	public void getGoodsCollectList(String deviceIndex,Class<GoodsCollectList> cls,RequestCallBack<GoodsCollectList> callBack){
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "goods_collect_list");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		postRequest(URL, params, cls, callBack);
	}

	
}

package com.lefen58.lefenmall.http;

import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.GetActivityInfoResult;
import com.lefen58.lefenmall.entity.ShakeResult;
import com.lefen58.lefenmall.entity.TurnTablePrize;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

/**
 * 活动相关请求
 * 
 * @author Administrator
 *
 */
public class ActivityNetRequest extends BaseNetRequest {
	
	private static final String URL=Ip.url + "activity.php";

	public ActivityNetRequest(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 获取活动详细信息
	 * @param deviceIndex
	 *            设备编号
	 * @param activityIndex
	 *            活动id
	 * @param cls
	 * @param callBack
	 */
	public void getActivityInfo(String deviceIndex, String activityIndex, Class<GetActivityInfoResult> cls,
			RequestCallBack<GetActivityInfoResult> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "details");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("activity_index", activityIndex);

		postRequest(URL, params, cls, callBack);
	}

	/**
	 * 参加摇一摇活动
	 * 
	 * @param deviceIndex 设备编号
	 * @param activityIndex 活动id
	 * @param cls
	 * @param callBack
	 */
	public void getShakeActivityResult(String deviceIndex, String activityIndex,
			Class<ShakeResult> cls, RequestCallBack<ShakeResult> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "shake");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		params.addBodyParameter("activity_index", activityIndex);
		
		postRequest(URL, params, cls, callBack);
	}
	
	
	/**
	 * 参加大转盘活动
	 * @param deviceIndex 设备编号
	 * @param activityIndex 活动id
	 * @param cls
	 * @param callBack
	 */
	public void getTurnTableActivityResult(String deviceIndex, String activityIndex,Class<TurnTablePrize> cls,RequestCallBack<TurnTablePrize> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "turntable");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		params.addBodyParameter("activity_index", activityIndex);
		
		postRequest(URL, params, cls, callBack);
	}
}

package com.lefen58.lefenmall.http;

import com.baidu.android.common.logging.Log;
import com.google.gson.JsonObject;
import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.BaseEntity;
import com.lefen58.lefenmall.entity.Get_SMS_code;
import com.lefen58.lefenmall.entity.ObtainIntegral;
import com.lefen58.lefenmall.entity.RegisterAccount;
import com.lefen58.lefenmall.entity.RegisterDevice;
import com.lefen58.lefenmall.entity.Start_app;
import com.lefen58.lefenmall.entity.Submit_card_info;
import com.lefen58.lefenmall.entity.Upload_image_data;
import com.lefen58.lefenmall.entity.User_info;
import com.lefen58.lefenmall.utils.PhoneInfor;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

public class AccountNetRequest extends BaseNetRequest {
	
	
	private static final String URL=Ip.url+"account.php";

	public AccountNetRequest(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * app每次启动时调用
	 * @param gapTime 本次启动间隔时间（当前时间-上次退出时间,单位：秒）
	 * @param osType //设备操作系统类型,0代表安卓，1代表IOS
	 * @param deviceIndex 客户端运行设备唯一自增编号
	 * @param token （token+gap_time做数学运算）（没有登录可以没有或值为空字符串）
	 * @param pushId 客户端当前的推送id
	 * @param callBack
	 */
	public void appStart(String gapTime,String pushId,Class<Start_app> cls,RequestCallBack<Start_app> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "start_app");
		params.addBodyParameter("os_type", "0");
		params.addBodyParameter("device_index",RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("device_token","0");
		params.addBodyParameter("token",RequestOftenKey.gettoken(mContext));
		params.addBodyParameter("push_id",pushId);
		params.addBodyParameter("gap_time",gapTime);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 新设备注册
	 * @param scrWidth 屏幕宽度
	 * @param scrHeight 屏幕高度
	 * @param cls
	 * @param callBack
	 */
	public void registerDevice(int scrWidth,int scrHeight, Class<RegisterDevice> cls,RequestCallBack<RegisterDevice> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "register_new_device");
		params.addBodyParameter("uuid", PhoneInfor.getIMEI(mContext));
		params.addBodyParameter("os_type", "0");
		params.addBodyParameter("os_version", PhoneInfor.getOSVersion());
		params.addBodyParameter("screen_size", "0");
		params.addBodyParameter("screen_dpi", scrWidth+"×"+scrHeight);
		params.addBodyParameter("device_brand", PhoneInfor.getDeviceBrand());
		params.addBodyParameter("device_model", PhoneInfor.getDeviceModel());
		params.addBodyParameter("device_cpu", "0");
		params.addBodyParameter("device_ram", String.valueOf((PhoneInfor.getTotalMemory(mContext)/1000/1000/1000+1)));
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取手机短信验证码
	 * @param phone 用户填写的手机号
	 * @param verifyType 请求验证码的类型，0表示注册验证，1表示快捷登录验证，2表示帐号操作安全验证
	 * @param deviceIndex 客户端运行设备编号
	 * @param cls
	 * @param callBack
	 */
	public void getSmsVerifyCode(String phone,int verifyType,String deviceIndex,Class<Get_SMS_code> cls,RequestCallBack<Get_SMS_code> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "get_SMS_code");
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("verify_type", Integer.toString(verifyType));
		params.addBodyParameter("device_index", deviceIndex);
		
		postRequest(URL, params, cls, callBack);
	}
	/**
	 * 验证短信验证码
	 * @param phone 手机号
	 * @param code 验证码
	 */
	public void checkSmsVerifyCode(String phone,String code,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "verify_SMS_code");
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("SMS_code", code);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 注册时验证短信码并注册帐号
	 * @param phone 用户填写的手机号
	 * @param code 用户填写的短信验证码
	 * @param pwd 用户设置的登录密码(16位md5值+SMS_code的md5值=伪装成32位md5值)
	 * @param deviceIndex 设备编号
	 * @param cls
	 * @param callBack
	 */
	public void registerAccoiunt(String phone,String code,String pwd,Class<RegisterAccount> cls,RequestCallBack<RegisterAccount> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "register_account");
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("SMS_code", code);
		params.addBodyParameter("login_password", pwd);
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 用户登陆
	 * @param account 用户要登录的帐号（手机号）
	 * @param pwd 用户填写的登录密码(16位md5值+盐的16位md5值=伪装成32位md5值)
	 * @param cls
	 * @param callBack
	 */
	public void login(String account,String pwd,Class<RegisterAccount> cls,RequestCallBack<RegisterAccount> callBack) {
		
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "login_by_password");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("account", account);
		params.addBodyParameter("login_password", pwd);
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 快捷登录（先通过接口获取短信）
	 * @param phone 用户填写的手机号
	 * @param code 用户填写的短信验证码
	 * @param deviceIndex 设备编号
	 * @param cls
	 * @param callBack
	 */
	public void quickLogin(String phone,String code,Class<RegisterAccount> cls,RequestCallBack<RegisterAccount> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "login_by_quick");
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("SMS_code", code);
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		
		postRequest(URL, params, cls, callBack);
	}
	
	/** 
	 * 重设登陆密码（先通过验证短信验证码接口）
	 * @param account 要找回密码的帐号（手机号）
	 * @param newPwd 用户输入的新的登录密码(16位md5值+SMS_code的16位值=32位md5值)
	 * @param cls
	 * @param callBack
	 */
	public void resetLoginPwd(String account,String newPwd,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "reset_login_password_ios");
		params.addBodyParameter("account", account);
		params.addBodyParameter("login_password", newPwd);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 修改登录密码
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端当前登录凭证(token+盐做数学运算)
	 * @param oldPwd 旧登录密码（16位md5值）
	 * @param newPwd 新登录密码（16位md5值+盐的16位md5)
	 * @param cls
	 * @param callBack
	 */
	public void modifyLoginPwd(String deviceIndex,String token,String oldPwd,String newPwd,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "amend_login_password");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("old_login_password", oldPwd);
		params.addBodyParameter("new_login_password", newPwd);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 初次设置(或重设)支付密码(先通过短信验证接口)
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端登录凭证(token值+盐做数学运算)
	 * @param newPwd 用户输入的新的登录密码(16位md5值+盐的16位md5值)
	 * @param cls
	 * @param callBack
	 */
	public void resetPayPwd(String deviceIndex,String token,String newPwd,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "reset_pay_password_ios");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("new_pay_password", newPwd);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 修改支付密码(通过旧支付密码)
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端登录凭证(token值+盐做数学运算)
	 * @param oldPwd 旧支付密码(16位md5值+盐的16位md5值)
	 * @param newPwd 用户输入的新的登录密码(16位md5值+盐的16位md5值)
	 * @param cls
	 * @param callBack
	 */
	public void modifyPayPwd(String deviceIndex,String token,String oldPwd,String newPwd,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "amend_pay_password");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("old_pay_password", oldPwd);
		params.addBodyParameter("new_pay_password", newPwd);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 退出登录
	 * @param deviceIndex
	 * @param token
	 * @param cls
	 * @param callBack
	 */
	public void LogOut(String deviceIndex,String token,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "login_out");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 设置用户资料
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端登录凭证(token值+盐做数学运算)
	 * @param info 用户信息实例(不需要修改或设置的字段可以不存在)
	 * @param cls
	 * @param callBack
	 */
	public void setUserInfo(String deviceIndex,String token,User_info info,Class<BaseEntity> cls,RequestCallBack<BaseEntity> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "set_user_info");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		JsonObject jsonObject=new JsonObject();
		jsonObject.addProperty("name", info.getName());
		jsonObject.addProperty("province", info.getProvince());
		jsonObject.addProperty("city", info.getCity());
		jsonObject.addProperty("district", info.getDistrict());
		jsonObject.addProperty("address", info.getAddress());
		jsonObject.addProperty("intro", info.getIntro());
		jsonObject.addProperty("sex", info.getSex());
		jsonObject.addProperty("birthday", info.getBirthday());
		params.addBodyParameter("user_info", jsonObject.toString());
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取用户资料
	 * @param deviceIndex
	 * @param token
	 * @param cls
	 * @param callBack
	 */
	public void getUserInfo(String deviceIndex,String token,Class<User_info> cls,RequestCallBack<User_info> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "get_user_info");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 上传用户头像(POST上传用户头像)
	 * @param deviceIndex
	 * @param token
	 * @param file 头像图片文件内容
	 * @param cls
	 * @param callBack
	 */
	public void uploadUserIcon(String deviceIndex,String token,String file,Class<Upload_image_data> cls,RequestCallBack<Upload_image_data> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "get_user_info");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("file", file);
		
		postRequest(URL, params, cls, callBack);
	}
	
	public void checkIDNumber() {
		
	}
	
	/**
	 * 提交身份证信息
	 * @param cardId 身份证号
	 * @param cardName 真实姓名
	 * @param cardValidity 有效期（时间戳，单位：秒）
	 * @param cardType 身份证类型，0临时，1正式
	 * @param cls
	 * @param callBack
	 */
	public void submitIDCardInfo(String cardId,String cardName,String cardValidity,String cardType,Class<Submit_card_info> cls,RequestCallBack<Submit_card_info> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "submit_card_info");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("token", RequestOftenKey.getToken(mContext));
		params.addBodyParameter("card_id", cardId);
		params.addBodyParameter("card_name", cardName);
		params.addBodyParameter("card_validity", cardValidity);
		params.addBodyParameter("card_type", cardType);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 提交身份证正面照片
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端登录凭证(token值+盐做数学运算)
	 * @param file 头像图片文件内容
	 * @param cls
	 * @param callBack
	 */
	public void submitIDCardFrontImage(String deviceIndex,String token,String file,Class<Upload_image_data> cls,RequestCallBack<Upload_image_data> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "upload_card_front_image");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("file", file);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 提交身份证反面照片
	 * @param deviceIndex 客户端运行设备的唯一自增编号
	 * @param token 客户端登录凭证(token值+盐做数学运算)
	 * @param file 头像图片文件内容
	 * @param cls
	 * @param callBack
	 */
	public void submitIDCardBackImage(String deviceIndex,String token,String file,Class<Upload_image_data> cls,RequestCallBack<Upload_image_data> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "upload_card_reverse_image");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("file", file);
		
		postRequest(URL, params, cls, callBack);
	}
	
	public void getIDCardInfo(String deviceIndex,String token) {
		
	}
	
	/**
	 * base64方式上传图片
	 * @param deviceIndex
	 * @param token
	 * @param imgRole 图片的作用（head：头像，card_front：身份证正面，card_reverse：身份证背面）
	 * @param imgName 图片名字，包括后缀名
	 * @param imgType 图片类型（image/png、image/jpeg、image/gif）
	 * @param imgSize 图片数据长度（image_data字段值的长度）
	 * @param imgData 图片数据base64编码
	 * @param cls
	 * @param callBack
	 */
	public void uploadBase64Image(String deviceIndex,String token,String imgRole,String imgName,String imgType,String imgSize,String imgData,Class<Upload_image_data> cls,RequestCallBack<Upload_image_data> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "upload_image_data");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("image_role", imgRole);
		params.addBodyParameter("image_name", imgName);
		params.addBodyParameter("image_type", imgType);
		params.addBodyParameter("image_data", imgSize);
		params.addBodyParameter("image_data", imgData);
		
		postRequest(URL, params, cls, callBack);
	}
	
	/**
	 * 获取用户积分余额
	 * @param deviceIndex
	 * @param token
	 * @param cls
	 * @param callBack
	 */
	public void getIntegralBalance(String deviceIndex,String token,Class<ObtainIntegral> cls,RequestCallBack<ObtainIntegral> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "get_integral_balance");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		
		postRequest(URL, params, cls, callBack);
	}
}

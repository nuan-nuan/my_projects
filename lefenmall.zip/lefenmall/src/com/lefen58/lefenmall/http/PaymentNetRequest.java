package com.lefen58.lefenmall.http;

import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.Payment;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

/**
 * 支付相关请求
 * @author Administrator
 *
 */
public class PaymentNetRequest extends BaseNetRequest {
	public static final String URL=Ip.url+"payment.php";

	public PaymentNetRequest(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 积分支付请求
	 * @param deviceIndex
	 * @param token
	 * @param orderId 要支付的订单编号
	 * @param payPwd 用户支付密码(16位md5值+盐的16位md5值)
	 * @param cls
	 * @param callBack
	 */
	public void scorePay(String deviceIndex,String token,String orderId,String payPwd,Class<Payment> cls,RequestCallBack<Payment> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("token", token);
		params.addBodyParameter("order_id", orderId);
		params.addBodyParameter("pay_pwd", payPwd);
		
		postRequest(URL, params, cls, callBack);
	}
	
}

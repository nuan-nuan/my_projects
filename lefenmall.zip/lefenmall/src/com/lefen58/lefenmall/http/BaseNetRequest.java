package com.lefen58.lefenmall.http;

import com.lefen58.lefenmall.utils.LefenHttpUtils;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

public class BaseNetRequest {

	private static final String TAG = "BaseNetRequest";
	protected Context mContext;
	
	public BaseNetRequest(Context context) {
		super();
		this.mContext = context;
	}

	/**
	 * 共用的get请求。
	 */
	protected <T>  void getRequest(String url ,RequestParams params,Class<T> cls,RequestCallBack<T> callBack){
		LefenHttpUtils.get(mContext, cls, url, null, params, callBack);
	}
	
	/**
	 * 共用的post请求。
	 */
	protected <T> void postRequest(String url ,RequestParams params,Class<T> cls,RequestCallBack<T> callBack){
		LefenHttpUtils.post(mContext, cls, url, null, params, callBack);
	}
}

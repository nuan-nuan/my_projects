package com.lefen58.lefenmall.http;

import com.lefen58.lefenmall.config.Ip;
import com.lefen58.lefenmall.entity.NearDetails;
import com.lefen58.lefenmall.entity.Search;
import com.lefen58.lefenmall.entity.StoreAllList;
import com.lefen58.lefenmall.utils.RequestOftenKey;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.content.Context;

public class NearbyNetRequest extends BaseNetRequest {
	public static final String URL=Ip.url+"nearby.php";

	public NearbyNetRequest(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 获取附近商家列表
	 * @param page 页码，默认0
	 * @param industryTop 联盟商家行业顶级分类，默认0表示全部分类
	 * @param industrySon /联盟商家行业二级分类，默认0
	 * @param type 商家类型0表示全部，1表示仅联盟商家，2表示仅兑换中心
	 * @param city 用户定位城市ID，必须是具体的城市ID
	 * @param county 用户定位区县id,默认0
	 * @param callBack
	 */
	public void getNearbyMerchantList(int page,String industryTop,String industrySon,String type,String city,String county,RequestCallBack<StoreAllList> callBack) {
		RequestParams params=new RequestParams();
		params.addBodyParameter("c", "list");
		params.addBodyParameter("device_index", RequestOftenKey.getDeviceIndex(mContext));
		params.addBodyParameter("industry_top", industryTop);
		params.addBodyParameter("industry_son", industrySon);
		params.addBodyParameter("page", Integer.toString(page));
		params.addBodyParameter("type", type);
		params.addBodyParameter("county", county);
		params.addBodyParameter("city", city);
		
		postRequest(URL, params,StoreAllList.class, callBack);
	}
	
	/**
	 * 搜索附件商家
	 * @param deviceIndex
	 * @param city 用户定位城市ID，必须是具体的城市ID
	 * @param county 用户定位区县id,默认0
	 * @param keyword 关键字
	 * @param cls
	 * @param callBack
	 */
	public void searchNearbyMerchants(String deviceIndex,String city,String county,String keyword,Class<Search> cls,RequestCallBack<Search> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "search");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("city", city);
		params.addBodyParameter("county", county);
		params.addBodyParameter("keyword", keyword);
		
		postRequest(URL, params,cls, callBack);
	}
	
	/**
	 * 获取商家详细资料
	 * @param deviceIndex
	 * @param merchantType 1代表联盟商家，2代表兑换中心
	 * @param merchantId merchant_type为1时代表联盟商家id，为2时代表兑换中心门面id
	 * @param cls
	 * @param callBack
	 */
	public void getMerchantDetails(String deviceIndex,int merchantType,String merchantId,Class<NearDetails> cls,RequestCallBack<NearDetails> callBack) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("c", "details");
		params.addBodyParameter("device_index", deviceIndex);
		params.addBodyParameter("merchant_type", Integer.toString(merchantType));
		params.addBodyParameter("merchant_id", merchantId);
		
		postRequest(URL, params,cls, callBack);
	}
}

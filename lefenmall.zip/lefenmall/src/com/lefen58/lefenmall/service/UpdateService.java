package com.lefen58.lefenmall.service;

import java.io.File;

import com.lefen58.lefenmall.R;
import com.lefen58.lefenmall.config.Constants;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.widget.RemoteViews;
import android.widget.Toast;

public class UpdateService extends Service {
	
	private static final int NOTIFICATION_ID=9999;
	
	private NotificationManager mNotificationManager;
	private Notification mNotification;
	private HttpUtils mHttpUtils;
	private String mUrl;
	private boolean isDownloading=false;
	

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mUrl="http://lefen58.huyongle.com/app/downAndroid.php";
//		mUrl="http://res.yimi.dkimg.cn/huyu/imageServer/resource/20150828/c76b5d9b-3b74-436e-af6d-b6187074d62e.apk";
		initNotification();
	}



	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		if (!isDownloading) {
			downLoad();
			isDownloading=true;
		}
		Toast.makeText(this, "正在下载更新", Toast.LENGTH_LONG).show();
		return super.onStartCommand(intent, flags, startId);
	}

	private void initNotification() {
		mNotificationManager=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		mNotification=new Notification();
		mNotification.icon=R.drawable.logo;
//		mNotification.largeIcon=BitmapFactory.decodeResource(getResources(), R.drawable.logo);
		mNotification.tickerText="乐分商城已经开始下载";
		
		RemoteViews rv=new RemoteViews(getPackageName(), R.layout.download_update_notification);
		rv.setImageViewResource(R.id.imgViewIcon, R.drawable.logo);
		rv.setTextViewText(R.id.txt_notice, getString(R.string.download_update_notification_text, "0%"));
		rv.setProgressBar(R.id.progBar, 100, 10, false);
		mNotification.contentView =rv;
		
		Intent i=new Intent();
		i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		PendingIntent pendingIntent=PendingIntent.getActivity(this, 0, i, 0);
		mNotification.contentIntent=pendingIntent;
		mNotificationManager.notify(NOTIFICATION_ID, mNotification);
		
	}
	
	private void downLoad() {
		if (mHttpUtils==null) {
			mHttpUtils=new HttpUtils();
		}
		if (!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
			Toast.makeText(this, "SD卡不可用", Toast.LENGTH_LONG).show();
			return;
		}
		final String filePath=Environment.getExternalStorageDirectory()+Constants.BASE_PATH+"lefenmall.apk";
//		File dir=new File(filePath);
//		if (!dir.exists()||!dir.isDirectory()) {
//			dir.mkdir();
//		}
		
		mHttpUtils.download(mUrl, filePath,false, false, new RequestCallBack<File>() {
			RemoteViews rv=mNotification.contentView;
			@Override
			public void onLoading(long total, long current, boolean isUploading) {
				// TODO Auto-generated method stub
				int progress=(int) (current*100/total);
				rv.setTextViewText(R.id.txt_notice, getString(R.string.download_update_notification_text, progress+"%"));
				rv.setProgressBar(R.id.progBar, 100, progress, false);
				mNotificationManager.notify(NOTIFICATION_ID, mNotification);
			}

			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
			}

			@Override
			public void onSuccess(ResponseInfo<File> arg0) {
				// TODO Auto-generated method stub
				Uri uri=Uri.fromFile(new File(filePath));
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(uri,
						"application/vnd.android.package-archive");
				PendingIntent pendingIntent = PendingIntent.getActivity(UpdateService.this, 0,
						intent, 0);
				mNotification.contentIntent=pendingIntent;
				mNotification.tickerText="乐分商城已经下载完成";
				mNotification.contentView.setTextViewText(R.id.txt_notice, "乐分商城下载完成，点击安装");
				mNotificationManager.notify(NOTIFICATION_ID, mNotification);
				isDownloading=false;
				UpdateService.this.stopSelf();
			}
			
			@Override
			public void onFailure(HttpException arg0, String arg1) {
				// TODO Auto-generated method stub
				isDownloading=false;
				Toast.makeText(UpdateService.this, "下载失败"+arg1, Toast.LENGTH_LONG).show();
				mNotification.tickerText="乐分商城失败";
				mNotification.contentView.setTextViewText(R.id.txt_notice, "乐分商城下载失败，请检查网络");
				mNotificationManager.notify(NOTIFICATION_ID, mNotification);
				isDownloading=false;
				UpdateService.this.stopSelf();
			}
		});
	}
}

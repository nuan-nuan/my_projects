package com.lefen58.lefenmall.config;

import java.io.File;

import android.os.Environment;

public class Constants {
	/**
	 ******************************************* 参数设置信息开始 ******************************************
	 */

	// 应用名称
	public static String APP_NAME = "";

	
	// 保存参数文件夹名称
	public static final String SHARED_PREFERENCE_NAME = "tc_jingdong_prefs";
	
	/** sp key-下拉刷新操作时间 **/
	public static final String SPKEY_PULL_REFRESH_TIME="pull_refresh_time";
	/** sp key-上拉加载操作时间 **/
	public static final String SPKEY_LOAD_MORE_TIME="load_more_time";
	/** sp key-此用户已参加大转盘活动的次数 -存取时后接活动id**/
	public static final String SPKEY_TURN_TABLE_COUNT="turntable_count";
	/** sp key-用户搜索商家历史**/
	public static final String SPKEY_MERCHANT_SEARCH_HISTORY="merchant_search_history";
	/** sp key-用户搜索产品历史**/
	public static final String SPKEY_GOODS_SEARCH_HISTORY="goods_search_history";
	
	
	
	
	/** sp key-最新版本名称**/
	public static final String SPKEY_LATEST_VERSION="latset_version";
	/** sp key-盐值**/
	public static final String SPKEY_SERVER_SALT="server_salt";
	/** sp key-设备id **/
	public static final String SPKEY_DEVICE_INDEX="device_index";
	/** sp key-是否是首次安装 **/
	public static final String SPKEY_IS_FIRST="isFirst";
	/** sp key-个推 推送标示 id **/
	public static final String SPKEY_CLIENTID="clientid";
	/** sp key-判断用户是否在登录状态 **/
	public static final String SPKEY_STATE="state";
	/** sp key- token **/
	public static final String SPKEY_TOKEN="token";
	/** sp key- 用户账号 **/
	public static final String SPKEY_PHONE="phone";
	

	
	
	
	
	
	
	
	
	

	// SDCard路径
	public static final String SD_PATH = Environment
			.getExternalStorageDirectory().getAbsolutePath() + File.separatorChar;

	/**
	 * 文件根目录
	 */
	public static final String BASE_PATH = "/com.lefen58/";
	
	// 缓存图片路径
	public static final String BASE_IMAGE_CACHE = BASE_PATH + "cache/images/";

	// 需要分享的图片
	public static final String SHARE_FILE = BASE_PATH + "QrShareImage.png";

	// 手机IMEI号码
	public static String IMEI = "";

	// 手机号码
	public static String TEL = "";

	// 屏幕高度
	public static int SCREEN_HEIGHT = 800;

	// 屏幕宽度
	public static int SCREEN_WIDTH = 480;

	// 屏幕密度
	public static float SCREEN_DENSITY = 1.5f;

	// 分享成功
	public static final int SHARE_SUCCESS = 0X1000;

	// 分享取消
	public static final int SHARE_CANCEL = 0X2000;

	// 分享失败
	public static final int SHARE_ERROR = 0X3000;

	// 开始执行
	public static final int EXECUTE_LOADING = 0X4000;

	// 正在执行
	public static final int EXECUTE_SUCCESS = 0X5000;

	// 执行完成
	public static final int EXECUTE_FAILED = 0X6000;

	// 加载数据成功
	public static final int LOAD_DATA_SUCCESS = 0X7000;

	// 加载数据失败
	public static final int LOAD_DATA_ERROR = 0X8000;

	// 动态加载数据
	public static final int SET_DATA = 0X9000;

	// 未登录
	public static final int NONE_LOGIN = 0X10000;

	/**
	 ******************************************* 参数设置信息结束 ******************************************
	 */

	public static String UseHelp = "http://lefen.huyongle.com/app/agreement/usehelp.html"; // 帮助
	public static String UseAgreement = "http://lefen.huyongle.com/app/agreement/useagreement.html"; // 使用协议
	public static String ActivityRules = "http://lefen.huyongle.com/app/agreement/activityrules.html"; // 活动规则
	public static String UserAgreement = "http://lefen.huyongle.com/app/agreement/useragreement.html"; // 用户协议
	
	public static String ImageUrl = "http://cdn.image.huyongle.com/";
	
	public static String Url = "http://lefen.huyongle.com/app/";
	
	

}

package com.lefen58.lefenmall.config;

public class Ip {
	
	/**线上域名*/
	public static String BASE_URL = "http://lefen58.huyongle.com/app/";
	/**测试域名*/
//	public static String BASE_URL = "http://test.58lefen.com/app/";
	
	

	/**
	 * 返回码
	 * 
	 * 	1	成功处理请求
		0	请求参数异常
		-1	操作频繁
		-2	系统限制
		-3	系统繁忙
		-4	token失效
		-5	验证失败
		-6	发送失败
		-7	文件上传出错
		-8	不支持的文件类型
		-9	无效的控制器参数
		-10	缺少控制器参数
		-11	数据异常
		-12	数据已存在
		-13	余额不足
		-14	订单失效

	 * 
	 * 
	 */



	/**
	 * APP每次启动时调用
	 * 
	 * 请求参数
	 * 
	 * 	"gap_time":""//本次启动间隔时间（当前时间-上次退出时间,单位：秒）
		"os_type":""//设备操作系统类型,0代表安卓，1代表IOS
		"device_index":"",//客户端运行设备唯一自增编号
		"token":"",//（token+gap_time做数学运算）（没有登录可以没有或值为空字符串）
		"app_version":""//客户端当前版本号
		"push_id":""//客户端当前的推送id

		返回

		"code":"",//服务器处理结果（1/0/-3）
		"login_status":"",//登录状态，0表示失效，1表示有效
		"newest_version":"",//App当前最新版本号
		"server_salt":""//数字串，服务器端给此设备的本次启动分配的盐，用于保护密码等机密数据。
		"login_device_name":""//当前登录设备品牌+型号（失效时才有此字段）
		"login_time":""//异地登录时间（失效时才有此字段）
	 * 
	 */
	public static String start_app = BASE_URL + "/account.php?c=start_app&";

	/**
	 * 新设备注册,设备首次安装app时调用
	 * 
	 * 请求参数
	 * 
	 * 	"uuid":"",//设备的唯一ID
		"os_type":"",//设备操作系统类型,0代表安卓，1代表IOS
		"os_version":"",//操作系统版本
		"screen_size":"",//设备屏幕尺寸
		"screen_dpi":"",//设备分辨率
		"device_brand":"",//设备品牌
		"device_model":"",//设备型号
		"device_cpu":"",//设备cpu型号
		"device_ram":"",//设备内存型号或大小
	 * 
	 * 返回参数
	 * 
	 * 	"code":"",//服务器处理结果(1/0/-3)
		"device_index":""//返回设备编号
	 */
	public static String register_new_device = BASE_URL + "/account.php?c=register_new_device&";
	
	/**
	 * 获取手机短信验证码
	 * 
	 * 请求参数
	 *	"phone":"",//用户填写的手机号
		"verify_type":""//请求验证码的类型，0表示注册验证，1表示快捷登录验证，2表示帐号操作安全验证
	 * 	"device_index":""//客户端运行设备编号
	 * 返回参数
	 * 
	 * 	"code":"",//服务器处理结果(1/0/-1/-2/-6)
		，-3表示发送失败（可重试）
	 */
	public static String get_SMS_code = BASE_URL + "/account.php?c=get_SMS_code&";

	/**
	 * 验证短信验证码接口
	 * 
	 * 请求参数
	 *	"phone":"",//手机号
		"code":""//验证码
	 * 
	 * 返回参数
	 * 
	 * "code":""//服务器返回结果（0/1/-5）
	 */
	public static String verify_SMS_code = BASE_URL + "/account.php?c=verify_SMS_code&";

	/**
	 * 注册时验证短信码并注册帐号
	 * 4295805122958120030
	 * 
	 * 123456666666666666
	 * 
	 * 1
	 * 
	 * 15691819362
	 * 
	 * 98812
	 * 请求参数
	 * 
	 * 	"phone":"",//用户填写的手机号
		"SMS_code":"",//用户填写的短信验证码
		"login_password":"",用户设置的登录密码(16位md5值+SMS_code的md5值=伪装成32位md5值)
		"device_index":""//设备编号
	 * 
	 * 返回参数
	 * 
	 * 	"code":"",//服务器处理结果(1/0/-3/-5)
		"token":""//登录凭证，注册成功时才有此字段
	 */
	public static String register_account = BASE_URL + "/account.php?c=register_account&";

	/**
	 * 用户登陆
	 * 
	 * 请求参数
	 * 
		"device_index":"",//客户端运行设备的唯一自增编号
		"account":"",//用户要登录的帐号（手机号）
		"login_password":""//用户填写的登录密码(16位md5值+盐的16位md5值=伪装成32位md5值)
	 * 
	 * 返回参数
	 * 
	 * 	"code":"",//服务器处理结果(1/0/-3/-5)
		"token":""//登录凭证，登录成功时才有此字段
	 */
	public static String login_by_password = BASE_URL + "/account.php?c=login_by_password&";


	/**
	 * 快捷登录（先通过接口4获取短信）
	 * 
	 * 请求参数
	 * 	"phone":"",//用户填写的手机号
		"SMS_code":"",//用户填写的短信验证码
		"device_index":""//设备编号
	 * 
	 * 返回参数
	 * 	"code":"",//服务器处理结果(1/0/-3/-5)
		"token":""//登录凭证，登录成功时才有此字段
	 * 
	 */
	public static String login_by_quick = BASE_URL + "/account.php?c=login_by_quick&";

	/**
	 * 重设登录密码（先通过接口4获取短信）
	 * 
	 * 请求参数
	 * 	"account":"",//要找回密码的帐号（手机号）
		"SMS_code":"",//用户填写的短信验证码
		"login_password":""//用户输入的新的登录密码(16位md5值+SMS_code的16位值=32位md5值)
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果(1/0/-5/-3)
	 */
	public static String reset_login_password = BASE_URL + "/account.php?c=reset_login_password&";
	public static String reset_login_password_ios = BASE_URL + "/account.php?c=reset_login_password_ios&";

	/**
	 * 修改登录密码
	 * 
	 * 请求参数
	 * 
	 *	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端当前登录凭证(token+盐做数学运算)
		"old_login_password":""//旧登录密码
		"new_login_password":""//新登录密码（16位md5值+盐的16位md5)
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果：（1、0、-3、-4、-5）
		修改密码成功后，登录状态将失效
	 */
	public static String amend_login_password = BASE_URL + "/account.php?c=amend_login_password&";

	/**
	 * 初次设置(或重设)支付密码(先通过接口4获取短信)
	 * 
	 * 请求参数
	 *	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"new_pay_password":""//用户输入的新的登录密码(16位md5值+盐的16位md5值)
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果(1、0、-3、-4、-5)
	 */
	public static String reset_pay_password = BASE_URL + "/account.php?c=reset_pay_password_ios&";


	/**
	 * 修改支付密码(通过旧支付密码)
	 * 
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"old_pay_password":""//旧支付密码
		"new_pay_password":""//用户输入的新的登录密码(16位md5值+盐的16位md5值)
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果：（1、0、-3、-4、-5）
	 */
	public static String amend_pay_password = BASE_URL + "/account.php?c=amend_pay_password&";

	/**
	 * 退出登录
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果：（1、0、-3、-4）
	 */
	public static String login_out = BASE_URL + "/account.php?c=login_out&";

	/**
	 * 设置用户资料
	 * 
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"user_info":{
		    "name":"",//用户昵称
		    "province",//用户所在省份
		    "city":"",//用户所在城市
		    "district":"",//用户所在区、县
		    "address":"",//用户详细地址
		    "intro":"",//用户个性签名
		    "sex":"",//用户性别
		    "birthday":"",//用户生日时间戳（单位：秒）
		     }//不需要修改或设置的字段可以不存在
	 * 
	 * 返回参数
	 * 
	 * "code":"",//服务器处理结果：
	 */
	public static String set_user_info = BASE_URL + "/account.php?c=set_user_info&";

	/**
	 * 上传用户头像(POST上传用户头像)
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"file":""//头像图片文件内容
	 * 
	 * 返回参数
	 * 	"code":"",//服务器处理结果：1/0/-3/-4/-7/-8
		"filename":"",//本次上传图片文件地址，加前缀http://cdn.image.huyongle.com/组成完整url
	 */
	public static String upload_head_image = BASE_URL + "/account.php?c=upload_head_image&";

	/**
	 * 验证身份证号有效性
	 * 请求参数
	 * 
	 * 	"apikey": "d41d8cd98f00b204e9800998ecf8427e"
		//apikey必须用post方式提交
		//身份证号使用get方式提交
	 * 
	 * 返回参数
	 * 	"errNum": 0,
	    "retMsg": "success",
	    "retData": {
	        "sex": "M", //M-男，F-女，N-未知
	        "birthday": "1987-04-20",
	        "address": "湖北省孝感市汉川市"
	    }
	 */
	public static String is_id = "http://apis.baidu.com/apistore/idservice/id?";

	/**
	 * 提交身份证信息
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证（token值+盐值做数学运算）
		"card_id":"",身份证号
		"card_name":"",真实姓名
		"card_validity":"",有效期（时间戳，单位：秒）
		"card_type":"",身份证类型，0临时，1正式
	 * 
	 * 返回参数
	 * "code":""//处理结果（1、0、-3、-4、-12)
	 */
	public static String submit_card_info = BASE_URL + "/account.php?c=submit_card_info&";

	/**
	 * 提交身份证正面照片
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"file":""//头像图片文件内容
	 * 
	 * 返回参数
	 * 	"code":"",//服务器处理结果：1/0/-3/-4/-7/-8/-11
		"filename":"",//本次上传图片文件地址，加前缀http://cdn.image.huyongle.com/组成完整url
	 */
	public static String upload_card_front_image = BASE_URL + "/account.php?c=upload_card_front_image&";

	/**
	 * 提交身份证反面照片
	 * 请求参数
	 * 
	 * 	"device_index":"",//客户端运行设备的唯一自增编号
		"token":"",//客户端登录凭证(token值+盐做数学运算)
		"file":""//头像图片文件内容
	 * 
	 * 返回参数
	 * 	"code":"",//服务器处理结果：1/0/-3/-4/-7/-8/-11
		"filename":"",//本次上传图片文件地址，加前缀http://cdn.image.huyongle.com/组成完整url
	 */
	public static String upload_card_reverse_image = BASE_URL + "/account.php?c=upload_card_reverse_image&";

	
	/**
	 * 	请求参数 支付接口
		"device_index":"",//设备编号
		"token":"",//用户登录凭证
		"order_id":"",//要支付的订单编号
		"pay_pwd":""//用户支付密码
		
		返回参数
		code:"",//服务器返回结果（1/0/-4/-13/-14）
		intrgral:"",//积分余额
		deal_id:""//交易流水号
	 */
	public static String payment = BASE_URL + "/payment.php?";

	public static String url = BASE_URL;
	
	public static String get_newest_version_info = BASE_URL + "/service.php?c=get_newest_version_info&";
}

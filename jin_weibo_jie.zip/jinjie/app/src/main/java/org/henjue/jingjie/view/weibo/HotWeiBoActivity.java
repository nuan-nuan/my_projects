package org.henjue.jingjie.view.weibo;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.WeiboListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.TabWeiboListFragment;
import org.henjue.jingjie.view.dialog.ListDialog;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Description:
 * Date: 2015/6/9
 * Time: 20:20
 *
 * @author henjue
 *         email:henjue@ketie.me
 * @version 1.0
 */
public class HotWeiBoActivity extends AppCompatActivity implements WeiboListAdapter.OnActionListener,SwipeRefreshLayout.OnRefreshListener, JsonResponseListener {
    private static final String LOG_TAG = HotWeiBoActivity.class.getSimpleName();
    private static final int REQUEST_EDIT = 0x1005;
    private static final int REQUEST_FORWARD = 0x1006;
    @InjectView(R.id.btn_back)
    ImageView mBtnBack;
    @InjectView(R.id.btn_refresh)
    ImageView mBtnRefresh;
    @InjectView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @InjectView(R.id.empty)
    TextView mEmpty;
    @InjectView(R.id.swipeRefresh)
    SwipeRefreshLayout mSwipeRefresh;
    private WeiboListAdapter adapter;
    private HBaseLinearLayoutManager mLayoutManager;
    private int page=1;
    private UserAuth userAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hot_weibo);
        ButterKnife.inject(this);
        adapter = new WeiboListAdapter(this, this,true);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager = new HBaseLinearLayoutManager(HotWeiBoActivity.this);
//        mRecyclerView.addItemDecoration(new ItemDecoration(mRecyclerView));
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        refresh();
    }
    public void refresh() {
        userAuth = UserAuth.read(this);
        RequestBuilder builder = new RequestBuilder(Constants.Api.MESSAGES_HOT, userAuth.token);
        builder.addParams("p", String.valueOf(page)).addParams("limit", "10").addParams("hq","");
        builder.get(this);
    }

    @Override
    public void onItemClick(WeiboListAdapter.TimeViewHolder holder, TimelineEntry data, int postion) {
        Intent intent = new Intent(HotWeiBoActivity.this, WeiboDetailsActivity.class);
        intent.putExtra("weibo", data);
        Pair<View, String> avatar = Pair.create((View) holder.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) holder.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(HotWeiBoActivity.this, avatar, nickname);
        ActivityCompat.startActivity(HotWeiBoActivity.this, intent, options.toBundle());
    }

    @Override
    public void onClickForward(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(HotWeiBoActivity.this, ForwardWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_FORWARD);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EDIT && resultCode == Activity.RESULT_OK) {
            refresh();
        } else if (requestCode == REQUEST_FORWARD && resultCode == Activity.RESULT_OK) {
            refresh();
        }
    }

    @Override
    public void onClickComment(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(HotWeiBoActivity.this, CreateCommentActivity.class);
        intent.putExtra("wb_id", "" + view.getData().getId());
        startActivity(intent);
    }

    @Override
    public void onClickLike(WeiboListAdapter.TimeViewHolder view) {
        RequestBuilder builder = new RequestBuilder(HotWeiBoActivity.this, Constants.Api.MESSAGES_PRAISE);
        builder.addParams("id", view.getData().getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception e, String url, int actionId) {

            }

            @Override
            public void onSuccess(JSONObject jsonObject, String url, int actionId) {
                try {
                    if (jsonObject.getInt("status") == 0) {
                        Toast.makeText(HotWeiBoActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(HotWeiBoActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(HotWeiBoActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    @Override
    public void onClickPull(final WeiboListAdapter.TimeViewHolder view) {
        if (view.getData().getAuthor().getId().equals(userAuth.uid)) {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"编辑", "设置成私密/公开", "删除"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        HotWeiBoActivity.this.editWeibo(view);
                    } else if (which == 2) {
                        HotWeiBoActivity.this.deleteWeibo(view.getPosition(), view.getData().getId());
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(HotWeiBoActivity.this.getFragmentManager(), "itemDialog");
        } else {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"取消关注", "举报"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        HotWeiBoActivity.this.deleteFriend(view);
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(HotWeiBoActivity.this.getFragmentManager(), "itemDialog");
        }
    }

    private void editWeibo(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(HotWeiBoActivity.this, EditWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_EDIT);
    }

    private void deleteFriend(WeiboListAdapter.TimeViewHolder holder) {
        RequestBuilder builder = RequestBuilder.create(HotWeiBoActivity.this, Constants.Api.FRIEND_DEL);
        builder.addParams("friend_id", holder.getData().getAuthor().getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                LogUtils.i(LOG_TAG, url);
                LogUtils.i(LOG_TAG, json.toString());
                try {
                    if (json.getInt("status") == 0) {
                        Toast.makeText(HotWeiBoActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(HotWeiBoActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {
                errorMsg.printStackTrace();
                Toast.makeText(HotWeiBoActivity.this, errorMsg.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void deleteWeibo(final int position, int tid) {
        RequestBuilder builder = RequestBuilder.create(HotWeiBoActivity.this, Constants.Api.MESSAGES_DEL);
        builder.addParams("id", tid);
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if (json.getInt("status") == 0) {
                        adapter.delete(position);
                        Toast.makeText(HotWeiBoActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(HotWeiBoActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {
                errorMsg.printStackTrace();
                Toast.makeText(HotWeiBoActivity.this, errorMsg.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClickUserPhoto(WeiboListAdapter.TimeViewHolder view) {
//        Toast.makeText(HotWeiBoActivity.this,"你点击了ID为："+uid+"的头像",Toast.LENGTH_SHORT).show();
        Intent intent = TargetUserHomeActivity.create(HotWeiBoActivity.this, view.getData().getAuthor());
        Pair<View, String> photo = Pair.create((View) view.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) view.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(HotWeiBoActivity.this, nickname, photo);
        ActivityCompat.startActivity(HotWeiBoActivity.this, intent, options.toBundle());
    }


    @Override
    public void onRefresh() {
        page = 1;
        refresh();
    }

    @Override
    public void onSuccess(JSONObject jsonObject, String url, int actionId) {
        LogUtils.d(LOG_TAG, "onSuccess:%s", url);
        try {
            mSwipeRefresh.setRefreshing(false);
            int status = jsonObject.getInt("status");
            if (status != 0) {
                if (status == 10000 && page == 1) {
                    adapter.reload(new ArrayList<TimelineEntry>(), false);
                    adapter.notifyDataSetChanged();
                }
//                    Toast.makeText(HotWeiBoActivity.this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
            } else {
                JSONArray data = jsonObject.getJSONObject("data").getJSONArray("list");
                LogUtils.d(TabWeiboListFragment.class.getName(), JsonFormatTool.formatJson(data));
                Gson gson = new Gson();
                ArrayList<TimelineEntry> timelines = new ArrayList<TimelineEntry>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject json = data.getJSONObject(i);
                    String json1 = json.toString();
                    LogUtils.i(LOG_TAG,json1);
                    final TimelineEntry timeline=gson.fromJson(json1,TimelineEntry.class);
                    timelines.add(timeline);

                }
                adapter.reload(timelines, page != 1);
                adapter.notifyDataSetChanged();
                if(page==1){
                    mLayoutManager.scrollToPosition(0);
                }
                boolean showEmpty=timelines.size()<=0;
                mRecyclerView.setVisibility(showEmpty?View.GONE:View.VISIBLE);
                mEmpty.setVisibility(!showEmpty?View.GONE:View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        Log.e("TimelineFragment", url, errorMsg);
        mSwipeRefresh.setRefreshing(false);
    }
}

package org.henjue.jingjie.view.weibo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by android on 5/2/15.
 */
public class CreateCommentActivity extends AppCompatActivity implements View.OnClickListener, JsonResponseListener {
    private static final String LOG_TAG = CreateCommentActivity.class.getName();
    private UserAuth user;
    private View mBtnBack;
    private View mBtnSend;
    private EditText mContent;
    private String wb_id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user= UserAuth.read(this);
        setContentView(R.layout.activity_create_comment);
        onNewIntent(getIntent());
        mBtnBack=findViewById(R.id.btn_back);
        mBtnSend=findViewById(R.id.btn_send);
        mContent=(EditText)findViewById(R.id.content);
        mBtnBack.setOnClickListener(this);
        mBtnSend.setOnClickListener(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        wb_id=intent.getStringExtra("wb_id");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_send:
                doSend();
                break;
        }
    }
    private void doSend() {
        Editable content = mContent.getText();
        if(TextUtils.isEmpty(content)){
            Toast.makeText(this, "微博内容不能为空", Toast.LENGTH_SHORT).show();
        }else{
            String text=content.toString();
            RequestBuilder builder=new RequestBuilder(this,Constants.Api.COMMENT_ADD);
            builder.addParams("content",text).addParams("from","android").addParams("id",wb_id).addParams("isret",0);
            builder.post(this);
        }
    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        LogUtils.d(LOG_TAG, JsonFormatTool.formatJson(json));
        try {
            Toast.makeText(this,json.getString("message"),Toast.LENGTH_SHORT).show();
            if(json.getInt("status")==0){
                setResult(RESULT_OK);
                finish();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        errorMsg.printStackTrace();
    }
}

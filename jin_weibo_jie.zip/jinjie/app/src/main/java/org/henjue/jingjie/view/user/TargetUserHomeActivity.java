package org.henjue.jingjie.view.user;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.WeiboListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.user.AbstractUser;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.view.TabMeFragment;
import org.henjue.jingjie.view.weibo.CreateCommentActivity;
import org.henjue.jingjie.view.weibo.ForwardWeiboActivity;
import org.henjue.jingjie.widget.DragTopLayout;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * 用户主页(和tab页中的me类似)
 */
public class TargetUserHomeActivity extends AppCompatActivity implements DragTopLayout.PanelListener, JsonResponseListener, WeiboListAdapter.OnActionListener {
    private static final int REQEUST_UPDATE = 0x1005;
    @InjectView(R.id.background)
    SimpleDraweeView mBackground;
    @InjectView(R.id.avatar)
    SimpleDraweeView mAvatar;
    @InjectView(R.id.nickname)
    TextView mNickname;
    @InjectView(R.id.follw_count)
    TextView mFollwCount;
    @InjectView(R.id.fans_count)
    TextView mFansCount;
    @InjectView(R.id.summary)
    TextView mSummary;
    @InjectView(R.id.btn_message)
    Button mBtnMessage;
    @InjectView(R.id.btn_attent)
    Button mBtnAttent;
    @InjectView(R.id.btn_edit_info)
    Button mBtnEditInfo;
    @InjectView(R.id.drag_top_container)
    LinearLayout mDragTopContainer;
    @InjectView(R.id.list_title)
    TextView mListTitle;
    @InjectView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @InjectView(R.id.drag_bottm_container)
    LinearLayout mDragBottmContainer;
    @InjectView(R.id.drag_layout)
    DragTopLayout mDragLayout;
    @InjectView(R.id.btn_back)
    TextView mBtnBack;
    @InjectView(R.id.title)
    TextView mTitle;
    @InjectView(R.id.btn_settings)
    TextView mBtnSettings;
    @InjectView(R.id.title_container)
    RelativeLayout mTitleContainer;
    private HBaseLinearLayoutManager mLayoutManager;
    private WeiboListAdapter adapter;
    private int page = 1;
    private TargetUser user;

    @OnClick(R.id.avatar)
    void updateAvatar(View v){
        if (user.isMe(this)) {
            Intent intent = new Intent(this, UpdateAvatarActivity.class);
            ActivityOptionsCompat options=ActivityOptionsCompat.makeSceneTransitionAnimation(this,v,"avatar");
            ActivityCompat.startActivityForResult(this,intent,1001,options.toBundle());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
            if(resultCode==RESULT_OK){
                if(requestCode==1001) {
                    mAvatar.setImageURI(data.getData());
                }else if(requestCode==REQEUST_UPDATE){
                    refreshUserInfo();
                    refresh();
                }
        }
    }
    public static <T extends AbstractUser> Intent create(Context context, T t){
        Intent intent = new Intent(context,TargetUserHomeActivity.class);
        intent.putExtra("user", t);
        return intent;
    }

    /**
     * 处理关注
     * @param view
     */
    @OnClick(R.id.btn_attent)
    void btn_attent(final View view){
        int isfollower = user.getIsfollower();
        if(isfollower==0) {
            RequestBuilder builder = RequestBuilder.create(this, Constants.Api.FRIEND_ADD);
            builder.addParams("friend_id", user.getId());
            builder.post(new JsonResponseListener() {
                @Override
                public void onSuccess(JSONObject json, String url, int actionId) {
                    try {
                        Toast.makeText(getActivity(), json.getString("message"), Toast.LENGTH_SHORT).show();
                        view.setBackgroundResource(R.drawable.ic_folloed);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onRequest() {

                }

                @Override
                public void onError(Exception errorMsg, String url, int actionId) {

                }
            });
        }else if(isfollower==1 || isfollower==3){

            RequestBuilder builder=RequestBuilder.create(this,Constants.Api.FRIEND_DEL);
            builder.addParams("friend_id",user.getId());
            builder.post(new JsonResponseListener() {
                @Override
                public void onSuccess(JSONObject json, String url, int actionId) {
                    try {
                        Toast.makeText(TargetUserHomeActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        if (json.getInt("status") == 0) {
                            refreshUserInfo();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onRequest() {

                }

                @Override
                public void onError(Exception errorMsg, String url, int actionId) {

                }
            });
        }
    }
    private void updateAddButton(AbstractUser u){
        int isfollower = u.getIsfollower();
        if(isfollower ==0){
            mBtnAttent.setText("关注");
            mBtnAttent.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_follo_normal, 0);
        }else if(isfollower ==3) {
            mBtnAttent.setText("相互");
            mBtnAttent.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_follo_both, 0);
        }else if (isfollower ==1){
            mBtnAttent.setText("取消");
            mBtnAttent.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_folloed, 0);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adapter = new WeiboListAdapter(this, this,true);
        setContentView(R.layout.activity_target_user_home);
        ButterKnife.inject(this);
        user = getIntent().getParcelableExtra("user");
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TargetUserHomeActivity.this.finish();
            }
        });

        ViewCompat.setTransitionName(findViewById(R.id.nickname), "nickname");
//        ViewCompat.setTransitionName(findViewById(R.id.avatar),"avatar");
        mLayoutManager = new HBaseLinearLayoutManager(this);
        //编辑资料功能
        findViewById(R.id.btn_edit_info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转一个界面
                Intent intent = new Intent(TargetUserHomeActivity.this, BasicInfoMainActivity.class);
                startActivityForResult(intent, REQEUST_UPDATE);
                finish();

            }
        });



        if (user.isMe(this)) {
            user= UserSaveHelper.getInstance().getUser();
            mBtnAttent.setVisibility(View.GONE);
            mBtnMessage.setVisibility(View.GONE);
            mBtnEditInfo.setVisibility(View.VISIBLE);
            mAvatar.setImageURI(Uri.parse(user.getAvatar()));
            mNickname.setText(user.getNickname());
            mSummary.setText(TextUtils.isEmpty(user.getSummary()) ? "没有说明" : user.getSummary());
            mFansCount.setText(user.getFansCount());
            mFollwCount.setText(user.getFollowCount());
            updateAddButton(user);
            refresh();
        } else {
            refreshUserInfo();
        }


        mBackground.setImageURI(Uri.parse("http://imga1.pic21.com/bizhi/131110/03627/s24.jpg"));
//        findViewById(R.id.tool_bar).bringToFront();
        mDragLayout.listener(this);

        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                //mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);

    }

    private void refreshUserInfo() {
        RequestBuilder builder = new RequestBuilder(this, Constants.Api.USER_INFO);

        if (!TextUtils.isEmpty(user.getId())) {
            builder.addParams("user_id", user.getId());
        } else {
            builder.addParams("nickname", user.getNickname());

        }
        builder.get(userInfoListener);
    }

    private void refresh() {
        if (user == null || user.getId()==null) return;
        RequestBuilder builder = RequestBuilder.create(this, Constants.Api.MESSAGES_USER);
        builder.addParams("p", String.valueOf(page)).addParams("limit", "10");
        builder.addParams("user_id", user.getId());
        builder.get(this);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ActivityCompat.finishAfterTransition(this);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private JsonResponseListener userInfoListener = new JsonResponseListener() {
        @Override
        public void onRequest() {

        }

        @Override
        public void onError(Exception e, String url, int actionId) {

        }

        @Override
        public void onSuccess(JSONObject jsonObject, String url, int actionId) {
            Log.i(TabMeFragment.class.getSimpleName(), jsonObject.toString());
            try {
                if (jsonObject.getInt("status") == 0) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    user=new Gson().fromJson(data.toString(), TargetUser.class);
                    mAvatar.setImageURI(Uri.parse(user.getAvatar()));
                    mNickname.setText(user.getNickname());
                    mSummary.setText(TextUtils.isEmpty(user.getSummary()) ? "没有说明" : user.getSummary());
                    mFansCount.setText(user.getFansCount());
                    mFollwCount.setText(user.getFollowCount());
                    refresh();
                } else {
                    Toast.makeText(TargetUserHomeActivity.this, "获取用户信息失败", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };


    @Override
    public void onPanelStateChanged(DragTopLayout.PanelState oldState, DragTopLayout.PanelState newState) {
        //LogUtils.i(TargetUserHomeActivity.class.getName(), "old:%s,new:%s", oldState, newState);
        if (oldState != newState) {
            if (newState == DragTopLayout.PanelState.COLLAPSED) {
                mTitleContainer.setBackgroundColor(Color.parseColor("#ff53c3f1"));
                for (int i = 0; i < mTitleContainer.getChildCount(); i++) {
                    View child = mTitleContainer.getChildAt(i);
                    if (child instanceof TextView) {
                        ((TextView) child).setTextColor(0xffffffff);
                    }
                }
            } else if (newState == DragTopLayout.PanelState.EXPANDED) {
                mTitleContainer.setBackgroundResource(android.R.color.transparent);
                for (int i = 0; i < mTitleContainer.getChildCount(); i++) {
                    View child = mTitleContainer.getChildAt(i);
                    if (child instanceof TextView) {
                        ((TextView) child).setTextColor(0xff000000);
                    }
                }
            }
        }
    }

    @Override
    public void onSliding(float ratio) {
        //LogUtils.i(TargetUserHomeActivity.class.getName(), "onSliding:%f",ratio);
        mTitleContainer.setBackgroundResource(android.R.color.transparent);
        for (int i = 0; i < mTitleContainer.getChildCount(); i++) {
            View child = mTitleContainer.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextColor(0xff000000);
            }
        }
    }

    @Override
    public void onRefresh() {
        //LogUtils.i(TargetUserHomeActivity.class.getName(), "onRefresh");
    }

    @Override
    public void onSuccess(JSONObject jsonObject, String url, int actionId) {

        try {
            int status = jsonObject.getInt("status");
            if (status != 0) {
                if (status == 10000 && page == 1) {
                    adapter.reload(new ArrayList<TimelineEntry>(), false);
                    adapter.notifyDataSetChanged();
                }
            } else {
                JSONArray data = jsonObject.getJSONObject("data").getJSONArray("list");
                Gson gson = new Gson();
                ArrayList<TimelineEntry> timelines = new ArrayList<TimelineEntry>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject json = data.getJSONObject(i);
                    final TimelineEntry timeline=gson.fromJson(json.toString(),TimelineEntry.class);
                    timelines.add(timeline);

                }
                adapter.reload(timelines, page != 1);
                mListTitle.setText(String.format("全部微博 (%d)", adapter.getItemCount()));
                adapter.notifyDataSetChanged();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {
    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
    }

    @Override
    public void onItemClick(WeiboListAdapter.TimeViewHolder holder, TimelineEntry data, int postion) {

    }

    @Override
    public void onClickForward(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(getActivity(), ForwardWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivity(intent);
    }

    @Override
    public void onClickComment(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(getActivity(), CreateCommentActivity.class);
        intent.putExtra("wb_id", "" + view.getData().getId());
        startActivity(intent);
    }

    Activity getActivity() {
        return this;
    }

    @Override
    public void onClickLike(WeiboListAdapter.TimeViewHolder view) {
        RequestBuilder builder = new RequestBuilder(getActivity(), Constants.Api.MESSAGES_PRAISE);
        builder.addParams("id", view.getData().getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception e, String url, int actionId) {

            }

            @Override
            public void onSuccess(JSONObject jsonObject, String url, int actionId) {
                try {
                    if (jsonObject.getInt("status") == 0) {
                        Toast.makeText(getActivity(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onClickPull(WeiboListAdapter.TimeViewHolder holder) {

    }

    @Override
    public void onClickUserPhoto(WeiboListAdapter.TimeViewHolder view) {
        Intent intent =TargetUserHomeActivity.create(this,user);
        Pair<View, String> photo = Pair.create((View) view.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) view.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(this, nickname, photo);
        ActivityCompat.startActivity(this, intent, options.toBundle());
    }
}

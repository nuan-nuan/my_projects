package org.henjue.jingjie.view.weibo;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.CommentMeAdapter;
import org.henjue.jingjie.adapter.LikeMeAdapter;
import org.henjue.jingjie.adapter.WeiboListAdapter;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.response.CommentMeResponse;
import org.henjue.jingjie.model.response.LikeMeResponse;
import org.henjue.jingjie.model.response.TimelineListResponse;
import org.henjue.jingjie.network2.ErrorUtils;
import org.henjue.jingjie.network2.Network;
import org.henjue.jingjie.network2.service.TimelineService;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;

import java.util.List;

/**
 * Created by android on 5/2/15.
 * 效果图“消息连线图”1,2,3三个图片
 */
public class FilterWeiBoActivity extends AppCompatActivity implements  View.OnClickListener, SwipeRefreshLayout.OnRefreshListener, WeiboListAdapter.OnActionListener {
    private static final String LOG_TAG =FilterWeiBoActivity.class.getName() ;
    private View mTitleContainer;
    private WeiboListAdapter adapter;
    private LikeMeAdapter likeMeAdapter;
    private CommentMeAdapter commentMeAdapter;
    private SwipeRefreshLayout mSwipeRefresh;
    private RecyclerView mRecyclerView;
    private TextView mCenterTitle;
    private View mBtnBack;
    private HBaseLinearLayoutManager mLayoutManager;
    private UserAuth userAuth;
    private int page=1;
    private static final int ATME=1;
    private static final int COMMENT=2;
    private static final int LIKED=3;
    private TimelineService service;
    private Callback<LikeMeResponse> likeMeResponseCallback=new Callback<LikeMeResponse>() {
        @Override
        public void start() {

        }

        @Override
        public void success(LikeMeResponse res, Response response) {
            if(res.getStatus()==0){
                likeMeAdapter.reload(res.getData().getList(), page != 1);
                likeMeAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void failure(HNetError hNetError) {
            ErrorUtils.checkError(FilterWeiBoActivity.this,hNetError);
        }

        @Override
        public void end() {

        }
    };
    private Callback<TimelineListResponse> timelineCallback=new Callback<TimelineListResponse>() {
        @Override
        public void start() {
            mSwipeRefresh.setRefreshing(true);
        }

        @Override
        public void success(TimelineListResponse res, Response response) {
            TimelineListResponse.Lst data = res.getData();
            if(data==null){
                Toast.makeText(FilterWeiBoActivity.this,res.getMessage(),Toast.LENGTH_SHORT).show();
                return;
            }
            List<TimelineEntry> list = data.getList();
            if(res.getStatus()==0 && list.size()>0) {
                adapter.reload(list, page != 1);
                adapter.notifyDataSetChanged();
            }else{
                Toast.makeText(FilterWeiBoActivity.this,res.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void failure(HNetError hNetError) {
            ErrorUtils.checkError(FilterWeiBoActivity.this, hNetError);
        }

        @Override
        public void end() {
            mSwipeRefresh.setRefreshing(false);
        }
    };
    private Callback<CommentMeResponse> commentCallback=new Callback<CommentMeResponse>() {
        @Override
        public void start() {
            mSwipeRefresh.setRefreshing(true);
        }

        @Override
        public void success(CommentMeResponse res, Response response) {
            CommentMeResponse.DataEntity data = res.getData();
            if(data==null){
                Toast.makeText(FilterWeiBoActivity.this,res.getMessage(),Toast.LENGTH_SHORT).show();
                return;
            }
            List<CommentMeResponse.DataEntity.CommentEntity> list = data.getComment();
            if(res.getStatus()==0 && list.size()>0) {
                commentMeAdapter.reload(list, page != 1);
                commentMeAdapter.notifyDataSetChanged();
            }else{
                Toast.makeText(FilterWeiBoActivity.this,res.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void failure(HNetError hNetError) {
            ErrorUtils.checkError(FilterWeiBoActivity.this, hNetError);
        }

        @Override
        public void end() {
            mSwipeRefresh.setRefreshing(false);
        }
    };

    public static Intent getAtMeIntent(Context context){
        Intent intent = new Intent(context, FilterWeiBoActivity.class);
        intent.putExtra("type", ATME);
        return intent;
    }
    public static Intent getCommentIntent(Context context){
        Intent intent = new Intent(context, FilterWeiBoActivity.class);
        intent.putExtra("type",COMMENT);
        return intent;
    }
    public static Intent getLikedntent(Context context){
        Intent intent = new Intent(context, FilterWeiBoActivity.class);
        intent.putExtra("type", LIKED);
        return intent;
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        service=Network.getService(TimelineService.class);
        setContentView(R.layout.activity_filter_weibolist);
        mTitleContainer=findViewById(R.id.title_container);
        adapter = new WeiboListAdapter(this,this,false);
        likeMeAdapter=new LikeMeAdapter(this);
        commentMeAdapter=new CommentMeAdapter(this);
        mSwipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        ViewCompat.setTransitionName(mRecyclerView,"body");
        mCenterTitle = (TextView) findViewById(R.id.center_title);
        mBtnBack =findViewById(R.id.btn_back);
        mCenterTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FilterWeiBoActivity.this.toggleGroupPopup(v);
            }
        });
        mBtnBack.setOnClickListener(this);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager=new HBaseLinearLayoutManager(this);
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        refresh();
    }
    public  void refresh(){
        userAuth = UserAuth.read(this);
        int type=getIntent().getIntExtra("type",0);
        if(type==ATME){
            if(mRecyclerView.getAdapter()!=adapter) {
                mRecyclerView.setAdapter(adapter);
            }
            mCenterTitle.setText("@我的微博");
            service.atMe(page,10,"a",timelineCallback);
        }else if(type==COMMENT){
            if(mRecyclerView.getAdapter()!=commentMeAdapter) {
                mRecyclerView.setAdapter(commentMeAdapter);
            }
            mCenterTitle.setText("评论我的微博");
            service.commentMe(page,commentCallback);
        }if(type==LIKED){
            if(mRecyclerView.getAdapter()!=likeMeAdapter) {
                mRecyclerView.setAdapter(likeMeAdapter);
            }
            mCenterTitle.setText("赞我的微博");
            service.likeMe(page, 10, "a", likeMeResponseCallback);
        }
    }
    private void toggleGroupPopup(View parent) {
        DisplayMetrics out = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(out);
        PopupWindow popupWindow = new PopupWindow(LayoutInflater.from(this).inflate(R.layout.group_pop, null, false), out.widthPixels/2, WindowManager.LayoutParams.WRAP_CONTENT );
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        int[] location = new int[2];
        parent.getLocationOnScreen(location);
        popupWindow.showAsDropDown(parent,-(((out.widthPixels/2)-parent.getMeasuredWidth())/2),0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_back:
                ActivityCompat.finishAfterTransition(this);
                break;
        }
    }


    @Override
    public void onRefresh() {
        page=1;
        refresh();
    }


    @Override
    public void onItemClick(WeiboListAdapter.TimeViewHolder holder, TimelineEntry data, int postion) {
        Toast.makeText(this, "你点击了ID为：" + data.getId() + "的微薄", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClickForward(WeiboListAdapter.TimeViewHolder view) {
        Toast.makeText(this,"你点击了ID为："+view.getData().getId()+"的微薄的转发按钮",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClickComment(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(this, CreateCommentActivity.class);
        intent.putExtra("wb_id",""+view.getData().getId());
        startActivity(intent);
    }

    @Override
    public void onClickLike(WeiboListAdapter.TimeViewHolder view) {
        Toast.makeText(this,"你点击了ID为："+view.getData().getId()+"的微薄的赞按钮",Toast.LENGTH_SHORT).show();
//        RequestBuilder builder=new RequestBuilder(Constants.Api.FAVORITES_ADD,userAuth.token);
//        builder.addParams("id",tid);
//        builder.post(new JsonResponse() {
//            @Override
//            public void onRequest() {
//
//            }
//
//            @Override
//            public void onError(Exception e, String url, int actionId) {
//
//            }
//
//            @Override
//            public void onSuccess(JSONObject jsonObject, String url, int actionId) {
//                try {
//                    if(jsonObject.getInt("status")==0){
//                        Toast.makeText(this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
//                    }else{
//                        Toast.makeText(this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }


    @Override
    public void onClickPull(WeiboListAdapter.TimeViewHolder view) {
        Toast.makeText(this,"你点击了ID为："+view.getData().getId()+"的微薄的三角形",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClickUserPhoto(WeiboListAdapter.TimeViewHolder view) {
//        Toast.makeText(this,"你点击了ID为："+uid+"的头像",Toast.LENGTH_SHORT).show();

        Intent intent = TargetUserHomeActivity.create(this,view.getData().getAuthor());
        Pair<View,String> photo=Pair.create((View)view.mAvatar,"user_photo");
        Pair<View,String> nickname=Pair.create((View)view.mNickname,"nickname");
        ActivityOptionsCompat options=ActivityOptionsCompat.makeSceneTransitionAnimation(this,nickname,photo);
        ActivityCompat.startActivity(this, intent, options.toBundle());
    }

}

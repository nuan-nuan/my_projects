package org.henjue.jingjie.adapter;

import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.model.Img;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;

import java.util.List;

/**
 * Description:
 * Date: 2015/6/14
 * Time: 12:31
 *
 * @author henjue
 *         email:henjue@ketie.me
 * @version 1.0
 */
public class ImgAdapter extends AbstractAdapter<Img,ImgAdapter.ViewHolder> {
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.weibo_list_img_item,parent,false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String url = getItem(position).getUrl();
        if(url.startsWith("http") || url.startsWith("ftp")){

        }else{
            url+="http://weibo.joyousphper.com/"+url;
        }
        holder.mImg.setImageURI(Uri.parse(url));
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final SimpleDraweeView mImg;
        public ViewHolder(View itemView) {
            super(itemView);
            mImg=(SimpleDraweeView)itemView.findViewById(R.id.img);
        }
    }
}

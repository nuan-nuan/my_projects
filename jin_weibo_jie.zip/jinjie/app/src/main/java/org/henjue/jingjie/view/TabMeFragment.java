package org.henjue.jingjie.view;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.settings.SettingsActivity;
import org.henjue.jingjie.view.user.TargetUserFollowerListActivity;
import org.henjue.jingjie.view.user.TargetUserFollowingListActivity;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.view.weibo.TargetUserWeiboListActivity;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Version 1.0
 * <p>
 * Date: 2015-03-20 20:15
 * Author: alanchen@fit-start.co
 * <p>
 * Copyright © 2014-2014 Shanghai Fit-start Network Technology Co., Ltd.
 */
public class TabMeFragment extends Fragment implements View.OnClickListener {
    private static final String ARG_UID = "_uid";
    @InjectView(R.id.btn_settings)
    TextView mBtnSettings;
    @InjectView(R.id.avatar)
    SimpleDraweeView mAvatar;
    @InjectView(R.id.nickname)
    TextView mNickname;
    @InjectView(R.id.summary)
    TextView mSummary;
    @InjectView(R.id.btn_top_contaier)
    RelativeLayout mBtnTopContaier;
    @InjectView(R.id.timeline_count)
    TextView mTimelineCount;
    @InjectView(R.id.weibo)
    LinearLayout mWeibo;
    @InjectView(R.id.follw_count)
    TextView mFollwCount;
    @InjectView(R.id.look)
    LinearLayout mLook;
    @InjectView(R.id.fans_count)
    TextView mFansCount;
    @InjectView(R.id.vermicelli)
    LinearLayout mVermicelli;
    private UserAuth user;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_me, null, false);
        ButterKnife.inject(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSummary = (TextView) view.findViewById(R.id.summary);
        mNickname = (TextView) view.findViewById(R.id.nickname);
        mTimelineCount = (TextView) view.findViewById(R.id.timeline_count);
        mFollwCount = (TextView) view.findViewById(R.id.follw_count);
        mFansCount = (TextView) view.findViewById(R.id.fans_count);
        mBtnSettings = (TextView) view.findViewById(R.id.btn_settings);
        mBtnTopContaier.setOnClickListener(this);
        mBtnSettings.setOnClickListener(clickListener);
        user = UserAuth.read(getActivity());
        refresh();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onResume() {
        super.onResume();
        mNickname.setText(UserSaveHelper.getInstance().getUser().getNickname());
        mAvatar.setImageURI(Uri.parse(UserSaveHelper.getInstance().getUser().getAvatar()));
    }

    @OnClick(R.id.weibo)
    void startWeiboList(View v){
        Intent intent = new Intent(getActivity(), TargetUserWeiboListActivity.class);
        intent.putExtra("uid", user.uid);
        startActivity(intent);
    }
    @OnClick(R.id.look)
    void startLookList(View v){
        Intent intent = TargetUserFollowingListActivity.create(getActivity(),user.uid);
        startActivity(intent);
    }
    @OnClick(R.id.vermicelli)
    void startVBermicelliList(View v){
        Intent intent = TargetUserFollowerListActivity.create(getActivity(), user.uid);
        startActivity(intent);
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                //点击按钮跳转设置界面
                case R.id.btn_settings:
                    Intent intent = new Intent();
                    intent.setClass(TabMeFragment.this.getActivity(), SettingsActivity.class);
                    TabMeFragment.this.startActivity(intent);
            }
        }
    };


    public static TabMeFragment newInstance(Pair... pairs) {
        return newInstance(null, pairs);
    }

    public static TabMeFragment newInstance(String uid, Pair... pairs) {
        TabMeFragment fragment = new TabMeFragment();
        Bundle args = new Bundle();
        if (!TextUtils.isEmpty(uid)) {
            args.putString(ARG_UID, uid);
        }
        fragment.setArguments(args);
        return fragment;
    }

    private JsonResponseListener listener = new JsonResponseListener() {
        @Override
        public void onRequest() {
        }

        @Override
        public void onError(Exception e, String url, int actionId) {
        }

        @Override
        public void onSuccess(JSONObject jsonObject, String url, int actionId) {
            LogUtils.i(TabMeFragment.class.getSimpleName(), "Url:%s\nResult:\n%s", url, JsonFormatTool.formatJson(jsonObject));
            try {
                if (jsonObject.getInt("status") == 0) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    TargetUser user=new Gson().fromJson(data.toString(), TargetUser.class);
                    UserSaveHelper.getInstance().setUser(user);
                    if(mNickname!=null)mNickname.setText(user.getNickname());
                    if(mSummary!=null)mSummary.setText(user.getSummary());
                    if(mFansCount!=null)mFansCount.setText(user.getFansCount());
                    if(mFollwCount!=null)mFollwCount.setText(user.getFollowCount());
                    if(mTimelineCount!=null)mTimelineCount.setText(user.getMsgCount());
                } else {
                    Toast.makeText(getActivity(), "获取用户信息失败", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onClick(View v) {
        TargetUser targetUser=UserSaveHelper.getInstance().getUser();
        Intent intent = TargetUserHomeActivity.create(getActivity(),targetUser);
        Pair<View, String> nickname = Pair.create((View) mNickname, "nickname");
        Pair<View, String> avatar = Pair.create((View)mAvatar, "avatar");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(), nickname, avatar);
        ActivityCompat.startActivity(getActivity(), intent, options.toBundle());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }

    public void refresh() {
        RequestBuilder builder = new RequestBuilder(getActivity(), Constants.Api.USER_INFO);
        builder.addParams("user_id", UserAuth.read(getActivity()).uid);
        builder.get(listener);
    }
}




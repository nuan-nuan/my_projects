package org.henjue.jingjie.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.henjue.jingjie.R;


/**
 * Created by android on 2015/5/13.
 */
public class TitleView extends LinearLayout {
    private OnClickListener leftListener;
    private OnClickListener rightListener;

    public void setLeftListener(OnClickListener leftListener) {
        this.leftListener = leftListener;
        if(leftBtn!=null){
            leftBtn.setOnClickListener(leftListener);
        }
    }

    public void setRightListener(OnClickListener rightListener) {
        this.rightListener = rightListener;
        if(rightListener!=null){
            rightBtn.setOnClickListener(rightListener);
        }
    }

    public ImageView getRightBtn() {
        return rightBtn;
    }

    public ImageView getLeftBtn() {
        return leftBtn;
    }

    public TextView getCenterTitle() {
        return centerTitle;
    }

    private ImageView leftBtn;
    private TextView centerTitle;
    private ImageView rightBtn;

    public TitleView(Context context) {
        this(context, null);
    }


    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setBackgroundResource(R.color.gloal_title_bg);
        LayoutParams leftParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        leftParams.gravity=Gravity.LEFT;
        leftBtn.setLayoutParams(leftParams);

        LayoutParams centerParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        centerParams.gravity=Gravity.CENTER;
        centerTitle.setLayoutParams(centerParams);

        LayoutParams rightParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rightParams.gravity=Gravity.RIGHT;
        rightBtn.setLayoutParams(rightParams);
        addView(leftBtn);
        addView(centerTitle);
        addView(rightBtn);
        if(leftBtn!=null){
            leftBtn.setOnClickListener(leftListener);
        }
        if(rightListener!=null){
            rightBtn.setOnClickListener(rightListener);
        }
    }

    public TitleView(Context context, AttributeSet attrs) {
        this(context,attrs,0);
    }

    public TitleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        leftBtn = new ImageView(getContext());
        centerTitle = new TextView(getContext());
        rightBtn = new ImageView(getContext());
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public TitleView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        leftBtn = new ImageView(getContext());
        centerTitle = new TextView(getContext());
        rightBtn = new ImageView(getContext());
    }
}

package org.henjue.jingjie.view.auth;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.view.dialog.AlertDialog;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by henjue on 15/4/9.
 * 输入验证码
 */
public class InputValidateActivity extends Activity implements TextWatcher, AlertDialog.PositiveListener, JsonResponseListener {
    @InjectView(R.id.btn_back)
    TextView mBtnBack;
    @InjectView(R.id.top)
    RelativeLayout mTop;
    @InjectView(R.id.code_lb)
    TextView mCodeLb;
    @InjectView(R.id.phone_lb)
    TextView mPhoneLb;
    @InjectView(R.id.code)
    EditText mCode;
    @InjectView(R.id.btn_next)
    Button mBtnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reg2);
        ButterKnife.inject(this);
        mCodeLb.setText(Html.fromHtml("我们已经发送了<a href=\"#\">验证码</a>到你的手机"));
        mPhoneLb.setText(getIntent().getStringExtra("phone"));
        mCode.addTextChangedListener(this);
    }

    @OnClick({R.id.btn_back})
    void onBack(View f) {
        Intent intent = new Intent(this, UserLoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
        startActivity(intent);
        overridePendingTransition(R.anim.default_exit_in, R.anim.default_exit_out);
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBack(null);
        }
        return super.onKeyDown(keyCode, event);
    }

    @OnClick(R.id.btn_next)
    public void onClick(View v) {
        Editable text = mCode.getText();
        if (TextUtils.isEmpty(text)) {
            AlertDialog dialog = AlertDialog.newInstance("信息提示", "请输入验证码");
            dialog.setPositiveListener(this);
            dialog.show(getFragmentManager(), "dialog");
        } else {
            postToServer();
        }
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        mBtnNext.setEnabled(!TextUtils.isEmpty(s));
    }

    @Override
    public void onPositiveClick(DialogInterface dialog) {

    }

    @Override
    public String positiveText() {
        return "确定";
    }


    private void postToServer() {
        RequestBuilder builder = new RequestBuilder(Constants.Api.USER_CHECKCODE);
        builder.addParams("phone", getIntent().getStringExtra("phone"));
        builder.addParams("code", mCode.getText().toString());
        builder.post(this);
    }


    @Override
    public void onSuccess(JSONObject jsonObject, String url, int actionId) {
        try {
            int status = jsonObject.getInt("status");
            Toast.makeText(InputValidateActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
            if (status == 0) {
                Intent intent=getIntent().getParcelableExtra("to");
                intent.putExtra("phone", getIntent().getStringExtra("phone"));
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(InputValidateActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {

    }
}

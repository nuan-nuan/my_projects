package org.henjue.jingjie.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.response.LikeMeResponse;
import org.henjue.jingjie.model.user.TargetUser;

import butterknife.ButterKnife;
import butterknife.InjectView;


/**
 * Created by ligux on 2015/3/31.
 */
public class LikeMeAdapter extends AbstractAdapter<LikeMeResponse.DataEntity.ListEntity, LikeMeAdapter.ViewHolder> {


    private final TargetUser me;

    public LikeMeAdapter(Context context) {
        me= UserSaveHelper.getInstance().getUser();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.liked_me_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int i) {
        LikeMeResponse.DataEntity.ListEntity data = getItem(i);
        holder.content.setText("赞了这条微博");
        holder.meAvatar.setImageURI(Uri.parse(me.getAvatar()));
        holder.meNickname.setText("@" + me.getNickname());
        holder.oldContent.setText(data.getContent_body());
        holder.avatar.setImageURI(Uri.parse(data.getUser().getUser_head()));
        holder.nickname.setText(data.getUser().getNickname());
        holder.posttime.setVisibility(View.GONE);
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {
        @InjectView(R.id.avatar)
        SimpleDraweeView avatar;
        @InjectView(R.id.nickname)
        TextView nickname;
        @InjectView(R.id.posttime)
        TextView posttime;
        @InjectView(R.id.btn_reply)
        ImageView btnReply;
        @InjectView(R.id.content)
        TextView content;
        @InjectView(R.id.me_avatar)
        SimpleDraweeView meAvatar;
        @InjectView(R.id.me_nickname)
        TextView meNickname;
        @InjectView(R.id.old_content)
        TextView oldContent;

        public ViewHolder(View v) {
            super(v);
            ButterKnife.inject(this, v);
        }
    }

}


package org.henjue.jingjie.model.response;

public class LikeResonse  extends BaseResponse{

    private DataEntity data;


    public void setData(DataEntity data) {
        this.data = data;
    }

    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * is_praise : 1
         */
        private int is_praise;

        public void setIs_praise(int is_praise) {
            this.is_praise = is_praise;
        }
        public boolean isLike(){
            return is_praise!=0;
        }
        public int getIs_praise() {
            return is_praise;
        }
    }
}

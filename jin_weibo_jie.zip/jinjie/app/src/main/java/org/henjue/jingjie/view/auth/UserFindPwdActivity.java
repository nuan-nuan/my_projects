package org.henjue.jingjie.view.auth;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.network2.ErrorUtils;
import org.henjue.jingjie.network2.Network;
import org.henjue.jingjie.network2.service.AuthService;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by henjue on 2015/5/24.
 */
public class UserFindPwdActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher, Callback<ToastResponse> {
    @InjectView(R.id.btn_back)
    TextView mBtnBack;
    @InjectView(R.id.edit_pass1)
    EditText mEditPass1;
    @InjectView(R.id.edit_pass2)
    EditText mEditPass2;
    @InjectView(R.id.btn_next)
    Button mBtnNext;
    private String phone;
    private AuthService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        service=Network.getService(AuthService.class);
        phone = getIntent().getStringExtra("phone");
        setContentView(R.layout.user_find_pwd_activity);
        ButterKnife.inject(this);
        mEditPass1 = (EditText) findViewById(R.id.edit_pass1);
        mEditPass2 = (EditText) findViewById(R.id.edit_pass2);
        mBtnNext = (Button) findViewById(R.id.btn_next);
        mBtnNext.setOnClickListener(this);
        mEditPass1.addTextChangedListener(this);
        mEditPass2.addTextChangedListener(this);
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBack(null);
        }
        return super.onKeyDown(keyCode, event);
    }
    @OnClick({R.id.btn_back})
    void onBack(View f) {
        Intent intent = new Intent(this, UserLoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
        startActivity(intent);
        overridePendingTransition(R.anim.default_exit_in, R.anim.default_exit_out);
        finish();
    }
    @Override
    public void onClick(View v) {
        Editable pass1 = mEditPass1.getText();
        if (TextUtils.isEmpty(pass1)) {
            Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
            return;
        }
        Editable pass2 = mEditPass2.getText();
        if (TextUtils.isEmpty(pass2)) {
            Toast.makeText(this, "请输入确认密码", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!pass1.toString().equals(pass2.toString())) {
            Toast.makeText(this, "两次密码输入一样", Toast.LENGTH_SHORT).show();
            return;
        }
        service.resetpwd(phone,pass1.toString(),pass2.toString(),this);

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        mBtnNext.setEnabled(
                !TextUtils.isEmpty(mEditPass1.getText()) &&
                !TextUtils.isEmpty(mEditPass2.getText()));
    }

    @Override
    public void start() {

    }

    @Override
    public void success(ToastResponse res, Response response) {
        if (res.getStatus()== 0) {
            Toast.makeText(this, "重置成功", Toast.LENGTH_SHORT).show();
            onBack(null);
        } else {
            Toast.makeText(this, res.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void failure(HNetError hNetError) {
        ErrorUtils.checkError(this, hNetError);
    }

    @Override
    public void end() {

    }
}

package org.henjue.jingjie.view.user;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.UserListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by henjue on 2015/5/24.
 */
public class UserListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, JsonResponseListener, UserListAdapter.OnActionListener, UserListAdapter.onShowListener {
    private static final String LOG_TAG = UserListFragment.class.getName();
    @InjectView(R.id.lb_title)
    TextView mLbTitle;
    private RecyclerView mRecyclerView;
    private UserListAdapter adapter;
    private SwipeRefreshLayout mSwipeRefresh;
    private HBaseLinearLayoutManager mLayoutManager;
    private int page = 1;
    private onBuildRequest buildRequestListener;

    public static UserListFragment newInstance(String title) {
        UserListFragment fragment = new UserListFragment();
        Bundle args = new Bundle();
        args.putString("title", title);
        fragment.setArguments(args);
        return fragment;
    }
    public UserListFragment(){
        adapter = new UserListAdapter(this);
    }
    @Override
    public void onShowHodler(UserListAdapter.ViewHolder holder) {
        if (buildRequestListener != null) {
            buildRequestListener.show(holder);
        }
        //follower
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }



    public interface onBuildRequest {
        void onBuild(JsonResponseListener listener, int page);
        void show(UserListAdapter.ViewHolder holder);

    }

    public void setOnBuildRequestListener(onBuildRequest buildRequest) {
        this.buildRequestListener = buildRequest;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.user_list, null, false);
        ButterKnife.inject(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        View btnBack = view.findViewById(R.id.btn_back);
        Bundle args = getArguments();
        if (args != null) {
            String title = args.getString("title");
            if (title != null) {
                mLbTitle.setText(title);
            }
        }
        ViewCompat.setTransitionName(view.findViewById(R.id.title_container), "title");
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.finishAfterTransition(UserListFragment.this.getActivity());
            }
        });
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefresh);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager = new HBaseLinearLayoutManager(getActivity());
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        mSwipeRefresh.setRefreshing(true);
        refresh();
    }
    public void setOnListener(UserListAdapter.OnActionListener listener){
        adapter.setListener(listener);
    }
    private void refresh() {
        if (buildRequestListener != null) {
            buildRequestListener.onBuild(this, page);
        }
    }

    @Override
    public void onRefresh() {
        page = 1;
        refresh();
    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
        LogUtils.i(LOG_TAG, JsonFormatTool.formatJson(json.toString()));
        try {
            if (json.getInt("status") == 0) {
                JSONArray jsonArray = json.getJSONObject("data").getJSONArray("list");
                Gson gson = new Gson();
                ArrayList<User> datas = new ArrayList<User>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    User item = gson.fromJson(jsonArray.getJSONObject(i).toString(), User.class);
                    datas.add(item);
                }
                adapter.reload(datas, page != 1);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getActivity(), json.getString("message"), Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
    }

    @Override
    public void onItem(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
    }

    @Override
    public void onBtnAdd(final UserListAdapter adapter, View view, final UserListAdapter.ViewHolder holder) {
        RequestBuilder builder = RequestBuilder.create(this, Constants.Api.FRIEND_ADD);
        builder.addParams("friend_id", holder.data.getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if (json.getInt("status") == 0) {
                        adapter.notifyItemRemoved(holder.getPosition());
                    }
                    Toast.makeText(getActivity(), json.getString("message"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {

            }
        });
    }

    @Override
    public void onAvatar(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        Intent intent =TargetUserHomeActivity.create(getActivity(),holder.data);
        Pair<View, String> photo = Pair.create((View) holder.mUserAvatar, "user_photo");
        Pair<View, String> nickname = Pair.create((View) holder.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(), nickname, photo);
        ActivityCompat.startActivity(getActivity(), intent, options.toBundle());
    }
}

package org.henjue.jingjie.view.user;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import org.henjue.jingjie.adapter.UserListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by henjue on 2015/5/24.
 */
public class TargetUserFollowingListActivity extends AppCompatActivity implements UserListFragment.onBuildRequest, UserListAdapter.OnActionListener {
    private UserListFragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragment = UserListFragment.newInstance("全部关注");
        fragment.setOnListener(this);
        fragment.setOnBuildRequestListener(this);
        getSupportFragmentManager().beginTransaction().replace(android.R.id.content, fragment).commit();
    }
    public static Intent create(Context context,String uid){
        Intent intent = new Intent(context, TargetUserFollowingListActivity.class);
        intent.putExtra("uid", uid);
        return intent;
    }
    @Override
    public void onBuild(JsonResponseListener listener, int page) {
        RequestBuilder builder=RequestBuilder.create(this, Constants.Api.FRIEND_FOLLOWING);
        builder.addParams("gt",1).addParams("user_id",getIntent().getStringExtra("uid"));
        builder.get(listener);
    }

    @Override
    public void show(UserListAdapter.ViewHolder holder) {

    }

    @Override
    public void onItem(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {

    }

    @Override
    public void onBtnAdd(final UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        int isfollower = holder.data.getIsfollower();
        if(isfollower ==0) {
            fragment.onBtnAdd(adapter, view, holder);
        }else if(isfollower ==1 || isfollower==3){
            Toast.makeText(this,"取消关注",Toast.LENGTH_SHORT).show();
            RequestBuilder builder=RequestBuilder.create(this,Constants.Api.FRIEND_DEL);
            builder.addParams("friend_id",holder.data.getId());
            builder.post(new JsonResponseListener() {
                @Override
                public void onSuccess(JSONObject json, String url, int actionId) {
                    try {
                        Toast.makeText(TargetUserFollowingListActivity.this,json.getString("message"),Toast.LENGTH_SHORT).show();
                        if(json.getInt("status")==0){
                            fragment.onRefresh();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onRequest() {

                }

                @Override
                public void onError(Exception errorMsg, String url, int actionId) {

                }
            });
        }
    }

    @Override
    public void onAvatar(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        fragment.onAvatar(adapter,view,holder);
    }
}

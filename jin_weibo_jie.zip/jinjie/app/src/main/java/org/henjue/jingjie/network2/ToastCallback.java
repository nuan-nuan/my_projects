package org.henjue.jingjie.network2;

import android.content.Context;
import android.widget.Toast;

import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;

public class ToastCallback implements Callback<ToastResponse> {
    private final Context mContext;
    public ToastCallback(Context context){
        this.mContext=context;
    }
    @Override
    public void start() {

    }

    @Override
    public void success(ToastResponse toastResponse, Response response) {
        Toast.makeText(mContext, toastResponse.getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void failure(HNetError hNetError) {
        ErrorUtils.checkError(mContext,hNetError);
    }

    @Override
    public void end() {

    }
}

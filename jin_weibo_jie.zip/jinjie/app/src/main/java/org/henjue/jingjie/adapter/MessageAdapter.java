package org.henjue.jingjie.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.model.MessageEntry;
import org.henjue.jingjie.utils.LogUtils;


/**
 * Created by android on 4/15/15.
 */
public class MessageAdapter extends AbstractAdapter<MessageEntry,RecyclerView.ViewHolder> {
    private final onKindActionListener mKindListener;
    private final onItemActionListener mItemListener;

    public MessageAdapter(onKindActionListener mKindListener,onItemActionListener mItemListener){
        this.mKindListener = mKindListener;
        this.mItemListener=mItemListener;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        LogUtils.d(MessageAdapter.class.getName(),"onCreateViewHolder.viewType=%d",viewType);
        switch (viewType){
            case MessageEntry.TYPE_HEADER_AT:
            case MessageEntry.TYPE_HEADER_COMMENT:
            case MessageEntry.TYPE_HEADER_LIKED:
                return new HeadViewHolder(inflater.inflate(R.layout.fragment_message_kind,null,false), mKindListener);
            case MessageEntry.TYPE_NORMAL:
                return new ItemViewHolder(inflater.inflate(R.layout.fragment_message_item,null,false),mItemListener);
            default:
                throw new IllegalArgumentException("error viewType !");
        }
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getViewType();
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()){
            case MessageEntry.TYPE_HEADER_AT: {
                TextView mLable = (TextView)holder.itemView.findViewById(R.id.lable);
                mLable.setText(R.string.message_kind_atme);
                mLable.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_message_atme,0,0,0);
                break;
            }
            case MessageEntry.TYPE_HEADER_COMMENT: {
                TextView mLable = (TextView) holder.itemView.findViewById(R.id.lable);
                mLable.setText(R.string.message_kind_comment);
                mLable.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_message_comment, 0, 0, 0);
                break;
            }
            case MessageEntry.TYPE_HEADER_LIKED:
                TextView mLable = (TextView)holder.itemView.findViewById(R.id.lable);
                mLable.setText(R.string.message_kind_liked);
                mLable.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_message_liked,0,0,0);
                break;
            case MessageEntry.TYPE_NORMAL:
                ((ItemViewHolder)holder).bindData((MessageEntry.ItemNormalEntry)getItem(position));
                break;
            default:
                throw new IllegalArgumentException("error viewType !");
        }
    }
    public interface onKindActionListener {
        void onClickAtMe(View v,HeadViewHolder holder);
        void onClickCommentMe(View v,HeadViewHolder holder);
        void onClickLikedMe(View v,HeadViewHolder holder);
    }
    public interface onItemActionListener {
        void onItem(View v,ItemViewHolder holder);
        void onUserPhoto(View v,ItemViewHolder holder);
    }
    public class HeadViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final onKindActionListener listener;

        public HeadViewHolder(View itemView,onKindActionListener listener) {
            super(itemView);
            this.listener=listener;
            if(listener!=null){
                itemView.setOnClickListener(this);
            }
        }

        @Override
        public void onClick(View v) {
            switch (getItemViewType()){
                case MessageEntry.TYPE_HEADER_AT:
                    listener.onClickAtMe(v,this);
                    break;
                case MessageEntry.TYPE_HEADER_COMMENT:
                    listener.onClickCommentMe(v,this);
                    break;
                case MessageEntry.TYPE_HEADER_LIKED:
                    listener.onClickLikedMe(v,this);
                    break;
            }
        }
    }
    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final onItemActionListener listener;
        private final TextView mNickname;
        private final SimpleDraweeView mUserAvatar;
        private final TextView mFirstMessage;
        public MessageEntry.ItemNormalEntry data;

        public ItemViewHolder(View itemView, onItemActionListener mItemListener) {
            super(itemView);
            this.listener=mItemListener;
            mNickname=(TextView)itemView.findViewById(R.id.nickname);
            mUserAvatar=(SimpleDraweeView)itemView.findViewById(R.id.user_avatar);
            mFirstMessage=(TextView)itemView.findViewById(R.id.first_message);
            if(mItemListener!=null){
                itemView.setOnClickListener(this);
                mUserAvatar.setOnClickListener(this);
            }
        }
        public void bindData(MessageEntry.ItemNormalEntry data){
            this.data=data;
             mNickname.setText("用户"+data.getSenduid());
            mFirstMessage.setText(data.getMessagebody());
        }
        @Override
        public void onClick(View v) {
            if(v==itemView){
                listener.onItem(v,this);
            }else if(v==mUserAvatar){
                listener.onUserPhoto(v,this);
            }
        }
    }
}

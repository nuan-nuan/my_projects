package org.henjue.jingjie.network2.service;

import org.henjue.library.hnet.anntoation.FormUrlEncoded;

@FormUrlEncoded
public interface UserService {
}

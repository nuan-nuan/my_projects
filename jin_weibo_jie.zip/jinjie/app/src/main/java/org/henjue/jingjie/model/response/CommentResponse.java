package org.henjue.jingjie.model.response;

import java.util.ArrayList;
import java.util.List;

public class CommentResponse extends BaseResponse{
    private DataSub data;

    public DataSub getData() {
        return data;
    }

    public void setData(DataSub data) {
        this.data = data;
    }

    public static class DataSub{
        List<DataEntry> data=new ArrayList<>();

        public List<DataEntry> getData() {
            return data;
        }

        public void setData(List<DataEntry> data) {
            this.data = data;
        }
    }
    public static class DataEntry{
        private int comment_id;
        private int content_id;
        private String comment_body;
        private long dataline;
        private int user_id;
        private String user_name;
        private String nickname;
        private String user_head;
        private int user_auth;

        public String getComment_body() {
            return comment_body;
        }

        public void setComment_body(String comment_body) {
            this.comment_body = comment_body;
        }

        public int getComment_id() {
            return comment_id;
        }

        public void setComment_id(int comment_id) {
            this.comment_id = comment_id;
        }

        public int getContent_id() {
            return content_id;
        }

        public void setContent_id(int content_id) {
            this.content_id = content_id;
        }

        public long getDataline() {
            return dataline;
        }

        public void setDataline(long dataline) {
            this.dataline = dataline;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public int getUser_auth() {
            return user_auth;
        }

        public void setUser_auth(int user_auth) {
            this.user_auth = user_auth;
        }

        public String getUser_head() {
            return user_head==null?"http://":user_head;
        }

        public void setUser_head(String user_head) {
            this.user_head = user_head;
        }

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }
    }
}

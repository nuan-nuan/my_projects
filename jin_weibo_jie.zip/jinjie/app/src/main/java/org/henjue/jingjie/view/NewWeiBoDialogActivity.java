package org.henjue.jingjie.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.view.weibo.CreateWeiboActivity;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import me.iwf.photopicker.PhotoPickerActivity;
import me.iwf.photopicker.utils.PhotoPickerIntent;

/**
 * Created by henjue on 2015/5/24.
 */
public class NewWeiBoDialogActivity extends AppCompatActivity {
    @InjectView(R.id.new_post_text)
    TextView mNewPostText;
    @InjectView(R.id.new_post_pic)
    TextView mNewPostPic;
    @InjectView(R.id.cover)
    LinearLayout mCover;
    @InjectView(R.id.ic_del)
    ImageView mIcDel;
    private static final int REQUEST_SELECT_PHOTO=0x2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newweinbo_dialog);
        ButterKnife.inject(this);
    }

    @OnClick({R.id.new_post_text,R.id.new_post_pic})
    void startNewWeibo(View v){
        if(v.getId()==R.id.new_post_pic){
            PhotoPickerIntent intent = new PhotoPickerIntent(NewWeiBoDialogActivity.this);
            intent.setPhotoCount(9);
            intent.setShowCamera(true);
            startActivityForResult(intent, REQUEST_SELECT_PHOTO);
        }else {
            Intent intent = new Intent(this, CreateWeiboActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
            startActivity(intent);
            finish();
        }
    }
    @OnClick({R.id.ic_del})
    void hide() {
        finish();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data!=null && resultCode == RESULT_OK) {
            if(requestCode==REQUEST_SELECT_PHOTO){
                ArrayList<String> paths=(ArrayList)data.getSerializableExtra(PhotoPickerActivity.KEY_SELECTED_PHOTOS);
                Intent intent = new Intent(this, CreateWeiboActivity.class);
                intent.putExtra("img_urls", paths);
                intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                startActivity(intent);
                finish();
            }

        }
    }
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0,R.anim.bottom_out);
    }
}

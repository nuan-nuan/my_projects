package org.henjue.jingjie.network2.service;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.response.LoginResponse;
import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.anntoation.Field;
import org.henjue.library.hnet.anntoation.FormUrlEncoded;
import org.henjue.library.hnet.anntoation.Param;
import org.henjue.library.hnet.anntoation.Post;

@FormUrlEncoded
public interface AuthService {
    @Post(Constants.Api.USER_LOGIN)
    void login(@Param("loginname")String loginname,@Param("password")String password,Callback<LoginResponse> callback);

    @Post(Constants.Api.USER_RESETPWD)
    void reg(@Param("phone")String phone,@Field("nickname")String nickname,@Param("pass1")String pass1,@Param("pass2")String pass2,Callback<LoginResponse> callback);

    @Post(Constants.Api.USER_REGISTER)
    void resetpwd(@Param("phone")String phone,@Field("pass1")String pass1,@Param("pass2")String pass2,Callback<ToastResponse> callback);
}

package org.henjue.jingjie.common;

import org.henjue.jingjie.model.user.TargetUser;

/**
 * Description:
 * Date: 2015/6/14
 * Time: 16:34
 *
 * @author henjue
 *         email:henjue@ketie.me
 * @version 1.0
 */
public class UserSaveHelper {
    private static UserSaveHelper mInstance;
    private TargetUser user=new TargetUser();
    public static synchronized UserSaveHelper getInstance(){
        synchronized (UserSaveHelper.class) {
            if (mInstance == null) {
                mInstance = new UserSaveHelper();
            }
            return mInstance;
        }
    }

    public TargetUser getUser() {
        return user;
    }

    public void setUser(TargetUser user) {
        this.user = user;
    }
}

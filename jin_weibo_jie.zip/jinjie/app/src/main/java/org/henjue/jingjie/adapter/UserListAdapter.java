package org.henjue.jingjie.adapter;

import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.span.SpanFormat;

/**
 * Created by ligux on 2015/4/3.
 */
public class UserListAdapter extends AbstractAdapter<User,UserListAdapter.ViewHolder> {

    public void setListener(OnActionListener listener) {
        this.listener = listener;
    }

    private OnActionListener listener;
    private final onShowListener mOnShowListener;

    public interface onShowListener{
        void onShowHodler(UserListAdapter.ViewHolder holder);
    }
    public UserListAdapter(onShowListener onShowListener) {
        this.mOnShowListener=onShowListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.user_list_item,null,false),listener);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        User data = getItem(position);
        holder.bindData(data);
        if(mOnShowListener!=null){
            mOnShowListener.onShowHodler(holder);
        }

    }
    public final class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public final SimpleDraweeView mUserAvatar;
        public final TextView mNickname;
        public final TextView mNewTimeline;
        public final TextView mBtnAdd;
        private OnActionListener listener;


        public User data;

        public ViewHolder(View itemView,OnActionListener listener) {
            super(itemView);
            mUserAvatar=(SimpleDraweeView)itemView.findViewById(R.id.user_avatar);
            mNickname=(TextView)itemView.findViewById(R.id.nickname);
            mNewTimeline=(TextView)itemView.findViewById(R.id.new_timeline);
            mBtnAdd=(TextView)itemView.findViewById(R.id.add);
            if(listener!=null){
                this.listener=listener;
                mUserAvatar.setOnClickListener(this);
                itemView.setOnClickListener(this);
                mBtnAdd.setOnClickListener(this);
            }
        }
        public void bindData(User data ){
            this.data=data;
            mUserAvatar.setImageURI(Uri.parse(data.getAvatar()));
            mNickname.setText(data.getNickname());
            mNewTimeline.setText(SpanFormat.formatContent(data.getLastContent()).toString());
            int isfollower = data.getIsfollower();
            if(isfollower ==3) {
                mBtnAdd.setText("");
                mBtnAdd.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                mBtnAdd.setBackgroundResource(R.drawable.ic_follo_both);
            }else if (isfollower ==1){
                mBtnAdd.setText("");
                mBtnAdd.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                mBtnAdd.setBackgroundResource(R.drawable.ic_folloed);
            }
        }
        @Override
        public void onClick(View v) {
            if(v==itemView){
                listener.onItem(UserListAdapter.this, v,this);
            }else if(v==mBtnAdd){
                listener.onBtnAdd(UserListAdapter.this,v, this);
            }else if(v==mUserAvatar){
                listener.onAvatar(UserListAdapter.this,v,this);
            }
        }
    }
    public interface OnActionListener{
        void onItem(UserListAdapter adapter,View view,ViewHolder holder);
        void onBtnAdd(UserListAdapter adapter,View view, ViewHolder holder);
        void onAvatar(UserListAdapter adapter,View view,ViewHolder holder);
    }
}

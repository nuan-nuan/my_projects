package org.henjue.jingjie.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.Img;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.span.SpanFormat;
import org.henjue.jingjie.utils.RelativeDateFormat;

import java.util.List;


/**
 * Created by ligux on 2015/3/31.
 */
public class WeiboListAdapter extends AbstractAdapter<TimelineEntry,WeiboListAdapter.TimeViewHolder>{
    public static final int VIEW_TYPE_NORMAL = 0;
    public static final int VIEW_TYPE_HASFORWARD = 1;
    public static final int TIEM_TYPE_COUNT = 2;
    private final OnActionListener onActionListener;
    private boolean showPull=true;

    public WeiboListAdapter(Context context, OnActionListener onActionListener,boolean showPull) {
        this.onActionListener=onActionListener;
           this.showPull=showPull;
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getRetdata() == null ?VIEW_TYPE_NORMAL:VIEW_TYPE_HASFORWARD;
    }


    @Override
    public TimeViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        final View view;
        if(i==VIEW_TYPE_NORMAL){
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.timeline_list_item_normal,null,false);
        }else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.timeline_list_item_hasforward,null,false);
        }
        return new TimeViewHolder(view,onActionListener);
    }

    @Override
    public void onBindViewHolder(TimeViewHolder timeViewHolder, int i) {
        TimelineEntry data = getItem(i);
        timeViewHolder.mContent.setText(SpanFormat.formatContent(data.getContent()));
        timeViewHolder.mContent.setMovementMethod(LinkMovementMethod.getInstance());
        timeViewHolder.mNickname.setText(data.getAuthor().getNickname());
        long posttime = data.getPosttime()*1000;
        timeViewHolder.mPosttime.setText(RelativeDateFormat.format(posttime));
        String url = data.getAuthor().getAvatar();
        url=TextUtils.isEmpty(url)?"http:///":url;
        url=url.startsWith("http")?url: Constants.API_HOST+url;
        if(data.isPraise()){
            ((TextView)timeViewHolder.btnLike.getChildAt(0)).setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_liked, 0, 0, 0);
        }
        timeViewHolder.mAvatar.setImageURI(Uri.parse(url));
        if(getItemViewType(i)==VIEW_TYPE_NORMAL){
        }else{
            timeViewHolder.mOldContent.setMovementMethod(LinkMovementMethod.getInstance());
            timeViewHolder.mOldContent.setText(SpanFormat.formatContent("@"+data.getRetdata().getAuthor().getNickname()+":"+data.getRetdata().getContent()));
        }
        timeViewHolder.bindData(data);
        timeViewHolder.mBtnPull.setVisibility(showPull?View.VISIBLE:View.GONE);
    }
    public static final class TimeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final SimpleDraweeView mAvatar;
        public final TextView mContent;
        public final TextView mOldContent;
        public final TextView mNickname;
        public final TextView mPosttime;
        private final OnActionListener onClickListener;
        public final View mBtnPull;
        public final View root;
        public final View btnForward;
        public final View btnComment;
        public final FrameLayout btnLike;

        public TimelineEntry getData() {
            return data;
        }

        private TimelineEntry data;
        public TimeViewHolder(View v, OnActionListener onClickListener) {
            super(v);
            this.onClickListener=onClickListener;
            mAvatar = (SimpleDraweeView)v.findViewById(R.id.avatar);
            mNickname =(TextView)v.findViewById(R.id.nickname);
            mPosttime = (TextView)v.findViewById(R.id.posttime);
            mContent = (TextView)v.findViewById(R.id.content);
            mOldContent = (TextView)v.findViewById(R.id.old_content);
            mBtnPull=v.findViewById(R.id.btn_pull);
            this.root=v.findViewById(R.id.root);
            this.btnForward=v.findViewById(R.id.btn_forward);
            this.btnComment=v.findViewById(R.id.btn_comment);
            this.btnLike=(FrameLayout)v.findViewById(R.id.btn_like);

            if(onClickListener!=null) {
                root.setOnClickListener(this);
                mContent.setOnClickListener(this);
                mBtnPull.setOnClickListener(this);
                mAvatar.setOnClickListener(this);
                btnForward.setOnClickListener(this);
                btnComment.setOnClickListener(this);
                btnLike.setOnClickListener(this);
                v.setOnClickListener(this);
            }
        }
        public void bindData(TimelineEntry data){
            itemView.findViewById(R.id.imgs_grid2).setVisibility(View.GONE);
            itemView.findViewById(R.id.imgs_grid1).setVisibility(View.GONE);
            itemView.findViewById(R.id.imgs_grid0).setVisibility(View.GONE);
            this.data=data;
            List<Img> imgs;
            if(getItemViewType()==WeiboListAdapter.VIEW_TYPE_NORMAL){
                imgs = data.getImgs();
            }else{
                imgs = data.getRetdata().getImgs();
            }
            int size = imgs.size();
            if(size >6){
                itemView.findViewById(R.id.imgs_grid2).setVisibility(View.VISIBLE);
            }
            if(size >3){
                itemView.findViewById(R.id.imgs_grid1).setVisibility(View.VISIBLE);
            }
            if(size >0){
                itemView.findViewById(R.id.imgs_grid0).setVisibility(View.VISIBLE);
            }
            for(int i=0;i<9 ;i++){
                int id=itemView.getContext().getResources().getIdentifier("timeline_item_img_"+i,"id",itemView.getContext().getPackageName());
                SimpleDraweeView img = ((SimpleDraweeView) itemView.findViewById(id));
                img.setVisibility(View.GONE);
                if(i>=size)continue;
                String url= imgs.get(i).getUrl();
                if(url.startsWith("http")){

                }else{
                    url="http://weibo.joyousphper.com/"+url;
                }
                img.setVisibility(View.VISIBLE);
                img.setImageURI(Uri.parse(url));
            }

        }
        @Override
        public void onClick(View v) {
            if(v==btnForward){
                onClickListener.onClickForward(this);
            }
            if(v==btnComment){
                onClickListener.onClickComment(this);
            }
            if(v==btnLike){
                onClickListener.onClickLike(this);
            }
            if(v==mAvatar){
                onClickListener.onClickUserPhoto(this);
            }
            if(v==mBtnPull){
                onClickListener.onClickPull(this);
            }
            if(v==root || v==mContent){
                onClickListener.onItemClick(this,data,getPosition());
            }
        }
    }
    public interface OnActionListener{
        void onItemClick(TimeViewHolder holder,TimelineEntry data,int postion);
        /**
         * 点击转发按钮
         */
        void onClickForward(TimeViewHolder holder);

        /**
         * 点击评论按钮
         */
        void onClickComment(TimeViewHolder holder);

        /**
         * 点击赞按钮
         */
        void onClickLike(TimeViewHolder holder);

        /**
         * 点击右上角的下拉按钮
         * @param holder
         */
        void onClickPull(TimeViewHolder holder);

        /**
         * 点击用户头像
         * @param holder
         */
        void onClickUserPhoto(TimeViewHolder holder);
    }
}


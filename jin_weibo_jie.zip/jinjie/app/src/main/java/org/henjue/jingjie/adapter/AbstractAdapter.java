package org.henjue.jingjie.adapter;

import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by android on 5/2/15.
 */
public abstract class AbstractAdapter<IT,VH extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<VH> {
    private ArrayList<IT> datas=new ArrayList<IT>();
    public void reload(List<IT> datas,boolean append){
        if(!append){
            this.datas.clear();
        }
        this.datas.addAll(datas);
    }
    public void delete(int position){
        this.datas.remove(position);
        notifyItemRemoved(position);
    }

    public ArrayList<IT> getDatas() {
        return datas;
    }

    @Override
    public final int getItemCount() {
        return this.datas.size();
    }

    public final IT getItem(int position){
        return datas.get(position);
    }
}

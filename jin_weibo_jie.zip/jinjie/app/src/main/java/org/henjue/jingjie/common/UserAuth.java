package org.henjue.jingjie.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;


/**
 * Created by henjue on 2015/4/7.
 */
public class UserAuth {
    private static final String PREFERENCES_NAME = "_user_auth";
    private static final String KEY_LOGINNAME = "_loginname";
    private static final String KEY_UID = "_uid";
    private static final String KEY_TOKEN = "_token";
    public final String loginname;
    public final String uid;
    public final String token;

    public UserAuth(String token, String uid, String loginname) {
        this.uid=uid;
        this.token=token;
        this.loginname=loginname;
    }
    public static UserAuth read(Fragment fragment){
        return read(fragment.getActivity());

    }
    public static UserAuth read(Context context){
        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
        String uid = pref.getString(KEY_UID,"");
        String loginname = pref.getString(KEY_LOGINNAME, "");
        String token = pref.getString(KEY_TOKEN, "");
        return new UserAuth(token,uid, loginname);
    }
    public boolean isValiate(){
        return this.token!=null && !"".equals(this.token);
    }
    public void write(Context context){
        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(KEY_LOGINNAME, loginname);
        editor.putString(KEY_UID, uid);
        editor.putString(KEY_TOKEN, token);
        editor.commit();
    }
    private boolean isEmpty(String text){
        return text==null||text.length()<=0||text.equals("null");
    }
    public static void clear(Context context) {
        if (null == context) {
            return;
        }
        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(KEY_TOKEN);
        editor.commit();
    }
}

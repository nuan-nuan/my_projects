package org.henjue.jingjie.view.auth;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.AuthRedirect;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.response.LoginResponse;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.network2.ErrorUtils;
import org.henjue.jingjie.network2.Network;
import org.henjue.jingjie.network2.service.AuthService;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;

/**
 * Created by henjue on 15/4/9.
 */
public class UserLoginActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher, Callback<LoginResponse> {
    private static final String LOG_TAG = UserLoginActivity.class.getName();
    private EditText mEditLoginname;
    private EditText mEditPassword;
    private Button mBtnLogin;
    private View mBtnReg;
    private SimpleDraweeView mAvatar;
    private TextView mLbLoginname;
    private UserAuth user;
    private View mBtnUseOther;
    private View mBtnFindPwd;
    private AuthService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        service=Network.getService(AuthService.class);
        mEditLoginname = (EditText)findViewById(R.id.edit_loginname);
        mLbLoginname = (TextView)findViewById(R.id.lb_loginname);
        mEditPassword = (EditText)findViewById(R.id.edit_password);
        mAvatar= (SimpleDraweeView)findViewById(R.id.avatar);
        mBtnLogin=(Button)findViewById(R.id.btn_login);
        mBtnUseOther=findViewById(R.id.btn_use_other);
        mBtnFindPwd=findViewById(R.id.btn_findPwd);
        mBtnUseOther.setOnClickListener(this);
        mBtnReg=findViewById(R.id.btn_reg);
        mBtnLogin.setOnClickListener(this);
        mBtnReg.setOnClickListener(this);
        mBtnFindPwd.setOnClickListener(this);
        mEditLoginname.addTextChangedListener(this);
        mEditPassword.addTextChangedListener(this);
        user = UserAuth.read(this);
        String loginname = user.loginname;
        LogUtils.i(LOG_TAG,loginname);
        if(!TextUtils.isEmpty(loginname)) {
            mAvatar.setImageURI(Uri.parse(UserSaveHelper.getInstance().getUser().getAvatar()));
            mLbLoginname.setText(loginname);
            mLbLoginname.setVisibility(View.VISIBLE);
            mBtnUseOther.setVisibility(View.VISIBLE);
            mEditLoginname.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        if(v==mBtnLogin) {
            RequestBuilder builder = new RequestBuilder(Constants.Api.USER_LOGIN);
            if(mEditLoginname.getVisibility()==View.VISIBLE) {
                builder.addParams("loginname", mEditLoginname.getText().toString());
                service.login( mEditLoginname.getText().toString(), mEditPassword.getText().toString(),this);
            }else{
                builder.addParams("loginname", user.loginname);
                service.login(user.loginname, mEditPassword.getText().toString(), this);
            }
        }else if(v==mBtnReg){
            Intent intent = new Intent(this, PhoneHandlerInputActivity.class);
            intent.putExtra("to",new Intent(this,UserRegFinalActivity.class));
            intent.putExtra("title","新用户注册");
            startActivity(intent);
            finish();
        }else if(v==mBtnUseOther){
//            mAvatar.setImageURI(Uri.parse("res://drawable/ic_default_avatar"));
            mLbLoginname.setVisibility(View.GONE);
            mEditLoginname.setVisibility(View.VISIBLE);
            v.setVisibility(View.GONE);
        }else if(v==mBtnFindPwd){
            Intent intent = new Intent(this, PhoneHandlerInputActivity.class);
            intent.putExtra("title","忘记密码");
            intent.putExtra("to",new Intent(this,UserFindPwdActivity.class));
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        final boolean enabled;
        if(mEditLoginname.getVisibility()==View.VISIBLE){
            enabled=!TextUtils.isEmpty(mEditLoginname.getText())&& !TextUtils.isEmpty(mEditPassword.getText());
         }else{
            enabled = !TextUtils.isEmpty(mEditPassword.getText());
         }
        mBtnLogin.setEnabled(enabled);
    }

    @Override
    public void start() {

    }

    @Override
    public void success(LoginResponse res, Response response) {
        int status=res.getStatus();
        if(status==0){
            Toast.makeText(UserLoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
            int uid=res.getData().getUserId();
            String loginname=res.getData().getUserName();
            String token=res.getData().getToken();
            new UserAuth(token,""+uid,loginname).write(UserLoginActivity.this);
            AuthRedirect.toHome(UserLoginActivity.this);
            finish();

        }else{
            Toast.makeText(UserLoginActivity.this,res.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void failure(HNetError hNetError) {
        ErrorUtils.checkError(this,hNetError);
    }

    @Override
    public void end() {

    }
}

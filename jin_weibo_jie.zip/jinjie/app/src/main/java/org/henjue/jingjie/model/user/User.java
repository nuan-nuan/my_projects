package org.henjue.jingjie.model.user;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by android on 5/2/15.
 */
public class User extends AbstractUser{
    @Override
    public int describeContents() {
        return super.describeContents();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
       super.writeToParcel(dest,flags);
    }

    protected User(Parcel in) {
        super(in);
    }
    public static final Creator<User> CREATOR = new Creator<User>() {
        public User createFromParcel(Parcel source) {
            return new User(source);
        }

        public User[] newArray(int size) {
            return new User[size];
        }
    };
}

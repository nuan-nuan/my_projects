package org.henjue.jingjie.view;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;

import org.henjue.jingjie.R;
import org.henjue.jingjie.widget.TitleView;

/**
 * Created by android on 2015/5/13.
 */
public abstract class AbstractActivity extends AppCompatActivity {
    private TitleView titleView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setContentView(int layoutResID) {
        setContentView(getLayoutInflater().inflate(layoutResID, null, false));
    }

    @Override
    public void setContentView(View view) {
        View titleView=getTitleView();
        if(titleView!=null){
            View root = getLayoutInflater().inflate(R.layout.activity_abstract, null, false);
            FrameLayout titleContainer=(FrameLayout)root.findViewById(R.id.title_container);
            FrameLayout contentContainer=(FrameLayout)root.findViewById(R.id.content_container);
            titleContainer.addView(titleView);
            contentContainer.addView(view);
            super.setContentView(root);
        }else{
            super.setContentView(view);
        }
    }

    /**
     *
     * @return
     */
    protected View getTitleView(){
        titleView = new TitleView(this);
        titleView.getCenterTitle().setText(onTitle());
        Drawable left = onLeft();
        Drawable right = onRight();
        if(left==null){
            titleView.getLeftBtn().setVisibility(View.GONE);
        }else{
            titleView.getLeftBtn().setVisibility(View.VISIBLE);
            titleView.getLeftBtn().setImageDrawable(left);
        }
        if(right==null){
            titleView.getRightBtn().setVisibility(View.GONE);
        }else{
            titleView.getRightBtn().setVisibility(View.VISIBLE);
            titleView.getRightBtn().setImageDrawable(right);
        }
        return titleView;
    }
    protected void setLeftListener(View.OnClickListener listener){
        if(titleView!=null){
            titleView.setLeftListener(listener);
        }
    }
    protected void setRightListener(View.OnClickListener listener){
        if(titleView!=null){
            titleView.setRightListener(listener);
        }
    }
    protected String onTitle(){
        return "";
    }
    protected Drawable onLeft(){
        return getResources().getDrawable(R.drawable.btn_back);
    }
    protected Drawable onRight(){
        return null;
    }
}


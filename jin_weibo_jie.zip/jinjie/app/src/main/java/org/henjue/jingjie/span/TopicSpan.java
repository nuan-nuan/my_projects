package org.henjue.jingjie.span;

import android.content.Context;
import android.view.View;


/**
 * Created by ligux on 2015/3/31.
 * 话题
 */
public class TopicSpan extends Span {
    public TopicSpan(String scheme, String content) {
        super(scheme, content, Type.TOPIC);
    }

    @Override
    public void onClick(View widget) {
        Context context = widget.getContext();
        //context.startActivity(new Intent(context, TopicActivity.class));
    }
}

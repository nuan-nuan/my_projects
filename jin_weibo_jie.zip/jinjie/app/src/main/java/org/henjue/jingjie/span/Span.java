package org.henjue.jingjie.span;

import android.text.TextPaint;
import android.text.style.ClickableSpan;


/**
 * Created by ligux on 2015/3/30.
 */
public abstract class Span extends ClickableSpan {
    public static enum Type {
        USER,
        TOPIC,
        WEB
    }

    public int getLength() {
        return content.length();
    }

    protected final Type type;
    protected final String content;

    protected final String scheme;

    public Span(String scheme, String content, Type type) {
        this.type = type;
        this.content = content;
        this.scheme = scheme;
    }

    @Override
    public void updateDrawState(TextPaint ds) {
        ds.setColor(ds.linkColor);
        ds.setUnderlineText(false);
    }
}

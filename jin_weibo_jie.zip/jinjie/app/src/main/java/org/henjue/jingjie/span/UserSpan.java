package org.henjue.jingjie.span;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;

/**
 * Created by ligux on 2015/3/31.
 */
public class UserSpan extends Span {
    public UserSpan(String scheme, String content) {
        super(scheme, content, Type.USER);
    }

    @Override
    public void onClick(View widget) {
        Context context = widget.getContext();
        TargetUser author=new TargetUser();
        author.setNickname(content);
        Intent intent = TargetUserHomeActivity.create(widget.getContext(),author);
        context.startActivity(intent);
    }
}

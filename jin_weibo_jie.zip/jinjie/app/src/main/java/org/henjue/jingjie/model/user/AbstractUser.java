package org.henjue.jingjie.model.user;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;

/**
 * Created by android on 5/2/15.
 */
public abstract class AbstractUser implements Parcelable {

    @SerializedName("user_id")
    protected String id;

    @SerializedName("nickname")
    protected String nickname;

    @SerializedName("user_head")
    protected String avatar;

    @SerializedName("lastcontent")
    protected String lastContent;

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    @SerializedName("user_gender")
    protected int sex=0;
    @SerializedName("city_name")
    protected String cityName;
    @SerializedName("mailadres")
    protected String email;
    public static String getSexText(AbstractUser user){
        return user.sex == 0 ? "女" : "男";
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    protected int isfollower;//0表示两者没有关系;1表示B收听A;2表示A收听B;3表示互相收听
    public int getIsfollower() {
        return isfollower;
    }

    public void setIsfollower(int isfollower) {
        this.isfollower = isfollower;
    }

    public String getLastContent() {
        return lastContent;
    }

    public void setLastContent(String lastContent) {
        this.lastContent = lastContent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAvatar() {
        return TextUtils.isEmpty(avatar) ?"http://":avatar.startsWith("http")?avatar: Constants.API_HOST+avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }



    public AbstractUser() {
    }
    public boolean isMe(Context context){
        TargetUser me = UserSaveHelper.getInstance().getUser();
        return me.getId().equals(this.id)|| me.nickname.equals(this.nickname);
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.nickname);
        dest.writeString(this.avatar);
        dest.writeString(this.lastContent);
        dest.writeInt(this.sex);
        dest.writeString(this.cityName);
        dest.writeString(this.email);
        dest.writeInt(this.isfollower);
    }

    protected AbstractUser(Parcel in) {
        this.id = in.readString();
        this.nickname = in.readString();
        this.avatar = in.readString();
        this.lastContent = in.readString();
        this.sex = in.readInt();
        this.cityName = in.readString();
        this.email = in.readString();
        this.isfollower = in.readInt();
    }
}

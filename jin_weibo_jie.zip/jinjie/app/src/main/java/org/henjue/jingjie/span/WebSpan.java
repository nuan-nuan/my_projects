package org.henjue.jingjie.span;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

/**
 * Created by ligux on 2015/3/31.
 */
public class WebSpan extends Span {
    public WebSpan(String scheme, String content) {
        super(scheme, content, Type.WEB);
    }

    @Override
    public void onClick(View widget) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(this.content));
        widget.getContext().startActivity(intent);

    }
}

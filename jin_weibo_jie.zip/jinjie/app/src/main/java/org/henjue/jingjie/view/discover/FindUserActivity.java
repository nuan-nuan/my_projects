package org.henjue.jingjie.view.discover;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.UserListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;


public class FindUserActivity extends AppCompatActivity implements TextWatcher, JsonResponseListener, SwipeRefreshLayout.OnRefreshListener, UserListAdapter.onShowListener, UserListAdapter.OnActionListener {

    private static final String LOG_TAG =FindUserActivity.class.getSimpleName() ;
    @InjectView(R.id.btn_back)
    ImageView mBtnBack;
    @InjectView(R.id.btn_refresh)
    ImageView mBtnRefresh;
    @InjectView(R.id.key_word)
    EditText mKeyWord;
    @InjectView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @InjectView(R.id.empty)
    TextView mEmpty;
    @InjectView(R.id.swipeRefresh)
    SwipeRefreshLayout mSwipeRefresh;
    private Handler searchHandler=new Handler();
    private SearchThread searchThread=new SearchThread();
    private int page=1;
    private HBaseLinearLayoutManager mLayoutManager;
    private UserListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_user);
        ButterKnife.inject(this);
        adapter=new UserListAdapter(this);
        adapter.setListener(this);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager = new HBaseLinearLayoutManager(this);
//        mRecyclerView.addItemDecoration(new ItemDecoration(mRecyclerView));
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                searchHandler.postDelayed(searchThread,1);
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        mKeyWord.addTextChangedListener(this);
        searchHandler.postDelayed(searchThread,1);
    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
        try {
            if(json.getInt("status")==0){
                JSONArray jarry = json.getJSONObject("data").getJSONArray("list");
                if(jarry.length()<=0){
                    mEmpty.setVisibility(View.VISIBLE);
                    mRecyclerView.setVisibility(View.GONE);
                }else{
                    mEmpty.setVisibility(View.GONE);
                    mRecyclerView.setVisibility(View.VISIBLE);
                    ArrayList<User> users=new ArrayList<User>();
                    Gson gson=new Gson();
                    for(int i=0;i<jarry.length();i++){
                        User user = gson.fromJson(jarry.getJSONObject(i).toString(), User.class);
                        users.add(user);
                    }
                    adapter.reload(users,false);
                    adapter.notifyDataSetChanged();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {
        mSwipeRefresh.setRefreshing(true);
    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
    }

    @Override
    public void onRefresh() {
        page=1;
        searchHandler.postDelayed(searchThread,1);
    }

    @Override
    public void onShowHodler(UserListAdapter.ViewHolder holder) {

    }

    @Override
    public void onItem(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {

    }

    @Override
    public void onBtnAdd(final UserListAdapter adapter,final  View view, final UserListAdapter.ViewHolder holder) {
        RequestBuilder builder = RequestBuilder.create(this, Constants.Api.FRIEND_ADD);
        builder.addParams("friend_id", holder.data.getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if (json.getInt("status") == 0) {
                        adapter.notifyItemRemoved(holder.getPosition());
                    }
                    Toast.makeText(FindUserActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {

            }
        });
    }

    @Override
    public void onAvatar(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        Intent intent = TargetUserHomeActivity.create(FindUserActivity.this, holder.data);
        Pair<View, String> photo = Pair.create((View) holder.mUserAvatar, "user_photo");
        Pair<View, String> nickname = Pair.create((View) holder.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(FindUserActivity.this, nickname, photo);
        ActivityCompat.startActivity(FindUserActivity.this, intent, options.toBundle());
    }

    private final class SearchThread extends Thread{
        @Override
        public void run() {
            RequestBuilder builder=RequestBuilder.create(FindUserActivity.this, Constants.Api.USER_SEARCH);
            builder.addParams("limit",20).addParams("",page);
            builder.addParams("wd",mKeyWord.getText().toString());
            builder.get(FindUserActivity.this);
        }
    }
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        searchHandler.removeCallbacks(searchThread);
        searchHandler.postDelayed(searchThread,2000);
    }
}

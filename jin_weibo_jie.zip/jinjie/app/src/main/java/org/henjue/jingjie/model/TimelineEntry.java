package org.henjue.jingjie.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.squareup.picasso.Target;

import org.henjue.jingjie.model.user.TargetUser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ligux on 2015/3/31.
 */
public class TimelineEntry implements Parcelable {


    public List<Img> getImgs() {
        return imgs;
    }

    public void setImgs(List<Img> imgs) {
        this.imgs = imgs;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getForwardContent() {
        return forwardContent;
    }

    public void setForwardContent(String forwardContent) {
        this.forwardContent = forwardContent;
    }

    public int getReposts_count() {
        return reposts_count;
    }

    public void setReposts_count(int reposts_count) {
        this.reposts_count = reposts_count;
    }

    public int getComments_count() {
        return comments_count;
    }

    public void setComments_count(int comments_count) {
        this.comments_count = comments_count;
    }

    public int getAttitudes_count() {
        return attitudes_count;
    }

    public void setAttitudes_count(int attitudes_count) {
        this.attitudes_count = attitudes_count;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public TimelineEntry getRetdata() {
        return retdata;
    }

    public void setRetdata(TimelineEntry retdata) {
        this.retdata = retdata;
    }

    public long getPosttime() {
        return posttime;
    }

    public void setPosttime(long posttime) {
        this.posttime = posttime;
    }

    public long getPraisetimes() {
        return praisetimes;
    }

    public void setPraisetimes(long praisetimes) {
        this.praisetimes = praisetimes;
    }

    public TargetUser getAuthor() {
        return author;
    }
    public void setAuthor(TargetUser author) {
        this.author = author;
    }

    private List<Img> imgs = new ArrayList<Img>();
    @SerializedName("content_body")
    private String content;
    private String forwardContent;
    private int reposts_count;
    private int comments_count;
    private int attitudes_count;
    @SerializedName("content_id")
    private int id;
    private TimelineEntry retdata;
    private long posttime;
    private long praisetimes;

    public boolean isPraise() {
        return praise!=0;
    }

    public void setPraise(boolean praise) {
        this.praise = praise?1:0;
    }

    @SerializedName("is_praise")
    private int praise;

    @SerializedName("user")
    private TargetUser author;

    public TimelineEntry() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(imgs);
        dest.writeString(this.content);
        dest.writeString(this.forwardContent);
        dest.writeInt(this.reposts_count);
        dest.writeInt(this.comments_count);
        dest.writeInt(this.attitudes_count);
        dest.writeInt(this.id);
        dest.writeParcelable(this.retdata, 0);
        dest.writeLong(this.posttime);
        dest.writeLong(this.praisetimes);
        dest.writeInt(this.praise);
        dest.writeParcelable(this.author, 0);
    }

    protected TimelineEntry(Parcel in) {
        this.imgs = in.createTypedArrayList(Img.CREATOR);
        this.content = in.readString();
        this.forwardContent = in.readString();
        this.reposts_count = in.readInt();
        this.comments_count = in.readInt();
        this.attitudes_count = in.readInt();
        this.id = in.readInt();
        this.retdata = in.readParcelable(TimelineEntry.class.getClassLoader());
        this.posttime = in.readLong();
        this.praisetimes = in.readLong();
        this.praise = in.readInt();
        this.author = in.readParcelable(Target.class.getClassLoader());
    }

    public static final Creator<TimelineEntry> CREATOR = new Creator<TimelineEntry>() {
        public TimelineEntry createFromParcel(Parcel source) {
            return new TimelineEntry(source);
        }

        public TimelineEntry[] newArray(int size) {
            return new TimelineEntry[size];
        }
    };
}

package org.henjue.jingjie.network2.service;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.response.CommentMeResponse;
import org.henjue.jingjie.model.response.CommentResponse;
import org.henjue.jingjie.model.response.LikeMeResponse;
import org.henjue.jingjie.model.response.LikeResonse;
import org.henjue.jingjie.model.response.TimelineListResponse;
import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.anntoation.Field;
import org.henjue.library.hnet.anntoation.FormUrlEncoded;
import org.henjue.library.hnet.anntoation.Get;
import org.henjue.library.hnet.anntoation.NoneEncoded;
import org.henjue.library.hnet.anntoation.Param;
import org.henjue.library.hnet.anntoation.Post;
import org.henjue.library.hnet.anntoation.Query;

@FormUrlEncoded
public interface TimelineService {
    /**
     * 微博列表
     * @param page
     * @param size
     * @param callback
     */
    @NoneEncoded
    @Get(Constants.Api.MESSAGES_FRIENDS)
    void list(@Query("p")int page,@Query("limit")int size,Callback<TimelineListResponse> callback);

    /**
     * 处理点赞
     * @param id
     * @param callback
     */
    @Post( Constants.Api.MESSAGES_PRAISE)
    void like(@Param("id")int id,Callback<LikeResonse> callback);


    /**
     * 取消关注
     * @param id
     * @param callback
     */
    @Post( Constants.Api.FRIEND_DEL)
    void deleteFriend(@Param("friend_id") String id, Callback<ToastResponse> callback);


    /**
     * 删除微博
     * @param id
     * @param callback
     */
    @Post(Constants.Api.MESSAGES_DEL)
    void deleteWeibo(@Param("id")int id,Callback<ToastResponse> callback);


    /**
     * @ 我的微博
     * @param page
     * @param size
     * @param type
     * @param callback
     */
    @NoneEncoded
    @Get(Constants.Api.COMMENT_ATME)
    void atMe(@Query("p")int page,@Query("limit")int size,@Query("t")String type,Callback<TimelineListResponse> callback);

    /**
     * 评论我的微博
     * @param page
     */
    @Get(Constants.Api.COMMENT_TOME)
    void commentMe(@Query("p")int page,Callback<CommentMeResponse> callback);


    /**
     * 赞我的微博
     * @param page
     */
    @NoneEncoded
    @Get(Constants.Api.COMMENT_LIKEDME)
    void likeMe(@Query("p")int page,@Query("limit")int size,@Query("t")String type,Callback<LikeMeResponse> callback);
}

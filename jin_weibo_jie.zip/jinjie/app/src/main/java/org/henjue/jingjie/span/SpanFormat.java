package org.henjue.jingjie.span;

import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.Spanned;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ligux on 2015/3/31.
 */
public class SpanFormat {
    public static Spanned formatContent(CharSequence text) {
        final SpannableStringBuilder ssb = new SpannableStringBuilder(text);
        //“^http://([w-]+.)+[w-]+(/[w-./?%&=]*)?$”
        //Pattern pattern = Pattern.compile("@[^\\s:：]+[:：\\s]|#([^\\#|.]+)#|http(s?)://(.*?)/\\w+/");//备份
        Pattern pattern = Pattern.compile("@[^\\s:：]+[:：\\s]|#([^\\#|.]+)#|http(s?)://(.*?)/\\w+/");
        final Matcher matcher = pattern.matcher(ssb);
        while (matcher.find()) {
            final String match = matcher.group();
            if (match.startsWith("@")) { //@某人，加亮字体
                String username = match;
                username = username.replace("@", "");
                username = username.replace(":", "");
                username = username.trim();
                UserSpan span = new UserSpan("@", username);
                ssb.setSpan(span, matcher.start(), matcher.end(), ssb.getSpanFlags(span));
            } else if (match.startsWith("#")) { //#某主题
                String theme = match;
                theme = theme.replace("#", "");
                theme = theme.trim();
                TopicSpan span = new TopicSpan("#", theme);
                ssb.setSpan(span, matcher.start(), matcher.end(), ssb.getSpanFlags(span));
            } else if (match.startsWith("http://")) { //匹配网址
                Uri uri = Uri.parse(match);
                WebSpan span = new WebSpan(uri.getScheme(), uri.toString());
                ssb.setSpan(span, matcher.start(), matcher.end(), ssb.getSpanFlags(span));
            }
        }
        return ssb;
    }
}

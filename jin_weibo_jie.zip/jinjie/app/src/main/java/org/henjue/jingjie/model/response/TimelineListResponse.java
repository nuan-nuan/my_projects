package org.henjue.jingjie.model.response;

import org.henjue.jingjie.model.TimelineEntry;

import java.util.ArrayList;
import java.util.List;

public class TimelineListResponse extends BaseResponse {
    private Lst data;

    public Lst getData() {
        return data;
    }

    public void setData(Lst data) {
        this.data = data;
    }

    public class Lst{
        private List<TimelineEntry> list=new ArrayList<TimelineEntry>();

        public List<TimelineEntry> getList() {
            return list;
        }

        public void setList(List<TimelineEntry> list) {
            this.list = list;
        }
    }
}

package org.henjue.jingjie.model.response;

public class ToastResponse extends BaseResponse {
}

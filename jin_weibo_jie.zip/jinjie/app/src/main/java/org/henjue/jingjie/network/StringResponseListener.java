package org.henjue.jingjie.network;

import com.android.http.RequestManager;

/**
 * Created by henjue on 2015/4/9.
 */
@Deprecated
public interface StringResponseListener extends RequestManager.RequestStringListener {
}

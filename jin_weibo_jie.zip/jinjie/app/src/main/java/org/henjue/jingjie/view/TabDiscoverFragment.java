package org.henjue.jingjie.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.view.discover.FindUserActivity;
import org.henjue.jingjie.view.weibo.HotWeiBoActivity;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Version 1.0
 * <p/>
 * Date: 2015-03-20 20:15
 * Author: alanchen@fit-start.co
 * <p/>
 * Copyright © 2014-2014 Shanghai Fit-start Network Technology Co., Ltd.
 */
public class TabDiscoverFragment extends Fragment {
    @InjectView(R.id.title_container)
    RelativeLayout mTitleContainer;
    @InjectView(R.id.hot_weibo)
    TextView mHotWeibo;
    @InjectView(R.id.find_user)
    TextView mFindUser;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_discover, null, false);
        ButterKnife.inject(this, view);
        return view;
    }
    @OnClick(R.id.hot_weibo)
    void onHotWeiboClick(View v){
        startActivity(new Intent(getActivity(), HotWeiBoActivity.class));
    }
    @OnClick(R.id.find_user)
    void onFindUserClick(View v){
        startActivity(new Intent(getActivity(), FindUserActivity.class));
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }
}

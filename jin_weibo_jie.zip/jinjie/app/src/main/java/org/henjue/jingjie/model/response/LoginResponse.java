package org.henjue.jingjie.model.response;

import org.henjue.jingjie.model.response.BaseResponse;

/**
 * Created by android on 15-7-6.
 */
public class LoginResponse  extends BaseResponse {


    /**
     * message : 登录成功
     * status : 0
     * data : {"token":"a45558f30ad2e69154401777f33ecf06","nickname":null,"userId":16,"userName":"15884421212","user_head":null}
     */
    private DataEntity data;


    public void setData(DataEntity data) {
        this.data = data;
    }

    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * token : a45558f30ad2e69154401777f33ecf06
         * nickname : null
         * userId : 16
         * userName : 15884421212
         * user_head : null
         */
        private String token;
        private String nickname;
        private int userId;
        private String userName;
        private String user_head;

        public void setToken(String token) {
            this.token = token;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public void setUser_head(String user_head) {
            this.user_head = user_head;
        }

        public String getToken() {
            return token;
        }

        public String getNickname() {
            return nickname;
        }

        public int getUserId() {
            return userId;
        }

        public String getUserName() {
            return userName;
        }

        public String getUser_head() {
            return user_head;
        }
    }
}

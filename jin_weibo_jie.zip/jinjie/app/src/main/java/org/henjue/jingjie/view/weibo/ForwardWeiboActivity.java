package org.henjue.jingjie.view.weibo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.user.FriendsListActivity;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *转发微博
 */
public class ForwardWeiboActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private static final String LOG_TAG = ForwardWeiboActivity.class.getName();
    private static final int REQUEST_AT_FRIEND =1001;//通过输入@弹出
    private static final int REQUEST_AT_FRIEND_BTN =1002;//通过@按钮
    private static final int REQUEST_OPEN_TYPE =1003;//选择公开类型
    private UserAuth user;
    private View mBtnBack;
    private View mBtnSend;
    private EditText mContent;
    private ArrayList<User> users =new ArrayList<User>();//at的用户列表
    private JsonResponseListener listener=new JsonResponseListener() {
        @Override
        public void onRequest() {

        }

        @Override
        public void onError(Exception e, String url, int actionId) {
            Log.e("newTextTimelineActivity",url,e);
        }

        @Override
        public void onSuccess(JSONObject jsonObject, String url, int actionId) {
            try {
                if(jsonObject.getInt("status")==0){
                    Toast.makeText(ForwardWeiboActivity.this,"修改成功",Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }else{
                    Toast.makeText(ForwardWeiboActivity.this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private View mBtnAt;
    private TimelineEntry entry;
    private TextView mOldWeibo;
    private TextView mOldAuthorNickname;
    private SimpleDraweeView mOldAuthorAvatar;
    private int openType=0;
    private TextView mBtnOpenType;
    private CheckBox mChkComment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user=UserAuth.read(this);
        entry = (TimelineEntry)getIntent().getParcelableExtra("weibo");
        setContentView(R.layout.activity_weibo_forward);
        mBtnBack=findViewById(R.id.btn_back);
        mBtnSend=findViewById(R.id.btn_send);
        mBtnAt=findViewById(R.id.btn_at);
        mOldWeibo=(TextView)findViewById(R.id.old_weibo);
        mOldAuthorAvatar=(SimpleDraweeView)findViewById(R.id.old_author_avatar);
        mOldAuthorNickname=(TextView)findViewById(R.id.old_author_nickname);

        mBtnOpenType = (TextView) findViewById(R.id.btn_isopen);
        mChkComment = (CheckBox) findViewById(R.id.chk_comment);
        mBtnOpenType.setOnClickListener(this);
        mContent=(EditText)findViewById(R.id.content);
        mBtnBack.setOnClickListener(this);
        mBtnAt.setOnClickListener(this);
        mBtnSend.setOnClickListener(this);
        mContent.addTextChangedListener(this);
        if(entry.getRetdata()!=null){
            mOldWeibo.setText(entry.getRetdata().getContent());
            mOldAuthorNickname.setText("@" + entry.getRetdata().getAuthor().getNickname());
            mOldAuthorAvatar.setImageURI(Uri.parse(entry.getRetdata().getAuthor().getAvatar()));
            mContent.setText("//@" + entry.getAuthor().getNickname() + ":" + entry.getContent());
        }else {
            mOldWeibo.setText(entry.getContent());
            mOldAuthorNickname.setText("@" + entry.getAuthor().getNickname());
            mOldAuthorAvatar.setImageURI(Uri.parse(entry.getAuthor().getAvatar()));
        }

//        mContent.setText();
//        mContent.setSelection(0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_send:
                doSend();
                break;
            case R.id.btn_isopen:
                Intent intent = new Intent(this, SelectShareLocationActivity.class);
                intent.putExtra("open_type", openType);
                startActivityForResult(intent, REQUEST_OPEN_TYPE);
                break;
            case R.id.btn_at:
                startActivityForResult(new Intent(this, FriendsListActivity.class),REQUEST_AT_FRIEND_BTN);
                break;
        }
    }

    private void doSend() {
        Editable content = mContent.getText();
        if(TextUtils.isEmpty(content)){
            Toast.makeText(this,"微博内容不能为空",Toast.LENGTH_SHORT).show();
        }else{
            String text=content.toString();

            RequestBuilder builder=new RequestBuilder(Constants.Api.MESSAGES_REPOST,user.token);
            builder.addParams("content", text);
            builder.addParams("iscomment",mChkComment.isChecked()?"1":"0");
            builder.addParams("open",openType);
            if(entry.getRetdata()!=null){
                builder.addParams("id", entry.getRetdata().getId());
            }else {
                builder.addParams("id", entry.getId());
            }
            builder.post(listener);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //LogUtils.i(LOG_TAG,"beforeTextChanged.text:%s,start:%d,count:%d,after:%d",s.toString(),start,count,after);
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        LogUtils.i(LOG_TAG,"onTextChanged.text:%s,start:%d,before:%d,count:%d",s.toString(),start,before,count);
        if(s.toString().endsWith("@")&& before==0 && count!=0) {
            startActivityForResult(new Intent(this, FriendsListActivity.class), REQUEST_AT_FRIEND);
        } else if(s.toString().endsWith("@")&& before!=0 && count==0){
            Editable text = mContent.getText();
            if(text.length()>=2) {
                text.delete(text.length() - 2, text.length());
            }else{
                text.delete(text.length() - 1, text.length());
            }
            Iterator<User> iterator = users.iterator();
            while(iterator.hasNext()){
                User user = iterator.next();
                boolean has=s.toString().contains(user.getNickname());
                if(!has) {
                    LogUtils.i(LOG_TAG, "从@列表中删除用户:%s", user.getNickname());
                    users.remove(user);
                }
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode==RESULT_OK){
            if(requestCode==REQUEST_AT_FRIEND||requestCode==REQUEST_AT_FRIEND_BTN) {
                User user = data.getParcelableExtra("user");
                this.users.add(user);
                if (requestCode == REQUEST_AT_FRIEND) {
                    mContent.getText().append(user.getNickname()+" ");
                } else if (requestCode == REQUEST_AT_FRIEND_BTN) {
                    mContent.getText().append("@" + user.getNickname()+ " ");
                }
            }else if(requestCode==REQUEST_OPEN_TYPE){
                this.openType=data.getIntExtra("open_type",0);
                mBtnOpenType.setText(data.getStringExtra("lable"));
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}


package org.henjue.jingjie.network2;

import android.app.Application;

import com.google.gson.Gson;

import org.henjue.jingjie.common.Constants;
import org.henjue.library.hnet.HNet;

public class Network {
    private static HNet net;
    public static void init(Application app){
        net=new HNet.Builder()
                .setEndpoint(Constants.API_HOST)
                .setIntercept(new RequestIntercept(app.getApplicationContext()))
                .setConverter(new GsonConverter(new Gson()))
                .build();
        net.setLogLevel(HNet.LogLevel.FULL);
    }
    public static <T> T getService(Class<T> clazz){
        return net.create(clazz);
    }
}

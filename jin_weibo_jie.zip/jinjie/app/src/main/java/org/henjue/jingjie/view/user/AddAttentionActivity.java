package org.henjue.jingjie.view.user;

import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;

import org.henjue.jingjie.adapter.UserListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;

/**
 * Created by ligux on 2015/4/3.
 * 添加关注
 */
public class AddAttentionActivity extends AppCompatActivity implements UserListFragment.onBuildRequest{
    private static final String LOG_TAG = AddAttentionActivity.class.getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UserListFragment fragment = new UserListFragment();
        fragment.setOnListener(fragment);
        fragment.setOnBuildRequestListener(this);
        getSupportFragmentManager().beginTransaction().replace(android.R.id.content, fragment).commit();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ActivityCompat.finishAfterTransition(AddAttentionActivity.this);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBuild(JsonResponseListener listener,int page) {
        RequestBuilder builder=new RequestBuilder(Constants.Api.USER_FOLLOWUSER, UserAuth.read(this).token);
        builder.addParams("p",page).addParams("limit", 10);
        builder.post(listener);
    }

    @Override
    public void show(UserListAdapter.ViewHolder holder) {
    }

}

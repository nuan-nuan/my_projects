package org.henjue.jingjie.view.user;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;

import org.henjue.jingjie.adapter.UserListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;

/**
 * Created by android on 15-5-6.
 */
public class FriendsListActivity extends AppCompatActivity implements UserListFragment.onBuildRequest, UserListAdapter.OnActionListener {
    private static final String LOG_TAG = FriendsListActivity.class.getName();
    private UserListFragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragment = UserListFragment.newInstance("好友列表");
        fragment.setOnListener(this);
        fragment.setOnBuildRequestListener(this);
        getSupportFragmentManager().beginTransaction().replace(android.R.id.content, fragment).commit();
    }
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ActivityCompat.finishAfterTransition(FriendsListActivity.this);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBuild(JsonResponseListener listener, int page) {
        RequestBuilder builder=RequestBuilder.create(this, Constants.Api.FRIEND_FOLLOWING);
        builder.addParams("gt",1);
        builder.post(listener);
    }

    @Override
    public void show(UserListAdapter.ViewHolder holder) {
        holder.mBtnAdd.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onItem(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        Intent data=new Intent();
        data.putExtra("user",holder.data);
        setResult(RESULT_OK,data);
        finish();
    }
    @Override
    public void onBtnAdd(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        fragment.onBtnAdd(adapter,view,holder);
    }

    @Override
    public void onAvatar(UserListAdapter adapter, View view, UserListAdapter.ViewHolder holder) {
        fragment.onAvatar(adapter,view,holder);
    }
}

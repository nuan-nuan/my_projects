package org.henjue.jingjie.view.auth;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.view.dialog.AlertDialog;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by henjue on 15/4/9.
 * 注册或找回密码第一步(输入手机号)
 */
public class PhoneHandlerInputActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher, AlertDialog.PositiveListener, AlertDialog.NegativeListener, JsonResponseListener {

    @InjectView(R.id.phoneNumber)
    EditText mPhoneNumber;
    @InjectView(R.id.btn_Next)
    Button mBtnNext;
    @InjectView(R.id.lb_title)
    TextView mLbTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reg);
        ButterKnife.inject(this);
        mBtnNext.setOnClickListener(this);
        mPhoneNumber.addTextChangedListener(this);
        mLbTitle.setText(getIntent().getStringExtra("title"));
    }

    @OnClick({R.id.btn_back})
    void onBack(View f) {
        Intent intent = new Intent(this, UserLoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
        startActivity(intent);
        overridePendingTransition(R.anim.default_exit_in, R.anim.default_exit_out);
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBack(null);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        Editable text = mPhoneNumber.getText();
        AlertDialog dialog = AlertDialog.newInstance("信息提示", "我们将发送验证码短信到这个号码:\n" + text.toString());
        dialog.setPositiveListener(this);
        dialog.setNegativeListener(this);
        dialog.show(getFragmentManager(), "dialog");
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        mBtnNext.setEnabled(!TextUtils.isEmpty(s));
    }

    @Override
    public void onPositiveClick(DialogInterface dialog) {
        RequestBuilder builder = new RequestBuilder(Constants.Api.USER_SENDCODE);
        builder.addParams("phone", mPhoneNumber.getText().toString());
        builder.post(this);
    }

    @Override
    public String positiveText() {
        return "确定";
    }

    @Override
    public void onNegativeClick(DialogInterface dialog) {
        dialog.dismiss();
    }

    @Override
    public String negativeText() {
        return "取消";
    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        try {
            int status = json.getInt("status");
            if (status == 0) {
                Intent intent = new Intent(this, InputValidateActivity.class);
                Intent to = getIntent().getParcelableExtra("to");
                intent.putExtra("to", to);
                intent.putExtra("phone", mPhoneNumber.getText().toString());
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(PhoneHandlerInputActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        Toast.makeText(PhoneHandlerInputActivity.this, errorMsg.getMessage(), Toast.LENGTH_SHORT).show();
    }
}

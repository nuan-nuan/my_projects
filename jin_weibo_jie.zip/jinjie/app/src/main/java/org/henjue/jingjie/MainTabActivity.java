package org.henjue.jingjie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.gson.Gson;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.FragmentTabAdapter;
import org.henjue.jingjie.view.NewWeiBoDialogActivity;
import org.henjue.jingjie.view.TabDiscoverFragment;
import org.henjue.jingjie.view.TabMeFragment;
import org.henjue.jingjie.view.TabMessageFragment;
import org.henjue.jingjie.view.TabWeiboListFragment;
import org.henjue.jingjie.view.auth.UserLoginActivity;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import me.iwf.photopicker.PhotoPickerActivity;

/**
 * 这种Tab实现方式是为了解决FragmentActivity 中Fragment生命周期问题
 */
public class MainTabActivity extends AppCompatActivity {
    private static final int REQUEST_NEW_TIMELINE = 0x1008;
    private FragmentTabHost tabhost;
    private RadioGroup radioGroup;
    public List<Fragment> fragments = new ArrayList<Fragment>();
    private TabWeiboListFragment timeLine;
    private TabMessageFragment messages;
    private TabDiscoverFragment discover;
    private TabMeFragment me;
    private FragmentTabAdapter tabAdapter;
    private UserAuth userAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        userAuth = UserAuth.read(this);
        if(!userAuth.isValiate()){
            startActivity(new Intent(this, UserLoginActivity.class));
            finish();
        }else {
            updateUserInfo();
            setContentView(R.layout.activity_main_tab);
            radioGroup = (RadioGroup) findViewById(android.R.id.tabs);
            timeLine = new TabWeiboListFragment();
            messages = new TabMessageFragment();
            discover = new TabDiscoverFragment();
            me = TabMeFragment.newInstance();
            fragments.add(timeLine);
            fragments.add(messages);
            fragments.add(discover);
            fragments.add(me);
            tabAdapter = new FragmentTabAdapter(this, fragments, R.id.tabcontent, radioGroup);
            tabAdapter.setOnRgsExtraCheckedChangedListener(new FragmentTabAdapter.OnRgsExtraCheckedChangedListener() {
                @Override
                public void OnRgsExtraCheckedChanged(RadioGroup radioGroup1, int checkedId, int index) {
                    if (index == 3) {
                        if(me.isResumed()){
                            me.refresh();
                        }
                    }
                }
            });
        }

    }

    private void updateUserInfo() {
        RequestBuilder builder = new RequestBuilder(this, Constants.Api.USER_INFO);
        builder.addParams("user_id", userAuth.uid);
        builder.get(listener);
    }
    private JsonResponseListener listener = new JsonResponseListener() {
        @Override
        public void onRequest() {
        }

        @Override
        public void onError(Exception e, String url, int actionId) {
        }

        @Override
        public void onSuccess(JSONObject jsonObject, String url, int actionId) {
            LogUtils.i(MainTabActivity.class.getSimpleName(), "Url:%s\nResult:\n%s", url, JsonFormatTool.formatJson(jsonObject));
            try {
                if (jsonObject.getInt("status") == 0) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    TargetUser user=new Gson().fromJson(data.toString(), TargetUser.class);
                    UserSaveHelper.getInstance().setUser(user);
                } else {
                    Toast.makeText(MainTabActivity.this, "获取用户信息失败", Toast.LENGTH_SHORT).show();
                    finish();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    public void onClick(View v){
        switch (v.getId()){
            case R.id.ic_del:
            case R.id.btn_newPost:
                startActivityForResult(new Intent(this, NewWeiBoDialogActivity.class), REQUEST_NEW_TIMELINE);
                overridePendingTransition(R.anim.bottom_in,0);
                break;
            case R.id.new_post_text: {
                startActivityForResult(new Intent(this, NewWeiBoDialogActivity.class), REQUEST_NEW_TIMELINE);
                overridePendingTransition(R.anim.bottom_in, 0);
                break;
            }
            case R.id.new_post_pic: {
                startActivityForResult(new Intent(this, NewWeiBoDialogActivity.class), REQUEST_NEW_TIMELINE);
                overridePendingTransition(R.anim.bottom_in, 0);
                break;
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            if(REQUEST_NEW_TIMELINE==requestCode){
                timeLine.onRefresh();
            }
        }else if(resultCode==RESULT_CANCELED){
            userAuth = UserAuth.read(this);
            if(!userAuth.isValiate()){
                finish();
            }
        }
    }




}

package org.henjue.jingjie.view.weibo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.AbstractAdapter;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.response.StringResponse;
import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network2.ErrorUtils;
import org.henjue.jingjie.network2.Network;
import org.henjue.jingjie.network2.ToastCallback;
import org.henjue.jingjie.network2.service.WeiBoService;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.dialog.AlertDialog;
import org.henjue.jingjie.view.user.FriendsListActivity;
import org.henjue.jingjie.widget.DividerGridItemDecoration;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;
import org.henjue.library.hnet.typed.TypedFile;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import me.iwf.photopicker.PhotoPagerActivity;
import me.iwf.photopicker.PhotoPickerActivity;
import me.iwf.photopicker.utils.PhotoPickerIntent;

/**
 * Created by henjue on 15/4/11.
 */
public class CreateWeiboActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private static final String LOG_TAG = CreateWeiboActivity.class.getName();
    private static final int REQUEST_AT_FRIEND = 1001;//通过输入@弹出
    private static final int REQUEST_AT_FRIEND_BTN = 1002;//通过@按钮
    private static final int REQUEST_OPEN_TYPE = 1003;//选择公开类型
    private static final int REQUEST_SELECT_PHOTO = 0x2000;
    @InjectView(R.id.btn_back)
    TextView mBtnBack;
    @InjectView(R.id.btn_send)
    TextView mBtnSend;
    @InjectView(R.id.content)
    EditText mContent;
    @InjectView(R.id.image_container)
    RecyclerView mImageContainer;
    @InjectView(R.id.btn_add_photo)
    ImageButton mBtnAddPhoto;
    @InjectView(R.id.btn_at)
    ImageButton mBtnAt;
    private UserAuth user;
    private ArrayList<User> users = new ArrayList<User>();//at的用户列表
    private ToastCallback listener;

    private int openType = 0;
    private List<ViewEntry> viewEntries = new ArrayList<>();
    private PhotoAdapter adapter;
    private ArrayList<String> img_urls=new ArrayList();
    private AlertDialog dialog;
    private WeiBoService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listener= new ToastCallback(this) {
            @Override
            public void start() {
                super.start();
            }

            @Override
            public void success(ToastResponse res, Response response) {
                if (res.getStatus() == 0) {
                    Toast.makeText(CreateWeiboActivity.this, "发布成功", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(CreateWeiboActivity.this, res.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void failure(HNetError hNetError) {
                super.failure(hNetError);
            }

            @Override
            public void end() {
                mBtnSend.setEnabled(true);
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        };
        user = UserAuth.read(this);
        service=Network.getService(WeiBoService.class);
        setContentView(R.layout.activity_weibo_new);
        ButterKnife.inject(this);
        adapter=new PhotoAdapter();
        mBtnBack.setOnClickListener(this);
        mBtnAt.setOnClickListener(this);
        mBtnSend.setOnClickListener(this);
        mBtnAddPhoto.setOnClickListener(this);
        mContent.addTextChangedListener(this);
        GridLayoutManager layout = new GridLayoutManager(this, 3);
        mImageContainer.setLayoutManager(layout);
        mImageContainer.setAdapter(adapter);
        mImageContainer.addItemDecoration(new DividerGridItemDecoration(this));
        ArrayList img_urls = (ArrayList) getIntent().getSerializableExtra("img_urls");
        if(img_urls!=null) this.img_urls.addAll(img_urls);
        for(String url: this.img_urls){
            viewEntries.add(new ImageEntry(url));
        }
        if(this.img_urls.size()>0 && viewEntries.size()<9){
            viewEntries.add(new AddButtonEntry());
        }
        if(viewEntries.size()>0){
            mBtnAddPhoto.setVisibility(View.GONE);
            mImageContainer.setVisibility(View.VISIBLE);
        }else{
            mBtnAddPhoto.setVisibility(View.VISIBLE);
            mImageContainer.setVisibility(View.GONE);
        }
        adapter.reload(viewEntries,false);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_send:
                doSend();
                break;
            case R.id.btn_isopen:
                Intent intent = new Intent(this, SelectShareLocationActivity.class);
                intent.putExtra("open_type", openType);
                startActivityForResult(intent, REQUEST_OPEN_TYPE);
                break;
            case R.id.btn_at:
                startActivityForResult(new Intent(this, FriendsListActivity.class), REQUEST_AT_FRIEND_BTN);
                break;
            case R.id.btn_add_photo:
                PhotoPickerIntent intentPhoto = new PhotoPickerIntent(CreateWeiboActivity.this);
                intentPhoto.setPhotoCount(9);
                intentPhoto.setShowCamera(true);
                startActivityForResult(intentPhoto, REQUEST_SELECT_PHOTO);
                break;
        }
    }

    private void doSend() {
        Editable content = mContent.getText();
        if (TextUtils.isEmpty(content)) {
            Toast.makeText(this, "微博内容不能为空", Toast.LENGTH_SHORT).show();
        } else {
            String text = content.toString();

            SendHandler handler = new SendHandler();
            if (img_urls.size() > 0) {
                handler.sendEmptyMessage(SendHandler.SEND_IMG);
            } else {
                handler.sendEmptyMessage(SendHandler.SEND_TEXT);
            }
            dialog=AlertDialog.newInstance("发布中...","");
            dialog.show(getFragmentManager(), "sendDialog");
            mBtnSend.setEnabled(false);
        }
    }

    private final class SendHandler extends Handler {
        public static final int SEND_IMG = 1;
        public static final int SEND_IMG_END = 2;
        public static final int SEND_TEXT = 3;
        int index = 0;
        private ArrayList<String> resultImgs = new ArrayList<>();

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == SEND_IMG) {
                final File file = new File(img_urls.get(index));
                service.upload(new TypedFile("image/png", file), new org.henjue.library.hnet.Callback<StringResponse>() {
                    @Override
                    public void start() {

                    }

                    @Override
                    public void success(StringResponse res, Response response) {
                        if (res.getStatus() == 0) {
                            String data = res.getData();
                            resultImgs.add(data);
                            LogUtils.i(LOG_TAG, "第%d张图片上传成功：%s", index, file.toString());
                        } else {
                            LogUtils.i(LOG_TAG, "第%d张图片上传失败：%s.Message:%s", index, file.toString(), res.getMessage());
                        }
                        if (index + 1 < img_urls.size()) {
                            index++;
                            sendEmptyMessage(SEND_IMG);
                        } else {
                            sendEmptyMessage(SEND_IMG_END);
                        }
                    }

                    @Override
                    public void failure(HNetError hNetError) {
                        ErrorUtils.checkError(CreateWeiboActivity.this, hNetError);
                        if (index + 1 < img_urls.size()) {
                            index++;
                            sendEmptyMessage(SEND_IMG);
                        } else {
                            sendEmptyMessage(SEND_IMG_END);
                        }
                    }

                    @Override
                    public void end() {

                    }
                });
            } else {
                String value = mContent.getText().toString();
                if (msg.what == SEND_IMG_END) {
                    service.addimg(value,resultImgs,listener);
                    for (String img : resultImgs) {
                        LogUtils.i(LOG_TAG, "加入图片%s", img);
                    }
                } else if (msg.what == SEND_TEXT) {
                    service.addtext(value, listener);
                }
            }
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //LogUtils.i(LOG_TAG,"beforeTextChanged.text:%s,start:%d,count:%d,after:%d",s.toString(),start,count,after);
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
//        LogUtils.i(LOG_TAG,"onTextChanged.text:%s,start:%d,before:%d,count:%d",s.toString(),start,before,count);
        if (s.toString().endsWith("@") && before == 0 && count != 0) {
            startActivityForResult(new Intent(this, FriendsListActivity.class), REQUEST_AT_FRIEND);
        } else if (s.toString().endsWith("@") && before != 0 && count == 0) {
            Editable text = mContent.getText();
            if (text.length() >= 2) {
                text.delete(text.length() - 2, text.length());
            } else {
                text.delete(text.length() - 1, text.length());
            }
            Iterator<User> iterator = users.iterator();
            while (iterator.hasNext()) {
                User user = iterator.next();
                boolean has = s.toString().contains(user.getNickname());
                if (!has) {
                    LogUtils.i(LOG_TAG, "从@列表中删除用户:%s", user.getNickname());
                    users.remove(user);
                }
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_AT_FRIEND || requestCode == REQUEST_AT_FRIEND_BTN) {
                User user = data.getParcelableExtra("user");
                this.users.add(user);
                if (requestCode == REQUEST_AT_FRIEND) {
                    mContent.getText().append(user.getNickname() + " ");
                } else if (requestCode == REQUEST_AT_FRIEND_BTN) {
                    mContent.getText().append("@" + user.getNickname() + " ");
                }
            } else if (requestCode == REQUEST_OPEN_TYPE) {
                this.openType = data.getIntExtra("open_type", 0);
            } else if (requestCode == REQUEST_SELECT_PHOTO) {
                if(data!=null) {
                    ArrayList<String> paths = (ArrayList<String>) data.getSerializableExtra(PhotoPickerActivity.KEY_SELECTED_PHOTOS);
                    this.img_urls.clear();
                    viewEntries.clear();
                    this.img_urls.addAll(paths);
                    for (String url : img_urls) {
                        viewEntries.add(new ImageEntry(url));
                    }
                    if (img_urls.size() > 0 && viewEntries.size() < 9) {
                        viewEntries.add(new AddButtonEntry());
                    }
                    adapter.reload(viewEntries, false);
                    adapter.notifyDataSetChanged();
                }else{
                    this.img_urls.clear();
                    viewEntries.clear();
                    if (img_urls.size() > 0 && viewEntries.size() < 9) {
                        viewEntries.add(new AddButtonEntry());
                    }
                    adapter.reload(viewEntries, false);
                    adapter.notifyDataSetChanged();
                }
                if(viewEntries.size()>0){
                    mBtnAddPhoto.setVisibility(View.GONE);
                    mImageContainer.setVisibility(View.VISIBLE);
                }else{
                    mBtnAddPhoto.setVisibility(View.VISIBLE);
                    mImageContainer.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
    private class PhotoAdapter extends AbstractAdapter<ViewEntry,ViewHolder> {
        public static final int VIEW_TYPE_IMG=1;
        public static final int VIEW_TYPE_ADD=2;
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.img_item_layout,parent,false);
            switch (viewType){
                case VIEW_TYPE_ADD:
                    return new AddButtonHolder(itemView);
                case VIEW_TYPE_IMG:
                    return new ImageHolder(itemView);
                default:
                    throw new IllegalArgumentException("View Type Is Error");
            }
        }
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if(holder.getItemViewType()==VIEW_TYPE_ADD){
            }else{
                String url = ((ImageEntry) getItem(position)).url;
                holder.iv.setImageURI(Uri.fromFile(new File(url)));
                ((ImageHolder)holder).setUrl(url);
            }
        }

        @Override
        public int getItemViewType(int position) {
            return getItem(position).type;
        }
    }
    private class AddButtonHolder extends ViewHolder{


        public AddButtonHolder(View itemView) {
            super(itemView);
            iv.setImageResource(R.drawable.icon_addpic);
        }

        @Override
        public void onClick(View v) {
            PhotoPickerIntent intentPhoto = new PhotoPickerIntent(CreateWeiboActivity.this);
            intentPhoto.setPhotoCount(9);
            intentPhoto.setShowCamera(true);
            startActivityForResult(intentPhoto, REQUEST_SELECT_PHOTO);
        }
    }
    private class ImageHolder extends ViewHolder{
        private String url="";
        public ImageHolder(View itemView) {
            super(itemView);
        }
        public void setUrl(String url){
            this.url=url;
        }
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(v.getContext(), PhotoPagerActivity.class);
            intent.putExtra(PhotoPagerActivity.EXTRA_CURRENT_ITEM, getLayoutPosition());
            intent.putExtra(PhotoPagerActivity.EXTRA_PHOTOS, img_urls);
            startActivityForResult(intent, REQUEST_SELECT_PHOTO);
        }
    }
    private abstract class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView iv;
        public ViewHolder(View itemView) {
            super(itemView);
            iv=(ImageView)itemView.findViewById(R.id.img);
            iv.setOnClickListener(this);
        }
    }
    private abstract class ViewEntry{
        protected final int type;
        ViewEntry(int type){
                this.type=type;
            }
    }
    private class ImageEntry extends ViewEntry{
        public final String url;
        ImageEntry(String url) {
            super(PhotoAdapter.VIEW_TYPE_IMG);
            this.url=url;
        }

    }
    private class AddButtonEntry extends ViewEntry{
        AddButtonEntry() {
            super(PhotoAdapter.VIEW_TYPE_ADD);
        }
    }

}

package org.henjue.jingjie.network;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.android.http.RequestManager;
import com.android.http.RequestMap;

import org.henjue.jingjie.common.StreamWrapper;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.utils.MD5Util;
import org.json.JSONObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;



/**
 * Version 1.0
 * <p/>
 * Date: 2015-03-27 17:20
 */
@Deprecated
public class RequestBuilder {
    private static final String LOG_TAG = RequestBuilder.class.getSimpleName();
    private static final boolean DEBUG = true;
    private String path;
    private IdentityHashMap<String, String> params=new IdentityHashMap<String,String>();
    private IdentityHashMap<String, File> files=new IdentityHashMap<String,File>();
    private IdentityHashMap<String, StreamWrapper> streams=new IdentityHashMap<String,StreamWrapper>();
    private String token;
    public static RequestBuilder create(Fragment fragment,String path){
        return new RequestBuilder(fragment.getActivity(),path);
    }
    public static RequestBuilder create(Context context,String path){
            return new RequestBuilder(context,path);
    }
    public static RequestBuilder create(String path){
        return new RequestBuilder(path);
    }
    public static RequestBuilder create(String path, String token){
        return new RequestBuilder(path,token);
    }
    public static RequestBuilder create(String path, IdentityHashMap<String, String> params){
        return new RequestBuilder(path,params);
    }
    public static RequestBuilder create(String path, IdentityHashMap<String, String> params, String token){
        return new RequestBuilder(path,params,token);
    }
    public RequestBuilder(Context context,String path) {
        this(path, UserAuth.read(context).token);
    }

    public RequestBuilder(String path) {
        this(path,new IdentityHashMap<String, String>());
    }

    public RequestBuilder(String path, String token) {
        this(path,new IdentityHashMap<String, String>(),token);
    }

    public RequestBuilder(String path, IdentityHashMap<String, String> params) {
        this.path = path;
        this.params = params;
        this.token = null;
    }

    public RequestBuilder(String path, IdentityHashMap<String, String> params, String token) {
        this.path = path;
        this.params = params;
        this.token = token;
    }
    public RequestBuilder setPath(String path) {
        this.path = path;
        return this;
    }


    public RequestBuilder setParams(IdentityHashMap<String, String> params) {
        this.params = params;
        return this;
    }
    public RequestBuilder addParams(String key, int value) {
        this.params.put(new String(key), String.valueOf(value));
        return this;
    }
    public RequestBuilder addParams(String key, String value) {
        assert  value!=null;
        this.params.put(new String(key), value);
        return this;
    }
    public RequestBuilder addParams(String key, File file) {
        assert  file!=null;
        this.files.put(new String(key), file);
        return this;
    }
    public RequestBuilder addParams(String key, StreamWrapper file) {
        assert  file!=null;
        this.streams.put(new String(key), file);
        return this;
    }
    public RequestBuilder setToken(String token) {
        this.token = token;
        return this;
    }
    public void post(final JsonResponseListener listener){
        RequestMap data = new RequestMap(buildParams(), files);
        for(String key:streams.keySet()){
            StreamWrapper stream = streams.get(key);
            data.put(key,stream.stream,stream.filename);
        }
        RequestManager.getInstance().post(this.path, data,listener,new Random().nextInt());
    }
    public void get(final JsonResponseListener listener){
        Map<String, String> pars = buildParams();
        StringBuffer sb=new StringBuffer(this.path.indexOf("?")>=0?"":"?");
        for(String key:pars.keySet()) {
            sb.append(key).append("=").append(pars.get(key)).append("&");
        }
        RequestManager.getInstance().get(this.path+sb.toString(), listener, new Random().nextInt());
    }
    private Map<String, String> buildParams(){
        this.params.put("rand",String.valueOf(System.currentTimeMillis()/1000));
        this.params.put("debug","1");
        if (this.token != null) {
            this.params.put("token",token);
        }
        if (params != null) {
            String sig = getKey(params);
            if (DEBUG) {
                Log.d(LOG_TAG, "加密后的Sig："+sig);
            }
            if (sig != null) {
                params.put("sig", sig);
            }
        }
        if (DEBUG) {
            String info="Params:\n\r";
            for(String key:params.keySet()){
                 info+=String.format("%s=%s", key, params.get(key)+"\n\r");
            }
            LogUtils.d(LOG_TAG,info);
        }
        return params;
    }
    private String getKey(Map<String, String> params) {
        if (params == null || params.isEmpty()) {
            return null;
        }
        if (DEBUG) {
            StringBuffer sbLog=new StringBuffer();
            for (String key : params.keySet()) {
                sbLog.append(key).append(",");
            }
            Log.d(LOG_TAG, "排序前：" + sbLog.toString());
        }
        List<Map.Entry<String,String>> list = new ArrayList<Map.Entry<String,String>>(params.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Map.Entry<String, String> lhs, Map.Entry<String, String> rhs) {
                return lhs.getKey().compareTo(rhs.getKey());
            }
        });
        StringBuffer sb = new StringBuffer();
        if (DEBUG) {
            StringBuffer sbLog = new StringBuffer();
            try {
                for (Map.Entry<String,String> entry : list) {
                    String key=entry.getKey();
                    String value=entry.getValue();
                    sbLog.append(key).append(",");
                    sb.append(URLEncoder.encode(key,"UTF-8")+"="+URLEncoder.encode(value,"UTF-8")).append("&");
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            Log.d(LOG_TAG, "排序后："+sbLog.toString());
        }else{
            for (Map.Entry<String,String> entry : list) {
                String key=entry.getKey();
                String value=entry.getValue();
                sb.append(key+"="+value).append("&");
            }
        }
        String plaintext = sb.toString();
        plaintext = plaintext.endsWith("&") ? plaintext.substring(0, plaintext.length() - 1) : plaintext;
        plaintext+="749ab3b68632680660d776891751e812";
        if (DEBUG) {
            Log.d(LOG_TAG, "未加密的Sig："+plaintext);
        }
            return MD5Util.MD5(plaintext).toLowerCase();

    }

    public class MapKeyComparator implements Comparator<String> {
        public int compare(String str1, String str2) {
            return str1.compareTo(str2);
        }
    }
}

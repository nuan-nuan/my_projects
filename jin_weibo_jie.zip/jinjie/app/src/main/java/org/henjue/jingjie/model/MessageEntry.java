package org.henjue.jingjie.model;

/**
 * Created by android on 5/2/15.
 */
public abstract class MessageEntry {
    public static final int TYPE_NORMAL=0;

    public static final int TYPE_HEADER_AT=1;
    public static final int TYPE_HEADER_COMMENT=2;
    public static final int TYPE_HEADER_LIKED=3;

    public int getViewType() {
        return viewType;
    }

    private int viewType=-1;
    public MessageEntry(int viewType){
        this.viewType=viewType;
    }
    public boolean isNormal(){return viewType==TYPE_NORMAL;}

   public static final class  KindAtMeEntry extends MessageEntry{
        public KindAtMeEntry() {
            super(MessageEntry.TYPE_HEADER_AT);
        }
    }

    public static final class  KindCommentEntry extends MessageEntry{
        public KindCommentEntry() {
            super(MessageEntry.TYPE_HEADER_COMMENT);
        }
    }
    public static final class  KindLikedEntry extends MessageEntry{
        public KindLikedEntry() {
            super(MessageEntry.TYPE_HEADER_LIKED);
        }
    }
    public static final class  ItemNormalEntry extends MessageEntry{
        private String message_id;
        private String senduid;
        private String sendtouid;
        private String messagebody;
        private long sendtime;
        private int countall;

        public String getMessage_id() {
            return message_id;
        }

        public void setMessage_id(String message_id) {
            this.message_id = message_id;
        }

        public String getSenduid() {
            return senduid;
        }

        public void setSenduid(String senduid) {
            this.senduid = senduid;
        }

        public String getSendtouid() {
            return sendtouid;
        }

        public void setSendtouid(String sendtouid) {
            this.sendtouid = sendtouid;
        }

        public String getMessagebody() {
            return messagebody;
        }

        public void setMessagebody(String messagebody) {
            this.messagebody = messagebody;
        }

        public long getSendtime() {
            return sendtime;
        }

        public void setSendtime(long sendtime) {
            this.sendtime = sendtime;
        }

        public int getCountall() {
            return countall;
        }

        public void setCountall(int countall) {
            this.countall = countall;
        }

        public ItemNormalEntry() {
            super(MessageEntry.TYPE_NORMAL);
        }
    }
}

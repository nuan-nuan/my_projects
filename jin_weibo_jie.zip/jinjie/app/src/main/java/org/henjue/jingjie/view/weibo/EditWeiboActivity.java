package org.henjue.jingjie.view.weibo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.Img;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.user.User;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.user.FriendsListActivity;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *编辑微博
 */
public class EditWeiboActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private static final String LOG_TAG = EditWeiboActivity.class.getName();
    private static final int REQUEST_AT_FRIEND =1001;//通过输入@弹出
    private static final int REQUEST_AT_FRIEND_BTN =1002;//通过@按钮
    private UserAuth user;
    private View mBtnBack;
    private View mBtnSend;
    private EditText mContent;
    private ArrayList<User> users =new ArrayList<User>();//at的用户列表
    private JsonResponseListener listener=new JsonResponseListener() {
        @Override
        public void onRequest() {

        }

        @Override
        public void onError(Exception e, String url, int actionId) {
            Log.e("newTextTimelineActivity",url,e);
        }

        @Override
        public void onSuccess(JSONObject jsonObject, String url, int actionId) {
            try {
                if(jsonObject.getInt("status")==0){
                    Toast.makeText(EditWeiboActivity.this,"修改成功",Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }else{
                    Toast.makeText(EditWeiboActivity.this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private View mBtnAt;
    private TimelineEntry entry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user=UserAuth.read(this);
        entry = (TimelineEntry)getIntent().getParcelableExtra("weibo");
        setContentView(R.layout.activity_weibo_edit);
        mBtnBack=findViewById(R.id.btn_back);
        mBtnSend=findViewById(R.id.btn_send);
        mBtnAt=findViewById(R.id.btn_at);
        mContent=(EditText)findViewById(R.id.content);
        mBtnBack.setOnClickListener(this);
        mBtnAt.setOnClickListener(this);
        mBtnSend.setOnClickListener(this);
        mContent.addTextChangedListener(this);
        mContent.setText(entry.getContent());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_send:
                doSend();
                break;
            case R.id.btn_at:
                startActivityForResult(new Intent(this, FriendsListActivity.class),REQUEST_AT_FRIEND_BTN);
                break;
        }
    }

    private void doSend() {
        Editable content = mContent.getText();
        if(TextUtils.isEmpty(content)){
            Toast.makeText(this,"微博内容不能为空",Toast.LENGTH_SHORT).show();
        }else{
            String text=content.toString();
            RequestBuilder builder=new RequestBuilder(Constants.Api.MESSAGES_EDIT,user.token);
            List<Img> imgs = entry.getImgs();
            for(Img img:imgs){
                String url = img.getUrl();
                builder.addParams("imgs[]", url);
                LogUtils.i(LOG_TAG,"加入图片%s", url);
            }
            builder.addParams("content_body",text).addParams("from","android").addParams("open",0).addParams("id",entry.getId());
            builder.post(listener);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //LogUtils.i(LOG_TAG,"beforeTextChanged.text:%s,start:%d,count:%d,after:%d",s.toString(),start,count,after);
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        LogUtils.i(LOG_TAG,"onTextChanged.text:%s,start:%d,before:%d,count:%d",s.toString(),start,before,count);
        if(s.toString().endsWith("@")&& before==0 && count!=0) {
            startActivityForResult(new Intent(this, FriendsListActivity.class), REQUEST_AT_FRIEND);
        } else if(s.toString().endsWith("@")&& before!=0 && count==0){
            Editable text = mContent.getText();
            if(text.length()>=2) {
                text.delete(text.length() - 2, text.length());
            }else{
                text.delete(text.length() - 1, text.length());
            }
            Iterator<User> iterator = users.iterator();
            while(iterator.hasNext()){
                User user = iterator.next();
                boolean has=s.toString().contains(user.getNickname());
                if(!has) {
                    LogUtils.i(LOG_TAG, "从@列表中删除用户:%s", user.getNickname());
                    users.remove(user);
                }
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode==RESULT_OK){
            if(requestCode==REQUEST_AT_FRIEND||requestCode==REQUEST_AT_FRIEND_BTN) {
                User user = data.getParcelableExtra("user");
                this.users.add(user);
                if (requestCode == REQUEST_AT_FRIEND) {
                    mContent.getText().append(user.getNickname()+" ");
                } else if (requestCode == REQUEST_AT_FRIEND_BTN) {
                    mContent.getText().append("@" + user.getNickname()+ " ");
                }
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}

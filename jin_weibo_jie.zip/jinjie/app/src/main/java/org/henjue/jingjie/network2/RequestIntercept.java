package org.henjue.jingjie.network2;

import android.content.Context;

import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.utils.MD5Util;
import org.henjue.library.hnet.RequestFacade;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by android on 15-6-25.
 */
public class RequestIntercept implements org.henjue.library.hnet.RequestIntercept {
    private final Context mContext;

    public RequestIntercept(Context context){
        this.mContext=context;

    }
    private HashMap<String, String> params = new HashMap<>();


    private String getKey(Map<String, String> params) {
        if (params == null || params.isEmpty()) {
            return null;
        }

        List<Map.Entry<String,String>> list = new ArrayList<Map.Entry<String,String>>(params.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Map.Entry<String, String> lhs, Map.Entry<String, String> rhs) {
                return lhs.getKey().compareTo(rhs.getKey());
            }
        });
        StringBuffer sb = new StringBuffer();

            for (Map.Entry<String,String> entry : list) {
                String key=entry.getKey();
                String value=entry.getValue();
                sb.append(key+"="+value).append("&");
            }
        String plaintext = sb.toString();
        plaintext = plaintext.endsWith("&") ? plaintext.substring(0, plaintext.length() - 1) : plaintext;
        plaintext+="749ab3b68632680660d776891751e812";
        return MD5Util.MD5(plaintext).toLowerCase();
    }

    @Override
    public void onStart(RequestFacade request) {
        params.clear();
        this.params.put("rand",String.valueOf(System.currentTimeMillis()/1000));
        request.add("debug",1);
        if(mContext!=null){
            UserAuth auth = UserAuth.read(mContext);
            if(auth!=null || auth.token!=null){
                request.add("token",auth.token);
            }
        }

    }

    @Override
    public void onComplite(RequestFacade request) {
        String key = getKey(params);
        if (key != null) {
            params.put("sig", key);
            request.add("sig", key);
        }
    }

    @Override
    public void onAdd(String name, Object value) {

        if (value instanceof String || value instanceof Integer || value instanceof Boolean || value instanceof Long || value instanceof Float) {
            params.put(name, String.valueOf(value));
            LogUtils.i("RequestIntercept","add Params:%s",String.valueOf(value));
        }
    }
}

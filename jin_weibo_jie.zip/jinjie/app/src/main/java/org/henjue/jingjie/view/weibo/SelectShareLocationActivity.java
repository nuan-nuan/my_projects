package org.henjue.jingjie.view.weibo;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioGroup;

import org.henjue.jingjie.R;

/**
 * Created by henjue on 2015/5/26.
 */
public class SelectShareLocationActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_share_location);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.open_type);
        int open_type=getIntent().getIntExtra("open_type",0);
        switch (open_type){
            case 0:
                radioGroup.check(R.id.open_type_open);
                break;
            case 1:
                radioGroup.check(R.id.open_type_friends);
                break;
            case 2:
                radioGroup.check(R.id.open_type_onlymy);
                break;
        }


        radioGroup.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        Intent data=new Intent();
        switch (checkedId){
            case R.id.open_type_open:
                data.putExtra("open_type",0);
                data.putExtra("lable","公开");
                break;
            case R.id.open_type_friends:
                data.putExtra("open_type",1);
                data.putExtra("lable","朋友圈");
                break;
            case R.id.open_type_onlymy:
                data.putExtra("open_type",2);
                data.putExtra("lable","仅自己可见");
                break;
        }
        setResult(RESULT_OK,data);
        finish();
    }
}

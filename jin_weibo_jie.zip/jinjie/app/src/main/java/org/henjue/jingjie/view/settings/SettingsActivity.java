package org.henjue.jingjie.view.settings;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.AuthRedirect;
import org.henjue.jingjie.common.DataCleanManager;
import org.henjue.jingjie.common.UserAuth;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * 设置界面
 * Author by kevin.
 */
public class SettingsActivity extends Activity {
    private static final String TAG = "SettingsActivity";
    @InjectView(R.id.btn_back)
    TextView mBtnBack;
    @InjectView(R.id.clear_cache)
    TextView mClearCache;
    @InjectView(R.id.clear_cache_la)
    RelativeLayout mClearCacheLa;
    @InjectView(R.id.only_quesion)
    TextView mOnlyQuesion;
    @InjectView(R.id.question_gto)
    TextView mQuestionGto;
    @InjectView(R.id.log_out)
    Button mLogOut;
    @InjectView(R.id.textqiye)
    TextView mTextqiye;
    @InjectView(R.id.textuser)
    TextView mTextuser;
    @InjectView(R.id.server_info)
    TextView mServerInfo;
    //清除图片缓存
    private RelativeLayout clear_cache_la;
    //微博服务协议
    private TextView server_info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.inject(this);
        findView();
    }
    @OnClick(R.id.clear_cache_la)
    void cleanCache(View v){
        DataCleanManager.cleanExternalCache(this);
        DataCleanManager.cleanFiles(this);
        DataCleanManager.cleanInternalCache(this);
        Toast.makeText(this,"清理缓存成功",Toast.LENGTH_SHORT).show();
    }
    public void findView() {
        clear_cache_la = (RelativeLayout) findViewById(R.id.clear_cache_la);
        server_info = (TextView) findViewById(R.id.server_info);
    }

    @OnClick(R.id.log_out)
    void logout(View v) {
        UserAuth.clear(this);
        AuthRedirect.toHome(this, Intent.FLAG_ACTIVITY_CLEAR_TOP);
        finish();
    }

}

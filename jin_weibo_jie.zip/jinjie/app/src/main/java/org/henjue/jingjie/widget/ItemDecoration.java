package org.henjue.jingjie.widget;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by android on 4/22/15.
 */
public class ItemDecoration extends RecyclerView.ItemDecoration {
    private Drawable mDivider;
    private int height=-1;
    public ItemDecoration(RecyclerView recyclerView){
        mDivider=new ColorDrawable(Color.parseColor("#00000000"));
        height=25;
    }
    @Override
    public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
        int left = parent.getPaddingLeft();
        int right = parent.getWidth() - parent.getPaddingRight();
        int childCount = parent.getChildCount();
        for(int i=0;i < childCount;i++){
            View child = parent.getChildAt(i);
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)child.getLayoutParams();
            int top = child.getBottom() + layoutParams.bottomMargin;
            int bottom = top + (height==-1?mDivider.getIntrinsicHeight():height);
            mDivider.setBounds(left, top, right, bottom);
            mDivider.draw(c);
        }

//
//        int top = parent.getPaddingTop();
//        int bottom = parent.getHeight() - parent.getPaddingBottom();
//        int childCount = parent.getChildCount();
//        for(int i=0;i < childCount;i++){
//            View child = parent.getChildAt(i);
//            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)child.getLayoutParams();
//            int left = child.getRight() + layoutParams.rightMargin;
//            int right = left + mDivider.getIntrinsicWidth();
//            mDivider.setBounds(left, top, right, bottom);
//            mDivider.draw(c);
//        }

    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent,
                               RecyclerView.State state) {
        outRect.set(0, 0, 0, height==-1?mDivider.getIntrinsicHeight():height);
        //outRect.set(0, 0,  mDivider.getIntrinsicHeight(),0);
    }
}

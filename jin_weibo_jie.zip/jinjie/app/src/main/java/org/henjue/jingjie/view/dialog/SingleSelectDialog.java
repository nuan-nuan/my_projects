package org.henjue.jingjie.view.dialog;

import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by henjue on 2015/4/7.
 */
public class SingleSelectDialog extends DialogFragment {

    public void setnListener(DialogInterface.OnClickListener nListener) {
        this.nListener = nListener;
    }

    DialogInterface.OnClickListener nListener;
    public static SingleSelectDialog newInstance(String title, String[] items,int defaultIndex) {
        SingleSelectDialog adf = new SingleSelectDialog();
        Bundle bundle = new Bundle();
        bundle.putString("alert-title", title);
        bundle.putStringArray("alert-items", items);
        bundle.putInt("alert-index", defaultIndex);
        adf.setArguments(bundle);
        return adf;
    }
    public static SingleSelectDialog newInstance(String title, String[] items) {
        return newInstance(title,items,0);
    }


    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());
        builder.setTitle(getArguments().getString("alert-title"));
        builder.setSingleChoiceItems(getArguments().getStringArray("alert-items"), getArguments().getInt("alert-index"), nListener);
        return builder.create();
    }

}

package org.henjue.jingjie;

import android.app.Application;

import com.android.http.RequestManager;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.tencent.bugly.crashreport.CrashReport;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.network2.Network;


/**
 * Created by henjue on 15/4/6.
 */
public class JApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Network.init(this);
        if(!BuildConfig.DEBUG) {
            CrashReport.UserStrategy strategy = new CrashReport.UserStrategy(this);
            strategy.setAppReportDelay(5000);
            CrashReport.initCrashReport(this, "900003345", BuildConfig.DEBUG, strategy);  //初始化SDK
        }
        Fresco.initialize(this);
        RequestManager.getInstance().init(this).setHost(Constants.API_HOST);
    }


}

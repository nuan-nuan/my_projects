package org.henjue.jingjie.view.weibo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.Img;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.span.SpanFormat;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.utils.RelativeDateFormat;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.henjue.jingjie.widget.ViewPagerIndicator;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by android on 4/24/15.
 */
public class WeiboDetailsActivity extends Activity implements JsonResponseListener, ViewPagerIndicator.PageChangeListener, DetailsCommentAdapter.OnActionListener, View.OnClickListener {
    private static final String LOG_TAG = WeiboDetailsActivity.class.getName();
    private View mRoot;
    private SimpleDraweeView mAvatar;
    private TextView mNickname;
    private TextView mPosttime;
    private View mBtnFriend;
    private TextView mContent;
    private TimelineEntry entry;
    private TextView mLikedCount;
    private ViewPager mViewPager;
    private DetailsCommentAdapter commentAdapter;
    private DetailsCommentAdapter replyAdapter;
//    private TextView mReplyCount;
//    private TextView mCommentCount;
    private List<View> views=new ArrayList<View>();
    private RadioGroup vIndicatro;
    private TextView mReplyCount;
    private TextView mCommentCount;
    private static final int REQUEST_FORWARD = 0x1006;
    private static final int REQUEST_COMMENT = 0x1007;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        entry=getIntent().getParcelableExtra("weibo");
        setContentView(R.layout.activity_weibo_details);
        mRoot=findViewById(R.id.root);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.finishAfterTransition(WeiboDetailsActivity.this);
            }
        });
        findViewById(R.id.btn_forward).setOnClickListener(this);
        findViewById(R.id.btn_comment).setOnClickListener(this);
        findViewById(R.id.btn_like).setOnClickListener(this);
        mAvatar=(SimpleDraweeView)findViewById(R.id.avatar);
        mNickname=(TextView)findViewById(R.id.nickname);
        mReplyCount=(TextView)findViewById(R.id.reply_count);
        mCommentCount=(TextView)findViewById(R.id.comment_count);
        mLikedCount=(TextView)findViewById(R.id.liked_count);
        ViewCompat.setTransitionName(mAvatar, "avatar");
        ViewCompat.setTransitionName(mNickname, "nickname");
        mPosttime=(TextView)findViewById(R.id.posttime);
        mPosttime.setText(RelativeDateFormat.format(entry.getPosttime()));
        mBtnFriend=findViewById(R.id.btn_friend);
        mContent=(TextView)findViewById(R.id.content);
        vIndicatro=(RadioGroup)findViewById(R.id.id_indicator);
        mContent.setMovementMethod(LinkMovementMethod.getInstance());
        mContent.setText(SpanFormat.formatContent(entry.getContent()));


        List<Img> imgs;
        if(entry.getRetdata()==null){
            imgs = entry.getImgs();
        }else{
            imgs = entry.getRetdata().getImgs();
        }
        int size = imgs.size();
        if(size >6){
            findViewById(R.id.imgs_grid2).setVisibility(View.VISIBLE);
        }
        if(size >3){
            findViewById(R.id.imgs_grid1).setVisibility(View.VISIBLE);
        }
        if(size >0){
            findViewById(R.id.imgs_grid0).setVisibility(View.VISIBLE);
        }
        for(int i=0;i< size;i++){
            int id=getResources().getIdentifier("timeline_item_img_"+i,"id",getPackageName());
            SimpleDraweeView img = ((SimpleDraweeView) findViewById(id));
            String url= imgs.get(i).getUrl();
            if(url.startsWith("http")){

            }else{
                url="http://weibo.joyousphper.com/"+url;
            }
            img.setImageURI(Uri.parse(url));
        }

        mLikedCount.setText("赞" + entry.getPraisetimes());
        mReplyCount.setText("转发" + entry.getReposts_count());
        mCommentCount.setText("评论" + entry.getComments_count());
        mAvatar.setImageURI(Uri.parse(entry.getAuthor().getAvatar()));
        mNickname.setText(entry.getAuthor().getNickname());
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        RecyclerView replyView = new RecyclerView(this);
        RecyclerView commentView = new RecyclerView(this);
        views.add(replyView);
        views.add(commentView);
        final HBaseLinearLayoutManager mLayoutManager1 = new HBaseLinearLayoutManager(this);
        final HBaseLinearLayoutManager mLayoutManager2 = new HBaseLinearLayoutManager(this);
        mLayoutManager1.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {

            }
        });
        mLayoutManager1.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager1.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
            }
        });
        mLayoutManager2.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {

            }
        });
        mLayoutManager2.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager2.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
            }
        });
        commentView.setLayoutManager(mLayoutManager1);
        commentAdapter = new DetailsCommentAdapter(this);
        commentView.setAdapter(commentAdapter);
        replyView.setLayoutManager(mLayoutManager2);
        replyAdapter = new DetailsCommentAdapter(this);
        replyView.setAdapter(replyAdapter);
        mViewPager.setAdapter(new DetailsViewPagerAdater(views));
        refresh();
        vIndicatro.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.reply_count) {
                    WeiboDetailsActivity.this.refreshReply();
                    mViewPager.setCurrentItem(0);
                } else {
                    WeiboDetailsActivity.this.refreshComment();
                    mViewPager.setCurrentItem(1);
                }
            }
        });
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    vIndicatro.check(R.id.reply_count);
                } else {
                    vIndicatro.check(R.id.comment_count);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        mViewPager.setCurrentItem(1);
        refreshComment();
    }

    private void refreshComment() {
        RequestBuilder builderComment=new RequestBuilder(this,Constants.Api.COMMENT_SHOW);
        builderComment.addParams("id",entry.getId()).addParams("tabtype","reply");
        builderComment.get(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if(json.getInt("status")==0){
                        commentAdapter.reload(json.getJSONArray("data"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {

            }
        });
    }

    private void refreshReply() {
        RequestBuilder builderComment=new RequestBuilder(this,Constants.Api.COMMENT_SHOW);
        builderComment.addParams("id",entry.getId()).addParams("tabtype","retwit");
        builderComment.get(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if(json.getInt("status")==0){
                        replyAdapter.reload(json.getJSONArray("data"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {

            }
        });
    }

    private void refresh() {
        RequestBuilder builder=new RequestBuilder(this,Constants.Api.MESSAGES_SHOW);
        builder.addParams("id", entry.getId());
        builder.get(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {

            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {

            }
        });

    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        LogUtils.d(LOG_TAG, JsonFormatTool.formatJson(json));
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
            errorMsg.printStackTrace();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        if(position==0){
            refreshReply();;
        }else{
            refreshComment();
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onAvatarClick(DetailsCommentAdapter.ViewHolder holder, JSONObject data, int postion) {
        try {
            TargetUser author=new TargetUser();
            author.setNickname(data.getString("nickname"));
            author.setId(data.getString("user_id"));
            Intent intent =TargetUserHomeActivity.create(this,author);
            startActivity(intent);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if((requestCode == REQUEST_FORWARD || requestCode==REQUEST_COMMENT) && resultCode == Activity.RESULT_OK) {
            refresh();
        }
    }
    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btn_forward){
            Intent intent = new Intent(this, ForwardWeiboActivity.class);
            intent.putExtra("weibo", entry);
            startActivityForResult(intent, REQUEST_FORWARD);
        }else if(v.getId()==R.id.btn_comment){
            Intent intent = new Intent(this, CreateCommentActivity.class);
            intent.putExtra("wb_id", "" + entry.getId());
            startActivityForResult(intent, REQUEST_COMMENT);
        } if(v.getId()==R.id.btn_like){
            RequestBuilder builder = new RequestBuilder(this, Constants.Api.MESSAGES_PRAISE);
            builder.addParams("id", entry.getId());
            builder.post(new JsonResponseListener() {
                @Override
                public void onRequest() {

                }

                @Override
                public void onError(Exception e, String url, int actionId) {

                }

                @Override
                public void onSuccess(JSONObject jsonObject, String url, int actionId) {
                    try {
                        if (jsonObject.getInt("status") == 0) {
                            Toast.makeText(WeiboDetailsActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(WeiboDetailsActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(WeiboDetailsActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}



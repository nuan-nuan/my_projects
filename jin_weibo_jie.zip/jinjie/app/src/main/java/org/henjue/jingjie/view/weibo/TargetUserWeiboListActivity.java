package org.henjue.jingjie.view.weibo;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.WeiboListAdapter;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.dialog.ListDialog;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by henjue on 2015/5/24.
 */
public class TargetUserWeiboListActivity extends AppCompatActivity implements JsonResponseListener, WeiboListAdapter.OnActionListener {
    private static final String LOG_TAG = TargetUserWeiboListActivity.class.getSimpleName();
    @InjectView(R.id.btn_back)
    ImageView mBtnBack;
    @InjectView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @InjectView(R.id.swipeRefresh)
    SwipeRefreshLayout mSwipeRefresh;
    private String uid;
    private HBaseLinearLayoutManager mLayoutManager;
    private WeiboListAdapter adapter;
    int page = 1;
    private static final int REQUEST_EDIT = 0x1005;
    private static final int REQUEST_FORWARD = 0x1006;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uid = getIntent().getStringExtra("uid");
        adapter = new WeiboListAdapter(this, this,true);
        setContentView(R.layout.target_user_weibo_list_activity);
        ButterKnife.inject(this);
        mLayoutManager = new HBaseLinearLayoutManager(this);
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        refresh();
    }
    public void refresh() {
        RequestBuilder builder = RequestBuilder.create(this, Constants.Api.MESSAGES_USER);
        builder.addParams("p", String.valueOf(page)).addParams("limit", "10");
        builder.addParams("user_id", uid);
        builder.get(this);
    }

    @Override
    public void onSuccess(JSONObject jsonObject, String url, int actionId) {
        LogUtils.d(LOG_TAG, "onSuccess:%s", url);
        try {
            mSwipeRefresh.setRefreshing(false);
            int status = jsonObject.getInt("status");
            if (status != 0) {
                if (status == 10000 && page == 1) {
                    adapter.reload(new ArrayList<TimelineEntry>(), false);
                    adapter.notifyDataSetChanged();
                }
                    Toast.makeText(TargetUserWeiboListActivity.this,jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
            } else {
                JSONArray data = jsonObject.getJSONObject("data").getJSONArray("list");
                LogUtils.d(LOG_TAG, JsonFormatTool.formatJson(data));
                Gson gson = new Gson();
                ArrayList<TimelineEntry> timelines = new ArrayList<TimelineEntry>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject json = data.getJSONObject(i);
                    final TimelineEntry timeline=gson.fromJson(json.toString(),TimelineEntry.class);
                    timelines.add(timeline);

                }
                adapter.reload(timelines, page != 1);
                adapter.notifyDataSetChanged();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {

    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
    }

    @Override
    public void onItemClick(WeiboListAdapter.TimeViewHolder holder, TimelineEntry data, int postion) {
        Intent intent = new Intent(TargetUserWeiboListActivity.this, WeiboDetailsActivity.class);
        intent.putExtra("weibo", data);
        Pair<View, String> avatar = Pair.create((View) holder.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) holder.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(TargetUserWeiboListActivity.this, avatar, nickname);
        ActivityCompat.startActivity(TargetUserWeiboListActivity.this, intent, options.toBundle());
    }

    @Override
    public void onClickForward(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(TargetUserWeiboListActivity.this, ForwardWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_FORWARD);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EDIT && resultCode == Activity.RESULT_OK) {
            refresh();
        } else if (requestCode == REQUEST_FORWARD && resultCode == Activity.RESULT_OK) {
            refresh();
        }
    }

    @Override
    public void onClickComment(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(TargetUserWeiboListActivity.this, CreateCommentActivity.class);
        intent.putExtra("wb_id", "" + view.getData().getId());
        startActivity(intent);
    }

    @Override
    public void onClickLike(WeiboListAdapter.TimeViewHolder view) {
        RequestBuilder builder = new RequestBuilder(TargetUserWeiboListActivity.this, Constants.Api.MESSAGES_PRAISE);
        builder.addParams("id", view.getData().getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception e, String url, int actionId) {

            }

            @Override
            public void onSuccess(JSONObject jsonObject, String url, int actionId) {
                try {
                    if (jsonObject.getInt("status") == 0) {
                        Toast.makeText(TargetUserWeiboListActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(TargetUserWeiboListActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(TargetUserWeiboListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    @Override
    public void onClickPull(final WeiboListAdapter.TimeViewHolder holder) {
        if (holder.getData().getAuthor().getId().equals(UserAuth.read(this).uid)) {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"编辑", "设置成私密/公开", "删除"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        TargetUserWeiboListActivity.this.editWeibo(holder);
                    } else if (which == 2) {
                        TargetUserWeiboListActivity.this.deleteWeibo(holder.getPosition(), holder.getData().getId());
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(TargetUserWeiboListActivity.this.getFragmentManager(), "itemDialog");
        } else {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"取消关注", "举报"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        TargetUserWeiboListActivity.this.deleteFriend(holder);
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(TargetUserWeiboListActivity.this.getFragmentManager(), "itemDialog");
        }
    }

    private void editWeibo(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(TargetUserWeiboListActivity.this, EditWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_EDIT);
    }

    private void deleteFriend(WeiboListAdapter.TimeViewHolder holder) {
        RequestBuilder builder = RequestBuilder.create(TargetUserWeiboListActivity.this, Constants.Api.FRIEND_DEL);
        builder.addParams("friend_id", holder.getData().getAuthor().getId());
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                LogUtils.i(LOG_TAG, url);
                LogUtils.i(LOG_TAG, json.toString());
                try {
                    if (json.getInt("status") == 0) {
                        Toast.makeText(TargetUserWeiboListActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(TargetUserWeiboListActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {
                errorMsg.printStackTrace();
                Toast.makeText(TargetUserWeiboListActivity.this, errorMsg.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void deleteWeibo(final int position, int tid) {
        RequestBuilder builder = RequestBuilder.create(TargetUserWeiboListActivity.this, Constants.Api.MESSAGES_DEL);
        builder.addParams("id", tid);
        builder.post(new JsonResponseListener() {
            @Override
            public void onSuccess(JSONObject json, String url, int actionId) {
                try {
                    if (json.getInt("status") == 0) {
                        adapter.notifyItemRemoved(position);
                        Toast.makeText(TargetUserWeiboListActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(TargetUserWeiboListActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onRequest() {

            }

            @Override
            public void onError(Exception errorMsg, String url, int actionId) {
                errorMsg.printStackTrace();
                Toast.makeText(TargetUserWeiboListActivity.this, errorMsg.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClickUserPhoto(WeiboListAdapter.TimeViewHolder view) {
//        Toast.makeText(TargetUserWeiboListActivity.this,"你点击了ID为："+uid+"的头像",Toast.LENGTH_SHORT).show();
        Intent intent = TargetUserHomeActivity.create(this,view.getData().getAuthor());
        Pair<View, String> photo = Pair.create((View) view.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) view.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(TargetUserWeiboListActivity.this, nickname, photo);
        ActivityCompat.startActivity(TargetUserWeiboListActivity.this, intent, options.toBundle());
    }

}

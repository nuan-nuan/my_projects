package org.henjue.jingjie.model.user;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

/**
 * Created by android on 15-5-31.
 */
public class TargetUser extends AbstractUser {

    @SerializedName("user_info")
    private String summary;

    @SerializedName("msg_num")
    private String msgCount;

    @SerializedName("followme_num")
    private String fansCount;

    @SerializedName("follow_num")
    private String followCount;

    private String avatar_large;//用户头像地址(大图)

    public String getAvatar_large() {
        return TextUtils.isEmpty(avatar_large)?"http:///":avatar_large;
    }

    public void setAvatar_large(String avatar_large) {
        this.avatar_large = avatar_large;
    }
    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getMsgCount() {
        return msgCount;
    }

    public void setMsgCount(String msgCount) {
        this.msgCount = msgCount;
    }

    public String getFansCount() {
        return fansCount;
    }

    public void setFansCount(String fansCount) {
        this.fansCount = fansCount;
    }

    public String getFollowCount() {
        return followCount;
    }

    public void setFollowCount(String followCount) {
        this.followCount = followCount;
    }

    public TargetUser() {
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.summary);
        dest.writeString(this.msgCount);
        dest.writeString(this.fansCount);
        dest.writeString(this.followCount);
        dest.writeString(this.avatar_large);
    }

    protected TargetUser(Parcel in) {
        super(in);
        this.summary = in.readString();
        this.msgCount = in.readString();
        this.fansCount = in.readString();
        this.followCount = in.readString();
        this.avatar_large = in.readString();
    }

    public static final Creator<TargetUser> CREATOR = new Creator<TargetUser>() {
        public TargetUser createFromParcel(Parcel source) {
            return new TargetUser(source);
        }

        public TargetUser[] newArray(int size) {
            return new TargetUser[size];
        }
    };
}

package org.henjue.jingjie.common;

import org.henjue.jingjie.BuildConfig;

/**
 * Version 1.0
 * <p/>
 * Date: 2015-03-27 17:16
 */
public class Constants {
    public static final String API_HOST;
    static{
        if(BuildConfig.DEBUG){
            API_HOST="http://weibo.joyousphper.com/";
        }else{
            API_HOST="http://jiantalk.chinacloudapp.cn/";
        }
    }
    public static class Api{
        //用户注册
        public static final String USER_REGISTER="/user/register";
        //用户登录
        public static final String USER_LOGIN="/user/login";
        //发送验证码
        public static final String USER_SENDCODE="/user/sendcode";
        //重置密码
        public static final String USER_RESETPWD="/user/resetpwd";

        //校验验证码验证码
        public static final String USER_CHECKCODE="/user/checkcode";

        //上传用户头像
        public static final String USER_UPLOADFACE="/user/uploadface";

        //待关于用户列表
        public static final String USER_FOLLOWUSER="/user/followuser";
        //退出登录
        public static final String USER_LOGOUT="/user/logout";
        //根据token获取当前登录用户编号
        public static final String USER_USERID="/user/userid";
        //获取用户信息
        public static final String USER_INFO="/user/info";
        //用户扩展信息
        public static final String USER_PROFILE="/user/profile";
        //发布文字微博
        public static final String MESSAGES_ADDTEXT="/messages/addtext";
        //发布图文微博
        public static final String MESSAGES_ADDIMG="/messages/addimg";
        //删除微博
        public static final String MESSAGES_DEL="/messages/del";
        //编辑微博
        public static final String MESSAGES_EDIT="/Messages/edit";

        //赞微博
        public static final String MESSAGES_PRAISE="/messages/praise";
        //我的微博
        public static final String MESSAGES_MY="/messages/my";
        //热门微博
        public static final String MESSAGES_HOT="/messages/hot";
        //我的以及好友的微博
        public static final String MESSAGES_FRIENDS="/messages/friends";
        //单条微博
        public static final String MESSAGES_SHOW="/messages/show";
        //用户微博列表
        public static final String MESSAGES_USER="/messages/user";
        //上传图片
        public static final String MESSAGES_UPLOAD="/messages/upload";

        //转发微博
        public static final String MESSAGES_REPOST="/messages/repost";
        //添加关注
        public static final String FRIEND_ADD="/friend/add";
        //取消关注
        public static final String FRIEND_DEL="/friend/del";
        //用户关系
        public static final String FRIEND_RELATION="/friend/relation";
        //好友分组
        public static final String FRIEND_GROUP="/friend/group";
        //相同关注
        public static final String FRIEND_SAMEFOLLOW="/friend/samefollow";
        //收听列表
        public static final String FRIEND_FOLLOWING="/friend/following";
        //听众列表
        public static final String FRIEND_FOLLOWER="/friend/follower";
        //对我的评论
        public static final String COMMENT_TOME="/comment/tome";
        //我发出的评论
        public static final String COMMENT_BYME="/comment/byme";
        //单条微博评论列表
        public static final String COMMENT_SHOW="/comment/show";
        //@我的
        public static final String COMMENT_ATME="/comment/atme";
        //赞我的
        public static final String COMMENT_LIKEDME="/comment/praiseme";
        //添加评论
        public static final String COMMENT_ADD="/comment/add";
        //删除评论
        public static final String COMMENT_DEL="/comment/del";
        //添加收藏
        public static final String FAVORITES_ADD="/favorites/add";
        //取消收藏
        public static final String FAVORITES_DEL="/favorites/del";
        //我的收藏列表
        public static final String FAVORITES_MYLIST="/favorites/mylist";
        //我的私信列表
        public static final String EMAIL_MYLIST="/email/mylist";
        //用户对话列表
        public static final String EMAIL_SHOW="/email/show";
        //发私信
        public static final String EMAIL_ADD="/email/add";
        //设置私信为已读
        public static final String EMAIL_READ="/email/read";
        //删除私信
        public static final String EMAIL_DEL="/email/del";
        //删除对话
        public static final String EMAIL_DELALL="/email/delall";
        //未读消息数量
        public static final String REMIND_UNREAD="/remind/unread";
        //设定指定类型未读信息数量为0
        public static final String REMIND_READ="/remind/read";
        //系统设置
        public static final String SYSTEM_INDEX="/system/index";
       // 设置用户信息
       public static final String USER_SETTING="/user/setting";


        // 找人
        public static final String USER_SEARCH="/user/search";
    }
}

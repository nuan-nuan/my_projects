package org.henjue.jingjie.network2.service;

import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.model.response.StringResponse;
import org.henjue.jingjie.network2.ToastCallback;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.RequestFacade;
import org.henjue.library.hnet.RequestFilter;
import org.henjue.library.hnet.anntoation.Filter;
import org.henjue.library.hnet.anntoation.FormUrlEncoded;
import org.henjue.library.hnet.anntoation.Multipart;
import org.henjue.library.hnet.anntoation.Param;
import org.henjue.library.hnet.anntoation.Post;
import org.henjue.library.hnet.typed.TypedFile;

import java.util.ArrayList;

@FormUrlEncoded
public interface WeiBoService {
    @Multipart
    @Post(Constants.Api.MESSAGES_UPLOAD)
    void upload(@Param("img")TypedFile file,Callback<StringResponse> callback);

    @Filter(SendFilter.class)
    @Post(Constants.Api.MESSAGES_ADDIMG)
    void addimg(@Param("content_body")String body,@Param("imgs[]")ArrayList<String> imgs,ToastCallback callback);

    @Filter(SendFilter.class)
    @Post(Constants.Api.MESSAGES_ADDTEXT)
    void addtext(@Param("content_body")String bodye,ToastCallback callback);

    class SendFilter implements RequestFilter{

        @Override
        public void onComplite(RequestFacade requestFacade) {
            requestFacade.add("from","android");
            requestFacade.add("open",0);
        }

        @Override
        public void onStart(RequestFacade requestFacade) {

        }

        @Override
        public void onAdd(String s, Object o) {

        }
    }
}

package org.henjue.jingjie.model.response;

import android.text.TextUtils;

import org.henjue.jingjie.common.Constants;

import java.util.List;

/**
 * Created by android on 15-7-6.
 */
public class LikeMeResponse extends BaseResponse {

    private DataEntity data;


    public void setData(DataEntity data) {
        this.data = data;
    }

    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * count : 5
         * list : [{"id":"105","imgs":[],"retid":"0","content_id":"192","replyid":"0","posttime":"1435239772","content_body":"哈哈哈gcycycygygt","replytimes":"5","user_id":"4","type":"android","user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"},"zftimes":"1","puid":"4","retdel":"1"},{"id":"103","imgs":[],"retid":"0","content_id":"192","replyid":"0","posttime":"1435239772","content_body":"哈哈哈gcycycygygt","replytimes":"5","user_id":"16","type":"android","user":{"lastcontent":"@我是一只爱吃喵的鱼  test","nickname":"陈小丑丑","user_head":"/Public/attachments/photo/20150706/1436186337.jpg","user_id":"16"},"zftimes":"1","puid":"4","retdel":"1"},{"id":"102","imgs":[],"retid":"0","content_id":"182","replyid":"0","posttime":"1434552983","content_body":"哈哈哈gcycycygygt","replytimes":"3","user_id":"4","type":"android","user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"},"zftimes":"1","puid":"4","retdel":"1"},{"imgs":[],"posttime":"1434553149","content_body":"哈哈哈gcycycygygt","type":"web","zftimes":"0","retdel":"0","id":"101","retid":"182","content_id":"184","replyid":"0","user_id":"4","replytimes":"0","user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"},"puid":"4","retdata":{"user_gender":"1","imgs":[{"url":"/Public/attachments/photo/20150617/1434552983.JPEG"},{"url":"/Public/attachments/photo/20150617/1434552983.JPEG"},{"url":"/Public/attachments/photo/20150617/1434552983.JPEG"}],"user_auth":"0","nickname":"我是一只爱吃喵的鱼","lastcontent":"gggg{|}/Public/attachments/photo/20150625/1435239787.JPEG{IMG}","pinbi":"0","posttime":"1434552983","content_body":"哈哈哈gcycycygygt","provinceid":"0","type":"android","zhiding":"0","zftimes":"1","cityid":"0","user_name":"henjue","open":"0","retid":"0","content_id":"182","replyid":"0","praisetimes":"2","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","filetype":"","replytimes":"3","user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"}}},{"id":"99","imgs":[],"retid":null,"content_id":null,"replyid":null,"posttime":null,"content_body":"哈哈哈gcycycygygt","replytimes":null,"user_id":"4","type":null,"user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"},"zftimes":null,"puid":"4","retdel":"1"}]
         */
        private String count;
        private List<ListEntity> list;

        public void setCount(String count) {
            this.count = count;
        }

        public void setList(List<ListEntity> list) {
            this.list = list;
        }

        public String getCount() {
            return count;
        }

        public List<ListEntity> getList() {
            return list;
        }

        public class ListEntity {
            /**
             * id : 105
             * imgs : []
             * retid : 0
             * content_id : 192
             * replyid : 0
             * posttime : 1435239772
             * content_body : 哈哈哈gcycycygygt
             * replytimes : 5
             * user_id : 4
             * type : android
             * user : {"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4"}
             * zftimes : 1
             * puid : 4
             * retdel : 1
             */
            private String id;
            private List<?> imgs;
            private String retid;
            private String content_id;
            private String replyid;
            private String posttime;
            private String content_body;
            private String replytimes;
            private String user_id;
            private String type;
            private UserEntity user;
            private String zftimes;
            private String puid;
            private String retdel;

            public void setId(String id) {
                this.id = id;
            }

            public void setImgs(List<?> imgs) {
                this.imgs = imgs;
            }

            public void setRetid(String retid) {
                this.retid = retid;
            }

            public void setContent_id(String content_id) {
                this.content_id = content_id;
            }

            public void setReplyid(String replyid) {
                this.replyid = replyid;
            }

            public void setPosttime(String posttime) {
                this.posttime = posttime;
            }

            public void setContent_body(String content_body) {
                this.content_body = content_body;
            }

            public void setReplytimes(String replytimes) {
                this.replytimes = replytimes;
            }

            public void setUser_id(String user_id) {
                this.user_id = user_id;
            }

            public void setType(String type) {
                this.type = type;
            }

            public void setUser(UserEntity user) {
                this.user = user;
            }

            public void setZftimes(String zftimes) {
                this.zftimes = zftimes;
            }

            public void setPuid(String puid) {
                this.puid = puid;
            }

            public void setRetdel(String retdel) {
                this.retdel = retdel;
            }

            public String getId() {
                return id;
            }

            public List<?> getImgs() {
                return imgs;
            }

            public String getRetid() {
                return retid;
            }

            public String getContent_id() {
                return content_id;
            }

            public String getReplyid() {
                return replyid;
            }

            public String getPosttime() {
                return posttime;
            }

            public String getContent_body() {
                return content_body;
            }

            public String getReplytimes() {
                return replytimes;
            }

            public String getUser_id() {
                return user_id;
            }

            public String getType() {
                return type;
            }

            public UserEntity getUser() {
                return user;
            }

            public String getZftimes() {
                return zftimes;
            }

            public String getPuid() {
                return puid;
            }

            public String getRetdel() {
                return retdel;
            }

            public class UserEntity {
                /**
                 * lastcontent : gggg
                 * nickname : 我是一只爱吃喵的鱼
                 * user_head : /Public/attachments/photo/20150614/1434267716.jpg
                 * user_id : 4
                 */
                private String lastcontent;
                private String nickname;
                private String user_head;
                private String user_id;

                public void setLastcontent(String lastcontent) {
                    this.lastcontent = lastcontent;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }

                public void setUser_head(String user_head) {
                    this.user_head = user_head;
                }

                public void setUser_id(String user_id) {
                    this.user_id = user_id;
                }

                public String getLastcontent() {
                    return lastcontent;
                }

                public String getNickname() {
                    return nickname;
                }

                public String getUser_head() {
                    return TextUtils.isEmpty(user_head) ?"http://":user_head.startsWith("http")?user_head: Constants.API_HOST+user_head;
                }

                public String getUser_id() {
                    return user_id;
                }
            }
        }
    }
}

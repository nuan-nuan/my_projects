package org.henjue.jingjie.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.response.CommentMeResponse;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.span.SpanFormat;

import butterknife.ButterKnife;
import butterknife.InjectView;


/**
 * Created by ligux on 2015/3/31.
 */
public class CommentMeAdapter extends AbstractAdapter<CommentMeResponse.DataEntity.CommentEntity, CommentMeAdapter.ViewHolder> {

    private final TargetUser me;

    public CommentMeAdapter(Context context) {
        me=UserSaveHelper.getInstance().getUser();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.comment_me_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int i) {
        CommentMeResponse.DataEntity.CommentEntity data = getItem(i);
        holder.meAvatar.setImageURI(Uri.parse(me.getAvatar()));
        holder.meNickname.setText("@" + me.getNickname());
        holder.oldContent.setText(data.getContent().getContent_body());
        holder.avatar.setImageURI(Uri.parse(data.getUser().getUser_head()));
        holder.content.setMovementMethod(LinkMovementMethod.getInstance());
        holder.content.setText(SpanFormat.formatContent(data.getComment_data().getComment_body()));
        holder.nickname.setText(data.getUser().getNickname());
        holder.posttime.setVisibility(View.GONE);

    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {
        @InjectView(R.id.avatar)
        SimpleDraweeView avatar;
        @InjectView(R.id.nickname)
        TextView nickname;
        @InjectView(R.id.posttime)
        TextView posttime;
        @InjectView(R.id.btn_reply)
        ImageView btnReply;
        @InjectView(R.id.root)
        RelativeLayout root;
        @InjectView(R.id.content)
        TextView content;
        @InjectView(R.id.me_avatar)
        SimpleDraweeView meAvatar;
        @InjectView(R.id.me_nickname)
        TextView meNickname;
        @InjectView(R.id.old_content)
        TextView oldContent;
        public ViewHolder(View v) {
            super(v);
            ButterKnife.inject(this,v);
        }
    }

}


package org.henjue.jingjie.view.dialog;

import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.henjue.jingjie.network.JsonResponseListener;

/**
 * Created by android on 15-5-4.
 */
public class EditDialog extends DialogFragment implements TextView.OnEditorActionListener, View.OnClickListener {


    private EditActionListener mListener;
    private String defaultText;
    private Button mBtnOk;

    @Override
    public void onClick(View v) {
        if(mListener!=null){
            Editable text = mEditText.getText();
            mListener.onFinishEditDialog(this,!defaultText.equals(text), text);
        }
        this.dismiss();
    }

    public interface EditActionListener {
        void onFinishEditDialog(EditDialog dialog,boolean change,Editable inputText);
    }
    public void setEditActionListener(EditActionListener listener){
        this.mListener=listener;
    }
    private EditText mEditText;
    public static EditDialog newInstance(String title) {
        return newInstance(title,"","");
    }
    public static EditDialog newInstance(String title, String hint) {
        return newInstance(title,"",hint);
    }
    public static EditDialog newInstance(String title, String defaultText,String hint) {
        EditDialog adf = new EditDialog();
        Bundle bundle = new Bundle();
        bundle.putString("alert-title", title);
        bundle.putString("alert-default", defaultText);
        bundle.putString("alert-hint", hint);
        adf.setArguments(bundle);
        return adf;
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LinearLayout root=new LinearLayout(getActivity());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.WRAP_CONTENT));
        mEditText=new EditText(getActivity());
        mEditText.setHint(getArguments().getString("alert-hint"));
        defaultText = getArguments().getString("alert-default");
        if(defaultText==null)defaultText="";
        mEditText.setText(defaultText);
        mEditText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        mEditText.setInputType(EditorInfo.TYPE_CLASS_TEXT);
        mEditText.setSingleLine();
        getDialog().setTitle(getArguments().getString("alert-title"));
        mEditText.requestFocus();                       // EditText获得焦点
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE); // 显示软键盘
        mEditText.setOnEditorActionListener(this);      // 设置Action监听器

        mBtnOk=new Button(getActivity());
        mBtnOk.setText("确定");
        mBtnOk.setOnClickListener(this);
        root.addView(mEditText);
        root.addView(mBtnOk);

        return root;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        return dialog;
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (EditorInfo.IME_ACTION_DONE == actionId) {
            // Return input text to activity
            if(mListener!=null){
                Editable text = mEditText.getText();
                mListener.onFinishEditDialog(this,!defaultText.equals(text), text);
            }
            this.dismiss();
            return true;
        }
        return false;
    }

}

package org.henjue.jingjie.view.user;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.common.Constants;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.databinding.ActivityBasicInfoMainBinding;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.view.dialog.EditDialog;
import org.henjue.jingjie.view.dialog.SingleSelectDialog;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * 自定义基本信息界面
 */

public class BasicInfoMainActivity extends Activity {
    private static final String LOG_TAG = BasicInfoMainActivity.class.getSimpleName();
    @InjectView(R.id.info_back)
    ImageView mInfoBack;
    @InjectView(R.id.title)
    RelativeLayout mTitle;
    @InjectView(R.id.info_loginname)
    TextView mInfoLoginname;
    @InjectView(R.id.info_nickname)
    TextView mInfoNickname;
    @InjectView(R.id.info_gender)
    TextView mInfoGender;
    @InjectView(R.id.info_city)
    TextView mInfoCity;
    @InjectView(R.id.info_summary)
    TextView mInfoSummary;
    @InjectView(R.id.info_birthday)
    TextView mInfoBirthday;
    @InjectView(R.id.info_mobile)
    TextView mInfoMobile;
    @InjectView(R.id.info_email)
    TextView mInfoEmail;
    private TargetUser user;
    private UserAuth auth;
    private boolean isChange = false;
    ActivityBasicInfoMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user= UserSaveHelper.getInstance().getUser();
        auth = UserAuth.read(this);
        setContentView(R.layout.activity_basic_info_main);
        binding=DataBindingUtil.setContentView(this,R.layout.activity_basic_info_main);
        ButterKnife.inject(this);
        binding.setUser(user);
        mInfoLoginname.setText(auth.loginname);
//        mInfoNickname.setText(user.getNickname());
//        mInfoSummary.setText(user.getSummary());
//        mInfoGender.setText(user.getSex() == 0 ? "女" : "男");
//        mInfoCity.setText(user.getCityName());
//        mInfoEmail.setText(user.getEmail());
    }

    void updateInfo(String key, String value, TextView view) {
        RequestBuilder builder = RequestBuilder.create(this, Constants.Api.USER_SETTING);
        builder.addParams("field", key).addParams("val", value);
        builder.post(new UpdateInfoListener(this, view, value));
    }

    @OnClick(R.id.info_mobile)
    void clickMobile(View v) {
        EditDialog dialog = EditDialog.newInstance("修改手机号");
        dialog.setEditActionListener(new EditDialog.EditActionListener() {
            @Override
            public void onFinishEditDialog(EditDialog dialog, boolean change, Editable inputText) {

            }
        });
        dialog.show(getFragmentManager(), "edit");
    }
    @OnClick(R.id.info_email)
    void clickEmail(View v) {
        EditDialog dialog = EditDialog.newInstance("修改邮箱",user.getEmail(),"");
        dialog.setEditActionListener(new EditDialog.EditActionListener() {
            @Override
            public void onFinishEditDialog(EditDialog dialog, boolean change, Editable inputText) {
                String value = inputText.toString();
                if (change) {
                    updateInfo("mailadres", value, mInfoEmail);
                }
            }
        });
        dialog.show(getFragmentManager(), "edit");
    }
    @Override
    public void finish() {
        if (isChange) {
            setResult(RESULT_OK);
        }
        super.finish();
    }

    @OnClick(R.id.info_city)
    void clickCity(View v) {
        EditDialog dialog = EditDialog.newInstance("修改城市", user.getCityName(), "");
        dialog.setEditActionListener(new EditDialog.EditActionListener() {
            @Override
            public void onFinishEditDialog(EditDialog dialog, boolean change, Editable inputText) {
                String value = inputText.toString();
                if (change) {
                    updateInfo("city_name", value, mInfoCity);
                }
            }
        });
        dialog.show(getFragmentManager(), "edit");
    }

    @OnClick(R.id.info_gender)
    void clickGender(View v) {
        final String[] items = new String[]{"女", "男"};
        SingleSelectDialog dialog = SingleSelectDialog.newInstance("修改性别", items, user.getSex());
        dialog.setnListener(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which != user.getSex()) {
                    updateInfo("user_gender", "" + which, mInfoGender);
                }
                dialog.dismiss();

            }
        });
        dialog.show(getFragmentManager(), "edit");
    }

    @OnClick(R.id.info_summary)
    void clickSummary(View v) {
        EditDialog dialog = EditDialog.newInstance("修改简介", user.getSummary(), "");
        dialog.setEditActionListener(new EditDialog.EditActionListener() {
            @Override
            public void onFinishEditDialog(EditDialog dialog, boolean change, Editable inputText) {
                String value = inputText.toString();
                if (change) {
                    updateInfo("user_info", value, mInfoSummary);
                }

            }
        });
        dialog.show(getFragmentManager(), "edit");
    }

    @OnClick(R.id.info_nickname)
    void clickNickName(View v) {
        EditDialog dialog = EditDialog.newInstance("修改昵称", user.getNickname(), "");
        dialog.setEditActionListener(new EditDialog.EditActionListener() {
            @Override
            public void onFinishEditDialog(EditDialog dialog, boolean change, Editable inputText) {
                String value = inputText.toString();
                if (change) {
                    updateInfo("nickname", value, mInfoNickname);
                }
            }
        });
        dialog.show(getFragmentManager(), "edit");
    }

    public class UpdateInfoListener implements JsonResponseListener {
        private final TextView mView;
        private String mNewText;
        private final Context mContext;

        public UpdateInfoListener(Context context, TextView view, String newText) {
            this.mView = view;
            this.mNewText = newText;
            this.mContext = context;
        }

        @Override
        public void onSuccess(JSONObject json, String url, int actionId) {
            try {
                if (json.getInt("status") == 0) {
                    if (mNewText.equals("0")) {
                        user.setSex(0);
                        mNewText = "女";
                    } else if (mNewText.equals("1")) {
                        user.setSex(1);
                        mNewText = "男";
                    }
                    mView.setText(mNewText);
                    isChange = false;
                }
                Toast.makeText(mContext, json.getString("message"), Toast.LENGTH_SHORT).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onRequest() {

        }

        @Override
        public void onError(Exception errorMsg, String url, int actionId) {
            errorMsg.printStackTrace();
        }
    }
}

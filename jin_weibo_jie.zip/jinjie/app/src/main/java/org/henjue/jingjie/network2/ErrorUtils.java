package org.henjue.jingjie.network2;

import android.content.Context;
import android.widget.Toast;

import org.henjue.library.hnet.exception.HNetError;


/**
 * Created by android on 15-6-29.
 */
public class ErrorUtils {
    public static void checkError(Context context,HNetError error){
        error.printStackTrace();
        if(error.getKind()== HNetError.Kind.HTTP ){
            Toast.makeText(context, "连接服务器出错了...", Toast.LENGTH_SHORT).show();
        }else if(error.getKind()== HNetError.Kind.NETWORK){
            Toast.makeText(context, "和服务器通讯失败...", Toast.LENGTH_SHORT).show();
        }else if(error.getKind()== HNetError.Kind.CONVERSION){
            Toast.makeText(context, "不能处理服务器返回给我的数据....", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "运行出错啦...", Toast.LENGTH_SHORT).show();
        }

    }
}

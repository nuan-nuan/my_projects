package org.henjue.jingjie.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by henjue on 2015/6/8.
 */
public class Img implements Parcelable {
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.url);
    }

    public Img() {
    }
    public Img(String url) {
        this.url=url;
    }
    private Img(Parcel in) {
        this.url = in.readString();
    }

    public static final Parcelable.Creator<Img> CREATOR = new Parcelable.Creator<Img>() {
        public Img createFromParcel(Parcel source) {
            return new Img(source);
        }

        public Img[] newArray(int size) {
            return new Img[size];
        }
    };
}

package org.henjue.jingjie.view.weibo;

import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import org.henjue.jingjie.R;
import org.henjue.jingjie.utils.RelativeDateFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by henjue on 2015/5/15.
 */
public class DetailsCommentAdapter extends RecyclerView.Adapter<DetailsCommentAdapter.ViewHolder> {
    private final OnActionListener listener;
    private JSONArray datas;
    public DetailsCommentAdapter(OnActionListener listener){
        this.listener=listener;
    }
    public void reload(JSONArray datas){
        this.datas=datas;
        notifyDataSetChanged();
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.timeline_details_item,null,false),listener);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            JSONObject data = datas.getJSONObject(position);
            holder.bindData(data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return datas==null?0:datas.length();
    }
    public interface OnActionListener {
        void onAvatarClick(ViewHolder holder, JSONObject data, int postion);
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        public final SimpleDraweeView mAvatar;
        public final TextView mContent;
        public final TextView mOldContent;
        public final TextView mNickname;
        public final TextView mPosttime;
        public final View root;
        private final OnActionListener listener;


        public JSONObject getData() {
            return data;
        }

        private JSONObject data;

        public ViewHolder(View v,final OnActionListener listener) {
            super(v);
            this.listener=listener;
            mAvatar = (SimpleDraweeView)v.findViewById(R.id.avatar);
            mNickname =(TextView)v.findViewById(R.id.nickname);
            mPosttime = (TextView)v.findViewById(R.id.posttime);
            mContent = (TextView)v.findViewById(R.id.content);
            mOldContent = (TextView)v.findViewById(R.id.old_content);
            this.root=v.findViewById(R.id.root);
            mAvatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v1) {
                    listener.onAvatarClick(ViewHolder.this, data, ViewHolder.this.getPosition());
                }
            });
        }
        public void bindData(JSONObject data){
            this.data=data;
            try {
                String user_head = data.getString("user_head");
                user_head= TextUtils.isEmpty(user_head)?"http://":user_head;
                mAvatar.setImageURI(Uri.parse(user_head));
                mNickname.setText(data.getString("nickname"));
                mContent.setText(data.getString("content_body"));
                mPosttime.setText(RelativeDateFormat.format(Long.parseLong(data.getString("posttime"))));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

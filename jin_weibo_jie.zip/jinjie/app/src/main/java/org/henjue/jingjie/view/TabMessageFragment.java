package org.henjue.jingjie.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.MessageAdapter;
import org.henjue.jingjie.common.UserAuth;
import org.henjue.jingjie.model.MessageEntry;
import org.henjue.jingjie.network.JsonResponseListener;
import org.henjue.jingjie.network.RequestBuilder;
import org.henjue.jingjie.utils.JsonFormatTool;
import org.henjue.jingjie.utils.LogUtils;
import org.henjue.jingjie.view.weibo.FilterWeiBoActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Version 1.0
 * <p/>
 * Date: 2015-03-20 20:15
 * Author: alanchen@fit-start.co
 * <p/>
 * Copyright © 2014-2014 Shanghai Fit-start Network Technology Co., Ltd.
 */
public class TabMessageFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, JsonResponseListener, MessageAdapter.onKindActionListener, MessageAdapter.onItemActionListener {
    private static final String LOG_TAG = TabMessageFragment.class.getName();
    private UserAuth userAuth;
    private SwipeRefreshLayout mSwipeRefresh;
    private RecyclerView mRecyclerView;
    private HBaseLinearLayoutManager mLayoutManager;
    private int page=1;
    private MessageAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_message, null, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSwipeRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefresh);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager=new HBaseLinearLayoutManager(getActivity());
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        adapter=new MessageAdapter(this,this);
        ArrayList<MessageEntry> datas=new ArrayList<MessageEntry>();
        addListKind(datas);
        adapter.reload(datas,false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        refresh();


    }

    private void refresh() {
        userAuth = UserAuth.read(getActivity());
        RequestBuilder builder=new RequestBuilder("/email/mylist",userAuth.token);
        builder.addParams("p",page);
        builder.post(this);
    }

    private void addListKind(ArrayList<MessageEntry> datas) {
        datas.add(0,new MessageEntry.KindAtMeEntry());
        datas.add(1,new MessageEntry.KindCommentEntry());
        datas.add(2,new MessageEntry.KindLikedEntry());
    }

    @Override
    public void onRefresh() {
        page=1;
        refresh();
    }

    @Override
    public void onSuccess(JSONObject json, String url, int actionId) {
        mSwipeRefresh.setRefreshing(false);
        LogUtils.d(LOG_TAG, JsonFormatTool.formatJson(json));
        ArrayList<MessageEntry> datas=new ArrayList<MessageEntry>();
        boolean append = page != 1;
        if(!append){
            addListKind(datas);
        }
        try {
            if(json.getInt("status")==0){
               JSONArray jarry=json.getJSONObject("data").getJSONArray("list");
                Gson gson=new Gson();
                for(int i=0;i<jarry.length();i++){
                    MessageEntry.ItemNormalEntry entry=gson.fromJson(jarry.getJSONObject(i).toString(), MessageEntry.ItemNormalEntry.class);
                    datas.add(entry);
                }
            }
            adapter.reload(datas, append);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequest() {
        mSwipeRefresh.setRefreshing(true);
    }

    @Override
    public void onError(Exception errorMsg, String url, int actionId) {
            errorMsg.printStackTrace();
        mSwipeRefresh.setRefreshing(false);

    }

    @Override
    public void onClickAtMe(View v, MessageAdapter.HeadViewHolder holder) {
        Pair<View, String> title=Pair.create(v,"body");
        ActivityOptionsCompat options=ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(),title);
        ActivityCompat.startActivity(getActivity(), FilterWeiBoActivity.getAtMeIntent(getActivity()), options.toBundle());
    }

    @Override
    public void onClickCommentMe(View v, MessageAdapter.HeadViewHolder holder) {
        Pair<View, String> title=Pair.create(v,"body");
        ActivityOptionsCompat options=ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(),title);
        ActivityCompat.startActivity(getActivity(), FilterWeiBoActivity.getCommentIntent(getActivity()), options.toBundle());
    }

    @Override
    public void onClickLikedMe(View v, MessageAdapter.HeadViewHolder holder) {
        Pair<View, String> title=Pair.create(v,"body");
        ActivityOptionsCompat options=ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(),title);
        ActivityCompat.startActivity(getActivity(), FilterWeiBoActivity.getLikedntent(getActivity()), options.toBundle());
    }

    @Override
    public void onItem(View v, MessageAdapter.ItemViewHolder holder) {

    }

    @Override
    public void onUserPhoto(View v, MessageAdapter.ItemViewHolder holder) {

    }
}

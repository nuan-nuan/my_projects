package org.henjue.jingjie.model.response;

import android.text.TextUtils;

import org.henjue.jingjie.common.Constants;

import java.util.List;

/**
 * Created by android on 15-7-6.
 */
public class CommentMeResponse extends  BaseResponse{

    /**
     * message : null
     * status : 0
     * data : {"total":"2","comment":[{"content":{"open":"0","retid":"0","content_id":"192","pinbi":"0","replyid":"0","posttime":"1435239772","praisetimes":"2","content_body":"tttttt","replytimes":"6","filetype":"","user_id":"4","zhiding":"0","type":"android","zftimes":"1"},"comment_data":{"id":"11","comment_body":"我的评论"},"user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","isfllower":2}},{"content":{"open":"0","retid":"0","content_id":"192","pinbi":"0","replyid":"0","posttime":"1435239772","praisetimes":"2","content_body":"tttttt","replytimes":"6","filetype":"","user_id":"4","zhiding":"0","type":"android","zftimes":"1"},"comment_data":{"id":"10","comment_body":"ADHD HSBC"},"user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","isfllower":2}}]}
     */
    private DataEntity data;



    public void setData(DataEntity data) {
        this.data = data;
    }



    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * total : 2
         * comment : [{"content":{"open":"0","retid":"0","content_id":"192","pinbi":"0","replyid":"0","posttime":"1435239772","praisetimes":"2","content_body":"tttttt","replytimes":"6","filetype":"","user_id":"4","zhiding":"0","type":"android","zftimes":"1"},"comment_data":{"id":"11","comment_body":"我的评论"},"user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","isfllower":2}},{"content":{"open":"0","retid":"0","content_id":"192","pinbi":"0","replyid":"0","posttime":"1435239772","praisetimes":"2","content_body":"tttttt","replytimes":"6","filetype":"","user_id":"4","zhiding":"0","type":"android","zftimes":"1"},"comment_data":{"id":"10","comment_body":"ADHD HSBC"},"user":{"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","isfllower":2}}]
         */
        private String total;
        private List<CommentEntity> comment;

        public void setTotal(String total) {
            this.total = total;
        }

        public void setComment(List<CommentEntity> comment) {
            this.comment = comment;
        }

        public String getTotal() {
            return total;
        }

        public List<CommentEntity> getComment() {
            return comment;
        }

        public class CommentEntity {
            /**
             * content : {"open":"0","retid":"0","content_id":"192","pinbi":"0","replyid":"0","posttime":"1435239772","praisetimes":"2","content_body":"tttttt","replytimes":"6","filetype":"","user_id":"4","zhiding":"0","type":"android","zftimes":"1"}
             * comment_data : {"id":"11","comment_body":"我的评论"}
             * user : {"lastcontent":"gggg","nickname":"我是一只爱吃喵的鱼","user_head":"/Public/attachments/photo/20150614/1434267716.jpg","user_id":"4","isfllower":2}
             */
            private ContentEntity content;
            private Comment_dataEntity comment_data;
            private UserEntity user;

            public void setContent(ContentEntity content) {
                this.content = content;
            }

            public void setComment_data(Comment_dataEntity comment_data) {
                this.comment_data = comment_data;
            }

            public void setUser(UserEntity user) {
                this.user = user;
            }

            public ContentEntity getContent() {
                return content;
            }

            public Comment_dataEntity getComment_data() {
                return comment_data;
            }

            public UserEntity getUser() {
                return user;
            }

            public class ContentEntity {
                /**
                 * open : 0
                 * retid : 0
                 * content_id : 192
                 * pinbi : 0
                 * replyid : 0
                 * posttime : 1435239772
                 * praisetimes : 2
                 * content_body : tttttt
                 * replytimes : 6
                 * filetype :
                 * user_id : 4
                 * zhiding : 0
                 * type : android
                 * zftimes : 1
                 */
                private String open;
                private String retid;
                private String content_id;
                private String pinbi;
                private String replyid;
                private String posttime;
                private String praisetimes;
                private String content_body;
                private String replytimes;
                private String filetype;
                private String user_id;
                private String zhiding;
                private String type;
                private String zftimes;

                public void setOpen(String open) {
                    this.open = open;
                }

                public void setRetid(String retid) {
                    this.retid = retid;
                }

                public void setContent_id(String content_id) {
                    this.content_id = content_id;
                }

                public void setPinbi(String pinbi) {
                    this.pinbi = pinbi;
                }

                public void setReplyid(String replyid) {
                    this.replyid = replyid;
                }

                public void setPosttime(String posttime) {
                    this.posttime = posttime;
                }

                public void setPraisetimes(String praisetimes) {
                    this.praisetimes = praisetimes;
                }

                public void setContent_body(String content_body) {
                    this.content_body = content_body;
                }

                public void setReplytimes(String replytimes) {
                    this.replytimes = replytimes;
                }

                public void setFiletype(String filetype) {
                    this.filetype = filetype;
                }

                public void setUser_id(String user_id) {
                    this.user_id = user_id;
                }

                public void setZhiding(String zhiding) {
                    this.zhiding = zhiding;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public void setZftimes(String zftimes) {
                    this.zftimes = zftimes;
                }

                public String getOpen() {
                    return open;
                }

                public String getRetid() {
                    return retid;
                }

                public String getContent_id() {
                    return content_id;
                }

                public String getPinbi() {
                    return pinbi;
                }

                public String getReplyid() {
                    return replyid;
                }

                public String getPosttime() {
                    return posttime;
                }

                public String getPraisetimes() {
                    return praisetimes;
                }

                public String getContent_body() {
                    return content_body;
                }

                public String getReplytimes() {
                    return replytimes;
                }

                public String getFiletype() {
                    return filetype;
                }

                public String getUser_id() {
                    return user_id;
                }

                public String getZhiding() {
                    return zhiding;
                }

                public String getType() {
                    return type;
                }

                public String getZftimes() {
                    return zftimes;
                }
            }

            public class Comment_dataEntity {
                /**
                 * id : 11
                 * comment_body : 我的评论
                 */
                private String id;
                private String comment_body;

                public void setId(String id) {
                    this.id = id;
                }

                public void setComment_body(String comment_body) {
                    this.comment_body = comment_body;
                }

                public String getId() {
                    return id;
                }

                public String getComment_body() {
                    return comment_body;
                }
            }

            public class UserEntity {
                /**
                 * lastcontent : gggg
                 * nickname : 我是一只爱吃喵的鱼
                 * user_head : /Public/attachments/photo/20150614/1434267716.jpg
                 * user_id : 4
                 * isfllower : 2
                 */
                private String lastcontent;
                private String nickname;
                private String user_head;
                private String user_id;
                private int isfllower;

                public void setLastcontent(String lastcontent) {
                    this.lastcontent = lastcontent;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }

                public void setUser_head(String user_head) {
                    this.user_head = user_head;
                }

                public void setUser_id(String user_id) {
                    this.user_id = user_id;
                }

                public void setIsfllower(int isfllower) {
                    this.isfllower = isfllower;
                }

                public String getLastcontent() {
                    return lastcontent;
                }

                public String getNickname() {
                    return nickname;
                }

                public String getUser_head() {
                    return TextUtils.isEmpty(user_head) ?"http://":user_head.startsWith("http")?user_head: Constants.API_HOST+user_head;
                }

                public String getUser_id() {
                    return user_id;
                }

                public int getIsfllower() {
                    return isfllower;
                }
            }
        }
    }
}

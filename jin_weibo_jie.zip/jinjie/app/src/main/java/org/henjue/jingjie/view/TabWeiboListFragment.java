package org.henjue.jingjie.view;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.henjue.jingjie.R;
import org.henjue.jingjie.adapter.WeiboListAdapter;
import org.henjue.jingjie.common.UserSaveHelper;
import org.henjue.jingjie.model.TimelineEntry;
import org.henjue.jingjie.model.response.LikeResonse;
import org.henjue.jingjie.model.response.TimelineListResponse;
import org.henjue.jingjie.model.response.ToastResponse;
import org.henjue.jingjie.model.user.TargetUser;
import org.henjue.jingjie.network2.ErrorUtils;
import org.henjue.jingjie.network2.Network;
import org.henjue.jingjie.network2.ToastCallback;
import org.henjue.jingjie.network2.service.TimelineService;
import org.henjue.jingjie.view.dialog.ListDialog;
import org.henjue.jingjie.view.user.AddAttentionActivity;
import org.henjue.jingjie.view.user.TargetUserHomeActivity;
import org.henjue.jingjie.view.weibo.CreateCommentActivity;
import org.henjue.jingjie.view.weibo.EditWeiboActivity;
import org.henjue.jingjie.view.weibo.ForwardWeiboActivity;
import org.henjue.jingjie.view.weibo.WeiboDetailsActivity;
import org.henjue.jingjie.widget.HBaseLinearLayoutManager;
import org.henjue.jingjie.widget.OnRecyclerViewScrollListener;
import org.henjue.jingjie.widget.OnRecyclerViewScrollLocationListener;
import org.henjue.library.hnet.Callback;
import org.henjue.library.hnet.Response;
import org.henjue.library.hnet.exception.HNetError;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Version 1.0
 * <p>
 * Date: 2015-03-20 20:15
 * Author: alanchen@fit-start.co
 * <p>
 * Copyright © 2014-2014 Shanghai Fit-start Network Technology Co., Ltd.
 */
public class TabWeiboListFragment extends Fragment implements View.OnClickListener, SwipeRefreshLayout.OnRefreshListener, WeiboListAdapter.OnActionListener {
    private static final String LOG_TAG = TabWeiboListFragment.class.getName();
    @InjectView(R.id.add_attention)
    ImageView mAddAttention;
    @InjectView(R.id.username)
    TextView mUsername;
    @InjectView(R.id.title_container)
    RelativeLayout mTitleContainer;
    @InjectView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @InjectView(R.id.swipeRefresh)
    SwipeRefreshLayout mSwipeRefresh;
    @InjectView(R.id.btn_refresh)
    ImageView mBtnRefresh;
    private WeiboListAdapter adapter;
    int page = 1;
    private static final int REQUEST_EDIT = 0x1005;
    private static final int REQUEST_FORWARD = 0x1006;
    private Callback<TimelineListResponse> listener2=new Callback<TimelineListResponse>() {
        @Override
        public void start() {
            mSwipeRefresh.setRefreshing(true);
        }

        @Override
        public void success(TimelineListResponse res, Response response) {
            int status = res.getStatus();
            if(status !=0){
                if (status == 10000 && page == 1) {
                    adapter.reload(new ArrayList<TimelineEntry>(), false);
                    adapter.notifyDataSetChanged();
                }
            }else{
                List<TimelineEntry> list = res.getData().getList();
                adapter.reload(list, page != 1);
                adapter.notifyDataSetChanged();
                if(page==1){
                    mLayoutManager.scrollToPosition(0);
                }
            }
        }

        @Override
        public void failure(HNetError hNetError) {

        }

        @Override
        public void end() {
            mSwipeRefresh.setRefreshing(false);
        }
    };
    private HBaseLinearLayoutManager mLayoutManager;
    private TimelineService service;
    private class  LikeCallback implements Callback<LikeResonse>{
        private final WeiboListAdapter.TimeViewHolder  entry;
        LikeCallback(WeiboListAdapter.TimeViewHolder entry){
            this.entry=entry;
        }
        @Override
        public void start() {
        }

        @Override
        public void success(LikeResonse likeResonse, Response response) {
                if (likeResonse.getStatus()== 0) {
                    boolean like = likeResonse.getData().isLike();
                    if(!like){
                        Toast.makeText(getActivity(), "取消成功", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getActivity(), "点赞成功", Toast.LENGTH_SHORT).show();
                    }
                    ((TextView)entry.btnLike.getChildAt(0)).setCompoundDrawablesWithIntrinsicBounds(like?R.drawable.ic_liked:R.drawable.ic_like, 0, 0, 0);
                } else {
                    Toast.makeText(getActivity(), likeResonse.getMessage(), Toast.LENGTH_SHORT).show();
                }
        }

        @Override
        public void failure(HNetError hNetError) {
            ErrorUtils.checkError(getActivity(), hNetError);
        }

        @Override
        public void end() {

        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_weibolist, null, false);
        ButterKnife.inject(this, view);
        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        service=Network.getService(TimelineService.class);
        adapter = new WeiboListAdapter(getActivity(), this,true);
        mUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TabWeiboListFragment.this.toggleGroupPopup(v);
            }
        });
        mBtnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                page = 1;
                TabWeiboListFragment.this.refresh();
            }
        });
        mAddAttention.setOnClickListener(this);
        mSwipeRefresh.setOnRefreshListener(this);
        mLayoutManager = new HBaseLinearLayoutManager(getActivity());
//        mRecyclerView.addItemDecoration(new ItemDecoration(mRecyclerView));
        mLayoutManager.setOnRecyclerViewScrollLocationListener(new OnRecyclerViewScrollLocationListener() {
            @Override
            public void onTopWhenScrollIdle(RecyclerView recyclerView) {

            }

            @Override
            public void onBottomWhenScrollIdle(RecyclerView recyclerView) {
                page++;
                refresh();
            }
        });
        mLayoutManager.addScrollListener(new OnRecyclerViewScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
                boolean enabled = firstVisibleItemPosition == 0;
                mSwipeRefresh.setEnabled(enabled);
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(adapter);
        refresh();


    }

    public void refresh() {
        mUsername.setText(UserSaveHelper.getInstance().getUser().getNickname());
        service.list(page,10,listener2);
    }

    private void toggleGroupPopup(View parent) {
        DisplayMetrics out = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(out);
        PopupWindow popupWindow = new PopupWindow(LayoutInflater.from(getActivity()).inflate(R.layout.group_pop, null, false), out.widthPixels / 2, WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        int[] location = new int[2];
        parent.getLocationOnScreen(location);
        popupWindow.showAsDropDown(parent, -(((out.widthPixels / 2) - parent.getMeasuredWidth()) / 2), 0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add_attention:
                Pair<View, String> title = Pair.create((View)mTitleContainer, "title");
                ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(), title);
                ActivityCompat.startActivity(getActivity(), new Intent(getActivity(), AddAttentionActivity.class), options.toBundle());
                break;
        }
    }


    @Override
    public void onRefresh() {
        page = 1;
        refresh();
    }

    @Override
    public void onItemClick(WeiboListAdapter.TimeViewHolder holder, TimelineEntry data, int postion) {
        Intent intent = new Intent(getActivity(), WeiboDetailsActivity.class);
        intent.putExtra("weibo", data);
        Pair<View, String> avatar = Pair.create((View) holder.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) holder.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(), avatar, nickname);
        ActivityCompat.startActivity(getActivity(), intent, options.toBundle());
    }

    @Override
    public void onClickForward(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(getActivity(), ForwardWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_FORWARD);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EDIT && resultCode == Activity.RESULT_OK) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    refresh();
                }
            },1000);

        } else if (requestCode == REQUEST_FORWARD && resultCode == Activity.RESULT_OK) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    refresh();
                }
            }, 1000);

        }
    }

    @Override
    public void onClickComment(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(getActivity(), CreateCommentActivity.class);
        intent.putExtra("wb_id", "" + view.getData().getId());
        startActivity(intent);
    }

    @Override
    public void onClickLike(final WeiboListAdapter.TimeViewHolder view) {
        service.like(view.getData().getId(),new LikeCallback(view));
    }


    @Override
    public void onClickPull(final WeiboListAdapter.TimeViewHolder view) {
        if (view.getData().getAuthor().isMe(getActivity())) {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"编辑", "设置成私密/公开", "删除"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        TabWeiboListFragment.this.editWeibo(view);
                    } else if (which == 2) {
                        TabWeiboListFragment.this.deleteWeibo(view.getPosition(), view.getData().getId());
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(getActivity().getFragmentManager(), "itemDialog");
        } else {
            ListDialog dialog = ListDialog.newInstance("", new String[]{"取消关注", "举报"});
            dialog.setnListener(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog1, int which) {
                    if (which == 0) {
                        TabWeiboListFragment.this.deleteFriend(view);
                    }
                    dialog1.dismiss();
                }
            });
            dialog.show(getActivity().getFragmentManager(), "itemDialog");
        }
    }

    private void editWeibo(WeiboListAdapter.TimeViewHolder view) {
        Intent intent = new Intent(getActivity(), EditWeiboActivity.class);
        intent.putExtra("weibo", view.getData());
        startActivityForResult(intent, REQUEST_EDIT);
    }

    private void deleteFriend(WeiboListAdapter.TimeViewHolder holder) {
        service.deleteFriend(holder.getData().getAuthor().getId(), new ToastCallback(getActivity()));
    }

    private void deleteWeibo(final int position, int tid) {
        service.deleteWeibo(tid,new ToastCallback(getActivity()){
            @Override
            public void success(ToastResponse toastResponse, Response response) {
                super.success(toastResponse, response);
                if(toastResponse.getStatus()==0){
                    adapter.delete(position);
                }
            }
        });
    }

    @Override
    public void onClickUserPhoto(WeiboListAdapter.TimeViewHolder view) {
//        Toast.makeText(getActivity(),"你点击了ID为："+uid+"的头像",Toast.LENGTH_SHORT).show();
        TargetUser author = view.getData().getAuthor();
        Intent intent = TargetUserHomeActivity.create(getActivity(), author);
        Pair<View, String> photo = Pair.create((View) view.mAvatar, "avatar");
        Pair<View, String> nickname = Pair.create((View) view.mNickname, "nickname");
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(), nickname, photo);
        ActivityCompat.startActivity(getActivity(), intent, options.toBundle());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }
}


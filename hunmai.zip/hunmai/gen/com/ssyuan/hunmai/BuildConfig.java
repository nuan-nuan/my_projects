/** Automatically generated file. DO NOT MODIFY */
package com.ssyuan.hunmai;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
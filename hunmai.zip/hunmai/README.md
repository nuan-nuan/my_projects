DragLayout
==========

* 使用support.v4包下的ViewDragHelper实现QQ5.0侧滑
测试能不能提交更新

##Screenshots
![image](https://github.com/BlueMor/DragLayout/blob/master/screenshots/123.gif)

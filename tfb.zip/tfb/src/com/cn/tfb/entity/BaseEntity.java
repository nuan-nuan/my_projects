package com.cn.tfb.entity;

import java.io.Serializable;

public class BaseEntity implements Serializable
{
	private static final long serialVersionUID = 3494481746382382614L;

}

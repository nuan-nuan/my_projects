
package com.cn.tfb.log;


/**
 * @author hzx
 * 2014��4��21��
 * @version V1.0
 */
public class LoggerConfig
{
	public static final boolean DEBUG = true;
}

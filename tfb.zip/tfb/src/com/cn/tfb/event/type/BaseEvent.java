package com.cn.tfb.event.type;

public class BaseEvent
{

}

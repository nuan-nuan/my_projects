package com.cn.tfb.json.parser;

public abstract class AbstractJSONParser
{

}

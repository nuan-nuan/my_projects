package com.cn.tfb.json.parser.deserializer;

public interface ParseProcess
{

}

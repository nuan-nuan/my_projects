package com.cn.tfb.json;

public interface JSONAware
{

	String toJSONString();
}

package com.cn.tfb.json.serializer;

public interface SerializeFilter
{

}

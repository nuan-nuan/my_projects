package com.cn.tfb.ui;

public class AccountActivity extends BaseActivity
{

}

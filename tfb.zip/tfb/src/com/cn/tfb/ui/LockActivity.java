package com.cn.tfb.ui;

public class LockActivity extends BaseActivity
{

}

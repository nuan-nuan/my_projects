package com.cn.tfb.volley;

@SuppressWarnings("serial")
public class TimeoutError extends VolleyError
{
}

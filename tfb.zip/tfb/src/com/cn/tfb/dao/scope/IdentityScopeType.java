package com.cn.tfb.dao.scope;

public enum IdentityScopeType
{
	Session, None
}

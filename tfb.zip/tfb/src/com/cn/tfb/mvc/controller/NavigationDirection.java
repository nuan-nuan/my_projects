
package com.cn.tfb.mvc.controller;


/**
 * @author hzx
 * 2014��4��21��
 * @version V1.0
 */
public enum NavigationDirection
{
	Forward, Backward
}
